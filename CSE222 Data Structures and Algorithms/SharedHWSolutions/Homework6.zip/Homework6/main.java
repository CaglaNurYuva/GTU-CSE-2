package Homework6;


public class main {

	public static void main(String[] args) { 
		// String str = "'Hush, hush!' whispered the rushing wind.";
		String str = "Buzzing bees buzz.";
		
		myMap newMapObj = new myMap();
		newMapObj.buildMap(str);
		System.out.println("Original String:\t" + str);
		System.out.println("Preprocessed String:\t" + newMapObj.str);
		MergeSort ms = new MergeSort(newMapObj);

		System.out.println("\n\nThe original (unsorted) map:");
		ms.printOriginalArray();

		System.out.println("\n\nThe sorted map:");
		ms.sort();
		ms.printSortedArray();
	}
}