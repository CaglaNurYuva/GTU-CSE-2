
/**
 * The Username class validates username string.
 *
 * @file Username.java
 * @author Çağla Nur Yuva
 * @brief Validates username.
 * @version 1.0
 * @date 2023-04-20
 */
public class Username {

    /**
     * Checks if a given username is valid.
     * @param username The username string to be checked for validity.
     * @return true if the username is valid, false otherwise.
     */
    private boolean checkIfValidUsername(final String username) {

        /* Base case */
        if (username == null || username.length() == 0) {
            System.out.println("The username is invalid. It should have at least 1 character.");
            return false;
        }

        /* Check if the first character of the username is a letter. */
        if (!this.isLetter(username.charAt(0))) {
            System.out.println("The username is invalid. It should have letters only.");
            return false;
        }

        /* Base case */
        if (username.length() == 1) { return true; }
          
        /* Removing the having been checked character from username and keep checking the other character. */
        return checkIfValidUsername(username.substring(1));
    }

    /**
     * Checks if a given character is a letter.
     * @param c The character to be checked.
     * @return true if the character is a letter, false otherwise.
     */
    private boolean isLetter(final char c) {
        return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
    }

    /**
     * Validates the username string.
     * @return true if the username is valid, false otherwise.
     */
    public boolean checkUsername(final String username) {
        return checkIfValidUsername(username);
    }

}

