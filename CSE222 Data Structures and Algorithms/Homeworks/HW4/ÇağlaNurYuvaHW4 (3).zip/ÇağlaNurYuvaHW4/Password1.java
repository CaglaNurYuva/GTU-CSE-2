import java.util.Stack;

/**
 * The Password1 class validates password1.
 *
 * @file Password1.java
 * @author Çağla Nur Yuva
 * @brief Validates password1.
 * @version 1.0
 * @date 2023-04-20
 */
public class Password1 {

    /**
     * Checks if the password contains at least one character from the username.
     * @param username  the username to be checked.
     * @param password1 The password to be checked.
     * @return true if the password contains at least one character from the username, false otherwise.      
     */
    private boolean containsUserNameSpirit(final String username, final String password1) {
        Stack<Character> stack = convertToStack(password1); /* Converting String keeping password1 to stack */

        /* Looking for a character that both is in password1 and username */
        while (!stack.isEmpty()) {
            char c = stack.pop();
            if (username.indexOf(c) != -1) { return true; }
        }
        System.out.println("The password1 is invalid. It should have at least 1 character from the username.");
        return false;
    }

    /**
     * Converts the password string to a stack of characters.
     * @param password1 The password in the form of String to be converted to stack.
     * @return Stack<Character> a stack of characters representing the password.
     */
    private Stack<Character> convertToStack(final String password1) {
        Stack<Character> stack = new Stack<>(); /* Creating a stack */

        /* Filling stack with characters of password1 */
        for (int i = 0; i < password1.length(); i++) {
            char c = password1.charAt(i);
            stack.push(c);
        }
        return stack;
    }

    /**
     * Checks if there is a corresponding closing bracket for each opening bracket.
     * @param password1 The password to be checked.
     * @return true if the password is balanced, false otherwise.
     */
    private boolean isBalancedPassword(final String password1) {
        Stack<Character> stack = new Stack<>(); /* Creating a stack */

        /* Iterating through password1 */
        for (int i = 0; i < password1.length(); i++) {
            char c = password1.charAt(i);

            /* Pushing opening brackets into stack to check later */
            if (c == '(' || c == '[' || c == '{') { stack.push(c); }

            else if (c == ')' || c == ']' || c == '}') {

                /* Checking if there is any correct opening bracket to match closed bracket */
                if (stack.isEmpty() || !isBalancedBrackets(stack.pop(), c)) {
                    System.out.println("The password1 is invalid. It should be balanced.");
                    return false;
                }
            }
        }

        /* Checking if there is any remaining unmatched bracket in stack */
        if (!stack.isEmpty()) {
            System.out.println("The password1 is invalid. It should be balanced.");
            return false;
        }

        return true;
    }

    /**
     * Checks if an opening bracket matches a closing bracket.
     * @param open the opening bracket to check.
     * @param close the closing bracket to check.
     * @return true if the opening and closing brackets match, false otherwise.
     */
    private boolean isBalancedBrackets(final char open, final char close) {

        /* Checking if open and close brackets are balanced */
        if (open == '(') return close == ')';
        if (open == '[') return close == ']'; 
        if (open == '{') return close == '}';
        return false;
    }

    /**
     * Checks if a character is a letter.
     * @param c the character to check
     * @return true if the character is a letter, false otherwise.
     */
    private boolean isLetter(final char c) {
        return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
    }

    /**
     * Checks if a palindrome can be formed from the password by calling helper method.
     * @param password1 The password to be checked.
     * @return true if a palindrome can be formed, false otherwise.
     */
    private boolean isPalindromePossible(final String password1) {

        /* Keeping odd/even frequency information of characters in password1. */
        boolean[] isOddFreq = new boolean[26];

        /* Removing brackets from password1 */
        String password = removeBrackets(password1);

        /* Keep record of odd/even frequency information of characters in password1. */
        for (int i = 0; i < password.length(); i++) {
            char c = password.charAt(i);
            isOddFreq[c - 'a'] = !isOddFreq[c - 'a'];
        }

        /* Call the recursive helper method to check if a palindrome can be formed. */
        if (!isPalindromePossibleHelper(isOddFreq, false)) {
            System.out.println("The password1 is invalid. It should be possible to obtain a palindrome from the password1.");
            return false;
        }
        return true;
    }

    /**
     * Recursively checks if a palindrome can be formed from the password.
     * @param isOddFreq array of boolean values to keep odd/even frequency information.
     * @param foundOddFreq keeps true if a char with odd frequency has been found so far, false otherwise.
     * @return true if a palindrome can be formed, false otherwise.
     */
    private boolean isPalindromePossibleHelper(final boolean[] isOddFreq, boolean foundOddFreq) {

       /**
        * The algorithm explanation: If there is more than one character that has odd
        * frequency in a string, that string cannot form a palindrome.
        * Therefore, this method checks if there is more than one character
        * that has odd frequency in password1.
        */

        /* Base case */
        if (isOddFreq.length == 0) { return true; }

        /* Checking the frequency of the first character */
        if (isOddFreq[0] == true) {
            if (foundOddFreq) { return false; } 
            else { foundOddFreq = true; }
        }

        /* Removing the first element of isOddFreq array since it has already been checked. */
        boolean[] restIsOddFreq = new boolean[isOddFreq.length - 1];
        copyArrayElements(isOddFreq, 1, restIsOddFreq, restIsOddFreq.length);

        /* Checking recursively the rest of the characters' frequencies */
        return isPalindromePossibleHelper(restIsOddFreq, foundOddFreq);
    }

    /**
     * Removes brackets from the password and returns the resulting string.
     * @param password1 The password to be removed from brackets.
     * @return String the password with brackets removed.
     */
    private String removeBrackets(String password1) {

        /* Iterating through password1 */
        for (int i = 0; i < password1.length(); i++) {

            /* Removing a bracket from password1 */
            if (isBracket(password1.charAt(i))) {
                String newString = password1.substring(0, i) + password1.substring(i + 1);
                password1 = newString;
                i--;
            }
        }
        return password1;
    }

    /**
     * Checks if a character is a bracket.
     * @param c the character to check.
     * @return true if the character is a bracket, false otherwise.
     */
    private boolean isBracket(final char c) {
        return (c == '(' || c == ')' || c == '[' || c == ']' || c == '{' || c == '}');
    }

    /**
     * Copies elements from an array to another.
     * @param source the source array to copy from.
     * @param start the starting index of the source array to copy from.
     * @param destination the destination array to copy to.
     * @param size the number of elements to copy.
     */
    private void copyArrayElements(final boolean[] source, final int start, final boolean[] destination, final int size) {
        for (int i = 0; i < size; i++) {
            destination[i] = source[i + start]; /* Copying elements from source to destination array */
        }
    }

    /**
     * Checks if the given password meets the limitations for a valid password.
     * @param password1 The password to be checked.
     * @return true if the password meets the limitations, false otherwise.
     */
    private boolean checkLimitations(final String password1) {

        int numOfBracket = 0;
        int numOfLetter = 0;

        /* Counting the number of brackets and letters while printing error message for the other characters */
        for (int i = 0; i < password1.length(); i++) {
            char c = password1.charAt(i);

            if (isBracket(c)) numOfBracket++;
            else if (isLetter(c)) numOfLetter++;

            else {
                System.out.println("The password1 is invalid. Only letter and brackets are allowed.");
                return false;
            }
        }

        /* Checking the number of letters */
        if (numOfLetter == 0) {
            System.out.println("The password1 is invalid. It should have letters too.");
            return false;
        }

        /* Checking the number of brackets */
        if (numOfBracket < 2) {
            System.out.println("The password1 is invalid. It should have at least 2 brackets.");
            return false;
        }

        /* Checking the length of password1 */
        if ((numOfLetter + numOfBracket) < 8) {
            System.out.println("The password1 is invalid. It should have at least 8 characters.");
            return false;
        }

        return true;
    }

    /**
     * Checks if the given password meets all the requirements for a valid password.
     * @param username  The username to be checked.
     * @param password1 The password to be checked.
     * @return true if the password meets all the requirements, false otherwise.
     */
    public boolean checkPassword1(final String username, final String password1) {

        /* Checking password1 if password1 meets all the requirements for a valid password. */ 
        if (checkLimitations(password1)) {
            if (containsUserNameSpirit(username, password1)) {
                if (isBalancedPassword(password1)) {
                    if (isPalindromePossible(password1)) return true;
                }
            }
        }
        return false;
    }

}

