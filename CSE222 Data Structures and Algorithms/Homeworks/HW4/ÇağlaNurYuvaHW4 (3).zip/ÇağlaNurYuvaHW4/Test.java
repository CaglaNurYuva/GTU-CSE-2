
/**
 * The Test class contains the main method and checkAll method to test 
 * the validation of a username and two passwords.
 *
 * @file Test.java
 * @author Çağla Nur Yuva
 * @brief Tests inputs' validness.
 * @version 1.0
 * @date 2023-04-20
 */
public class Test {

	/**
	 * The main method runs a series of tests to validate a username and two
	 * passwords.
	 * @param args An array of strings for command-line arguments.
	 */
	public static void main(String[] args) {

		/* Keeps test case number */
		int testNum = 1;
		 
		/* Checking inputs of Test1 */                                                                
		checkInputs("sibelgulmez", "[rac()ecar]", 74, new int[] { 4, 17, 29 }, testNum++);

		/* Checking inputs of Test2 */
		checkInputs("", "[rac()ecar]", 74, new int[] { 4, 17, 29 }, testNum++);

		/* Checking inputs of Test3 */ 
		checkInputs("sibel1", "[rac()ecar]", 74, new int[] { 4, 17, 29 }, testNum++);

		/* Checking inputs of Test4 */ 
		checkInputs("sibel", "pass[]", 74, new int[] { 4, 17, 29 }, testNum++);

		/* Checking inputs of Test5 */ 
		checkInputs("sibel", "abcdabcd", 74, new int[] { 4, 17, 29 }, testNum++);

		/* Checking inputs of Test6 */ 
		checkInputs("sibel", "[[[[]]]]", 74, new int[] { 4, 17, 29 }, testNum++);

		/* Checking inputs of Test7 */ 
		checkInputs("sibel", "[no](no)", 74, new int[] { 4, 17, 29 }, testNum++);

		/* Checking inputs of Test8 */ 
		checkInputs("sibel", "[rac()ecar]]", 74, new int[] { 4, 17, 29 }, testNum++);

		/* Checking inputs of Test9 */ 
		checkInputs("sibel", "[rac()ecars]", 74, new int[] { 4, 17, 29 }, testNum++);

		/* Checking inputs of Test10 */ 
		checkInputs("sibel", "[rac()ecar]", 5, new int[] { 4, 17, 29 }, testNum++);

		/* Checking inputs of Test11 */ 
		checkInputs("sibel", "[rac()ecar]", 35, new int[] { 4, 17, 29 }, testNum++);

		/* Checking inputs of Test12 */ 
		checkInputs(".cinnamon.", "[rac()ecar]", 35, new int[] { 4, 17, 29 }, testNum++);

		/* Checking inputs of Test13 */ 
		checkInputs("mehmet", "{[(abacaba)]}", 42, new int[] { 1, 5, 10 }, testNum++);

		/* Checking inputs of Test14 */ 
		checkInputs("william", "william123", 100, new int[] { 1, 5, 10 }, testNum++);

		/* Checking inputs of Test15 */ 
		checkInputs("ceviz", "{(aabbcc)dddee}", 100, new int[] { 1, 5, 10 }, testNum++);

		/* Checking inputs of Test16 */ 
		checkInputs("yellowBee", "{[a]b}c)de(f)", 25, new int[] { 3, 7, 11 }, testNum++);

		/* Checking inputs of Test17 */ 
		checkInputs("cat", "{[x]x}aaf(f)z", 777, new int[] { 7, 37, 73 }, testNum++);

		/* Checking inputs of Test18 */ 
		checkInputs("Water", "a[b{c}d[e]f]g", 11, new int[] { 3, 7, 11 }, testNum++);

		/* Checking inputs of Test19 */ 
		checkInputs("(1234.)", "(ca[<<]ca)", 11, new int[] { 3, 7, 11 }, testNum++);

		/* Checking inputs of Test20 */ 
		checkInputs("cinnamon", "{[aa][bb][cc][dd][ee][ff][ff]}", 2, new int[] { 4, 17, 29 }, testNum++);

		/* Checking inputs of Test21 */ 
		checkInputs("orange", "(ca[]ca)", 27, new int[] { 4, 17, 29 }, testNum++);

		/* Checking inputs of Test22 */ 
		checkInputs("cagla", "(<ca[**]ca>)", 74, new int[] { 4, 17, 29 }, testNum++);

		/* Checking inputs of Test23 */ 
		checkInputs("blue", "9", 74, new int[] { 4, 17, 29 }, testNum++);

		/* Checking inputs of Test24 */ 
		checkInputs("gizem", "{[{{([])}}]}", 74, new int[] { 4, 17, 29 }, testNum++);

		/* Checking inputs of Test25 */ 
		checkInputs("yusufsinan", "uaakkaakk", 100, new int[] { 1, 5, 10 }, testNum++);

		/* Checking inputs of Test26 */ 
		checkInputs("erkanzerger", "[lool]", 74, new int[] { 4, 17, 29 }, testNum++);

		/* Checking inputs of Test27 */ 
		checkInputs("gokhankaya", "kayykayy]", 74, new int[] { 4, 17, 29 }, testNum++);

		/* Checking inputs of Test28 */ 
		checkInputs("sametgul", "yakyak[]", 75, new int[] { 4, 17, 29 }, testNum++);
	}

	/**
	 * Checks if the username, password1 and password2 are valid.
	 * @param username The username to check.
	 * @param password1 The first password to check.
	 * @param password2 The second password to check.
	 * @param denominations An array of integers representing the list of denominations.                     
	 * @param testNum The number of the test being performed.
	 * @return True if the username, password1 and password2 are valid, false otherwise.        
	 */
	public static boolean checkInputs(final String username, final String password1, final int password2, final int[] denominations, final int testNum) {

		Username usernameObj = new Username();
	   	Password1 password1Obj = new Password1();
	   	Password2 password2Obj = new Password2();

		/* Printing current test information */
	   	System.out.println("Test " + testNum + "... Inputs:");
	   	System.out.println("username: '" + username + "' - password1: '" + password1 + "' - password2: '" + password2 + "'");
	   
	   	/* Validating username, password1 and password2 */
	   	if (usernameObj.checkUsername(username)) {
			if (password1Obj.checkPassword1(username, password1)) {
				if (password2Obj.checkPassword2(password2, denominations)) {
					System.out.println("The username and passwords are valid. The door is opening, please wait...");
					System.out.println("------------------------------------------------------ ");
					return true;
				}
			}
		}

	   	System.out.println("------------------------------------------------------ ");
	   	return false;
	}
}

