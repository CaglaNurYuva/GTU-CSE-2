
/**
 * The Password2 class validates password2.
 *
 * @file Password2.java
 * @author Çağla Nur Yuva
 * @brief Validates password2.
 * @version 1.0
 * @date 2023-04-20
 */
public class Password2 {

    /**
     * Checks if it is possible to obtain the password by the sum of some or all elements of the denominations array by calling helper method.
     * @param password2 The password to be checked.
     * @param denominations The array of denominations to be used for the check.
     * @return true if the password is obtained by the sum of some or all elements of the denominations array, false otherwise.     
     */
    private boolean isExactDivision(final int password2, final int[] denominations) {

        /* Checking denominations array */
        if (denominations == null || denominations.length == 0) { return false; } 

        /* Calling the recursive helper method */
        return isExactDivisionHelper(password2, denominations, 0, 0);
    }


    /**
     * Checks recursively if it is possible to obtain the password by the sum of some or all elements of the denominations array.
     * @param password2 The password to be checked.
     * @param denominations The array of denominations to be used for the check.
     * @param index The current index in the denominations array.
     * @param sum The current sum of elements obtained by using denominations array's elements.
     * @return true if the password is recursively obtained by the sum of some or all elements of the denominations array, false otherwise.      
     */
    private boolean isExactDivisionHelper(final int password2, final int[] denominations, final int index, final int sum) {

        /* Base case */
        if (sum == password2) { return true; }

        /* Base case */
        if (sum > password2 || index >= denominations.length) { return false; }

        /* Calling the method recursively to include the certain element of denominations array at the certain index. */
        if (isExactDivisionHelper(password2, denominations, index, sum + denominations[index])) { return true; }

        /* Calling the method recursively to skip the certain element of denominations array at the certain index. */
        if (isExactDivisionHelper(password2, denominations, index + 1, sum)) { return true; }

        /* password2 could not be obtained by using the two options above, therefore returns false. */
        return false;
    }

    /**
     * Checks if the password is valid.
     * @param password2 The password to be checked.
     * @param denominations The array of denominations to be used for the check.
     * @return true if the password is valid, false otherwise.
     */
    public boolean checkPassword2(final int password2, final int[] denominations) {

        /* Checks if password2 between 10 and 10000. */
        if (password2 < 10 || password2 > 10000) {
            System.out.println("The password2 is invalid. It should be between 10 and 10,000.");
            return false;
        }

        /* Checks if it is possible to obtain the password by the sum of some or all elements of the denominations array. */
        if (!isExactDivision(password2, denominations)) {
            System.out.println("The password2 is invalid. It is not compatible with the denominations.");
            return false;
        }
        return true;
    }

}



