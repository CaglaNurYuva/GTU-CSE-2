

/**
 * Account class to represent a social media account.
 *
 * @file     Account.java
 * @author   Çağla Nur Yuva
 * @brief    Function implementations needed for basic social media account
 * @version  1.0
 * @date     2023-04-05
 */
public class Account {

    /** The unique ID of the account. */
    private int accountID;

    /** The username of the account. */
    private String username;

    /** The birth date of the account.*/
    private String birthDate;

    /** The location of the account. */
    private String location;

    /** The array of posts shared by the account. */
    private Post[] posts;

    /** The array of accounts that the account is following. */
    private Account[] following;

    /** The array of accounts that are following the account. */
    private Account[] followers;

    /** The array of messages received by the account. */
    private Message[] inbox;

    /** The array of messages sent by the account. */
    private Message[] outbox;

    /** The array of account IDs that are blocked by the account. */
    private int[] blockedAccountsID;

    /** The account ID of the last account that this account visited his/her profile. */
    private int lastAccID_onProfile;

    /** The account ID of the last account that this account visited his/her posts. */
    private int lastAccID_onPost;

    /** Whether the account is currently logged in or not. */
    private boolean isLogin;  

    /** The length of all arrays */
    private int arraySize;

   
    /** 
     * Constructs a new Account object.
     * @param accountID The account ID.
     * @param username The username of the account.
     * @param birthDate The birth date of the account.
     * @param location The location of the account.
     */
    public Account(final int accountID, final String username, final String birthDate, final String location) { 

        /* Initializing the class variables with the given values. */
        this.arraySize = 100;
        this.accountID = accountID; 
        this.username = username;   
        this.birthDate = birthDate;
        this.location = location;
        this.posts = new Post[arraySize];
        this.following =  new Account[arraySize]; 
        this.followers = new Account[arraySize]; 
        this.inbox = new Message[arraySize];
        this.outbox = new Message[arraySize];
        this.blockedAccountsID = new int[arraySize];
        this.isLogin = false;
        this.lastAccID_onProfile = 0;
        this.lastAccID_onPost = 0;  

        /* Setting all array elements to default values, which is null or 0. */
        for(int i = 0; i < this.posts.length; i++) { this.posts[i] = null; }
        for(int i = 0; i < this.following.length; i++) { this.following[i] = null; }
        for(int i = 0; i < this.followers.length; i++) { this.followers[i] = null; }
        for(int i = 0; i < this.inbox.length; i++) { this.inbox[i] = null; }
        for(int i = 0; i < this.outbox.length; i++) { this.outbox[i] = null; }
        for(int i = 0; i < this.blockedAccountsID.length; i++) { this.blockedAccountsID[i] = 0; }

    } 


    /** 
     * Logs out from the account.
     */
    public void LogOut() {

        /* Checking if the account has already logged in. */ 
        if(!this.isLogin) {
            System.out.println("You are not logged in.");
            return;
        } 

        /* Logging out. */
        else {
            isLogin = false;
            this.lastAccID_onProfile = 0;
            this.lastAccID_onPost = 0;
        }  
    } 



    /** 
     * Adds a new post to the account's posts.
     * @param post The post to be added.
     */
    public void addPost(final Post post) { 

            
        /* Checking if the account is logged in. */
        if (!this.isLogin) {
            System.out.println("You need to log in to share a post.");
            return;
        }
      
        /* Checking if the post belongs to the account. */    
        if(this.accountID != post.getAccountID()) {
            System.out.println("You cannot share this post since it does not belong to you...");
            return;
        }


        /* Sharing a post */
        for(int i = 0; i < this.posts.length; i++) {
            if(this.posts[i] == null) {
                this.posts[i] = post;
                post.setPostShared();
                return;
            }

            /* Checking if the same post ID will be used again or not. */
            if(this.posts[i].getPostID() == post.getPostID()) {
                System.out.println("Adding post is failed. Post ID has already been used.");
                return;
            }
        }

        System.out.println("Posts array is full...");
    } 


    /** 
     * Returns the ID of the account.
     * @return int The account ID.
     */
    public int getAccountID() { return this.accountID; } 


    /** 
     * Returns the number of posts that the account has.
     * @return int The number of posts.
     */
    private int getPostsNum() {  

        /* Iterating through posts array */
        for(int i = 0; i < this.posts.length ; i++) { if(this.posts[i] == null) return i; } 
        return arraySize;
    }  


    /** 
     * Returns the array of posts of the account.
     * @return Post[] The array of posts of the account.
     */
    private Post[] getPosts() { return this.posts; }  


    /** 
     * Checks if current account blocked the account with the given accountID .
     * @param newAccountID The accountID of the account to be checked.
     * @return int the index of accountID in blockedAccountsID array, -1 if it does not exist.
     */
    public int isBlocked(final int newAccountID) {

        /* Iterating through blockedAccountsID array */
        for(int i = 0; i < this.blockedAccountsID.length; i++) { 
            if(this.blockedAccountsID[i] == 0) return -1; 
            else if(this.blockedAccountsID[i] == newAccountID) return i;
        }
        return -1;
    } 


    /** 
     * Checks if the account is following the account with the given accountID.
     * @param account The account to be checked.
     * @return int the index of account in following array, -1 if it does not exist.
     */
    public int isFollowing(final Account account) {

        /* Iterating through following array */
        for(int i = 0; i < this.following.length; i++) {
            if(this.following[i] == null) return -1; 
            else if(this.following[i].accountID == account.accountID) return i; 
        }
        return -1;
    } 


    /** 
     * Checks if the account is follower of the account with the given account.
     * @param account The account to be checked.
     * @return int the index of account in followers array, -1 if it does not exist.
     */
    public int isFollower(final Account account) {

        /* Iterating through followers array */
        for(int i = 0; i < this.followers.length; i++) {
            if(this.followers[i] == null) return -1; 
            else if(this.followers[i].accountID == account.accountID) return i; 
        }
        return -1;
    } 


    /** 
     * Returns the number of followers of the account.
     * @return int The number of followers of the account.
     */
    private int getFollowersNum() { 

        /* Iterating through posts array */
        for(int i = 0; i < this.followers.length ; i++) { if(this.followers[i] == null) return i; } 
        return arraySize;
    } 


    /** 
     * Returns the array of followers of the account.
     * @return Account[] The array of followers of the account.
     */
    private Account[] getFollowers() { return this.followers; } 

    /** 
     * Sets the follower at the specified index in the array of followers.
     * @param follower The follower to set.
     * @param index The index at which to set the follower.
     */
    private void setFollowers(final Account follower,final int index) { this.followers[index] = follower; } 

    /** 
     * Follows the specified account if necessary conditions are met.
     * @param account The account to follow.
     */
    public void Follow(final Account account) {

        /* Checking if the account is logged in or not. */
        if (!this.isLogin) { System.out.println("You need to log in to follow an account."); return; }

        /* Checking if the account tries to follow itself or not. */    
        if (account.accountID == this.accountID) { System.out.println("You cannot follow yourself."); return; }

        /* Checking if this account is blocked by the other account or not. */
        if (account.isBlocked(this.accountID) != -1) { 
            System.out.println("You cannot follow an account that blocked you."); 
            return; 
        }

        /* Checking if the other account is blocked by this account or not. */
        if (this.isBlocked(account.accountID) != -1) { 
            System.out.println("You cannot follow an account that you blocked."); 
            return; 
        }

        /* Checking if this account is following the other account or not. */
        if (this.isFollowing(account) != -1) { System.out.println("You are already following this account."); return; }

       
        /* Adding the other account to following array of this account. */
        for(int i = 0; i < this.following.length; i++) {
            if(this.following[i] == null) {
                this.following[i] = account;
                break;
            }
            
            else if((i + 1) == this.following.length) {
            	System.out.println("Following array is full...");
            	return;
            }
        }

        /* Adding this account to followers array of the other account. */
        for(int i = 0; i < account.followers.length; i++) {
            if(account.getFollowers()[i] == null) {
                account.setFollowers(this, i);
                break;
            }
            
            else if((i + 1) == account.followers.length) {
            	System.out.println("Followers array is full...");
            	return;
            }
        }
    }  


    /** 
     * Returns the username of the account with the specified accountID from the array of accounts.
     * @param AccountID The account ID of the account to get the username of.
     * @param accounts The array of accounts to search in.
     * @return String The username of the account with the specified accountID.
     */
    private String getUsername(final int AccountID, final Account[] accounts) {
      
        /* Iterating through accounts array */
        for(int i = 0; i < accounts.length; i++) { 
            if(accounts[i] == null) { break; }
            else if(accounts[i].accountID == AccountID) return accounts[i].username; 
        }

        System.out.println("There is no such account...");
        return accounts[0].username;
    } 
    

    /** 
     * Returns the number of accounts that the user is following.
     * @return int representing the number of accounts being followed.
     */
    private int getFollowingNum() { 
        
        /* Iterating through posts array */
        for(int i = 0; i < this.following.length ; i++) { if(this.following[i] == null) return i; } 
        return arraySize;
    } 


    /** 
     * {@inheritDoc}
     * Returns a string representation of the user's profile.
     * @return String Represents user profile information.
     */
    @Override
    public String toString() {

        /* Adding account information to string. */
        String str = "-------------------------" + "\n";
        str += "User ID: " + this.accountID + "\n";
        str += "Username: " + this.username + "\n";
        str += "Location: " + this.location + "\n";
        str += "Birth Date: " + this.birthDate + "\n"; 
        str += this.username + " is following " + this.getFollowingNum()  + " account(s) and has " + this.getFollowersNum() + " followers(s).\n";

        /* Handling the case in which the account has follower. */
        if(this.getFollowersNum() != 0) {
            str += "The followers of " + this.username + " are: ";
            for(int i = 0; i < this.getFollowersNum(); i++) { str += this.followers[i].username + ", "; }
            str += "\n";
        }

         /* Handling the case in which the account has following. */
        if(this.getFollowingNum() != 0) {
            str += this.username + " is following: " ;
            for(int i = 0; i < this.getFollowingNum(); i++) { str += this.following[i].username + ", "; }
            str += '\n';
        }
      
        str +=  this.username + " has " +  this.getPostsNum()  + " posts.";
        return str;  /* Returning string representing account information */
    } 


    /** 
     * Displays the profile information for a given account, if necessary conditions are met.
     * @param account The account whose profile will be displayed.
     */
    public void viewProfile(final Account account) { 

        /* Checking if the account is logged in or not. */
        if(!this.isLogin) {
            System.out.println("You need to log in to view the profile.");
            return;
        }
  
        /* Checking if this account is blocked by the other account or not. */
        if(account.isBlocked(this.accountID) != -1) {  
            System.out.println("You cannot view profile of an account that blocked you.");
            return;
        }

        /* Checking if the other account is blocked by this account or not. */
        if(this.isBlocked(account.accountID) != -1) {  
            System.out.println("You cannot view profile of an account that you blocked.");
            return;
        }

      
        System.out.println(account.toString());  /* Viewing profile */

        /* Tracking The account ID of the last account that this account visited his/her profile. */
        this.lastAccID_onProfile = account.accountID;
        this.lastAccID_onPost = 0;
    }  

  
    /** 
     * Displays the posts for a given account, if necessary conditions are met.
     * @param account The account whose posts will be displayed.
     */
    public void viewPosts(final Account account) { 

        /* Checking if the account is logged in or not. */
        if(!this.isLogin) { System.out.println("You need to log in to view posts."); return; }

        /* Checking if this account is blocked by the other account or not. */
        if(account.isBlocked(this.accountID) != -1) {  
            System.out.println("You cannot view posts of an account that blocked you.");
            return;
        }

        /* Checking if the other account is blocked by this account or not. */
        if (this.isBlocked(account.accountID) != -1) {  
            System.out.println("You cannot view posts of an account that you blocked.");
            return;
        }

        /* Checking if the other account's profile has already been viewed or not. */
        if(this.lastAccID_onProfile != account.accountID) {
            System.out.println("You have to view profile before viewing posts.");
            return;
        }

        /* Viewing posts */
        if(account.getPostsNum() == 0) { System.out.println("There is no post that is shared..."); }

        else {
            System.out.println("\n--- Posts ---");	
            for(int i = 0; i < account.getPostsNum(); i++) {
                System.out.println(account.posts[i].getPostInfo(account.username)); 
            }
        }

        /* Tracking The account ID of the last account that this account visited his/her posts. */ 
        this.lastAccID_onPost = account.accountID;
    } 


    /** 
     * Logs in the user with the given username, if necessary conditions are met.
     * @param username The username to log in with.
     * @param accounts An array of all accounts in the social media software.
     */
    public void LogIn(final String username, final Account[] accounts) {

        /* Checking if the account has already logged in.*/
        if(this.isLogin == true) { System.out.println("You have already been logged in."); return; }

        /* Checking if there is any other account that has already logged in. */
        for(int i = 0; accounts[i] != null; i++) {
            if(accounts[i].isLogin == true) {
                System.out.println("Another account whose username is " + getUsername(accounts[i].accountID,accounts) + " has already been logged in. You cannot login more than one account at the same time.");
                return;
            }
        }  
  
        /* Logging in if the username is correct. */
        if(username == this.username) {
            this.isLogin = true;
            this.lastAccID_onProfile = 0;
            this.lastAccID_onPost = 0;
        }
        else System.out.println("Login is failed. Wrong username has been entered.");
    }  


    /** 
     * Adds a like to a given post, if necessary conditions are met.
     * @param newLike The like object to add.
     * @param interactedPost The post to add the like to.
     * @param account the account that shared the post.
     */
    public void addLike(final Like newLike, final Post interactedPost, final Account account) {

        /* Checking if the account is logged in or not. */
        if (!this.isLogin) { System.out.println("You need to log in to like a post."); return; }
      
        /* Checking if like and post objects are associated with each other or not. */
        if(newLike.getPostID() != interactedPost.getPostID()) { 
            System.out.println("This like is not associated with this post.");
            return;
        }

        /* Checking if like and account objects are associated with each other. */
        if(newLike.getAccountID() != this.accountID) { 
            System.out.println("This like is not associated with your account.");
            return;
        }

        /* Checking if the account that shared the post is indicated correctly */
        if(account.accountID != interactedPost.getAccountID()) { 
            System.out.println("The owner of the post is indicated incorrectly, owner is not " + account.username); 
            return;
        }
      
        /* Checking if the post is shared or not. */
        if(!interactedPost.isPostShared()) { 
            System.out.println("You cannot like a post that has not been shared yet.");
            return;
        }

        /* Checking if this account is blocked by the other account or not. */
        if(account.isBlocked(this.getAccountID()) != -1) {  
            System.out.println("You cannot like a post of an account that blocked you."); 
            return;
        }

        /* Checking if the other account is blocked by this account or not. */
        if(this.isBlocked(account.getAccountID()) != -1) {  
            System.out.println("You cannot like a post of an account that you blocked."); 
            return;
        }


        /* Checking if the other account's profile has already been viewed or not. */
        if(this.lastAccID_onProfile != interactedPost.getAccountID()) { 
            System.out.println("You need to view profile before liking a post.");
            return;
        }
      
        /* Checking if the other account's posts has already been viewed or not. */
        if(this.lastAccID_onPost != interactedPost.getAccountID()) { 
            System.out.println("You need to view posts before liking a post.");
            return;
        }

       
        int i = 0;
        for(i = 0; i < interactedPost.getLikesNum(); i++) {
     
            /* Checking if the same like object is being used or not. */
            if(interactedPost.getLikes()[i].getInteractionID() == newLike.getInteractionID()) {
                System.out.println("You cannot use the same like object again to like a post.");
                return;
            }

            /* Handling the case in which the account has already liked the post. */ 
            if(interactedPost.getLikes()[i].getAccountID() == newLike.getAccountID()) { 
                if(interactedPost.getLikes()[i].getPostID() == newLike.getPostID()) {
                    System.out.println("Error: " + this.username + " has already liked this post.");
                    return;
                }
            }
        }

        /* Adding a like */
        if(i < arraySize) interactedPost.setLikes(newLike,i);
        else  System.out.println("Error: Maximum number of likes reached.");
    } 


    /** 
     * Adds a comment to a post.
     * @param newComment The comment to add.
     * @param interactedPost The post to interact with.
     * @param account the account that shared the post.
     */
    public void addComment(final Comment newComment, final Post interactedPost, final Account account) {

        /* Checking if the account is logged in or not. */
        if (!this.isLogin) { System.out.println("You need to log in to comment a post."); return; }

        /* Checking if comment and post objects are associated with each other or not. */
        if(newComment.getPostID() != interactedPost.getPostID()) { 
            System.out.println("This comment is not associated with this post.");
            return;
        }

        /* Checking if comment and account objects are associated with each other. */
        if(newComment.getAccountID() != this.accountID) { 
            System.out.println("This comment is not associated with your account.");
            return;
        }

        /* Checking if the account that shared the post is indicated correctly */
        if(account.accountID != interactedPost.getAccountID()) { 
            System.out.println("The owner of the post is indicated incorrectly, owner is not " + account.username); 
            return;
        }

        /* Checking if the post is shared or not. */
        if(!interactedPost.isPostShared()) { 
            System.out.println("You cannot add a comment to a post that has not been shared yet.");
            return;
        }

        /* Checking if this account is blocked by the other account or not. */
        if(account.isBlocked(this.getAccountID()) != -1) {  
            System.out.println("You cannot add a comment to a post of an account that blocked you."); 
            return;
        }

        /* Checking if the other account is blocked by this account or not. */
        if(this.isBlocked(account.getAccountID()) != -1) {  
            System.out.println("You cannot add a comment to a post of an account that you blocked."); 
            return;
        }

        /* Checking if the other account's profile has already been viewed or not. */
        if(this.lastAccID_onProfile != interactedPost.getAccountID()) {
            System.out.println("You need to view profile before commenting a post.");
            return;
        }
      
        /* Checking if the other account's posts has already been viewed or not. */
        if(this.lastAccID_onPost != interactedPost.getAccountID()) {
            System.out.println("You need to view posts before commenting a post.");
            return;
        }

    
        int i = 0;
        /* Checking if the same comment object is being used or not. */
        for(i = 0; i < interactedPost.getCommentsNum(); i++) {
            if(interactedPost.getComments()[i].getInteractionID() == newComment.getInteractionID()) {
                System.out.println("You cannot use the same comment object again to add a comment to a post.");
                return;
            }
        }
      
        /* Adding a comment */
        if(i < arraySize) interactedPost.setComments(newComment,i);
        else  System.out.println("Error: Maximum number of comments reached.");
    } 


    /** 
     * Views interactions for a given account, including post's likes and comments.
     * @param account The account to view interactions for.
     * @param accounts An array of all accounts in the social media software.
     */
    public void viewInteractions(final Account account, final Account[] accounts) {

        /* Checking if the account is logged in or not. */
        if (!this.isLogin) { System.out.println("You need to log in to view interactions."); return; }

        /* Checking if this account is blocked by the other account or not. */
        if(account.isBlocked(this.accountID) != -1) {
            System.out.println("You cannot view an account's interactions that blocked you.");
            return;
        }

        /* Checking if the other account is blocked by this account or not. */
        if(this.isBlocked(account.accountID) != -1) {
            System.out.println("You cannot view an account's interactions that you blocked.");
            return;
        }

        if(account.getPostsNum() == 0) { System.out.println("There is no post to view interactions of..."); return; }
        
        /* Viewing interactions of all posts one by one. */
        for(int i = 0; i < account.getPostsNum(); i++) {   
            System.out.println("----------------------");
            System.out.println("(PostID: " + account.posts[i].getPostID() + "): " + account.posts[i].getPostContent());
            int numOfLikes = account.posts[i].getLikesNum();

            if(numOfLikes == 0) { System.out.println("The post has no likes."); }
                
            else {
                System.out.print("The post was liked by the following account(s): ");
                for(int j = 0; j < numOfLikes; j++) {  /* Viewing likes. */
                    System.out.print(getUsername(account.posts[i].getLikes()[j].getAccountID(), accounts) + ", "); 
                }
                System.out.println();
            }
          
            int numOfComments = account.posts[i].getCommentsNum();
            if(numOfComments == 0) { System.out.println("The post has no comments."); }
                
            else {
                System.out.println("The post has " + numOfComments + " comment(s)...");  /* Viewing the number of comments. */
                for(int j = 0; j < numOfComments; j++) {  /* Viewing comments. */
                    System.out.println("Comment " + (j+1) + ": '" + account.getUsername(account.posts[i].getComments()[j].getAccountID(), accounts)+ "' said '" + account.posts[i].getComments()[j].getContent() + "'");
                }
            }
              
            System.out.println();
        }   
    }  


    /** 
     * Adds a message to the account's outbox.
     * @param message The message to add to the outbox.
     */
    public void addMessageToOutbox(final Message message) {

        /* Checking if the account is logged in. */
        if (!this.isLogin) { System.out.println("You need to log in to send a message."); return; }

        /* Adding a message to outbox */
        for(int i = 0; i < this.outbox.length; i++) {
            if(this.outbox[i] == null) {
                this.outbox[i] = message;
                return;
            }
        }

        System.out.println("Outbox is full...");
    }  


    /** 
      * Adds a message to the account's inbox.
      * @param message The message to add to the inbox.
      */ 
    public void addMessageToInbox(final Message message) {

        /* Adding a message to inbox */
        for(int i = 0; i < this.inbox.length; i++) {
            if(this.inbox[i] == null) {
                this.inbox[i] = message;
                return;
            }
        }

        System.out.println("Inbox is full...");
    } 


    /** 
     * Prints the number of messages in the outbox, if necessary conditions are met.
     */ 
    public void CheckOutbox() {

        /* Checking if the account is logged in. */
        if (!this.isLogin) { System.out.println("You need to log in to check outbox."); return; }

       
        /* Checking outbox */
        for(int i = 0; i < this.outbox.length ; i++) { 
            if(this.outbox[i] == null) {
                System.out.println("There is/are " + i + " message(s) in the outbox.");
                return;
            }
        } 
        
        System.out.println("There is/are " + arraySize + " message(s) in the outbox.");
    } 


    /** 
     * Prints the number of messages in the inbox, if necessary conditions are met.
     */ 
    public void CheckInbox() {

        /* Checking if the account is logged in. */
        if (!this.isLogin) { System.out.println("You need to log in to check inbox."); return; }

        /* Checking inbox */
        for(int i = 0; i < this.inbox.length ; i++) { 
            if(this.inbox[i] == null) {
                System.out.println("There is/are " + i + " message(s) in the inbox.");
                return;
            }
        } 
        
        System.out.println("There is/are " + arraySize + " message(s) in the inbox.");
    }  


    /** 
     * Views messages in the inbox, if necessary conditions are met.
     * @param accounts An array of all accounts in the social media software.
     */ 
    public void viewInbox(final Account[] accounts) {

        /* Checking if the account is logged in. */
        if (!this.isLogin) { System.out.println("You need to log in to view inbox."); return; }

        /* Viewing inbox. */ 
        for(int i = 0; i < this.inbox.length; i++) {
            if(this.inbox[i] != null) {
          
                System.out.println("--------------------------");
                System.out.println("Message ID: " + this.inbox[i].getMessageID());
                System.out.println("From: " + this.getUsername(this.inbox[i].getSenderID(), accounts));
                System.out.println("To: " + this.getUsername(this.inbox[i].getReceiverID(), accounts));
                System.out.println("Message: " + this.inbox[i].getContent());
            }

            else {
                if(i == 0) System.out.println("Inbox is empty.");
                break;
            }
        }
    }  


    /** 
     * Views messages in the outbox, if necessary conditions are met.
     * @param accounts An array of all accounts in the social media software.
     */ 
    public void viewOutbox(final Account[] accounts) {

        /* Checking if the account is logged in. */
        if (!this.isLogin) { System.out.println("You need to log in to view outbox."); return; }

        /* Viewing outbox. */ 
        for(int i = 0; i < this.outbox.length; i++) {
            if(this.outbox[i] != null) {
              
                System.out.println("--------------------------");
                System.out.println("Message ID: " + this.outbox[i].getMessageID());
                System.out.println("From: " + this.getUsername(this.outbox[i].getSenderID(), accounts));
                System.out.println("To: " + this.getUsername(this.outbox[i].getReceiverID(), accounts));
                System.out.println("Message: " + this.outbox[i].getContent());
            }

            else {
                if(i == 0) System.out.println("Outbox is empty.");
                break;
            }
        }
    }  
  

    /** 
     * Blocks the specified account and adds its account ID to the array of blocked account IDs.
     * @param accountBlocked The account to be blocked
     */ 
    public void BlockAccount(final Account accountBlocked) {

        /* Checking if the account is logged in. */
        if(!this.isLogin) { System.out.println("You need to log in to block an account."); return; }
      
        /* Checking if the account tries to block itself */
        if(accountBlocked.accountID == this.accountID) { System.out.println("You cannot block yourself."); return; }

        /* Checking if the other account is blocked by this account or not. */
        if(this.isBlocked(accountBlocked.accountID) != -1) {
            System.out.println("You have already blocked this account.");
            return;
        }
    
        /* Removing the blocked account from the following array and this account from the followers array */
        if(this.isFollowing(accountBlocked) != -1) { this.unFollow(accountBlocked); }

      
        for(int i = 0; i < this.blockedAccountsID.length; i++) {
            if(this.blockedAccountsID[i] == 0) {
                this.blockedAccountsID[i] = accountBlocked.accountID; /* Blocking the account */

                /* Resetting the record of viewing profile */
                if(this.lastAccID_onProfile == accountBlocked.accountID) { this.lastAccID_onProfile = 0; } 

                /* Resetting the record of viewing posts */
                if(this.lastAccID_onPost == accountBlocked.accountID) { 
                    this.lastAccID_onProfile = 0; 
                    this.lastAccID_onPost = 0;
                } 
                return;
            }
        } 

        System.out.println("blockedAccountsID is full...");
    } 

    /** 
     * Returns login information.
     * @return true if the account is logged in.
     */		
    public boolean getIsLogin() { return isLogin; }


    /** 
     * Unfollows the specified account.
     * @param account The account to be unfollowed.
     */	
    public void unFollow(final Account account) {

        /* Checking if the account is logged in. */
        if(!this.isLogin) { System.out.println("You need to log in to unfollow an account."); return; }

        /* Checking if the account tries to unfollow itself or not */
        if(account.accountID == this.accountID) { System.out.println("You cannot unfollow yourself."); return; }

        /* Checking if this account is blocked by the other account or not. */
        if (account.isBlocked(this.accountID) != -1) { 
            System.out.println("You cannot unfollow the account that blocked you.");
            return;
        }

        /* Checking if the other account is blocked by this account or not. */
        if (this.isBlocked(account.accountID) != -1) { 
            System.out.println("You cannot unfollow the account that you blocked.");
            return;
        }

        /* Checking if this account is following the other account. */
        int index = this.isFollowing(account);

       
        
        if(index != -1) {
            this.following[index] = null; /* Unfollowing the other account. */
            for(int i = index; this.following[i] != null; i++) { this.following[i] = this.following[i + 1]; }

            int num = account.isFollower(this);
            account.followers[num] = null; /* Removing this account from followers list of the other account */
            for(int i = num; account.followers[i] != null; i++) { account.followers[i] = account.followers[i + 1]; }
        }

        else System.out.println("You have to follow the account before unfollow the account.");
    } 
  
}
