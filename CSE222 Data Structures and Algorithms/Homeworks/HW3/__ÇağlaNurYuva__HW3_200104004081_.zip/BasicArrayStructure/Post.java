

/**
 * Post class to represent a social media post.
 *
 * @file     Post.java
 * @author   Çağla Nur Yuva
 * @brief    Function implementations related to social media posts 
 * @version  1.0
 * @date     2023-04-05
 */
public class Post {

    /** The unique ID of the post. */
    private int postID;

    /** The unique ID of the account that created the post. */
    private int accountID;

    /** Keeps all likes of the post. */
    private Like[] likes;

    /** Keeps all comments of the post. */
    private Comment[] comments;

    /** The text content of the post. */
    private String content;

    /** Keeps the information if the post is shared or not */
    private boolean isShared;


    /**
     * Constructs a new Post object.
     * @param postID The unique ID of the post.
     * @param accountID The unique ID of the account that created the post.
     * @param content Text content of the post.
     */
    public Post(final int postID, final int accountID, final String content) {

        /* Initializing the class variables with the given values. */
        this.postID = postID;
        this.accountID = accountID;
        this.likes = new Like[100];
        this.comments = new Comment[100];
        this.content = content;
        this.isShared = false;

        /* Setting all array elements to default values, which is null. */
        for(int i = 0; i < this.likes.length; i++) { this.likes[i] = null; }
        for(int i = 0; i < this.comments.length; i++) { this.comments[i] = null; }
    }  


    /**
     * Returns the post ID of the post.
     * @return int The post ID of the post.
     */
    public int getPostID() { return this.postID; } 
  

    /**
     * Returns a string representation of the post.
     * @param username The username of the account associated with the post.
     * @return String a string representing the post.
     */
    public String getPostInfo(final String username) { return "(PostID: " + postID + ") " + username + ": " + content; } 


    /**
     * Returns an array of Like objects representing all likes added on the post.
     * @return Like[] an array of Like objects representing all likes added on the post.
     */
    public Like[] getLikes() { return this.likes; } 

    /**
     * Sets the Like object at the specified index in the likes array.
     * @param newLike The Like object to be set at the specified index.
     * @param index The index to set the Like object at.
     */
    public void setLikes(final Like newLike, final int index) { this.likes[index] = newLike; } 


    /**
     * Sets the Like object at the specified index in the likes array.
     * @param newLike The Like object to be set at the specified index.
     * @param index The index to set the Like object at.
     */
    public void setComments(final Comment newComment, final int index) { this.comments[index] = newComment; } 


    /**
     * Returns the number of likes on this post.
     * @return int The number of likes added on the post.
     */
    public int getLikesNum() { 

        int i = 0;
        for(i = 0; this.likes[i] != null; i++) { /* empty */ }  /* Iterating through likes array */
        return i;
    } 


    /**
     * Returns the number of comments added on the post.
     * @return int The number of comments added on the post.
     */
    public int getCommentsNum() { 

        int i = 0;
        for(i = 0; this.comments[i] != null; i++) { /* empty */ }  /* Iterating through comments array */
        return i;
    } 

    
    /**
     * Returns the text content of the post.
     * @return String The text content of the post.
     */
    public String getPostContent() { return this.content; } 


    /**
     * Returns an array of Comment objects representing all comments on the post.
     * @return Comment[] An array of Comment objects representing all comments on the post.
     */
    public Comment[] getComments() { return this.comments; } 

    /**
     * Returns the account ID associated with the post.
     * @return int The account ID associated with the post.
     */
    public int getAccountID() { return accountID; } 

    
    /**
     * Returns the information if the post is shared or not.
     * @return true if the post is shared, false otherwise.
     */
    public boolean isPostShared() { return isShared; } 


    /**
     * Sets isShared variable as true.
     */
    public void setPostShared() { this.isShared = true; } 
    
}

