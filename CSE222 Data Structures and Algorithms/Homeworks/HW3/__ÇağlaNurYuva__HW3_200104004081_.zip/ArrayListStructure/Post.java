
import java.util.ArrayList;

/**
 * Post class to represent a social media post.
 *
 * @file     Post.java
 * @author   Çağla Nur Yuva
 * @brief    Function implementations related to social media posts 
 * @version  1.0
 * @date     2023-04-05
 */
public class Post {

    /** The unique ID of the post. */
    private int postID;

    /** The unique ID of the account that created the post. */
    private int accountID;

    /** Keeps all likes of the post. */
    private ArrayList<Like> likes;

    /** Keeps all comments of the post. */
    private ArrayList<Comment> comments;

    /** The text content of the post. */
    private String content;

    /** Keeps the information if the post is shared or not */
    private boolean isShared;


    /**
     * Constructs a new Post object.
     * @param postID The unique ID of the post.
     * @param accountID The unique ID of the account that created the post.
     * @param content Text content of the post.
     */
    public Post(final int postID, final int accountID, final String content) {

        /* Initializing the class variables with the given values. */
        this.postID = postID;
        this.accountID = accountID;
        this.likes = new ArrayList<Like>(); 
        this.comments = new ArrayList<Comment>();
        this.content = content;
        this.isShared = false;
    }  


    /**
     * Returns the post ID of the post.
     * @return int The post ID of the post.
     */
    public int getPostID() { return this.postID; } 
  

    /**
     * Returns a string representation of the post.
     * @param username The username of the account associated with the post.
     * @return String a string representing the post.
     */
    public String getPostInfo(final String username) { return "(PostID: " + postID + ") " + username + ": " + content; } 


    /**
     * Returns an array of Like objects representing all likes added on the post.
     * @return ArrayList<Like> an array of Like objects representing all likes added on the post.
     */
    public ArrayList<Like> getLikes() { return this.likes; } 


    /**
     * Returns the number of likes on this post.
     * @return int The number of likes added on the post.
     */
    public int getLikesNum() { return this.likes.size(); } 


    /**
     * Returns the number of comments added on the post.
     * @return int The number of comments added on the post.
     */
    public int getCommentsNum() { return this.comments.size(); } 

    
    /**
     * Returns the text content of the post.
     * @return String The text content of the post.
     */
    public String getPostContent() { return this.content; } 


    /**
     * Returns an array of Comment objects representing all comments on the post.
     * @return ArrayList<Comment> An array of Comment objects representing all comments on the post.
     */
    public ArrayList<Comment> getComments() { return this.comments; } 

    /**
     * Returns the account ID associated with the post.
     * @return int The account ID associated with the post.
     */
    public int getAccountID() { return accountID; } 

    
    /**
     * Returns the information if the post is shared or not.
     * @return true if the post is shared, false otherwise.
     */
    public boolean isPostShared() { return isShared; } 


    /**
     * Sets isShared variable as true.
     */
    public void setPostShared() { this.isShared = true; } 


    /** 
     * Checks if the like object is is in likes array or not.
     * @param like The like object to be checked.
     * @return int the index of like object in likes array, -1 if it does not exist.
     */
    public int isLiked(final Like like) {

        /* Iterating through likes array */
        for(int i = 0; i < this.likes.size(); i++) { 
            if(this.likes.get(i).getInteractionID() == like.getInteractionID()) return i;
        }
        return -1;
    } 


    /** 
     * Checks if the comment object is is in likes array or not.
     * @param like The comment object to be checked.
     * @return int the index of like object in comments array, -1 if it does not exist.
     */
    public int isCommented(final Comment comment) {

        /* Iterating through comments array */
        for(int i = 0; i < this.comments.size(); i++) { 
            if(this.comments.get(i).getInteractionID() == comment.getInteractionID()) return i;
        }
        return -1;
    } 
    
}

