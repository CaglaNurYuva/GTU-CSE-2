
import java.util.ArrayList;

/**
 * Account class to represent a social media account.
 *
 * @file     Account.java
 * @author   Çağla Nur Yuva
 * @brief    Function implementations needed for basic social media account
 * @version  1.0
 * @date     2023-04-05
 */
public class Account {

    /** The unique ID of the account. */
    private int accountID;

    /** The username of the account. */
    private String username;

    /** The birth date of the account.*/
    private String birthDate;

    /** The location of the account. */
    private String location;

    /** The array of posts shared by the account. */
    private ArrayList<Post> posts;

    /** The array of accounts that the account is following. */
    private ArrayList<Account> following;

    /** The array of accounts that are following the account. */
    private ArrayList<Account> followers;

    /** The array of messages received by the account. */
    private ArrayList<Message> inbox;

    /** The array of messages sent by the account. */
    private ArrayList<Message> outbox;

    /** The array of account IDs that are blocked by the account. */
    private ArrayList<Integer> blockedAccountsID;

    /** The array of strings that are keeping the action history of the account */    
    private ArrayList<String> actionHistory;

    /** The account ID of the last account that this account visited his/her profile. */
    private int lastAccID_onProfile;

    /** The account ID of the last account that this account visited his/her posts. */
    private int lastAccID_onPost;

    /** Whether the account is currently logged in or not. */
    private boolean isLogin;  

   
    /** 
     * Constructs a new Account object.
     * @param accountID The account ID.
     * @param username The username of the account.
     * @param birthDate The birth date of the account.
     * @param location The location of the account.
     */
    public Account(final int accountID, final String username, final String birthDate, final String location) { 

        /* Initializing the class variables with the given values. */
        this.accountID = accountID; 
        this.username = username;   
        this.birthDate = birthDate;
        this.location = location;
        this.posts = new ArrayList<Post>(); 
        this.following = new ArrayList<Account>(); 
        this.followers = new ArrayList<Account>(); 
        this.inbox = new ArrayList<Message>(); 
        this.outbox = new ArrayList<Message>(); 
        this.blockedAccountsID = new ArrayList<Integer>(); 
        this.actionHistory = new ArrayList<String>();
        this.isLogin = false;
        this.lastAccID_onProfile = 0;
        this.lastAccID_onPost = 0;  
    } 


    /** 
     * Logs out from the account.
     */
    public void LogOut() {

        /* Checking if the account has already logged in. */ 
        if(!this.isLogin) {
            System.out.println("You are not logged in.");
            return;
        } 

        /* Logging out. */
        else {
            isLogin = false;
            this.lastAccID_onProfile = 0;
            this.lastAccID_onPost = 0;
        }  

        this.actionHistory.add("- You logged out");  /* Keeping record of the action */
    } 


    /** 
     * Adds a new post to the account's posts.
     * @param post The post to be added.
     */
    public void addPost(final Post post) { 

        /* Checking if the account is logged in. */
        if(!this.isLogin) {
            System.out.println("You need to log in to share a post.");
            return;
        }

        /* Checking if the post belongs to the account. */    
        if(this.accountID != post.getAccountID()) {
            System.out.println("You cannot share this post since it does not belong to you...");
            return;
        }
      
        /* Checking if the same post ID will be used again or not. */
        for(int i = 0; i < this.posts.size(); i++) {
            if(this.posts.get(i).getPostID() == post.getPostID()) {
                System.out.println("Adding post is failed. Post ID has already been used.");
                return;
            }
        }
        posts.add(post);  /* Sharing the post */
        post.setPostShared();  /* Setting the post as shared */
        this.actionHistory.add("- You added a post whose ID is " + post.getPostID() + "."); /* Keeping record of the action */
    } 


    /** 
     * Returns the ID of the account.
     * @return int The account ID.
     */
    public int getAccountID() { return this.accountID; } 


    /** 
     * Returns the number of posts that the account has.
     * @return int The number of posts.
     */
    private int getPostsNum() { return this.posts.size(); }  


    /** 
     * Returns the array of posts of the account.
     * @return ArrayList<Post> The array of posts of the account.
     */
    private ArrayList<Post> getPosts() { return this.posts; }  


    /** 
     * Checks if current account blocked the account with the given accountID .
     * @param newAccountID The accountID of the account to be checked.
     * @return int the index of accountID in blockedAccountsID array, -1 if it does not exist.
     */
    public int isBlocked(final int newAccountID) {

        /* Iterating through blockedAccountsID array */
        for(int i = 0; i < this.blockedAccountsID.size(); i++) {
            if(this.blockedAccountsID.get(i) == newAccountID)  return i; 
        }
        return -1;
    } 


    /** 
     * Checks if the account is following the account with the given accountID.
     * @param account The account to be checked.
     * @return int the index of account in following array, -1 if it does not exist.
     */
    public int isFollowing(final Account account) {

        /* Iterating through following array */
        for(int i = 0; i < this.following.size(); i++) { 
            if(this.following.get(i).accountID == account.accountID) return i;
        }
        return -1;
    } 


    /** 
     * Checks if the account is follower of the account with the given account.
     * @param account The account to be checked.
     * @return int the index of account in followers array, -1 if it does not exist.
     */
    public int isFollower(final Account account) {

        /* Iterating through following array */
        for(int i = 0; i < this.followers.size(); i++) { 
            if(this.followers.get(i).accountID == account.accountID) return i;
        }
        return -1;
    } 


    /** 
     * Returns the number of followers of the account.
     * @return int The number of followers of the account.
     */
    private int getFollowersNum() { return this.followers.size(); } 


    /** 
     * Returns the array of followers of the account.
     * @return ArrayList<Account> The array of followers of the account.
     */
    private ArrayList<Account> getFollowers() { return this.followers; } 


    /** 
     * Follows the specified account if necessary conditions are met.
     * @param account The account to follow.
     */
    public void Follow(final Account account) {

        /* Checking if the account is logged in or not. */
        if (!this.isLogin) { System.out.println("You need to log in to follow an account."); return; }

        /* Checking if the account tries to follow itself or not. */    
        if (account.accountID == this.accountID) { System.out.println("You cannot follow yourself."); return; }

        /* Checking if this account is blocked by the other account or not. */
        if (account.isBlocked(this.accountID) != -1) { 
            System.out.println("You cannot follow an account that blocked you."); 
            return; 
        }

        /* Checking if the other account is blocked by this account or not. */
        if (this.isBlocked(account.accountID) != -1) { 
            System.out.println("You cannot follow an account that you blocked."); 
            return; 
        }

        /* Checking if this account is following the other account or not. */
        if (this.isFollowing(account) != -1) { System.out.println("You are already following this account."); return; }

        /* Adding the other account to following array of this account. */
        this.following.add(account); 
        
        /* Adding this account to followers array of the other account. */
        account.followers.add(this); 

        this.actionHistory.add("- You followed " + account.username); /* Keeping record of the action */
    }  


    /** 
     * Returns the username of the account with the specified accountID from the array of accounts.
     * @param AccountID The account ID of the account to get the username of.
     * @param accounts The array of accounts to search in.
     * @return String The username of the account with the specified accountID.
     */
    private String getUsername(final int AccountID, final ArrayList<Account> accounts) {
      
        /* Iterating through accounts array */
        for(int i = 0; i < accounts.size(); i++) { 
            if(accounts.get(i).accountID == AccountID) return accounts.get(i).username; 
        }

        System.out.println("There is no such account.");
        return accounts.get(0).username;
    } 
    

    /** 
     * Returns the number of accounts that the user is following.
     * @return int representing the number of accounts being followed.
     */
    private int getFollowingNum() { return this.following.size(); } 


    /** 
     * {@inheritDoc}
     * Returns a string representation of the user's profile.
     * @return String Represents user profile information.
     */
    @Override
    public String toString() {

        /* Adding account information to string. */
        String str = "-------------------------" + "\n";
        str += "User ID: " + this.accountID + "\n";
        str += "Username: " + this.username + "\n";
        str += "Location: " + this.location + "\n";
        str += "Birth Date: " + this.birthDate + "\n"; 
        str += this.username + " is following " + this.following.size() + " account(s) and has " + this.followers.size() + " followers(s).\n";

        /* Handling the case in which the account has follower. */
        if(this.followers.size() != 0) {
            str += "The followers of " + this.username + " are: ";
            for(int i = 0; i < this.followers.size(); i++) { str += this.followers.get(i).username + ", "; }
            str += "\n";
        }

         /* Handling the case in which the account has following. */
        if(this.following.size() != 0) {
            str += this.username + " is following: " ;
            for(int i = 0; i < this.following.size(); i++) { str += this.following.get(i).username + ", "; }
            str += '\n';
        }
      
        str +=  this.username + " has " + this.posts.size() + " posts.";
        return str;  /* Returning string representing account information */
    } 


    /** 
     * Displays the profile information for a given account, if necessary conditions are met.
     * @param account The account whose profile will be displayed.
     */
    public void viewProfile(final Account account) { 

        /* Checking if the account is logged in or not. */
        if(!this.isLogin) {
            System.out.println("You need to log in to view the profile.");
            return;
        }
  
        /* Checking if this account is blocked by the other account or not. */
        if(account.isBlocked(this.accountID) != -1) {  
            System.out.println("You cannot view profile of an account that blocked you.");
            return;
        }

        /* Checking if the other account is blocked by this account or not. */
        if(this.isBlocked(account.accountID) != -1) {  
            System.out.println("You cannot view profile of an account that you blocked.");
            return;
        }

      
        System.out.println(account.toString());  /* Viewing profile */

        /* Tracking The account ID of the last account that this account visited his/her profile. */
        this.lastAccID_onProfile = account.accountID;
        this.lastAccID_onPost = 0;
        this.actionHistory.add("- You viewed the profile of " + account.username); /* Keeping record of the action */
    }  

  
    /** 
     * Displays the posts for a given account, if necessary conditions are met.
     * @param account The account whose posts will be displayed.
     */
    public void viewPosts(final Account account) { 

        /* Checking if the account is logged in or not. */
        if(!this.isLogin) { System.out.println("You need to log in to view posts."); return; }

        /* Checking if this account is blocked by the other account or not. */
        if(account.isBlocked(this.accountID) != -1) {  
            System.out.println("You cannot view posts of an account that blocked you.");
            return;
        }

        /* Checking if the other account is blocked by this account or not. */
        if (this.isBlocked(account.accountID) != -1) {  
            System.out.println("You cannot view posts of an account that you blocked.");
            return;
        }

        /* Checking if the other account's profile has already been viewed or not. */
        if(this.lastAccID_onProfile != account.accountID) {
            System.out.println("You have to view profile before viewing posts.");
            return;
        }

        /* Viewing posts */
        if(account.posts.size() == 0) { System.out.println("There is no post that is shared..."); }

        else {
            System.out.println("\n--- Posts ---");	
            for(int i = 0; i < account.posts.size(); i++) {
                System.out.println(account.posts.get(i).getPostInfo(account.username)); 
            }
        }

        /* Tracking The account ID of the last account that this account visited his/her posts. */ 
        this.lastAccID_onPost = account.accountID;
        this.actionHistory.add("- You viewed the posts of " + account.username); /* Keeping record of the action */
    } 


    /** 
     * Logs in the user with the given username, if necessary conditions are met.
     * @param username The username to log in with.
     * @param accounts An array of all accounts in the social media software.
     */
    public void LogIn(final String username, final ArrayList<Account> accounts) {

        /* Checking if the account has already logged in.*/
        if(this.isLogin == true) { System.out.println("You have already been logged in."); return; }

        /* Checking if there is any other account that has already logged in. */
        for(int i = 0; i < accounts.size(); i++) {
            if(accounts.get(i).isLogin == true) {
                System.out.println("Another account whose username is " + getUsername(accounts.get(i).accountID,accounts) + " has already been logged in. You cannot login more than one account at the same time.");
                return;
            }
        }  

        /* Logging in if the username is correct. */
        if(username == this.username) {
            this.isLogin = true;
            this.lastAccID_onProfile = 0;
            this.lastAccID_onPost = 0;
            this.actionHistory.add("- You logged in"); /* Keeping record of the action */
        }
        else System.out.println("Login is failed. Wrong username has been entered.");
    }  


    /** 
     * Adds a like to a given post, if necessary conditions are met.
     * @param newLike The like object to add.
     * @param interactedPost The post to add the like to.
     * @param account the account that shared the post.
     */
    public void addLike(final Like newLike, final Post interactedPost, final Account account) {

        /* Checking if the account is logged in or not. */
        if (!this.isLogin) { System.out.println("You need to log in to like a post."); return; }
      
        /* Checking if like and post objects are associated with each other or not. */
        if(newLike.getPostID() != interactedPost.getPostID()) { 
            System.out.println("This like is not associated with this post.");
            return;
        }

        /* Checking if like and account objects are associated with each other. */
        if(newLike.getAccountID() != this.accountID) { 
            System.out.println("This like is not associated with your account.");
            return;
        }

        /* Checking if the account that shared the post is indicated correctly */
        if(account.accountID != interactedPost.getAccountID()) { 
            System.out.println("The owner of the post is indicated incorrectly, owner is not " + account.username); 
            return;
        }
      
        /* Checking if the post is shared or not. */
        if(!interactedPost.isPostShared()) { 
            System.out.println("You cannot like a post that has not been shared yet.");
            return;
        }

        /* Checking if this account is blocked by the other account or not. */
        if(account.isBlocked(this.getAccountID()) != -1) {  
            System.out.println("You cannot like a post of an account that blocked you."); 
            return;
        }

        /* Checking if the other account is blocked by this account or not. */
        if(this.isBlocked(account.getAccountID()) != -1) {  
            System.out.println("You cannot like a post of an account that you blocked."); 
            return;
        }


        /* Checking if the other account's profile has already been viewed or not. */
        if(this.lastAccID_onProfile != interactedPost.getAccountID()) { 
            System.out.println("You need to view profile before liking a post.");
            return;
        }
      
        /* Checking if the other account's posts has already been viewed or not. */
        if(this.lastAccID_onPost != interactedPost.getAccountID()) { 
            System.out.println("You need to view posts before liking a post.");
            return;
        }

       
        for(int i = 0; i < interactedPost.getLikes().size(); i++) {
     
            /* Checking if the same like object is being used or not. */
            if(interactedPost.getLikes().get(i).getInteractionID() == newLike.getInteractionID()) {
                System.out.println("You cannot use the same like object again to like a post.");
                return;
            }

            /* Handling the case in which the account has already liked the post. */ 
            if(interactedPost.getLikes().get(i).getAccountID() == newLike.getAccountID()) { 
                if(interactedPost.getLikes().get(i).getPostID() == newLike.getPostID()) {
                    System.out.println("Error: " + this.username + " has already liked this post.");
                    return;
                }
            }
        }

        /* Adding a like */
        interactedPost.getLikes().add(newLike);

        /* Keeping record of the action */
        this.actionHistory.add("- You liked " + account.username + "'s post id: " + interactedPost.getPostID()); 
    } 


    /** 
     * Adds a comment to a post.
     * @param newComment The comment to add.
     * @param interactedPost The post to interact with.
     * @param account the account that shared the post.
     */
    public void addComment(final Comment newComment, final Post interactedPost, final Account account) {

        /* Checking if the account is logged in or not. */
        if (!this.isLogin) { System.out.println("You need to log in to comment a post."); return; }

        /* Checking if comment and post objects are associated with each other or not. */
        if(newComment.getPostID() != interactedPost.getPostID()) { 
            System.out.println("This comment is not associated with this post.");
            return;
        }

        /* Checking if comment and account objects are associated with each other. */
        if(newComment.getAccountID() != this.accountID) { 
            System.out.println("This comment is not associated with your account.");
            return;
        }

        /* Checking if the account that shared the post is indicated correctly */
        if(account.accountID != interactedPost.getAccountID()) { 
            System.out.println("The owner of the post is indicated incorrectly, owner is not " + account.username); 
            return;
        }

        /* Checking if the post is shared or not. */
        if(!interactedPost.isPostShared()) { 
            System.out.println("You cannot add a comment to a post that has not been shared yet.");
            return;
        }

        /* Checking if this account is blocked by the other account or not. */
        if(account.isBlocked(this.getAccountID()) != -1) {  
            System.out.println("You cannot add a comment to a post of an account that blocked you."); 
            return;
        }

        /* Checking if the other account is blocked by this account or not. */
        if(this.isBlocked(account.getAccountID()) != -1) {  
            System.out.println("You cannot add a comment to a post of an account that you blocked."); 
            return;
        }

        /* Checking if the other account's profile has already been viewed or not. */
        if(this.lastAccID_onProfile != interactedPost.getAccountID()) {
            System.out.println("You need to view profile before commenting a post.");
            return;
        }
      
        /* Checking if the other account's posts has already been viewed or not. */
        if(this.lastAccID_onPost != interactedPost.getAccountID()) {
            System.out.println("You need to view posts before commenting a post.");
            return;
        }

    
        /* Checking if the same comment object is being used or not. */
        for(int i = 0; i < interactedPost.getComments().size(); i++) {
            if(interactedPost.getComments().get(i).getInteractionID() == newComment.getInteractionID()) {
                System.out.println("You cannot use the same comment object again to add a comment to a post.");
                return;
            }
        }
      
        /* Adding a comment */
        interactedPost.getComments().add(newComment); 

        /* Keeping record of the action */
        this.actionHistory.add("- You commented " + account.username + "'s post id: " + interactedPost.getPostID()); 
    } 


    /** 
     * Returns the username of the account.
     * @return String Represents the username of the account.
     */
    public String getAccUsername() { return this.username; }


    /** 
     * Views interactions for a given account, including post's likes and comments.
     * @param account The account to view interactions for.
     * @param accounts An array of all accounts in the social media software.
     */
    public void viewInteractions(final Account account, final ArrayList<Account> accounts) {

        /* Checking if the account is logged in or not. */
        if (!this.isLogin) { System.out.println("You need to log in to view interactions."); return; }

        /* Checking if this account is blocked by the other account or not. */
        if(account.isBlocked(this.accountID) != -1) {
            System.out.println("You cannot view an account's interactions that blocked you.");
            return;
        }

        /* Checking if the other account is blocked by this account or not. */
        if(this.isBlocked(account.accountID) != -1) {
            System.out.println("You cannot view an account's interactions that you blocked.");
            return;
        }

        /* Viewing interactions of all posts one by one. */
        for (int i = 0; i < account.posts.size(); i++) {   
            System.out.println("----------------------");
            System.out.println("(PostID: " + account.posts.get(i).getPostID() + "): " + account.posts.get(i).getPostContent());
            int numOfLikes = account.posts.get(i).getLikesNum();

            if(numOfLikes == 0) { System.out.println("The post has no likes."); }
                
            else {
                System.out.print("The post was liked by the following account(s): ");
                for(int j = 0; j < numOfLikes; j++) {  /* Viewing likes. */
                    System.out.print(getUsername(account.posts.get(i).getLikes().get(j).getAccountID(), accounts) + ", "); 
                }
                System.out.println();
            }
          
            int numOfComments = account.posts.get(i).getCommentsNum();
            if(numOfComments == 0) { System.out.println("The post has no comments."); }
                
            else {
                System.out.println("The post has " + numOfComments + " comment(s)...");  /* Viewing the number of comments. */
                for(int j = 0; j < numOfComments; j++) {  /* Viewing comments. */
                    System.out.println("Comment " + (j+1) + ": '" + account.getUsername(account.posts.get(i).getComments().get(j).getAccountID(), accounts)+ "' said '" + account.posts.get(i).getComments().get(j).getContent() + "'");
                }
            }
              
            System.out.println();
        }   

        this.actionHistory.add("- You viewed interactions of " + account.username); /* Keeping record of the action */
    }  


    /** 
     * Adds a message to the account's outbox.
     * @param message The message to add to the outbox.
     */
    public void addMessageToOutbox(final Message message) {

        /* Checking if the account is logged in. */
        if (!this.isLogin) { System.out.println("You need to log in to send a message."); return; }

        /* Adding a message to outbox */
        this.outbox.add(message);
    }  


    /** 
     * Returns actionHistory array.
     * @return ArrayList<String> Represents the action history of the account.
     */
    public ArrayList<String> getActionHistory() { return this.actionHistory; }


    /** 
      * Adds a message to the account's inbox.
      * @param message The message to add to the inbox.
      */ 
    public void addMessageToInbox(final Message message) {
        this.inbox.add(message); /* Adding a message to inbox */
    } 


    /** 
     * Prints the number of messages in the outbox, if necessary conditions are met.
     */ 
    public void CheckOutbox() {

        /* Checking if the account is logged in. */
        if (!this.isLogin) { System.out.println("You need to log in to check outbox."); return; }
      
        System.out.println("There is/are " + this.outbox.size() + " message(s) in the outbox.");
        this.actionHistory.add("- You checked your outbox");
    } 


    /** 
     * Prints the number of messages in the inbox, if necessary conditions are met.
     */ 
    public void CheckInbox() {

        /* Checking if the account is logged in. */
        if (!this.isLogin) { System.out.println("You need to log in to check inbox."); return; }

        System.out.println("There is/are " + this.inbox.size() + " message(s) in the inbox.");
        this.actionHistory.add("- You checked your inbox");
    }  


    /** 
     * Views messages in the inbox, if necessary conditions are met.
     * @param accounts An array of all accounts in the social media software.
     */ 
    public void viewInbox(final ArrayList<Account> accounts) {

        /* Checking if the account is logged in. */
        if (!this.isLogin) { System.out.println("You need to log in to view inbox."); return; }

        /* Viewing inbox. */ 
        if(this.inbox.size() == 0) System.out.println("Inbox is empty.");
        else {
            for(int i = 0; i < this.inbox.size(); i++) {
                System.out.println("--------------------------");
                System.out.println("Message ID: " + this.inbox.get(i).getMessageID());
                System.out.println("From: " + this.getUsername(this.inbox.get(i).getSenderID(), accounts));
                System.out.println("To: " + this.getUsername(this.inbox.get(i).getReceiverID(), accounts));
                System.out.println("Message: " + this.inbox.get(i).getContent());
            }
        }
        this.actionHistory.add("- You viewed your inbox"); /* Keeping record of the action */
    }  


    /** 
     * Views messages in the outbox, if necessary conditions are met.
     * @param accounts An array of all accounts in the social media software.
     */ 
    public void viewOutbox(final ArrayList<Account> accounts) {

        /* Checking if the account is logged in. */
        if (!this.isLogin) { System.out.println("You need to log in to view outbox."); return; }

        /* Viewing outbox. */ 
        if(this.outbox.size() == 0) System.out.println("Outbox is empty.");
        else {
            for(int i = 0; i < this.outbox.size(); i++) {
                System.out.println("--------------------------");
                System.out.println("Message ID: " + this.outbox.get(i).getMessageID());
                System.out.println("From: " + this.getUsername(this.outbox.get(i).getSenderID(), accounts));
                System.out.println("To: " + this.getUsername(this.outbox.get(i).getReceiverID(), accounts));
                System.out.println("Message: " + this.outbox.get(i).getContent());
            }
        }
        this.actionHistory.add("- You viewed your outbox"); /* Keeping record of the action */
    }  
  

    /** 
     * Blocks the specified account and adds its account ID to the array of blocked account IDs.
     * @param accountBlocked The account to be blocked
     */ 
    public void BlockAccount(final Account accountBlocked) {

        /* Checking if the account is logged in. */
        if(!this.isLogin) { System.out.println("You need to log in to block an account."); return; }
      
        /* Checking if the account tries to block itself */
        if(accountBlocked.accountID == this.accountID) { System.out.println("You cannot block yourself."); return; }

        /* Checking if the other account is blocked by this account or not. */
        if(this.isBlocked(accountBlocked.accountID) != -1) {
            System.out.println("You have already blocked this account.");
            return;
        }
    
        /* Removing the blocked account from the following array and this account from the followers array */
        if(this.isFollowing(accountBlocked) != -1) { this.unFollow(accountBlocked); }
        this.blockedAccountsID.add(accountBlocked.accountID); /* Blocking the account */
      
        /* Resetting the record of viewing profile */
        if(this.lastAccID_onProfile == accountBlocked.accountID) { this.lastAccID_onProfile = 0; } 

        /* Resetting the record of viewing posts */
        if(this.lastAccID_onPost == accountBlocked.accountID) { 
            this.lastAccID_onProfile = 0; 
            this.lastAccID_onPost = 0;
        } 
        this.actionHistory.add("- You blocked " + accountBlocked.username);  /* Keeping record of the action */ 
    } 

    /** 
     * Returns login information.
     * @return true if the account is logged in.
     */		
    public boolean getIsLogin() { return isLogin; }
  
  
    /** 
     * Unfollows the specified account.
     * @param account The account to be unfollowed.
     */	
    public void unFollow(final Account account) {

        /* Checking if the account is logged in. */
        if(!this.isLogin) { System.out.println("You need to log in to unfollow an account."); return; }

        /* Checking if the account tries to unfollow itself or not */
        if(account.accountID == this.accountID) { System.out.println("You cannot unfollow yourself."); return; }

        /* Checking if this account is blocked by the other account or not. */
        if (account.isBlocked(this.accountID) != -1) { 
            System.out.println("You cannot unfollow the account that blocked you.");
            return;
        }

        /* Checking if the other account is blocked by this account or not. */
        if (this.isBlocked(account.accountID) != -1) { 
            System.out.println("You cannot unfollow the account that you blocked.");
            return;
        }


        /* Checking if this account is following the other account. */
        int index = this.isFollowing(account);
        
        if(index != -1) {
            this.following.remove(index); /* Unfollowing the other account. */
            account.followers.remove(account.isFollower(this)); /* Removing this account from followers list of the other account */
            this.actionHistory.add("- You unfollowed " + account.username); /* Keeping record of the action */
       }
        else System.out.println("You have to follow the account before unfollow the account.");
    } 
  

    /** 
     * Unlikes the specified post by using the specified like object.
     * @param account The account that shared the post.
     * @param like The like object to be unliked.
     * @param interactedPost The post that like was added on.
     */
    public void unLike(final Post interactedPost, final Account account, Like like) { 
      
        /* Checking if the account is logged in. */
        if(!this.isLogin) { System.out.println("You need to log in to unlike a post."); return; } 

        /* Checking if like and post objects are associated with each other or not. */
        if(like.getPostID() != interactedPost.getPostID()) { 
            System.out.println("This like is not associated with this post."); 
            return; 
        }
      
        /* Checking if like and account objects are associated with each other. */
        if(like.getAccountID() != this.accountID) { 
            System.out.println("This like is not associated with your account."); 
            return;
        }

        /* Checking if the post is shared or not. */
        if(!interactedPost.isPostShared()) { 
            System.out.println("You cannot unlike a post that has not been shared yet."); 
            return;
        }

        /* Checking if the account that shared the post is indicated correctly */
        if(account.accountID != interactedPost.getAccountID()) { 
            System.out.println("The owner of the post is indicated incorrectly, owner is not " + account.username); 
            return;
        }
      
        /* Checking if this account is blocked by the other account or not. */
        if(account.isBlocked(this.getAccountID()) != -1) {  
            System.out.println("You cannot unlike a post of an account blocked you."); 
            return;
        }

        /* Checking if the other account is blocked by this account or not. */
        if(this.isBlocked(account.getAccountID()) != -1) {  
            System.out.println("You cannot unlike a post of an account you blocked."); 
            return;
        }
        
        /* Checking if the other account's profile has already been viewed or not. */
        if(this.lastAccID_onProfile != account.accountID) { 
            System.out.println("You have to view profile before unlike a post."); 
            return;
        }

        /* Checking if the other account's posts has already been viewed or not. */
        if(this.lastAccID_onPost != account.accountID) { 
            System.out.println("You have to view posts before unlike a post."); 
            return;
        }


        /* Checking if the specified post was liked before with this object or not. */
        int index = interactedPost.isLiked(like);
        if(index != -1) {
            interactedPost.getLikes().remove(index); /* Unliking the post. */

            /* Keeping record of the action */
            this.actionHistory.add("- You unliked " + account.username + "'s post id: " + interactedPost.getPostID()); 
        }
        else System.out.println("This like was not added to this post so you cannot unlike it."); 
    } 
  
    
    /** 
     * Unblocks the specified account.
     * @param account The account to be unblocked.
     */
    public void unBlock(final Account account) {
      
        /* Checking if the account is logged in. */
        if(!this.isLogin) { System.out.println("You need to log in to unblock an account."); return; }

        /* Checking if the account tries to unblock itself or not */
        if(account.accountID == this.accountID) { System.out.println("You cannot unblock yourself."); return; }

        /* Checking if the specified account was blocked before or not. */
        int index = this.isBlocked(account.accountID);
        if(index != -1) {
            this.blockedAccountsID.remove(index); /* Unblocking the specified account */
            this.actionHistory.add("- You unblocked " + account.username); /* Keeping record of the action */
        }
        else System.out.println("You cannot unblock an account that you did not block before."); 
    } 


    /** 
     * Uncomments the specified post by using the specified comment object.
     * @param account The account that shared the post.
     * @param comment The comment object to be uncommented.
     * @param interactedPost The post that comment was added on.
     */
    public void unComment(final Post interactedPost, final Account account, Comment comment) {

        /* Checking if the account is logged in. */
        if(!this.isLogin) { System.out.println("You need to log in to uncomment a post."); return; }

        /* Checking if comment and post objects are associated with each other or not. */
        if(comment.getPostID() != interactedPost.getPostID()) { 
            System.out.println("This comment is not associated with this post."); 
            return;
        }
      
        /* Checking if comment and account objects are associated with each other. */
        if(comment.getAccountID() != this.accountID) { 
            System.out.println("This comment is not associated with your account."); 
            return;
        }

        /* Checking if the post is shared or not. */
        if(!interactedPost.isPostShared()) { 
            System.out.println("You cannot uncomment a post that has not been shared yet.");
            return;
        }
      
        /* Checking if the account that shared the post is indicated correctly */
        if(account.accountID != interactedPost.getAccountID()) { 
            System.out.println("The owner of the post is indicated incorrectly, owner is not " + account.username);
            return;
        }

        /* Checking if this account is blocked by the other account or not. */
        if(account.isBlocked(this.getAccountID()) != -1) { 
            System.out.println("You cannot uncomment a post of an account blocked you.");
            return;
        }

        /* Checking if the other account is blocked by this account or not. */
        if(this.isBlocked(account.getAccountID()) != -1) { 
            System.out.println("You cannot uncomment a post of an account you blocked.");
            return;
        }

        /* Checking if the other account's profile has already been viewed or not. */
        if(this.lastAccID_onProfile != account.accountID) {
            System.out.println("You have to view profile before uncomment a post.");
            return;
        }

        /* Checking if the other account's posts has already been viewed or not. */
        if(this.lastAccID_onPost != account.accountID) {
            System.out.println("You have to view posts before uncomment a post.");
            return;
        }

        /* Checking if the specified post was commented before with this object or not. */
        int index = interactedPost.isCommented(comment);
        if(index != -1) {
            interactedPost.getComments().remove(index); /* Uncommenting the specified post */
            System.out.println("The uncommented message: " + comment.getContent());

            /* Keeping record of the action */
            this.actionHistory.add("- You uncommented " + account.username + "'s post id: " + interactedPost.getPostID()); 
        }

        else System.out.println("This comment was not added to this post so you cannot uncomment it."); 
    } 


    /** 
     * Views action history of the account.
     */ 
    public void viewActionHistory() {

        /* Checking if the account is logged in. */  
        if(!this.isLogin) {  System.out.println("You need to log in to view your action history."); return; }
        if(this.actionHistory.size() == 0) { System.out.println("Your action history is empty..."); return; }  

        /* Viewing action history of the account */
        for(int i = 0; i < this.actionHistory.size(); i++) { System.out.println(this.actionHistory.get(i)); }
        this.actionHistory.add("- You viewed your action history");  /* Keeping record of the action */
    } 
  

}
