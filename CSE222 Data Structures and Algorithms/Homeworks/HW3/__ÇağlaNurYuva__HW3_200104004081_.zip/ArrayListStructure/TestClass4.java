
import java.util.ArrayList;

/**
 * This class runs tests for the social media software.
 * It contains main method to test methods of other classes.
 * 
 * @file    TestClass4.java
 * @author  Çağla Nur Yuva
 * @brief   Basic social media software test
 * @version 1.0
 * @date    2023-04-05
 */
public class TestClass4 {

    /**
     * Runs tests for the social media software.
     * @param args An array of strings for command-line arguments.
     */
    public static void main(String[] args) {

        int trackAccountID = 1;  /* Keeps track of Account ID */  
        int trackPostID = 1;     /* Keeps track of Post ID */     
        int trackMessageID = 0;  /* Keeps track of Message ID */  
        int trackInteractionID = 1; /* Keeps track of InteractionID */
        ArrayList<Account> allAccounts = new ArrayList<Account>(); /* Keeps all created accounts */

        System.out.println("---------------------------- SCENERIO 4 STARTS ----------------------------");

        /* Creating accounts and add them to the allAccounts array. */
        System.out.println("\nSTEP 1... Creating accounts without error...");
        Account gizemsungu = new Account(trackAccountID++, "gizemsungu", "13.01.1993", "Ankara");
        allAccounts.add(gizemsungu);
        System.out.println("An account with username gizemsungu has been created.");

        Account sibelgulmez = new Account(trackAccountID++, "sibelgulmez","10.03.1995", "Istanbul");
        allAccounts.add(sibelgulmez);
        System.out.println("An account with username sibelgulmez has been created.");
      
        Account gokhankaya = new Account(trackAccountID++, "gokhankaya", "17.06.1988", "Samsun");
        allAccounts.add(gokhankaya);
        System.out.println("An account with username gokhankaya has been created.");

        Account yusufakgul = new Account(trackAccountID++, "yusufakgul", "11.08.1969", "Sivas");
        allAccounts.add(yusufakgul);
        System.out.println("An account with username yusufakgul has been created.");

        Account erkanzerger = new Account(trackAccountID++, "erkanzerger", "10.10.1975", "Kars");
        allAccounts.add(erkanzerger);
        System.out.println("An account with username erkanzerger has been created.");

        Account mehmetgokturk = new Account(trackAccountID++, "mehmetgokturk", "06.02.1974", "Antalya");
        allAccounts.add(mehmetgokturk);
        System.out.println("An account with username mehmetgokturk has been created.");

        Account habilkalkan = new Account(trackAccountID++, "habilkalkan", "23.09.1980", "Trabzon");
        allAccounts.add(habilkalkan);
        System.out.println("An account with username habilkalkan has been created.");

        Account cemayar = new Account(trackAccountID++, "cemayar", "25.02.1995", "Konya");
        allAccounts.add(cemayar);
        System.out.println("An account with username cemayar has been created.");

        Account sametgul = new Account(trackAccountID++, "sametgul", "19.10.1993", "Edirne");
        allAccounts.add(sametgul);
        System.out.println("An account with username sametgul has been created.");

        Account hasaricelebi = new Account(trackAccountID++, "hasaricelebi", "28.07.1964", "Bayburt");
        allAccounts.add(hasaricelebi);
        System.out.println("An account with username hasaricelebi has been created.");

        /* Creating some test cases to test functionality of unFollow() and viewActionHistory() methods */
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 2... Logging in the account of \"sibelgulmez\" without error...");
        sibelgulmez.LogIn("sibelgulmez",allAccounts);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 3... \"sibelgulmez\" follows nine account without error...");
        sibelgulmez.Follow(erkanzerger);
        sibelgulmez.Follow(sametgul);
        sibelgulmez.Follow(yusufakgul);
        sibelgulmez.Follow(gizemsungu);
        sibelgulmez.Follow(gokhankaya);
        sibelgulmez.Follow(mehmetgokturk);
        sibelgulmez.Follow(hasaricelebi);
        sibelgulmez.Follow(habilkalkan);
        sibelgulmez.Follow(cemayar);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 4... Viewing profile of \"sibelgulmez\" to show having been followed accounts without error...");
        sibelgulmez.viewProfile(sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 5... \"sibelgulmez\" unfollows \"gizemsungu\" without error...");
        sibelgulmez.unFollow(gizemsungu);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 6... Viewing profile of \"sibelgulmez\" to show \"gizemsungu\" has been unfollowed...");
        sibelgulmez.viewProfile(sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 7... \"sibelgulmez\" unfollows \"gokhankaya\",\"mehmetgokturk\",\"sametgul\" without error...");
        sibelgulmez.unFollow(gokhankaya);
        sibelgulmez.unFollow(mehmetgokturk);
        sibelgulmez.unFollow(sametgul);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 8... \"mehmetgokturk\" tries to unfollow \"hasaricelebi\" without logging in...");
        mehmetgokturk.unFollow(hasaricelebi); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 9... Viewing profile of \"sibelgulmez\" to show having been followed accounts without error...");
        sibelgulmez.viewProfile(sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 10... \"sibelgulmez\" tries to follow \"cemayar\" and \"hasaricelebi\" without unfollowing them...");
        sibelgulmez.Follow(cemayar); 
        sibelgulmez.Follow(hasaricelebi); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 11... \"sibelgulmez\" tries to follow \"sametgul\" and \"gizemsungu\" without error (They were unfollowed before.)...");
        sibelgulmez.Follow(sametgul); 
        sibelgulmez.Follow(gizemsungu); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 12... Viewing profile of \"sibelgulmez\" to show having been followed accounts without error...");
        sibelgulmez.viewProfile(sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 13... \"sibelgulmez\" tries to unfollow \"gokhankaya\" and \"mehmetgokturk\" without following them...");
        sibelgulmez.unFollow(gokhankaya);
        sibelgulmez.unFollow(mehmetgokturk); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 14... \"sibelgulmez\" tries to unfollow \"sibelgulmez\"...");
        sibelgulmez.unFollow(sibelgulmez); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 15... \"erkanzerger\" tries to unfollow \"cemayar\" without logging in...");
        erkanzerger.unFollow(cemayar); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 16... Viewing profile of \"sibelgulmez\" to show having been followed accounts without error...");
        sibelgulmez.viewProfile(sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 17... \"erkanzerger\" tries to view his own action history without logging in...");
        erkanzerger.viewActionHistory(); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 18... \"sibelgulmez\" tries to view her own action history without error...");
        sibelgulmez.viewActionHistory();
      

        Post Post1 = new Post(trackPostID++,sibelgulmez.getAccountID(),"C is a nightmare.");
        Post Post2 = new Post(trackPostID++,sibelgulmez.getAccountID(),"That is called life.");
        Post Post3 = new Post(trackPostID++,sibelgulmez.getAccountID(),"I will buy an orange car.");

        Like Like1 = new Like(trackInteractionID++, gizemsungu.getAccountID(), Post1.getPostID()); 
        Like Like10 = new Like(trackInteractionID++, cemayar.getAccountID(), Post1.getPostID());
        Like Like11 = new Like(trackInteractionID++, hasaricelebi.getAccountID(), Post1.getPostID()); 

        Comment Comment1 = new Comment(trackInteractionID++, gizemsungu.getAccountID(), Post1.getPostID(), "I think so sometimes...");
        Comment Comment2 = new Comment(trackInteractionID++, gizemsungu.getAccountID(), Post1.getPostID(), "Slowly but surely!");
        Comment Comment17 = new Comment(trackInteractionID++, cemayar.getAccountID(), Post1.getPostID(), "Keep writing..");
        Comment Comment18 = new Comment(trackInteractionID++, hasaricelebi.getAccountID(), Post1.getPostID(), "I am tired..");
        Comment Comment19 = new Comment(trackInteractionID++, sibelgulmez.getAccountID(), Post1.getPostID(), "Thanks guys!");
        Comment Comment20 = new Comment(trackInteractionID++, sibelgulmez.getAccountID(), Post1.getPostID(), "I am very happy to have met you!");
      
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 19... \"sibelgulmez\" logs out without error...");
        sibelgulmez.LogOut();

        /* Creating some test cases to test functionality of unLike() and unComment() methods */
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 20... \"cemayar\" logs in without error...");
        cemayar.LogIn("cemayar",allAccounts);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 21... \"cemayar\" tries to unlike and uncomment a post that has not been shared yet...");
        cemayar.unLike(Post1,sibelgulmez,Like10);
        cemayar.unComment(Post1,sibelgulmez,Comment17); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 22... \"cemayar\" logs out without error...");
        cemayar.LogOut();

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 23... \"hasaricelebi\" logs in without error...");
        hasaricelebi.LogIn("hasaricelebi",allAccounts);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 24... \"hasaricelebi\" tries to unlike and uncomment a post that has not been shared yet...");
        hasaricelebi.unLike(Post1,sibelgulmez,Like11); 
        hasaricelebi.unComment(Post1,sibelgulmez,Comment18);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 25... \"hasaricelebi\" logs out without error...");
        hasaricelebi.LogOut();

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 26... \"sibelgulmez\" logs in without error...");
        sibelgulmez.LogIn("sibelgulmez",allAccounts);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 27... \"sibelgulmez\" adds one post without error...");
        sibelgulmez.addPost(Post1);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 28... \"sibelgulmez\" logs out without error...");
        sibelgulmez.LogOut();
      
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 29... \"gizemsungu\" logs in without error...");
        gizemsungu.LogIn("gizemsungu",allAccounts); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 30... \"gizemsungu\" views profile and posts of \"sibelgulmez\" without error to add like and comment...");
        gizemsungu.viewProfile(sibelgulmez);
        gizemsungu.viewPosts(sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 31... \"gizemsungu\" adds one like to the post of \"sibelgulmez\" without error...");
        gizemsungu.addLike(Like1, Post1, sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 32... \"gizemsungu\" tries to add one like to the post of \"sibelgulmez\" that \"gizemsungu\" liked before ...");
        gizemsungu.addLike(Like1, Post1, sibelgulmez); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 33... \"gizemsungu\" adds two comments to the post of \"sibelgulmez\" without error...");
        gizemsungu.addComment(Comment1, Post1, sibelgulmez);
        gizemsungu.addComment(Comment2, Post1, sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 34... \"gizemsungu\" logs out without error...");
        gizemsungu.LogOut();

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 35... \"gokhankaya\" logs in without error...");
        gokhankaya.LogIn("gokhankaya",allAccounts); 
        Like Like2 = new Like(trackInteractionID++, gokhankaya.getAccountID(), Post1.getPostID()); 
        Comment Comment3 = new Comment(trackInteractionID++, gokhankaya.getAccountID(), Post1.getPostID(), "You will learn in time...");

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 36... \"gokhankaya\" views profile and posts of \"sibelgulmez\" without error to add like and comment...");
        gokhankaya.viewProfile(sibelgulmez);
        gokhankaya.viewPosts(sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 37... \"gokhankaya\" adds one like and one comment to the post of \"sibelgulmez\" without error...");
        gokhankaya.addLike(Like2, Post1, sibelgulmez);
        gokhankaya.addComment(Comment3, Post1, sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 38... \"gokhankaya\" logs out without error...");
        gokhankaya.LogOut();

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 39... \"yusufakgul\" logs in without error...");
        yusufakgul.LogIn("yusufakgul",allAccounts); 
        Like Like3 = new Like(trackInteractionID++, yusufakgul.getAccountID(), Post1.getPostID()); 
        Comment Comment4 = new Comment(trackInteractionID++, yusufakgul.getAccountID(), Post1.getPostID(), "If you don't have time, do not sleep at night.");
        Comment Comment5 = new Comment(trackInteractionID++, yusufakgul.getAccountID(), Post1.getPostID(), "I take this personally.");

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 40... \"yusufakgul\" views profile and posts of \"sibelgulmez\" without error to add like and comment...");
        yusufakgul.viewProfile(sibelgulmez);
        yusufakgul.viewPosts(sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 41... \"yusufakgul\" adds one like to the post of \"sibelgulmez\" without error...");
        yusufakgul.addLike(Like3, Post1, sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.print("\nSTEP 42... \"yusufakgul\" tries to add one like to the post of \"sibelgulmez\" by using a like object that");
        System.out.println(" is not associated with \"yusufakgul\" ...");
        yusufakgul.addLike(Like2, Post1, sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 43... \"yusufakgul\" adds one comment to the post of \"sibelgulmez\" without error...");
        yusufakgul.addComment(Comment4, Post1, sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.print("\nSTEP 44... \"yusufakgul\"  tries to add one comment to the post of \"sibelgulmez\" by using a comment object that");
        System.out.println(" is not associated with \"yusufakgul\" ...");
        yusufakgul.addComment(Comment2, Post1, sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 45... \"yusufakgul\" logs out without error...");
        yusufakgul.LogOut();

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 46... \"erkanzerger\" logs in without error...");
        erkanzerger.LogIn("erkanzerger",allAccounts); 

        Like Like4 = new Like(trackInteractionID++, erkanzerger.getAccountID(), Post1.getPostID()); 
        Comment Comment6 = new Comment(trackInteractionID++, erkanzerger.getAccountID(), Post1.getPostID(), "Hahahaha");
        Comment Comment7 = new Comment(trackInteractionID++, erkanzerger.getAccountID(), Post1.getPostID(), "Not my problem");
        Comment Comment77 = new Comment(trackInteractionID++, erkanzerger.getAccountID(), Post1.getPostID(), "I am done with you guys.");

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 47... \"erkanzerger\" views profile and posts of \"sibelgulmez\" without error to add like and comment...");
        erkanzerger.viewProfile(sibelgulmez);
        erkanzerger.viewPosts(sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 48... \"erkanzerger\" adds one like to the post of \"sibelgulmez\" without error...");
        erkanzerger.addLike(Like4, Post1, sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 49... \"erkanzerger\" adds three comments to the post of \"sibelgulmez\" without error...");
        erkanzerger.addComment(Comment6, Post1, sibelgulmez);
        erkanzerger.addComment(Comment7, Post1, sibelgulmez);
        erkanzerger.addComment(Comment77, Post1, sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 50... \"erkanzerger\" logs out without error...");
        erkanzerger.LogOut();

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 51... \"mehmetgokturk\" logs in without error...");
        mehmetgokturk.LogIn("mehmetgokturk",allAccounts); 

        Like Like5 = new Like(trackInteractionID++, mehmetgokturk.getAccountID(), Post1.getPostID()); 
        Comment Comment8 = new Comment(trackInteractionID++, mehmetgokturk.getAccountID(), Post1.getPostID(), "I am crying at Z23 classroom now...");

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 52... \"mehmetgokturk\" views profile and posts of \"sibelgulmez\" without error to add like and comment...");
        mehmetgokturk.viewProfile(sibelgulmez);
        mehmetgokturk.viewPosts(sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 53... \"mehmetgokturk\" adds one like and one comment to the post of \"sibelgulmez\" without error...");
        mehmetgokturk.addLike(Like5, Post1, sibelgulmez);
        mehmetgokturk.addComment(Comment8, Post1, sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 54... \"mehmetgokturk\" logs out without error...");
        mehmetgokturk.LogOut();

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 55... \"habilkalkan\" logs in without error...");
        habilkalkan.LogIn("habilkalkan",allAccounts);
        Like Like6 = new Like(trackInteractionID++, habilkalkan.getAccountID(), Post1.getPostID()); 
        Comment Comment9 = new Comment(trackInteractionID++, habilkalkan.getAccountID(), Post1.getPostID(), "Come electronics instead!");

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 56... \"habilkalkan\" views profile and posts of \"sibelgulmez\" without error to add like and comment...");
        habilkalkan.viewProfile(sibelgulmez);
        habilkalkan.viewPosts(sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 57... \"habilkalkan\" adds one like and one comment to the post of \"sibelgulmez\" without error...");
        habilkalkan.addLike(Like6, Post1, sibelgulmez);
        habilkalkan.addComment(Comment9, Post1, sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 58... \"habilkalkan\" logs out without error...");
        habilkalkan.LogOut();

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 59... \"cemayar\" logs in without error...");
        cemayar.LogIn("cemayar",allAccounts);
        Like Like7 = new Like(trackInteractionID++, cemayar.getAccountID(), Post1.getPostID()); 
        Comment Comment10 = new Comment(trackInteractionID++, cemayar.getAccountID(), Post1.getPostID(), "Everything is mess like C :(");

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 60... \"cemayar\" views profile and posts of \"sibelgulmez\" without error to add like and comment...");
        cemayar.viewProfile(sibelgulmez);
        cemayar.viewPosts(sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 61... \"cemayar\" adds one like and one comment to the post of \"sibelgulmez\" without error...");
        cemayar.addLike(Like7, Post1, sibelgulmez);
        cemayar.addComment(Comment10, Post1, sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 62... \"cemayar\" logs out without error...");
        cemayar.LogOut();

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 63... \"sametgul\" logs in without error...");
        sametgul.LogIn("sametgul",allAccounts); 

        Like Like8 = new Like(trackInteractionID++, sametgul.getAccountID(), Post1.getPostID()); 
        Comment Comment11 = new Comment(trackInteractionID++, sametgul.getAccountID(), Post1.getPostID(), "Good luck you have 20 minutes");

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 64... \"sametgul\" views profile and posts of \"sibelgulmez\" without error to add like and comment...");
        sametgul.viewProfile(sibelgulmez);
        sametgul.viewPosts(sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 65... \"sametgul\" adds one like and one comment to the post of \"sibelgulmez\" without error...");
        sametgul.addLike(Like8, Post1, sibelgulmez);
        sametgul.addComment(Comment11, Post1, sibelgulmez);

        /* Testing viewActionHistory(), unLike() and unComment() method */
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 66... \"sametgul\" views his own action history without error...");
        sametgul.viewActionHistory();

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 67... \"yusufakgul\" tries to view his own action history without logging in...");
        yusufakgul.viewActionHistory(); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 68... \"sametgul\" logs out without error...");
        sametgul.LogOut();

        Comment Comment13 = new Comment(trackInteractionID++, gokhankaya.getAccountID(), Post1.getPostID(), "Noo...");
        Comment Comment14 = new Comment(trackInteractionID++, erkanzerger.getAccountID(), Post1.getPostID(), "Sleeping at home.");
        Comment Comment15 = new Comment(trackInteractionID++, sametgul.getAccountID(), Post3.getPostID(), "It is magical...");
        Comment Comment16 = new Comment(trackInteractionID++, gizemsungu.getAccountID(), Post2.getPostID(), "Writing thesis...");
      

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 69... \"hasaricelebi\" logs in without error...");
        hasaricelebi.LogIn("hasaricelebi",allAccounts);
        Like Like9 = new Like(trackInteractionID++, hasaricelebi.getAccountID(), Post1.getPostID()); 
        Comment Comment12 = new Comment(trackInteractionID++, hasaricelebi.getAccountID(), Post1.getPostID(), "System Programming is waiting for you!");

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 70... \"hasaricelebi\" views profile and posts of \"sibelgulmez\" without error to add/remove like and comment...");
        hasaricelebi.viewProfile(sibelgulmez);
        hasaricelebi.viewPosts(sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.print("\nSTEP 71... \"hasaricelebi\" tries to unlike the post of \"sibelgulmez\" without liking the post with");
        System.out.println(" this particular like object.");
        hasaricelebi.unLike(Post1,sibelgulmez,Like9); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 72... \"hasaricelebi\" adds one like and one comment to the post of \"sibelgulmez\" without error...");
        hasaricelebi.addLike(Like9, Post1, sibelgulmez);
        hasaricelebi.addComment(Comment12, Post1, sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 73... \"hasaricelebi\" views post interactions of \"sibelgulmez\" without error...");
        hasaricelebi.viewInteractions(sibelgulmez,allAccounts);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 74... \"erkanzerger\" tries to view post interactions of \"sibelgulmez\" without logging in...");
        erkanzerger.viewInteractions(sibelgulmez,allAccounts); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 75... \"hasaricelebi\" logs out without error...");
        hasaricelebi.LogOut();
     
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 76... \"erkanzerger\" logs in without error...");
        erkanzerger.LogIn("erkanzerger",allAccounts);
   
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 77... \"erkanzerger\" tries to unlike the post of \"sibelgulmez\" without viewing profile of \"sibelgulmez\"...");
        erkanzerger.unLike(Post1,sibelgulmez,Like4); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 78... \"erkanzerger\" views profile of \"sibelgulmez\" without error...");
        erkanzerger.viewProfile(sibelgulmez);
       
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 79... \"erkanzerger\" tries to unlike the post of \"sibelgulmez\" without viewing posts of \"sibelgulmez\"...");
        erkanzerger.unLike(Post1,sibelgulmez,Like4); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 80... \"erkanzerger\" views posts of \"sibelgulmez\" without error...");
        erkanzerger.viewPosts(sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 81... \"erkanzerger\" unlikes the post of \"sibelgulmez\" without error...");
        erkanzerger.unLike(Post1,sibelgulmez,Like4);
        
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 82... \"yusufakgul\" tries to unlike the post of \"sibelgulmez\" without logging in...");
        yusufakgul.unLike(Post1,sibelgulmez,Like3);
       
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 83... \"erkanzerger\" uncomments the post of \"sibelgulmez\" without error...");
        erkanzerger.unComment(Post1,sibelgulmez,Comment6);

        System.out.println("\n*********************************************************************");
        System.out.print("\nSTEP 84... \"erkanzerger\" tries to uncomment the post of \"sibelgulmez\" without commenting the post with");
        System.out.println(" this particular comment object.");
        erkanzerger.unComment(Post1,sibelgulmez, Comment6); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 85... \"erkanzerger\" uncomments the post of \"sibelgulmez\" without error...");
        erkanzerger.unComment(Post1,sibelgulmez, Comment77);
      
        System.out.println("\n*********************************************************************");
        System.out.print("\nSTEP 86... \"erkanzerger\" tries to uncomment the post of \"sibelgulmez\" without commenting the post with");
        System.out.println(" this particular comment object.");
        erkanzerger.unComment(Post1,sibelgulmez, Comment14); 
      
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 87... \"erkanzerger\" views his own action history without error...");
        erkanzerger.viewActionHistory();

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 88... \"erkanzerger\" logs out without error...");
        erkanzerger.LogOut();

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 89... \"gokhankaya\" tries to uncomment the post of \"sibelgulmez\" without logging in...");
        gokhankaya.unComment(Post1,sibelgulmez, Comment8); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 90... \"yusufakgul\" logs in without error...");
        yusufakgul.LogIn("yusufakgul",allAccounts);
    
        /* Creating some test cases to test functionality of unLike(), unComment() and viewActionHistory() methods */
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 91... \"erkanzerger\" tries to uncomment the post of \"sibelgulmez\" without logging in...");
        erkanzerger.unComment(Post1,sibelgulmez, Comment6); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 92... \"yusufakgul\" views profile and posts of \"sibelgulmez\" without error to add/remove like and comment...");
        yusufakgul.viewProfile(sibelgulmez);
        yusufakgul.viewPosts(sibelgulmez);
      
        System.out.println("\n*********************************************************************");
        System.out.print("\nSTEP 93... \"yusufakgul\" tries to unlike the post of \"sibelgulmez\" by indicating the wrong account");
        System.out.println(" as the owner of the post...");
        yusufakgul.unLike(Post1,sametgul,Like3); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 94... \"yusufakgul\" unlikes the post of \"sibelgulmez\" without error...");
        yusufakgul.unLike(Post1,sibelgulmez,Like3);
   
        System.out.println("\n*********************************************************************");
        System.out.print("\nSTEP 95... \"yusufakgul\" tries to unlike the post of \"sibelgulmez\" without liking the post with");
        System.out.println(" this particular like object.");
        yusufakgul.unLike(Post1,sibelgulmez,Like3); 
        
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 96... \"yusufakgul\" uncomments the post of \"sibelgulmez\" without error...");
        yusufakgul.unComment(Post1,sibelgulmez, Comment4);
    
        System.out.println("\n*********************************************************************");
        System.out.print("\nSTEP 97... \"yusufakgul\" tries to uncomment the post of \"sibelgulmez\" by indicating the wrong account");
        System.out.println(" as the owner of the post...");
        yusufakgul.unComment(Post1, habilkalkan,Comment4); 
     
        System.out.println("\n*********************************************************************");
        System.out.print("\nSTEP 98... \"yusufakgul\" tries to uncomment the post of \"sibelgulmez\" by using a comment object");
        System.out.println(" that is not associated with \"yusufakgul\" ...");
        yusufakgul.unComment(Post1,sibelgulmez, Comment1); 
  
        System.out.println("\n*********************************************************************");
        System.out.print("\nSTEP 99... \"yusufakgul\" tries to uncomment the post of \"sibelgulmez\" without commenting the post with");
        System.out.println(" this particular comment object.");
        yusufakgul.unComment(Post1,sibelgulmez, Comment5); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 100... \"yusufakgul\" adds a comment the post of \"sibelgulmez\" without error...");        
        yusufakgul.addComment(Comment5, Post1, sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 101... \"yusufakgul\" uncomments the post of \"sibelgulmez\" without error...");       
        yusufakgul.unComment(Post1,sibelgulmez, Comment5);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 102... \"yusufakgul\" views his own action history without error...");  
        yusufakgul.viewActionHistory();

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 103... \"yusufakgul\" logs out without error...");
        yusufakgul.LogOut();
    
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 104... \"mehmetgokturk\" logs in without error...");
        mehmetgokturk.LogIn("mehmetgokturk",allAccounts);

        System.out.println("\n*********************************************************************");
        System.out.print("\nSTEP 105... \"mehmetgokturk\" views profile and posts of \"sibelgulmez\" without error to show \"mehmetgokturk\"");
        System.out.println(" is not blocked by \"sibelgulmez\" or vice versa...");
        mehmetgokturk.viewProfile(sibelgulmez);
        mehmetgokturk.viewPosts(sibelgulmez); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 106... \"mehmetgokturk\" logs out without error...");
        mehmetgokturk.LogOut();
     
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 107... \"sibelgulmez\" tries to unblock \"mehmetgokturk\" and \"gokhankaya\" without logging in...");
        sibelgulmez.unBlock(mehmetgokturk); 
        sibelgulmez.unBlock(gokhankaya); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 108... \"sibelgulmez\" logs in without error...");
        sibelgulmez.LogIn("sibelgulmez",allAccounts);

        /* Creating some test cases to test functionality of unBlock() and unFollow() methods */
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 109... \"sibelgulmez\" tries to unblock \"mehmetgokturk\" and \"gokhankaya\" without blocking them...");
        sibelgulmez.unBlock(mehmetgokturk);
        sibelgulmez.unBlock(gokhankaya); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 110... \"sibelgulmez\" tries to unblock \"sibelgulmez\" ...");
        sibelgulmez.unBlock(sibelgulmez); 
      
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 111... \"sibelgulmez\" views profile of \"sibelgulmez\" to show following numbers after unblocking stuff above...");
        sibelgulmez.viewProfile(sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 112... \"sibelgulmez\" blocks \"mehmetgokturk\" without error...");
        sibelgulmez.BlockAccount(mehmetgokturk);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 113... \"sibelgulmez\" tries to unfollow \"mehmetgokturk\" after blocking \"mehmetgokturk\" ...");
        sibelgulmez.unFollow(mehmetgokturk); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 114... \"sibelgulmez\" logs out without error...");
        sibelgulmez.LogOut();

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 115... \"mehmetgokturk\" logs in without error...");
        mehmetgokturk.LogIn("mehmetgokturk",allAccounts);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 116... \"mehmetgokturk\" tries to unfollow \"sibelgulmez\" after being blocked by \"sibelgulmez\" ...");
        mehmetgokturk.unFollow(sibelgulmez); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 117... \"mehmetgokturk\" logs out without error...");
        mehmetgokturk.LogOut();

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 118... \"sibelgulmez\" logs in without error...");
        sibelgulmez.LogIn("sibelgulmez",allAccounts);

        System.out.println("\n*********************************************************************");
        System.out.print("\nSTEP 119... \"sibelgulmez\" views profile of \"sibelgulmez\" without error");
        System.out.println(" to compare the number of following accounts below after unblock/unfollow/follow operations...");
        sibelgulmez.viewProfile(sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 120... \"sibelgulmez\" tries to follow \"mehmetgokturk\" who is blocked by \"sibelgulmez\"...");
        sibelgulmez.Follow(mehmetgokturk); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 121... \"sibelgulmez\" unblocks \"mehmetgokturk\" without error...");
        sibelgulmez.unBlock(mehmetgokturk);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 122... \"sibelgulmez\" follows \"mehmetgokturk\" without error...");
        sibelgulmez.Follow(mehmetgokturk); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 123... \"sibelgulmez\" unfollows \"erkanzerger\" without error...");
        sibelgulmez.unFollow(erkanzerger);

        System.out.println("\n*********************************************************************");
        System.out.print("\nSTEP 124... \"sibelgulmez\" views profile of \"sibelgulmez\" without error");
        System.out.println(" to compare the number of following accounts after unblock/unfollow/follow operations above...");
        sibelgulmez.viewProfile(sibelgulmez); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 125... \"sibelgulmez\" tries to send a message to \"erkanzerger\" without following \"erkanzerger\" ...");
        Message Message1 = new Message(trackMessageID++,sibelgulmez,erkanzerger,"Can you hear me?");

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 126... \"sibelgulmez\" follows \"erkanzerger\" without error...");
        sibelgulmez.Follow(erkanzerger); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 127... \"sibelgulmez\" sends a message to \"erkanzerger\" without error ...");
        Message Message2 = new Message(trackMessageID++,sibelgulmez,erkanzerger,"Can you hear me now?");

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 128... \"sibelgulmez\" views her own outbox without error...");
        sibelgulmez.viewOutbox(allAccounts);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 129... \"sibelgulmez\" blocks \"mehmetgokturk\" without error...");
        sibelgulmez.BlockAccount(mehmetgokturk);
       
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 130... \"sibelgulmez\" views profile of \"sibelgulmez\" without error to show following accounts after blocking...");
        sibelgulmez.viewProfile(sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 131... \"sibelgulmez\" blocks \"gokhankaya\" without error...");
        sibelgulmez.BlockAccount(gokhankaya);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 132... \"sibelgulmez\" views profile of \"sibelgulmez\" without error to show following accounts after blocking...");
        sibelgulmez.viewProfile(sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 133... \"sibelgulmez\" tries to follow \"gokhankaya\" who is blocked by \"sibelgulmez\"...");
        sibelgulmez.Follow(gokhankaya); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 134... \"sibelgulmez\" unblocks \"gokhankaya\" without error...");
        sibelgulmez.unBlock(gokhankaya);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 135... \"sibelgulmez\" follows \"gokhankaya\" without error...");
        sibelgulmez.Follow(gokhankaya); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 136... \"sibelgulmez\" views profile of \"sibelgulmez\" without error to show following accounts after unblock/following...");
        sibelgulmez.viewProfile(sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 137... \"sibelgulmez\" blocks \"gokhankaya\" without error...");
        sibelgulmez.BlockAccount(gokhankaya);
      
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 138... \"sibelgulmez\" views profile and posts of \"sibelgulmez\" without error to add comments...");
        sibelgulmez.viewProfile(sibelgulmez); 
        sibelgulmez.viewPosts(sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 139... \"sibelgulmez\" adds two comments to the post of \"sibelgulmez\" ...");
        sibelgulmez.addComment(Comment19,Post1,sibelgulmez);
        sibelgulmez.addComment(Comment20,Post1,sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.print("\nSTEP 140... \"sibelgulmez\" tries to uncomment the post of \"sibelgulmez\" by indicating the wrong");
        System.out.println(" account as the owner of the post...");
        sibelgulmez.unComment(Post1, erkanzerger,Comment19); 
    
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 141... \"sibelgulmez\" logs out without error...");
        sibelgulmez.LogOut();

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 142... \"mehmetgokturk\" logs in without error...");
        mehmetgokturk.LogIn("mehmetgokturk",allAccounts);

        /* Creating some test cases to test functionality of unLike(), unComment(), unBlock() and viewActionHistory() methods */
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 143... \"mehmetgokturk\" tries to view profile and posts of \"sibelgulmez\" who blocked \"mehmetgokturk\"...");
        mehmetgokturk.viewProfile(sibelgulmez);
        mehmetgokturk.viewPosts(sibelgulmez); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 144... \"mehmetgokturk\" tries to unlike and uncomment the post of \"sibelgulmez\" who blocked \"mehmetgokturk\"...");
        mehmetgokturk.unLike(Post1,sibelgulmez,Like5);
        mehmetgokturk.unComment(Post1,sibelgulmez, Comment8);
      
        System.out.println("\n*********************************************************************");
        System.out.print("\nSTEP 145... \"mehmetgokturk\" tries to uncomment the post of \"sibelgulmez\" by using a comment object that is");
        System.out.println(" not associated with \"mehmetgokturk\" ...");
        mehmetgokturk.unComment(Post1,sibelgulmez, Comment10); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 146... \"mehmetgokturk\" logs out without error...");
        mehmetgokturk.LogOut();

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 147... \"gokhankaya\" logs in without error...");
        gokhankaya.LogIn("gokhankaya",allAccounts);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 148... \"gokhankaya\" tries to view profile and posts of \"sibelgulmez\" who blocked \"gokhankaya\"...");
        gokhankaya.viewProfile(sibelgulmez); 
        gokhankaya.viewPosts(sibelgulmez); 
    
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 149... \"gokhankaya\" tries to unlike and uncomment the post of \"sibelgulmez\" who blocked \"gokhankaya\"...");
        gokhankaya.unLike(Post1,sibelgulmez,Like2);
        gokhankaya.unComment(Post1,sibelgulmez, Comment13); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 150... \"gokhankaya\" logs out without error...");
        gokhankaya.LogOut();
      
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 151... \"sibelgulmez\" logs in without error...");
        sibelgulmez.LogIn("sibelgulmez",allAccounts);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 152... \"sibelgulmez\" unblocks \"mehmetgokturk\" and \"gokhankaya\" without error...");
        sibelgulmez.unBlock(mehmetgokturk);
        sibelgulmez.unBlock(gokhankaya);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 153... \"sibelgulmez\" logs out without error...");
        sibelgulmez.LogOut();

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 154... \"mehmetgokturk\" logs in without error...");
        mehmetgokturk.LogIn("mehmetgokturk",allAccounts);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 155... \"mehmetgokturk\" views profile and posts of \"sibelgulmez\" without error to add/remove like and comment...");
        mehmetgokturk.viewProfile(sibelgulmez);
        mehmetgokturk.viewPosts(sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.print("\nSTEP 156... \"mehmetgokturk\" tries to unlike the post of \"sibelgulmez\" by indicating the wrong account");
        System.out.println(" as the owner of the post...");
        mehmetgokturk.unLike(Post1,cemayar,Like5); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 157... \"mehmetgokturk\" unlikes the post of \"sibelgulmez\" without error...");
        mehmetgokturk.unLike(Post1,sibelgulmez,Like5);
        
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 158... \"mehmetgokturk\" uncomments the post of \"sibelgulmez\" without error...");
        mehmetgokturk.unComment(Post1,sibelgulmez, Comment8);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 159... \"mehmetgokturk\" views his own action history without error...");
        mehmetgokturk.viewActionHistory();

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 160... \"mehmetgokturk\" logs out without error...");
        mehmetgokturk.LogOut();

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 161... \"gokhankaya\" logs in without error...");
        gokhankaya.LogIn("gokhankaya",allAccounts);

        /* Creating some test cases to test functionality of unLike() and viewActionHistory() methods */
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 162... \"gokhankaya\" views profile and posts of \"sibelgulmez\" without error to remove like...");
        gokhankaya.viewProfile(sibelgulmez);
        gokhankaya.viewPosts(sibelgulmez);
        
        System.out.println("\n*********************************************************************");
        System.out.print("\nSTEP 163... \"gokhankaya\" tries to unlike the post of \"sibelgulmez\" by using a like object that is not");
        System.out.println(" associated with this post...");
        gokhankaya.unLike(Post2,sibelgulmez,Like2); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 164... \"gokhankaya\" unlikes the post of \"sibelgulmez\" without error...");
        gokhankaya.unLike(Post1,sibelgulmez,Like2);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 165... \"hasaricelebi\" views his own action history without error...");
        hasaricelebi.viewActionHistory(); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 166... \"gokhankaya\" logs out without error...");
        gokhankaya.LogOut();

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 167... \"gizemsungu\" logs in without error...");
        gizemsungu.LogIn("gizemsungu",allAccounts);

        /* Creating some test cases to test functionality of unLike(), unComment() and viewActionHistory() methods */
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 168... \"gizemsungu\" views profile and posts of \"sibelgulmez\" without error to remove like/comment...");
        gizemsungu.viewProfile(sibelgulmez);
        gizemsungu.viewPosts(sibelgulmez);
       
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 169... \"gokhankaya\" tries to unlike the post of \"sibelgulmez\" without logging in...");
        gokhankaya.unLike(Post1,sibelgulmez,Like2);
      
        System.out.println("\n*********************************************************************");
        System.out.print("\nSTEP 170... \"gizemsungu\" tries to unlike the post of \"sibelgulmez\" by using a like object that is not");
        System.out.println(" associated with this post...");
        gizemsungu.unLike(Post3,sibelgulmez,Like1); 

        System.out.println("\n*********************************************************************");
        System.out.print("\nSTEP 171... \"gizemsungu\" tries to unlike the post of \"sibelgulmez\" by using a like object that is not associated");
        System.out.println(" with \"gizemsungu\" ...");
        gizemsungu.unLike(Post1, sibelgulmez,Like2); 
      
        System.out.println("\n*********************************************************************");
        System.out.print("\nSTEP 172... \"gizemsungu\" tries to unlike the post of \"sibelgulmez\" by using a like object that is not associated");
        System.out.println(" with \"gizemsungu\" ...");
        gizemsungu.unLike(Post1,sibelgulmez,Like3); 
      
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 173... \"gizemsungu\" uncomments the post of \"sibelgulmez\" without error...");
        gizemsungu.unComment(Post1,sibelgulmez, Comment1);
    
        System.out.println("\n*********************************************************************");
        System.out.print("\nSTEP 174... \"gizemsungu\" tries to uncomment the post of \"sibelgulmez\" by using a comment object that is not");
        System.out.println(" associated with this post...");
        gizemsungu.unComment(Post1,sibelgulmez,Comment16); 
      
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 175... \"gizemsungu\" views his own action history without error...");
        gizemsungu.viewActionHistory();

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 176... \"gizemsungu\" logs out without error...");
        gizemsungu.LogOut();
      
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 177... \"sametgul\" logs in without error...");
        sametgul.LogIn("sametgul",allAccounts);

        /* Creating some test cases to test functionality of unLike(), unComment() and unBlock() methods */
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 178... \"sametgul\" tries to unlike the post of \"sibelgulmez\" without viewing profile of \"sibelgulmez\"...");
        sametgul.unLike(Post1,sibelgulmez,Like8);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 179... \"sametgul\" tries to uncomment the post of \"sibelgulmez\" without viewing profile of \"sibelgulmez\"...");
        sametgul.unComment(Post1,sibelgulmez,Comment11);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 180... \"sametgul\" blocks \"sibelgulmez\" without error...");
        sametgul.BlockAccount(sibelgulmez); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 181... \"sametgul\" tries to unlike the post of \"sibelgulmez\" who is blocked by \"sametgul\" ...");
        sametgul.unLike(Post1,sibelgulmez,Like8);
     
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 182... \"sametgul\" tries to uncomment the post of \"sibelgulmez\" who is blocked by \"sametgul\" ...");
        sametgul.unComment(Post1,sibelgulmez,Comment11); 
    
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 183... \"sametgul\" unblocks \"sibelgulmez\" without error...");
        sametgul.unBlock(sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.print("\nSTEP 184... \"sametgul\" views profile of \"sibelgulmez\" to test if unlike/uncomment can be done after viewing profile"); 
        System.out.println(" but not viewing posts...");
        sametgul.viewProfile(sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.print("\nSTEP 185... \"sametgul\" tries to uncomment the post of \"sibelgulmez\" by using a comment object that is not");
        System.out.println(" associated with this post...");
        sametgul.unComment(Post1,sibelgulmez,Comment15); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 186... \"sametgul\" tries to unlike the post of \"sibelgulmez\" without viewing posts of \"sibelgulmez\"...");
        sametgul.unLike(Post1,sibelgulmez,Like8);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 187... \"sametgul\" tries to uncomment the post of \"sibelgulmez\" without viewing posts of \"sibelgulmez\"...");
        sametgul.unComment(Post1,sibelgulmez,Comment11); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 188... \"sametgul\" views posts of \"sibelgulmez\" without error...");
        sametgul.viewPosts(sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 189... \"sametgul\" unlikes the post of \"sibelgulmez\" without error...");
        sametgul.unLike(Post1,sibelgulmez,Like8);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 190... \"sametgul\" uncomments the post of \"sibelgulmez\" without error...");
        sametgul.unComment(Post1,sibelgulmez,Comment11);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 191... \"sametgul\" views post interactions of \"sibelgulmez\" to show uncomment and unlike operations' success...");
        sametgul.viewInteractions(sibelgulmez,allAccounts);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 192... \"sametgul\" logs out without error...");
        sametgul.LogOut(); 
       
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 193... \"cemayar\" logs in without error...");
        cemayar.LogIn("cemayar",allAccounts);

        /* Creating some test cases to test functionality of unLike(), unComment() and unBlock() methods */
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 194... \"cemayar\" tries to uncomment the post of \"sibelgulmez\" without viewing profile of \"sibelgulmez\"...");
        cemayar.unComment(Post1,sibelgulmez,Comment10); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 195... \"cemayar\" views the profile of \"sibelgulmez\" without error...");
        cemayar.viewProfile(sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 196... \"cemayar\" tries to uncomment the post of \"sibelgulmez\" without viewing posts of \"sibelgulmez\"...");
        cemayar.unComment(Post1,sibelgulmez,Comment10); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 197... \"cemayar\" views the posts of \"sibelgulmez\" without error...");
        cemayar.viewPosts(sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 198... \"cemayar\" blocks \"sibelgulmez\" without error...");
        cemayar.BlockAccount(sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 199... \"cemayar\" tries to unlike the post of \"sibelgulmez\" who is blocked by \"cemayar\" ...");
        cemayar.unLike(Post1,sibelgulmez,Like7);
   
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 200... \"cemayar\" tries to uncomment the post of \"sibelgulmez\" who is blocked by \"cemayar\" ...");
        cemayar.unComment(Post1,sibelgulmez,Comment10);
 
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 201... \"cemayar\" unblocks \"sibelgulmez\" without error...");
        cemayar.unBlock(sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 202... \"cemayar\" views profile and posts of \"sibelgulmez\" to show \"cemayar\" has unblocked \"sibelgulmez\"...");
        cemayar.viewProfile(sibelgulmez);
        cemayar.viewPosts(sibelgulmez);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 203... \"cemayar\" views post interactions of \"sibelgulmez\" to compare before/after of unlike/uncomment below...");
        cemayar.viewInteractions(sibelgulmez,allAccounts);
        
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 204... \"cemayar\" unlikes the post of \"sibelgulmez\" without error...");
        cemayar.unLike(Post1,sibelgulmez,Like7); 

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 205... \"cemayar\" uncomments the post of \"sibelgulmez\" without error...");
        cemayar.unComment(Post1,sibelgulmez,Comment10); 
   
        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 206... \"cemayar\" views post interactions of \"sibelgulmez\" to compare before/after of unlike/uncomment above...");
        cemayar.viewInteractions(sibelgulmez,allAccounts);

        System.out.println("\n*********************************************************************");
        System.out.println("\nSTEP 207... \"cemayar\" logs out without error...");
        cemayar.LogOut(); 
        System.out.println("\n*********************************************************************");

        System.out.println("---------------------------- SCENERIO 4 ENDS ----------------------------");
  
    }
}

