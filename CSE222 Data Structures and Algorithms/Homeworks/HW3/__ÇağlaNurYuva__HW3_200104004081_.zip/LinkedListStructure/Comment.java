
/**
 * Comment class to represent a comment made by an account on a post.
 *
 * @file     Comment.java
 * @author   Çağla Nur Yuva
 * @brief    Function implementations related to comment interaction 
 * @version  1.0
 * @date     2023-04-05
 */
public class Comment extends Interaction {

    /** The text content of the comment. */
    private String content;


    /**
     * Constructs a new Comment object.
     * @param interactionID The unique ID of the interaction.
     * @param accountID The unique ID of the account that made the comment.
     * @param postID The unique ID of the post that the comment is made on.
     * @param content The text content of the comment.
     */
    public Comment(final int interactionID, final int accountID, final int postID, final String content) {
        super(interactionID, accountID, postID);
        this.content = content;  
    } 


    /**
     * Returns the text content of the comment.
     * @return String The text content of the comment.
     */
    public String getContent() { return content; } 

}
