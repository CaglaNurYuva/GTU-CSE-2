
import java.util.LinkedList;

/**
 * This class runs tests for the social media software.
 * It contains main method to test methods of other classes.
 * 
 * @file    TestClass2.java
 * @author  Çağla Nur Yuva
 * @brief   Basic social media software test
 * @version 1.0
 * @date    2023-04-05
 */
public class TestClass2 {

    /**
     * Runs tests for the social media software.
     * @param args An array of strings for command-line arguments.
     */
    public static void main(String[] args) {

        int trackAccountID = 1;  /* Keeps track of Account ID */
        int trackPostID = 1;     /* Keeps track of Post ID */
        int trackMessageID = 0;  /* Keeps track of Message ID */
        int trackInteractionID = 1; /* Keeps track of InteractionID */
        LinkedList<Account> allAccounts = new LinkedList<Account>(); /* Keeps all created accounts */

        System.out.println("---------------------------- SCENERIO 1 STARTS ----------------------------");

        /* Creating accounts and add them to the allAccounts array. */
        System.out.println("Step 1... Creating accounts...");
        Account gizemsungu = new Account(trackAccountID++, "gizemsungu", "13.01.1993", "Ankara");
        allAccounts.add(gizemsungu);
        System.out.println("An account with username gizemsungu has been created.");

        Account sibelgulmez = new Account(trackAccountID++, "sibelgulmez","10.03.1995", "Istanbul");
        allAccounts.add(sibelgulmez);
        System.out.println("An account with username sibelgulmez has been created.");
      
        Account gokhankaya = new Account(trackAccountID++, "gokhankaya", "17.06.1988", "Samsun");
        allAccounts.add(gokhankaya);
        System.out.println("An account with username gokhankaya has been created.");

        /* Logging into an account */  
        System.out.println("\nStep 2... Logging into an account (username: sibelgulmez)…");
        sibelgulmez.LogIn("sibelgulmez",allAccounts);

        /* Sharing posts */
        Post post1 = new Post(trackPostID++,sibelgulmez.getAccountID(),"I like Java.");
        Post post2 = new Post(trackPostID++,sibelgulmez.getAccountID(),"Java the coffee...");
        System.out.println("\nStep 3... Sharing two posts…");
        sibelgulmez.addPost(post1);
        sibelgulmez.addPost(post2);

        /* Following accounts */
        System.out.println("\nStep 4... Following gizemsungu and gokhankaya...");
        sibelgulmez.Follow(gizemsungu);
        sibelgulmez.Follow(gokhankaya);

        /* Logging out from an account */
        System.out.println("\nStep 5... Logging out from account 'sibelgulmez'…");
        sibelgulmez.LogOut();

        /* Logging into an account */
        System.out.println("\nStep 6... Logging into another account (username: gokhankaya)…");
        gokhankaya.LogIn("gokhankaya",allAccounts);

        /* Viewing profile of an account */
        System.out.println("\nStep 7... Viewing sibelgulmez's profile...");
        gokhankaya.viewProfile(sibelgulmez);

        /* Viewing posts of an account */
        System.out.println("\nStep 8... Viewing sibelgulmez'posts...");
        gokhankaya.viewPosts(sibelgulmez);

        /* Liking a post */
        System.out.println("\nStep 9... Liking a post of sibelgulmez...");
        Like like1 = new Like(trackInteractionID++, gokhankaya.getAccountID(), post1.getPostID());
        gokhankaya.addLike(like1, post1,sibelgulmez);

        /* Adding a comment */
        System.out.println("\nStep 10... Adding a comment on a post of sibelgulmez...");
        Comment comment1 = new Comment(trackInteractionID++, gokhankaya.getAccountID(), post1.getPostID(), "me too!");
        gokhankaya.addComment(comment1, post1,sibelgulmez);

        /* Following accounts */
        System.out.println("\nStep 11... Following sibelgulmez and gizemsungu...");
        gokhankaya.Follow(sibelgulmez);
        gokhankaya.Follow(gizemsungu);

        /* Sending a message to another account */
        System.out.println("\nStep 12... Sending a message to gizemsungu...");
        Message message1 = new Message(trackMessageID++, gokhankaya, gizemsungu,"This homework is too easy!");

        /* Logging out from an account */
        System.out.println("\nStep 13... Logging out from account 'gokhankaya'..");
        gokhankaya.LogOut();

        /* Logging into an account */
        System.out.println("\nStep 14... Logging into another account (username: gizemsungu)…");
        gizemsungu.LogIn("gizemsungu",allAccounts);

        /* Checking outbox of an account */
        System.out.println("\nStep 15... Checking outbox...");
        gizemsungu.CheckOutbox();

        /* Checking inbox of an account */
        System.out.println("\nStep 16... Checking inbox...");
        gizemsungu.CheckInbox();

        /* Viewing inbox of an account */
        System.out.println("\nStep 17... Viewing inbox..."); 
        gizemsungu.viewInbox(allAccounts);

        /* Viewing profile of an account */
        System.out.println("\nStep 18... Viewing sibelgulmez's profile...");
        gizemsungu.viewProfile(sibelgulmez);

        /* Viewing posts of an account */
        System.out.println("\nStep 19... Viewing sibelgulmez's posts...");
        gizemsungu.viewPosts(sibelgulmez);

        /* Viewing posts' interactions of an account */
        System.out.println("\nStep 20... Viewing sibelgulmez's posts' interactions...");
        gizemsungu.viewInteractions(sibelgulmez, allAccounts);

        /* Liking posts */
        System.out.println("\nStep 21... Liking sibelgulmez's posts...");
        Like like2 = new Like(trackInteractionID++, gizemsungu.getAccountID(), post1.getPostID());
        Like like3 = new Like(trackInteractionID++, gizemsungu.getAccountID(), post2.getPostID());
        gizemsungu.addLike(like2,post1,sibelgulmez);
        gizemsungu.addLike(like3,post2,sibelgulmez);

        /* Viewing posts' interactions of an account */
        System.out.println("\nStep 22... Viewing sibelgulmez's posts' interactions...");
        gizemsungu.viewInteractions(sibelgulmez, allAccounts);

        System.out.println("---------------------------- SCENERIO 1 ENDS ------------------------------");
      
        System.out.println("---------------------------- SCENERIO 2 STARTS ------------------------------");

        /* Logging into an account */
        System.out.println("\nStep 1... \"gizemsungu\" logs in.");
        gizemsungu.LogIn("gizemsungu",allAccounts);

        /* Sharing posts */
        System.out.println("\nStep 1-a... \"gizemsungu\" shares a post (let's call it Post1).");
        Post Post1 = new Post(trackPostID++,gizemsungu.getAccountID(),"C is a nightmare.");
        gizemsungu.addPost(Post1);

        System.out.println("\nStep 1-b... \"gizemsungu\" shares another post (let's call it Post2).");
        Post Post2 = new Post(trackPostID++,gizemsungu.getAccountID(),"I love chess.");
        gizemsungu.addPost(Post2);

        /* Logging out from an account */
        System.out.println("\nStep 1-c... \"gizemsungu\" logs out.");
        gizemsungu.LogOut();

        /* Logging into an account */
        System.out.println("\nStep 2... \"sibelgulmez\" logs in.");
        sibelgulmez.LogIn("sibelgulmez",allAccounts);

        /* Viewing profile of an account */
        System.out.println("\nStep 2-a... \"sibelgulmez\" views the profile of \"gizemsungu\".");
        sibelgulmez.viewProfile(gizemsungu);

        /* Liking a post */
        System.out.println("\nStep 2-b... \"sibelgulmez\" likes Post1.");
        Like Like1 = new Like(trackInteractionID++, sibelgulmez.getAccountID(), Post1.getPostID()); 
        sibelgulmez.addLike(Like1, Post1,gizemsungu);
   
        /* Logging out from an account */ 
        System.out.println("\nStep 2-c... \"sibelgulmez\" logs out.");
        sibelgulmez.LogOut(); 

        /* Logging into an account */ 
        System.out.println("\nStep 3... \"gokhankaya\" logs in.");
        gokhankaya.LogIn("gokhankaya",allAccounts);

        /* Viewing profile of an account */ 
        System.out.println("\nStep 3-a... \"gokhankaya\" views the profile of \"gizemsungu\"."); 
        gokhankaya.viewProfile(gizemsungu);

        /* Commenting a post */
        System.out.println("\nStep 3-b... \"gokhankaya\" comments on Post2 (ex: Nice!)."); 
        Comment Comment1 = new Comment(trackInteractionID++, gokhankaya.getAccountID(), Post2.getPostID(), "me too!");
        gokhankaya.addComment(Comment1, Post2,gizemsungu);

        /* Sending a message to another account */ 
        System.out.println("\nStep 3-c... \"gokhankaya\" sends a message to  \"gizemsungu\" (ex: \"Hello!\")."); 
        Message Message1 = new Message(trackMessageID++,gokhankaya,gizemsungu,"Hello!");
      
        /* Logging out from an account */        
        System.out.println("\nStep 3-d... \"gokhankaya\" logs out.");
        gokhankaya.LogOut(); 
      
        /* Logging into an account */ 
        System.out.println("\nStep 4... \"gizemsungu\" logs in.");
        gizemsungu.LogIn("gizemsungu",allAccounts);

        /* Viewing profile of an account */ 
        System.out.println("\nStep 4-a... \"gizemsungu\" views her own profile."); 
        gizemsungu.viewProfile(gizemsungu);

        /* Viewing inbox of an account */
        System.out.println("\nStep 4-b... \"gizemsungu\" reads the message from \"gokhankaya\"."); 
        gizemsungu.viewInbox(allAccounts);

        System.out.println("---------------------------- SCENERIO 2 ENDS ------------------------------");
    
    }

}
