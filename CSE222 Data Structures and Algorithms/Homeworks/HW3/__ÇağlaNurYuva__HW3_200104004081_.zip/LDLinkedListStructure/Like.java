
/**
 * Like class to represent a like interaction on a post.
 *
 * @file     Like.java
 * @author   Çağla Nur Yuva
 * @brief    Constructor implementation 
 * @version  1.0
 * @date     2023-04-05
 */
public class Like extends Interaction {

    /**
     * Constructs a new Like object.
     * @param interactionID The unique ID of the interaction.
     * @param accountID The unique ID of the account that liked the post.
     * @param postID The unique ID of the post that is liked.
     */
    public Like(final int interactionID,final int accountID, final int postID) {
        super(interactionID, accountID, postID);
    }  
    
}
