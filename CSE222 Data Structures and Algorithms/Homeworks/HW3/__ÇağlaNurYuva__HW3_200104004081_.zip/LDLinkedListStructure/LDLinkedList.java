
import java.util.AbstractList;
import java.util.List;
import java.util.NoSuchElementException;


/**
 * LDLinkedList class to implement linked list that supports lazily deleting nodes.
 *
 * @param <E> the type of elements in this list
 * @file     LDLinkedList.java
 * @author   Çağla Nur Yuva
 * @brief    Function implementations related to linked list and its features 
 * @version  1.0
 * @date     2022-04-05
 */
public class LDLinkedList<E> extends AbstractList<E> implements List<E> {

    /** Keeps head node */
    private Node<E> head;

    /** Keeps size of this linked list */
    private int size;

    /** Keeps the number of nodes that are lazily deleted */
    private int lazilyDeletedCount;


    /**
     * Constructs an empty linked list and initializes the class variables.
     */
    public LDLinkedList() {
        this.head = null;
        this.size = 0;
        this.lazilyDeletedCount = 0;
    }

    /**
     * Node class represents a node in this linked list.
     * @param <E> the type of element in this node.
     */
    private class Node<E> {
  
        /** Keeps data of this node */
        private E data;

        /** Keeps the next node of this node */
        private Node<E> next;

        /** Keeps the information if this node is lazily deleted or not */
        private boolean isLazilyDeleted;

        /**
         * Constructs a node with the given data and initializes the class variables.
         * @param data the data to store in this node
         */
        Node(E data) {
            this.data = data;
            next = null;
            isLazilyDeleted = false;
        }


        /**
         * Returns the data stored in this node.
         * @return the data stored in this node
         */
        private E getData() { return data; }

        /**
         * Sets the data of this node to the given data.
         * @param data the data to set
         */
        private void setData(E data) { this.data = data; }

        /**
         * Returns the next node in this linked list.
         * @return Node<E> the next node in this linked list
         */
        private Node<E> getNext() { return next; }

        /**
         * Sets the next node in this linked list to the given node.
         * @param next the next node in this linked list
         */
        private void setNext(Node<E> next) { this.next = next; }

        /**
         * Returns if this node is lazily deleted or not.
         * @return true if this node is lazily deleted, false otherwise
         */
        private boolean isLazilyDeleted() { return isLazilyDeleted; }

        /**
         * Sets the isLazilyDeleted variable of this node to the given value.
         * @param isLazilyDeleted the value to set the isLazilyDeleted variable to
         */
        private void setLazilyDeleted(boolean isLazilyDeleted) { this.isLazilyDeleted = isLazilyDeleted; }
    }


    /**
     * {@inheritDoc}
     * Returns the number of non-lazily deleted elements in this list.
     * @return int the number of non-lazily deleted elements in this list
     */
    @Override
    public int size() { return size - lazilyDeletedCount; }


    /**
     * {@inheritDoc}
     * Returns the element at the specified position in this list.
     * @param index the index of the element to return
     * @return the element at the specified position in this list
     * @throws IndexOutOfBoundsException if the index is out of range.
     * @throws NoSuchElementException if there is no non-lazily deleted element at the specified index
     */
    @Override
    public E get(int index) {

        /* Throwing error if the index is out of range */
        if(index < 0 || index >= size) { throw new IndexOutOfBoundsException(); }
      
        Node<E> currentNode = head;
        int currentIndex = 0;
      
        /* Traversing the linked list */
        while(currentNode != null) {

            /* Ignoring the nodes that are marked as lazily deleted. */
            if(!currentNode.isLazilyDeleted()) {

                /* Finding the node at the given index */
                if(currentIndex == index) { return currentNode.getData(); }
                currentIndex++;  
            }
            currentNode = currentNode.getNext(); /* Setting the currentNode variable to the next node */
        }

        /* Throwing error since there is no non-lazily deleted element at the index */
        throw new NoSuchElementException(); 
    }


    /**
     * {@inheritDoc}
     * Sets the element at the specified position in this list with the specified element.
     * @param index the index of the element to set
     * @param element the element to be stored at the specified position
     * @return the old value of the node at the specified index
     * @throws IndexOutOfBoundsException if the index is out of range.
     * @throws NoSuchElementException if there is no non-lazily deleted element at the specified index
     */
    @Override
    public E set(int index, E element) {

        /* Throwing error if the index is out of range */
        if(index < 0 || index >= size) { throw new IndexOutOfBoundsException(); }
      
        Node<E> currentNode = head;
        int currentIndex = 0;
      
        /* Traversing the linked list */
        while(currentNode != null) {

            /* Ignoring the nodes that are marked as lazily deleted. */
            if(!currentNode.isLazilyDeleted()) {

                /* Finding the node at the given index */
                if(currentIndex == index) {
                    E oldValue = currentNode.getData();
                    currentNode.setData(element); /* Setting data */
                    return oldValue;
                }
                currentIndex++;
            }
            currentNode = currentNode.getNext(); /* Setting the currentNode variable to the next node */
        }

        /* Throwing error since there is no non-lazily deleted element at the index */
        throw new NoSuchElementException();
    }


    /**
     * {@inheritDoc}
     * Adds the specified element to the end of this list.
     * @param element the element to be added to the end of this list.
     * @return true if the element has been added to the list, false otherwise.
     */
    @Override
    public boolean add(E element) {

        Node<E> newNode = new Node<>(element); /* Creating a new node */

        /* If the head of the list is null, the empty node is head node. */
        if(head == null) { head = newNode; } 

        else {
            Node<E> currentNode = head;

            /* Traversing the linked list */
            while(currentNode.getNext() != null) { currentNode = currentNode.getNext(); }
            currentNode.setNext(newNode); /* Setting first empty node as new node */
        }
        size++;
        return true;
    }


    /**
     * {@inheritDoc}
     * Removes the element at the specified index in this list, if certain conditions are met.
     * Marks the element at the specified index in this list as deleted, if certain conditions are met.
     * @param index the index of the element to be removed.
     * @return the value of the removed element
     * @throws IndexOutOfBoundsException if the index is out of range.
     * @throws NoSuchElementException if there is no non-lazily deleted element at the specified index.
     */
    @Override
    public E remove(int index) {

        /* Throwing error if the index is out of range */
        if(index < 0 || index >= size) throw new IndexOutOfBoundsException();
      
        Node<E> currentNode = head;
        Node<E> prev = null;
        int currentIndex = 0;
      
        /* Traversing the linked list */
        while(currentNode != null) {

            /* Ignoring the nodes that are marked as lazily deleted. */
            if(!currentNode.isLazilyDeleted()) {

                /* Finding the specified index */
                if(currentIndex == index) {
                    currentNode.setLazilyDeleted(true); /* Setting the node as lazily deleted. */
                    lazilyDeletedCount++;
                    if(this.lazilyDeletedCount >= 2)  this.removeLazyDeletedNodes(); /* Removing lazily deleted nodes. */
                    return currentNode.getData();
                }
                currentIndex++;
            }

            /* Arranging previous and current nodes again */
            prev = currentNode;
            currentNode = currentNode.getNext();
        }

        /* Throwing error since there is no non-lazily deleted element at the index */
        throw new NoSuchElementException(); 
    }


    /**
     * Searches for the specified element in this list and returns its index.
     * @param element the element to search for
     * @return int the index of the first occurrence of the element in this list,
     * or -1 if the element is not found.
     */
    public int search(E element) {
        Node<E> currentNode = head;
        int currentIndex = 0;
      
        /* Traversing the linked list */
        while(currentNode != null) {

            /* Ignoring the nodes that are marked as lazily deleted. */
            if(!currentNode.isLazilyDeleted()) {
                if(currentNode.getData().equals(element)) { return currentIndex; }
                currentIndex++;
            }
            currentNode = currentNode.getNext();  /* Setting the currentNode variable to the next node */
        }
        return -1; /* Returning -1 if the element is not found */
    }


    /**
     * Removes all lazily deleted nodes from this list.
     */
    private void removeLazyDeletedNodes() {

        Node<E> currentNode = this.head;
        Node<E> previousNode = null;

        /* Traversing the linked list */
        while(currentNode != null) {

            /* Finding the nodes that are marked as lazily deleted. */
            if(currentNode.isLazilyDeleted()) {

               /* Removing a lazily deleted node */
                if(previousNode == null) { this.head = currentNode.getNext(); } 
                else { previousNode.setNext(currentNode.getNext()); }

                /* Arranging size of this list again */
                this.lazilyDeletedCount--;
                this.size--;
            } 
              
            else { previousNode = currentNode; }
            currentNode = currentNode.getNext();  /* Setting the currentNode variable to the next node */
        }
    }
  
}
