
/**
 * Message class to represent a message.
 *
 * @file     Message.java
 * @author   Çağla Nur Yuva
 * @brief    Function implementations related to messages 
 * @version  1.0
 * @date     2023-04-05
 */
public class Message {

    /** The unique ID of the message. */
    private int messageID;

    /** The unique ID of the account who sent the message. */
    private int senderID;

    /** The unique ID of the account who received the message. */
    private int receiverID;

    /** The text content of the message. */
    private String content;


    /**
     * Constructs a new Message object.
     * Checks necessary conditions to send a message.
     * If the conditions are met, message is sent to both outbox of sender and inbox of receiver.      
     * @param messageID The unique ID of the message.
     * @param sender The account that sent the message.
     * @param receiver The account that received the message.
     * @param content The text content of the message.
     */
    public Message(final int messageID,final Account sender, final Account receiver, final String content) {

        /* Initializing the class variables with the given values. */
        this.messageID = messageID;
        this.senderID = sender.getAccountID();
        this.receiverID = receiver.getAccountID();
        this.content = content;

        /* Checking if necessary conditions are met to send a message. */
        if(!sender.getIsLogin()) System.out.println("You can't send a message without logging in.");
        else if(this.senderID == this.receiverID) System.out.println("You can't send a message to yourself.");
        else {
            if((!receiver.isBlocked(senderID))) {
                if(!sender.isBlocked(receiverID)) {
                    if(sender.isFollowing(receiver)) {

                        /* Sending a message */
                        sender.addMessageToOutbox(this);
                        receiver.addMessageToInbox(this);

                        /* Keeping record of action history */
                        sender.getActionHistory().add("- You sent a message to " + receiver.getAccUsername()); 
                        receiver.getActionHistory().add("- You received a message from " + sender.getAccUsername());
                    }
                    else { 
                        System.out.println("You can't send a message because you are not following the account that will receive the message."); 
                    }
                }
             
                else { System.out.println("You can't send a message to an account you blocked."); }
            }

            else { System.out.println("You can't send a message to an account blocked you."); }
        }  
    }  


    /**
     * Returns the ID of the message.
     * @return int The ID of the message.
     */
    public int getMessageID() { return this.messageID; } 

    /**
     * Returns the ID of the account that sent the message.
     * @return int The ID of the account that sent the message.
     */
    public int getSenderID() { return this.senderID; } 

    /**
     * Returns the ID of the account that received the message.
     * @return int The ID of the account that received the message.
     */
    public int getReceiverID() { return this.receiverID; } 

    /**
     * Returns the text content of the message.
     * @return String The text content of the message.
     */
    public String getContent() { return this.content; } 
  
}
