package homework1;


/**
 * Interaction class to represent an interaction between an account and a post.
 *
 * @file     Interaction.java
 * @author   Çağla Nur Yuva
 * @brief    Function implementations related to interaction 
 * @version  1.0
 * @date     2023-03-19
 */
public abstract class Interaction {
  
    /** The unique ID of the interaction. */
    protected int interactionID; 

    /** The unique ID of the account that made the interaction. */
    protected int accountID;

    /** The unique ID of the post that the interaction is made on. */
    protected int postID;


    /**
     * Constructs a new Interaction object.
     * @param interactionID The unique ID of the interaction.
     * @param accountID The unique ID of the account that made the interaction.
     * @param postID The unique ID of the post that the interaction is made on.
     */
    public Interaction(final int interactionID, final int accountID, final int postID) {

        /* Initializing the class variables with the given values. */
        this.interactionID = interactionID;
        this.accountID = accountID;
        this.postID = postID;
    }  


    /**
     * Returns the ID of the account that made the interaction.
     * @return int The ID of the account.
     */
    public int getAccountID() { return accountID; } 


   /**
    * Returns the ID of the post that the interaction is made on.
    * @return int The ID of the post.
    */
    public int getPostID() { return postID; } 

  
}