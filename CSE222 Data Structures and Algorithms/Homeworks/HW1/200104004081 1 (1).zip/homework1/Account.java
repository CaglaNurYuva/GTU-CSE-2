package homework1;

/**
 * Account class to represent a social media account.
 *
 * @file     Account.java
 * @author   Çağla Nur Yuva
 * @brief    Function implementations needed for basic social media account
 * @version  1.0
 * @date     2023-03-19
 */
public class Account {


    /** The unique ID of the account. */
    private int accountID;

    /** The username of the account. */
    private String username;

    /** The birth date of the account.*/
    private String birthDate;

    /** The location of the account. */
    private String location;

    /** The array of posts shared by the account. */
    private Post[] posts;

    /** The array of accounts that the account is following. */
    private Account[] following;

    /** The array of accounts that are following the account. */
    private Account[] followers;

    /** The array of messages received by the account. */
    private Message[] inbox; 

    /** The array of messages sent by the account. */
    private Message[] outbox;

    /** The array of account IDs that are blocked by the account. */
    private int[] blockedAccountsID;

    /** The account ID of the last account that this account visited his/her profile. */
    private int lastAccID_onProfile;

    /** The account ID of the last account that this account visited his/her posts. */
    private int lastAccID_onPost;

    /** Whether the account is currently logged in or not. */
    private boolean isLogin;  
   

    /** 
     * Constructs a new Account object.
     * @param accountID The account ID.
     * @param username The username of the account.
     * @param birthDate The birth date of the account.
     * @param location The location of the account.
     */
    public Account(final int accountID, final String username, final String birthDate, final String location) { 

        /* Initializing the class variables with the given values. */
        this.accountID = accountID; 
        this.username = username;   
        this.birthDate = birthDate;
        this.location = location;
        this.posts = new Post[100];
        this.following = new Account[100];
        this.followers = new Account[100];
        this.inbox = new Message[100];
        this.outbox = new Message[100];
        this.blockedAccountsID = new int[100];
        this.isLogin = false;
        this.lastAccID_onProfile = 0;
        this.lastAccID_onPost = 0;

        /* Setting all array elements to default values, which is null or 0. */
        for(int i = 0; i < this.posts.length; i++) { this.posts[i] = null; }
        for(int i = 0; i < this.following.length; i++) { this.following[i] = null; }
        for(int i = 0; i < this.followers.length; i++) { this.followers[i] = null; }
        for(int i = 0; i < this.inbox.length; i++) { this.inbox[i] = null; }
        for(int i = 0; i < this.outbox.length; i++) { this.outbox[i] = null; }
        for(int i = 0; i < this.blockedAccountsID.length; i++) { this.blockedAccountsID[i] = 0; }
       
    } 

    /** 
     * Logs out from the account.
     */
    public void LogOut() {

       /* Checking if the account has already logged in. */ 
       if (!isLogin) {
          System.out.println("You are not logged in.");
          return;
        } 

        /* Logging out. */
        else {
          isLogin = false;
          this.lastAccID_onProfile = 0;
          this.lastAccID_onPost = 0;
        }  
    } 

    /** 
     * Adds a new post to the account's posts.
     * @param post The post to be added.
     */
    public void addPost(final Post post) { 

        /* Checking if the account is logged in. */
        if (!this.isLogin) {
            System.out.println("You need to log in to share a post.");
            return;
        }
      
        /* Sharing a post */
        for(int i = 0; i < this.posts.length; i++) {
            if(this.posts[i] == null) {
                this.posts[i] = post;
                break;
            }

            /* Checking if the same post ID will be used again or not. */
            if(this.posts[i].getPostID() == post.getPostID()) {
                System.out.println("Adding post is failed. Post ID has already been used.");
                return;
            }
        }
    } 

    /** 
     * Returns the ID of the account.
     * @return int The account ID.
     */
    public int getAccountID() { return this.accountID; } 

    /** 
     * Returns the number of posts that the account has.
     * @return int The number of posts.
     */
    private int getPostsNum() {  
      
        int i = 0;
        for(i = 0; this.posts[i] != null; i++) { /* empty */ } /* Iterating through posts array */
        return i;
    }  

    /** 
     * Returns the array of posts of the account.
     * @return Post[] The array of posts of the account.
     */
    private Post[] getPosts() { return posts; }  

    /** 
     * Checks if current account blocked the account with the given accountID .
     * @param accountID The accountID of the account to be checked.
     * @return true if the account with the given accountID is blocked, false otherwise.
     */
    public boolean isBlocked(final int accountID) {

        /* Iterating through blockedAccountsID array */
        for(int i = 0; this.blockedAccountsID[i] != 0; i++) { if(this.blockedAccountsID[i] == accountID) return true; }
        return false;
    } 

    /** 
     * Checks if the account is following the account with the given accountID.
     * @param accountID The account ID of the account to be checked.
     * @return true if the account is following the account with the given accountID, false otherwise.
     */
    public boolean isFollowing(final int accountID) {

        /* Iterating through following array */
        for(int i = 0; this.following[i] != null; i++) { if(this.following[i].accountID == accountID) return true; }
        return false;
    } 


    /** 
     * Returns the number of followers of the account.
     * @return int The number of followers of the account.
     */
    private int getFollowersNum() {
      
        int i=0;
        for(i = 0; this.followers[i] != null; i++) { /* empty */ }  /* Iterating through followers array */
        return i;
    } 

    /** 
     * Returns the array of followers of the account.
     * @return Account[] The array of followers of the account.
     */
    private Account[] getFollowers() { return this.followers; } 


    /** 
     * Sets the follower at the specified index in the array of followers.
     * @param follower The follower to set.
     * @param index The index at which to set the follower.
     */
    private void setFollowers(final Account follower,final int index) { this.followers[index] = follower; } 

    /** 
     * Follows the specified account if necessary conditions are met.
     * @param account The account to follow.
     */
    public void Follow(final Account account) {

        /* Checking conditions to follow an account. */
        if (!isLogin) {
            System.out.println("You need to log in to follow an account.");
            return;
        }

        if (account.accountID == this.accountID) {
            System.out.println("You cannot follow yourself.");
            return;
        }

        if (account.isBlocked(this.accountID)) { 
            System.out.println("You cannot follow a blocked account.");
            return;
        }

        if (this.isFollowing(account.getAccountID())) { 
            System.out.println("You are already following this account.");
            return;
        }

        /* Adding the other account to following array of this account. */
        for(int i = 0; i < this.following.length; i++) {
            if(this.following[i] == null) {
                this.following[i] = account;
                break;
            }
        }

        /* Adding this account to followers array of the other account. */
        for(int i = 0; i <= account.getFollowersNum(); i++) {
            if(account.getFollowers()[i] == null) {
                account.setFollowers(this, i);
                break;
            }
        }

    } 



    /** 
     * Returns the username of the account with the specified accountID from the array of accounts.
     * @param AccountID The account ID of the account to get the username of.
     * @param accounts The array of accounts to search in.
     * @return String The username of the account with the specified accountID.
     */
    private String getUsername(final int AccountID, final Account[] accounts) {
      
        /* Iterating through accounts array */
        for(int i = 0; accounts[i] != null; i++) { if(accounts[i].accountID == AccountID) return accounts[i].username; }
        return accounts[0].username;
    } 


    /** 
     * Returns the number of accounts that the user is following.
     * @return int representing the number of accounts being followed.
     */
    private int getFollowingNum() {
      
        int i=0;
        for(i = 0; i < this.following.length; i++) {  /* Iterating through following array */
            if(this.following[i] == null) { return i; }
            else i++;
        }
        return i;
    } 

    /** 
     * Returns a string representation of the user's profile.
     * @return String Represents user profile information.
     */
    @Override
    public String toString() {

        /* Adding account information to string. */
        String str = "-------------------------" + "\n";
        str += "User ID: " + this.accountID + "\n";
        str += "Username: " + this.username + "\n";
        str += "Location: " + this.location + "\n";
        str += "Birth Date: " + this.birthDate + "\n"; 
        str += this.username + " is following " + this.getFollowingNum() + " account(s) and has " + this.getFollowersNum() + " followers(s).\n";

        /* Handling the case in which the account has follower. */
        if(this.getFollowersNum() != 0) {
          
          str += "The followers of " + this.username + " are: ";
          for(int i = 0; i < this.getFollowersNum(); i++) {
              if(this.followers[i] != null) { str += this.followers[i].username + ", "; }
              else break;
          }
          str += "\n";
        }

         /* Handling the case in which the account has following. */
        if(this.getFollowingNum() != 0) {
          
            str += this.username + " is following: " ;
            for(int i = 0; i < this.getFollowingNum(); i++) {
              if(this.following[i] != null) { str += this.following[i].username + ", "; }
              else break;
            }
            str += '\n';
        }
      
        str +=  this.username + " has " + this.getPostsNum() + " posts.";
        return str;  /* Returning string representing account information */
    } 


    /** 
     * Displays the profile information for a given account, if necessary conditions are met.
     * @param account The account whose profile will be displayed.
     */
    public void viewProfile(final Account account) { 

        /* Checking conditions to view profile of an account */
        if (!this.isLogin) {
            System.out.println("You need to log in to view the profile.");
            return;
        }
  
        if (account.isBlocked(this.getAccountID())) {  
            System.out.println("You cannot view profile of an account blocked you.");
            return;
        }

        System.out.println(account.toString());  /* Viewing profile */

        /* Tracking The account ID of the last account that this account visited his/her profile. */
        this.lastAccID_onProfile = account.accountID;
        this.lastAccID_onPost = 0;
        
    }  

  
    /** 
     * Displays the posts for a given account, if necessary conditions are met.
     * @param account The account whose posts will be displayed.
     */
    public void viewPosts(final Account account) { 

         /* Checking conditions to view posts of an account */
        if(!isLogin) {
            System.out.println("You need to log in to view posts.");
            return;
        }

        if(account.isBlocked(this.getAccountID())) {  
            System.out.println("You cannot view posts of an account blocked you.");
            return;
        }

        if(this.lastAccID_onProfile != account.accountID) {
            System.out.println("You have to view profile before viewing posts.");
            return;
        }

        /* Viewing posts */
        for(int i = 0; i <= account.getPostsNum(); i++) {
            if(account.getPosts()[i] != null) { System.out.println(account.getPosts()[i].getPostInfo(account.username)); } 
            else {
              if(i == 0) System.out.println("There is no post that is shared...");
              break;
            }
        }

         /* Tracking The account ID of the last account that this account visited his/her posts. */ 
         this.lastAccID_onPost = account.accountID;
        
    } 

    /** 
     * Logs in the user with the given username, if necessary conditions are met.
     * @param username The username to log in with.
     * @param accounts An array of all accounts in the social media software.
     */
    public void LogIn(final String username, final Account[] accounts) {

        /* Checking if the account has already logged in.*/
        if(this.isLogin == true) { 
            System.out.println("You have already been logged in.");
            return;
        }

        /* Checking if there is any other account that has already logged in. */
        for(int i = 0; accounts[i] != null; i++) {
          
          if(accounts[i].isLogin == true) {
              System.out.println("Another account whose username is " + getUsername(accounts[i].accountID,accounts) + " has already been logged in. You cannot login more than one account at the same time.");
              return;
              
          }
        }  

          /* Logging in if the username is correct. */
          if(username == this.username) {
              this.isLogin = true;
              this.lastAccID_onProfile = 0;
              this.lastAccID_onPost = 0;
          }
          else System.out.println("Login is failed. Wrong username has been entered.");
    }  

    /** 
     * Adds a like to a given post, if necessary conditions are met.
     * @param newLike The like object to add.
     * @param interactedPost The post to add the like to.
     */
    public void addLike(final Like newLike, final Post interactedPost) {

        /* Checking conditions to add a like */
        if (!this.isLogin) {
            System.out.println("You need to log in to like a post.");
            return;
        }
      
        if(newLike.getPostID() != interactedPost.getPostID()) {
            System.out.println("Like object is not associated with this post.");
            return;
        }

        if(this.lastAccID_onProfile != interactedPost.getAccountID()) {
            System.out.println("You need to view profile before liking a post.");
            return;
        }
      
        if(this.lastAccID_onPost != interactedPost.getAccountID()) {
            System.out.println("You need to view posts before liking a post.");
            return;
        }
      
       
        /* Adding a like */
        for(int i = 0; i <= interactedPost.getLikesNum(); i++) {
          
            if(interactedPost.getLikes()[i] == null) {  
                interactedPost.setLikes(newLike,i);
                return;
            }

            /* Handling the case in which the account has already liked the post. */  
            else if (interactedPost.getLikes()[i].getAccountID() == this.accountID) {
                System.out.println("Error: " + this.username + " has already liked this post.");
                return;
            }
        }

        System.out.println("Error: Maximum number of likes reached.");
    } 

    /** 
     * Adds a comment to a post.
     * @param newComment The comment to add.
     * @param interactedPost The post to interact with.
     */
    public void addComment(final Comment newComment, final Post interactedPost) {

        /* Checking conditions to add a comment */
        if (!this.isLogin) {
            System.out.println("You need to log in to comment a post.");
            return;
        }

        if(newComment.getPostID() != interactedPost.getPostID()) {
            System.out.println("Comment object is not associated with this post.");
            return;
        }

        if(this.lastAccID_onProfile != interactedPost.getAccountID()) {
            System.out.println("You need to view profile before commenting a post.");
            return;
        }
      
        if(this.lastAccID_onPost != interactedPost.getAccountID()) {
            System.out.println("You need to view posts before commenting a post.");
            return;
        }
      
        /* Adding a comment */
        for(int i = 0; i <= interactedPost.getCommentsNum(); i++) {
            if(interactedPost.getComments()[i] == null) {    
                interactedPost.setComments(newComment,i);
                return;
            } 
        }
      
        System.out.println("Error: Maximum number of comments reached.");
    } 


    /** 
     * Views interactions for a given account, including post's likes and comments.
     * @param account The account to view interactions for.
     * @param accounts An array of all accounts in the social media software.
     */
    public void viewInteractions(final Account account, final Account[] accounts) {

        if (!this.isLogin) {
            System.out.println("You need to log in to view interactions.");
            return;
        }

        if(account.isBlocked(this.accountID) == true) {
            System.out.println("The account was blocked you therefore you cannot view his/her interactions.");
            return;
        }

        /* Viewing interactions of all posts one by one. */
        for (int i = 0; i < account.posts.length; i++) { 
            if (account.posts[i] != null) {
              
              System.out.println("----------------------");
              System.out.println("(PostID: " + account.posts[i].getPostID() + "): " + account.posts[i].getPostContent());
              
              int j = 0;
              for(j = 0; j <= account.posts[i].getLikesNum(); j++) {  /* Viewing likes. */
                  if(account.posts[i].getLikes()[j] == null) {
                      if(j == 0) System.out.println("The post has no likes.");
                      break;
                  }
                  if(j == 0) System.out.print("The post was liked by the following account(s): ");
                  System.out.print(getUsername(account.posts[i].getLikes()[j].getAccountID(), accounts) + ", "); 
              }
              
               
              if(j != 0) System.out.println();
              j = account.posts[i].getCommentsNum();
              if(j == 0) { 
                System.out.println("The post has no comments.");
                continue;
              }
              else System.out.println("The post has " + j + " comment(s)...");  /* Viewing the number of comments. */
              

              for(j = 0; j < account.posts[i].getCommentsNum(); j++) {  /* Viewing comments. */
                   System.out.println("Comment " + (j+1) + ": '" + account.getUsername(account.posts[i].getComments()[j].getAccountID(), accounts)+ "' said '" + account.posts[i].getComments()[j].getContent() + "'"); 
              }

               System.out.println();
            }

            else break;
        }   
    }  


    /** 
     * Adds a message to the account's outbox.
     * @param message The message to add to the outbox.
     */
    public void addMessageToOutbox(final Message message) {

        /* Checking if the account is logged in. */
        if (!this.isLogin) {
            System.out.println("You need to log in to send a message.");
            return;
        }

        /* Adding a message to outbox */
        for(int i = 0; i < this.outbox.length; i++) {
            if(this.outbox[i] == null) {
                this.outbox[i] = message;
                return;
            }
        }

        System.out.println("Outbox is full...");
       
    }  

     /** 
      * Adds a message to the account's inbox.
      * @param message The message to add to the inbox.
      */ 
     public void addMessageToInbox(final Message message) {

        /* Adding a message to inbox */
        for(int i = 0; i < this.inbox.length; i++) {
            if(this.inbox[i] == null) {
                this.inbox[i] = message;
                return;
            }
        }

        System.out.println("Inbox is full...");
    } 

    /** 
     * Prints the number of messages in the outbox, if necessary conditions are met.
     */ 
    public void CheckOutbox() {

        /* Checking if the account is logged in. */
        if (!isLogin) {
            System.out.println("You need to log in to check outbox.");
            return;
        }
      
        int i = 0;
        for(i = 0; this.outbox[i] != null ; i++) { /* empty */ } 
        System.out.println("There is/are " + i + " message(s) in the outbox.");
    } 


    /** 
     * Prints the number of messages in the inbox, if necessary conditions are met.
     */ 
    public void CheckInbox() {

        /* Checking if the account is logged in. */
        if (!isLogin) {
            System.out.println("You need to log in to check inbox.");
            return;
        }
      
        int i = 0;
        for(i = 0; this.inbox[i] != null ; i++) { /* empty */ }
        System.out.println("There is/are " + i + " message(s) in the inbox.");
    }  


    /** 
     * Views messages in the inbox, if necessary conditions are met.
     * @param accounts An array of all accounts in the social media software.
     */ 
    public void viewInbox(final Account[] accounts) {

        /* Checking if the account is logged in. */
        if (!isLogin) {
            System.out.println("You need to log in to view inbox.");
            return;
        }

       /* Viewing inbox. */ 
       for(int i = 0; i < this.inbox.length; i++) {
            if(this.inbox[i] != null) {
              
                System.out.println("--------------------------");
                System.out.println("Message ID: " + this.inbox[i].getMessageID());
                System.out.println("From: " + this.getUsername(this.inbox[i].getSenderID(), accounts));
                System.out.println("To: " + this.getUsername(this.inbox[i].getReceiverID(), accounts));
                System.out.println("Message: " + this.inbox[i].getContent());
  
            }
             else {
              if(i == 0) System.out.println("Inbox is empty.");
              break;
            }
        }
      
    }  


    /** 
     * Views messages in the outbox, if necessary conditions are met.
     * @param accounts An array of all accounts in the social media software.
     */ 
    public void viewOutbox(final Account[] accounts) {

        /* Checking if the account is logged in. */
        if (!isLogin) {
            System.out.println("You need to log in to view outbox.");
            return;
        }

         /* Viewing outbox. */ 
        for(int i = 0; i < this.outbox.length; i++) {
            if(this.outbox[i] != null) {
              
                System.out.println("--------------------------");
                System.out.println("Message ID: " + this.outbox[i].getMessageID());
                System.out.println("From: " + this.getUsername(this.outbox[i].getSenderID(), accounts));
                System.out.println("To: " + this.getUsername(this.outbox[i].getReceiverID(), accounts));
                System.out.println("Message: " + this.outbox[i].getContent());
  
            }
             else {
              if(i == 0) System.out.println("Outbox is empty.");
              break;
            }
        }
      
    }  
  

    /** 
     * Blocks the specified account and adds its account ID to the array of blocked account IDs.
     * @param accountBlocked The account to be blocked
     */ 
    public void BlockAccount(final Account accountBlocked) {
      
        int i = 0;
        for(i = 0; this.blockedAccountsID[i] != 0; i++) { /* empty */ } 
      
        if(accountBlocked.accountID == this.accountID) System.out.println("You cannot block yourself.");
        else this.blockedAccountsID[i] = accountBlocked.accountID;  /* Blocking the account */
    } 

    /** 
     * Returns login information.
     * @return true if the account is logged in.
     */		
    public boolean getIsLogin() { return isLogin; }
  
  
/*****************************************************************/
  
    
   


   

}
