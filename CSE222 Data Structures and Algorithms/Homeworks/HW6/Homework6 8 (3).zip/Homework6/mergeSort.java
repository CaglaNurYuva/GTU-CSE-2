
/**
 * This class containts methods to apply merge sort
 * algorithm to a custom map.
 * 
 * @file    mergeSort.java
 * @author  Çağla Nur Yuva
 * @brief   Applies merge sort algorithm to a custom map.
 * @version 1.0
 * @date    2023-05-16
 */
public class mergeSort {  
    
    /** Keeps original custom map */
    private myMap originalMap;

    /** Keeps sorted custom map */
    private myMap sortedMap;

    /** It keeps track of sorted keys of a custom map */
    private String [] aux;


    /** Constructs a new mergeSort object */
    private mergeSort() {
    
        /* Initializing originalMap, sortedMap and aux array */
        originalMap = new myMap();
        sortedMap = new myMap();
        aux = new String[0];
    }


    /**
     * Constructs a new mergeSort object with 
     * a given custom map and sorts it.
     * @param map the custom map to sort
     */
    public mergeSort(final myMap map) {
    
        /* Initializing originalMap, sortedMap and aux array */
        originalMap = new myMap(map);
        sortedMap = new myMap(map);
        aux = new String[map.getSize()];

        /* Copying the keys from the original map into the aux array */
        int i = 0;
        for (String key : (originalMap.getMap()).keySet()) {
            aux[i] = key;
            i++;
        }

        /* Sorting the keys that are in aux array using merge sort algorithm */
        mergeSortMap(0, aux.length - 1);
    }
    
    
    /** Updates sortedMap by using aux array for keys and originalMap for values. */
    private void updateSortedMap() {
        
        /* Clearing sortedMap */
        sortedMap.clearMap();
        
        /* Adding the corresponding entries of originalMap to sortedMap using aux array as keys */ 
        for (int i = 0; i < originalMap.getSize(); i++) {
            String keyToUse = new String(aux[i]);
            info newInfo = new info(originalMap.getInfo(keyToUse));
            sortedMap.add(keyToUse,newInfo);
        }
    }


    /**
     * Returns orijinal custom map.
     * @return the original custom map
     */
    public myMap getOriginalMap() { return originalMap; }


    /**
     * Returns sorted custom map.
     * @return the sorted custom map
     */
    public myMap getSortedMap() { return sortedMap; }


    /**
     * Recursively sorts the subarray from left to right using merge sort.
     * @param left the left index of the subarray
     * @param right the right index of the subarray
     */
    private void mergeSortMap(final int left, final int right) {
        
        /* If the subarray has length 1 or less, it is already sorted */
        if (left >= right) { return; }
        int mid = (left + right) / 2;

        /* Dividing the aux array in half and recursively sort each half */
        mergeSortMap(left, mid);
        mergeSortMap(mid + 1, right);

        /* Merging the sorted halves into a single sorted subarray */
        merge(left, mid, right);
        
        /* Updating the sortedMap with the new order of keys that are in aux array */
        updateSortedMap();
    }


    /**
     * Merges sorted subarrays into a single sorted subarray.
     * @param left the left index of the first subarray
     * @param mid the right index of the first subarray
     * @param right the right index of the second subarray
     */
    private void merge(final int left, final int mid, final int right) {

        int i = left;
        int j = mid + 1;
        int k = left;

        /* Keep comparing count variables of values of sortedMap */
        while (i <= mid && j <= right) {

            /* Obtaining count variables of the values of sortedMap using keys */
            int num1 = (sortedMap.getValue(sortedMap.getKey(i))).getCount();
            int num2 = (sortedMap.getValue(sortedMap.getKey(j))).getCount();

            /* Comparing variables and filling aux array */
            if (num1 <= num2) {
                aux[k] = sortedMap.getKey(i);
                i++;
                k++;
            } 
                
            else {
                aux[k] = sortedMap.getKey(j);
                j++;
                k++;
            }
        }

        /* Copying the remaining elements from the first subarray */
        while (i <= mid) {
            aux[k] = sortedMap.getKey(i);
            i++;
            k++;
        }

        /* Copying the remaining elements from the second subarray */
        while (j <= right) {
            aux[k] = sortedMap.getKey(j);
            j++;
            k++;
        }
    }
    
}

