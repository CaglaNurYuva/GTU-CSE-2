
/**
 * Test class is used to test myMap, mergeSort
 * info and Preprocess classes and their functionality.
 * 
 * @file    Test.java
 * @author  Çağla Nur Yuva
 * @brief   Tests the classes and their functionality.
 * @version 1.0
 * @date    2023-05-16
 */
public class Test {  

    /**
     * It tests myMap, mergeSort, info and Preprocess classes. 
     * @param args An array of strings for command-line arguments.
     */
    public static void main(String[] args) {  

        /* Testing some cases */
        testInput("java");
        System.out.println("-----------------------------------------------------------");
        
        testInput("abc aba");
        System.out.println("-----------------------------------------------------------");
        
        testInput("Buzzing bees buzz.");
        System.out.println("-----------------------------------------------------------");
        
        testInput("'Hush, hush!' whispered the rushing wind.");
        System.out.println("-----------------------------------------------------------");
        
        testInput(".cinnamon.");
        System.out.println("-----------------------------------------------------------");
        
        testInput("Thanks for the semester :) <3");
        System.out.println("-----------------------------------------------------------");
    }


    /**
     * Tests the classes with the given input string and prints results.
     * @param input the input string to test with.
     */
    private static void testInput(final String input) {

        /* Preprocessing and validating the given input String */
        Preprocess preprocess = new Preprocess();
        String preprocessed = preprocess.preprocessStr(input);

        /* Validating preprocessed String */
        if(preprocessed == null) return;
        
        myMap map = new myMap(preprocessed);   /* Creating a custom map with preprocessed String */
        mergeSort sort = new mergeSort(map);   /* Creating mergeSort object and sorting the custom map */

        /* Printing the original map */
        System.out.println("\n\nThe original (unsorted) map:");
        sort.getOriginalMap().printMap();

        /* Printing the sorted map */
        System.out.println("\n\nThe sorted map:");
        sort.getSortedMap().printMap();
    }
}
