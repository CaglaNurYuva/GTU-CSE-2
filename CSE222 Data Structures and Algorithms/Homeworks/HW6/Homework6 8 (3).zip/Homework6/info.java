
/**
 * info class represents the value of custom map's one entry.
 * 
 * @file    info.java
 * @author  Çağla Nur Yuva
 * @brief   Represents the value of custom map's one entry.
 * @version 1.0
 * @date    2023-05-16
 */
public class info {  

    /** Keeps the size of words array */
    private int count = 0;

    /** Dynamic array keeping words in it. */
    private String [] words = new String[0];
    

    /** Constructs a new info object. */
    public info() {
        count = 0;
        words = new String[0];
    }


    /**
     * Constructs a new info object by using its parameter.
     * @param otherInfo the info object to copy from.
     */
    public info(final info otherInfo) {

        count = otherInfo.count;
        words = new String[otherInfo.words.length];

        /* Copying the words array of otherInfo to the words array of this object */
        for (int i = 0; i < otherInfo.words.length; i++) words[i] = otherInfo.words[i];
    }


    /**
     * Reallocates the array to a new size.
     * @param newSize the new size of the array.
     */
    private void reallocate(final int newSize) {
        String[] newArr = new String[newSize];
        
        /* Copying the elements of words array to the newArr array */
        for (int i = 0; i < words.length; i++) newArr[i] = words[i];
        
        /* Assigning newly created array to words array */
        words = newArr;
    }


    /**
     * Sets the count to a new value.
     * @param newCount the new value of the count variable.
     */
    private void setCount(final int newCount) { count = newCount; }


    /**
     * Creates a word for certain value of entry of the custom map.
     * @param preprocessed Preprocessed string
     * @param index the index which is in a word of preprocessed String. 
     */
    public void createWord(final String preprocessed, final int index) {
        int rightSide = 0, leftSide = 0;

        /* Finding the right boundary of the word */
        for (int j = index; j < preprocessed.length(); j++) {

            char c = preprocessed.charAt(j);
            if (c == ' ') {
                rightSide = j - 1;
                break;
            }   

            else if (j == preprocessed.length() - 1) {
                rightSide = j;
                break;
            }
        }

        /* Finding the left boundary of the word */
        for (int j = index; j >= 0; j--) {

            char c = preprocessed.charAt(j);
            if (c == ' ') {
                leftSide = j + 1;
                break;
            }   

            else if (j == 0) {
                leftSide = j;
                break;
            }           
        }

        /* Adding the new word to the words array */
        push(preprocessed.substring(leftSide, rightSide + 1));
    }


    /**
     * Adds a word to the words array.
     * @param newWord the word to be added to the words array.
     */
    private void push(final String newWord) {
    
        reallocate(count + 1);  /* Reallocating words array */
        words[count] = newWord;
        count++;
    }


    /**
     * Returns the count variable.
     * @return the value of the count variable
     */
    public int getCount() { return count; }
    

    /**
     * Returns the words array.
     * @return the words array
     */
    public String[] getWords() { return words; }

}

