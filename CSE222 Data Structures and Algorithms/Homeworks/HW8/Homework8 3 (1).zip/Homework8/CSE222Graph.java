
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;


/**
 * CSE222Graph class is used to represent a graph 
 * that is created from a given map.
 * 
 * @file    CSE222Graph.java
 * @author  Çağla Nur Yuva
 * @brief   Represents a graph created from a given map.
 * @version 1.0
 * @date    2023-06-04
 */
public class CSE222Graph {

    /** A map that stores the adjacency list for each vertex */
    private Map <Integer, List<Integer> > adjacencyList;

    /** The source vertex */
    private int Source;

    /** The destination vertex */
    private int Destination;
    

    /**
     * Constructs a new CSE222Graph object by using given map.
     * @param map The map to create the graph from.
     */
    public CSE222Graph(CSE222Map map) {

        /* Initializing data fields */
	    Source = map.getSource();
	    Destination = map.getDestination();
        adjacencyList = new HashMap<>();

        ArrayList<ArrayList<Integer> > graphMatrix = map.getMap();
        createGraph(graphMatrix);  /* Creating graph */
    }


    /**
     * Creates a graph from given matrix.
     * @param graphMatrix The matrix to create the graph from.
     */
    private void createGraph(ArrayList <ArrayList<Integer> > graphMatrix) {

        int size = graphMatrix.size();  
        int vertex = 0;                 

        /* Iterating over given map */
        for (int i = 0; i < size; i++) { 
            for (int j = 0; j < size; j++) { 

                /* Checking if there is an obstacle at this position or not */
                if (graphMatrix.get(i).get(j) == 0) {

                    /* Add a new vertex to the graph */
                    addVertex(vertex);

                    /* Adding an edge to the vertex above this position, if it exists */               
                    if (i > 0 && graphMatrix.get(i - 1).get(j) == 0) { 
                        addEdge(vertex, vertex - 1 - countZeros(i, j, i - 1, j, graphMatrix)); 
                    }
                    
                    /* Adding an edge to the vertex below this position, if it exists */
                    if (i < size - 1 && graphMatrix.get(i + 1).get(j) == 0) { 
                        addEdge(vertex, vertex + 1 + countZeros(i, j, i + 1, j, graphMatrix)); 
                    }

                    /* Adding an edge to the vertex to the left of this position, if it exists */
                    if (j > 0 && graphMatrix.get(i).get(j - 1) == 0) { 
                        addEdge(vertex, vertex - 1);
                    }

                    /* Adding an edge to the vertex to the right of this position, if it exists */
                    if (j < size - 1 && graphMatrix.get(i).get(j + 1) == 0) { 
                        addEdge(vertex, vertex + 1);
                    }

                    /* Adding an edge to the vertex diagonally above and to the left of this position, if it exists */
                    if (i > 0 && j > 0 && graphMatrix.get(i - 1).get(j - 1) == 0) { 
                        addEdge(vertex, vertex - 1 - countZeros(i, j, i - 1, j - 1, graphMatrix)); 
                    }

                    /* Adding an edge to the vertex diagonally above and to the right of this position, if it exists */
                    if (i > 0 && j < size - 1 && graphMatrix.get(i - 1).get(j + 1) == 0) {
                        addEdge(vertex, vertex - 1 - countZeros(i, j, i - 1, j + 1, graphMatrix)); 
                    }

                    /* Adding an edge to the vertex diagonally below and to the left of this position, if it exists */
                    if (i < size - 1 && j > 0 && graphMatrix.get(i + 1).get(j - 1) == 0) { 
                        addEdge(vertex, vertex + 1 + countZeros(i, j, i + 1, j - 1, graphMatrix)); 
                    }

                    /* Adding an edge to the vertex diagonally below and to the right of this position, if it exists */
                    if (i < size - 1 && j < size - 1 && graphMatrix.get(i + 1).get(j + 1) == 0) { 
                        addEdge(vertex, vertex + 1 + countZeros(i, j, i + 1, j + 1, graphMatrix)); 
                    }
                      
                    vertex++; 
                }
            }
        }
    }


    /**
     * Counts the number of zeros in a given range of the matrix.
     * @param x1 The starting x coordinate of range.
     * @param y1 The starting y coordinate of range.
     * @param x2 The ending x coordinate of range.
     * @param y2 The ending y coordinate of range.
     * @param graphMatrix The matrix to count the zeros in.
     * @return The number of zeros in given range.
     */
    private int countZeros(int x1, int y1, int x2, int y2, ArrayList <ArrayList<Integer> > graphMatrix) { 

        /* Swapping the coordinates if x1 is greater than x2 */
    	if (x1 > x2) { 
			int temp1 = x1; 
			x1 = x2; 
			x2 = temp1; 
			
			temp1 = y1; 
			y1 = y2; 
			y2 = temp1;
		} 

     	int count = 0; 
     	
        /* Counting the number of zeros between (x1, y1) and the end of the row */
     	for (int j = y1 + 1; j < graphMatrix.get(0).size(); j++) {
       		if (graphMatrix.get(x1).get(j) == 0) count++;   
	    } 
	 
        /* Counting the number of zeros between the start of the row and (x2, y2) */
	    for (int j = 0; j < y2; j++) {
       	    if (graphMatrix.get(x2).get(j) == 0) count++;   
	    }
	 
        return count; 
    }


    /**
     * Adds a vertex to the graph.
     * @param newVertex The vertex to add.
     */
    private void addVertex(Integer newVertex) {   
        adjacencyList.put(newVertex, new LinkedList <Integer>());   
    }   


    /**
     * Adds an edge between two vertices in the graph.
     * @param sourceVertex The starting vertex of the edge.
     * @param destinationVertex The ending vertex of the edge.
     */
    private void addEdge(Integer sourceVertex, Integer destinationVertex) {   
        adjacencyList.get(sourceVertex).add(destinationVertex);   
    }   
   

    /**
     * Returns the number of vertices in the graph.
     * @return The number of vertices in the graph.
     */
    public int getNumVertices() { return adjacencyList.keySet().size(); }  


    /**
     * Returns neighbors of each vertex in graph, which is adjacency list.
     * @return A map of vertices to their corresponding neighbors.
     */
    public Map <Integer, List<Integer> > getNeighbors() { return adjacencyList; }


    /**
     * Returns the source vertex of the graph.
     * @return The source vertex of the graph.
     */
    public Integer getSource() { return Source; }
    

    /**
     * Returns the destination vertex of the graph.
     * @return The destination vertex of the graph.
     */
    public Integer getDestination() { return Destination; }
    
}

