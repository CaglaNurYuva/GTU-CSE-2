
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;


/**
 * CSE222BFS class is used to implement BFS algorithm on
 * a given graph and find the shortest path.
 * 
 * @file    CSE222BFS.java
 * @author  Çağla Nur Yuva
 * @brief   Performs BFS algorithm on a graph.
 * @version 1.0
 * @date    2023-06-04
 */
public class CSE222BFS {

    /** The graph on which the algorithm is applied */
    private CSE222Graph graph;


    /**
     * Creates a new instance of CSE222BFS with the given graph.
     * @param graph The graph to apply the BFS algorithm on.
     */
    public CSE222BFS(CSE222Graph graph) {
        this.graph = graph;
    }


    /**
     * Applies BFS algorithm and returns array of parent vertices for each vertex.
     * @return An array of parent vertices for each vertex.
     */
    private int[] BFSAlgorithm() {

        /* Storing parent vertex of each vertex */
        int[] parents = new int[graph.getNumVertices()]; 

        /* Storing the vertices to be visited */
        Queue<Integer> checkVertexes = new LinkedList<>(); 

        /* Storing the visited vertices */
        boolean[] visitedVertexes = new boolean[graph.getNumVertices()]; 

        /* Adding source vertex to the queue and marking it as visited */
        checkVertexes.add(graph.getSource()); 
        visitedVertexes[graph.getSource()] = true; 

        /* Marking source vertex as has no parent */
        parents[graph.getSource()] = -1; 


        /* Iterating through queue until it is empty */
        while (!checkVertexes.isEmpty()) { 

            /* Getting a vertex from the queue */
            int vertex = checkVertexes.poll(); 

            /* Getting the neighbors of this vertex */
            List<Integer> neighbors = graph.getNeighbors().get(vertex); 


            /* Iterating through neighbors */
            for (int neighbor: neighbors) { 

                /* Checking if the neighbor is visited or not */
                if (visitedVertexes[neighbor] == false) { 

                    /* Adding it to the queue and marking it as visited */
                    checkVertexes.add(neighbor); 
                    visitedVertexes[neighbor] = true; 

                    /* Setting its parent as the current vertex */
                    parents[neighbor] = vertex; 
                }
            }
        }

        return parents;
    }


    /**
     * Finds the shortest path in graph using BFS algorithm and returns it as a list of vertices.
     * @return The shortest path from source to destination as a list of vertices.
     * @throws IllegalStateException If there is no feasible path from source to destination.
     */
    public List<Integer> findPath() throws IllegalStateException  {

        /* Applying BFS algorithm */
        int[] parents = BFSAlgorithm();
      
        /* Storing the path */
        List<Integer> shortestPath = new ArrayList<>(); 

        /* If no feasible path (the distance is infinity) is found, throw IllegalStateException exception. */
        if (parents[graph.getDestination()] == 0) { 
            throw new IllegalStateException("No feasible path is found by using BFS algorithm.");	
        }


        /* Getting destination vertex */
        int vertex = graph.getDestination(); 

        /* Looping while there is a parent vertex */
        while (vertex != -1) { 
            shortestPath.add(vertex);  
            vertex = parents[vertex];  
        }
        
        /* Reversing the order of elements in the shortest path list */
        int size = shortestPath.size();
        for (int i = 0; i < size / 2; i++) {
            int temp = shortestPath.get(i);
            shortestPath.set(i, shortestPath.get(size - 1 - i));
            shortestPath.set(size - 1 - i, temp);
        } 
        
        return shortestPath; 
    }
}

