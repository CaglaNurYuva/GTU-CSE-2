
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;


/**
 * TestCases class is used to test CSE222Map,
 * CSE222Graph, CSE222Dijkstra and CSE222BFS classes. 
 * 
 * @file    TestCases.java
 * @author  Çağla Nur Yuva
 * @brief   The class tests the functionality of the classes used.
 * @version 1.0
 * @date    2023-06-04
 */
public class TestCases implements Runnable {

    /** The name of the file containing the map */
    private String FileName;

    /** The width of the map */
    private int X_SIZE;

    /** The height of the map */
    private int Y_SIZE;


    /**
     * Constructor for the TestCases class.
     * @param FileName The name of the file containing the map.
     * @param X_SIZE The width of the map.
     * @param Y_SIZE The height of the map.
     */
    public TestCases(String FileName, int X_SIZE, int Y_SIZE) {
        this.FileName = FileName;
        this.X_SIZE = X_SIZE;
        this.Y_SIZE = Y_SIZE;
    }


    /** This method tests the functionality of the CSE222Map, CSE222Graph, CSE222Dijkstra and CSE222BFS classes. */
    public void test(){
        
        System.out.println("\n\n*******************\nMap is " + this.FileName + " with X_SIZE " + this.X_SIZE + " and Y_SIZE " + this.Y_SIZE + "\n********************\n");

        try {

            /* Creating a new map */
            CSE222Map Map = new CSE222Map (this.FileName, this.X_SIZE, this.Y_SIZE);

            /* Creating a new graph */
            CSE222Graph Graph = new CSE222Graph (Map);

            /* Finding the shortest path using Dijkstra's algorithm */
            CSE222Dijkstra Dijkstra = new CSE222Dijkstra (Graph);
            List<Integer> DijkstraPath = Dijkstra.findPath();

            /* Finding the shortest path using BFS algorithm */
            CSE222BFS BFS= new CSE222BFS (Graph);
            List<Integer> BFSPath = BFS.findPath();
            
            /* Converting the map to a PNG image to show map without any path on it */
            Map.convertPNG(FileName,0);   

            /* Drawing the shortest paths found by both algorithms on different maps */
            Map.convertPNG(FileName,1);   
            Map.drawLine(DijkstraPath,FileName,1);
            Map.convertPNG(FileName,2);   
            Map.drawLine(BFSPath,FileName,2);

            /* Writing the shortest paths found by both algorithms to different text files */
            Map.writePath(DijkstraPath, FileName,1);
            Map.writePath(BFSPath, FileName,2);
            
            
            /* Printing the results of the test */
            System.out.println("********** " + FileName  + " RESULTS"+ " **********");
            System.out.println("Dijkstra Path: " + (DijkstraPath.size() - 1));
            System.out.println("BFS Path: " + (BFSPath.size() - 1));
            System.out.println("********** " + "END OF RESULTS" +  " **********");
        } 

        /* Handling file not found exception */
        catch (FileNotFoundException exception1) {  
            System.err.println("Error for " + FileName + " : " + "File is not found. " + exception1.getMessage());
            exception1.printStackTrace();
        } 

        /* Handling input/output exception */ 
        catch (IOException exception2) {    
            System.err.println("Error for " + FileName + " : " +  "An input/output error occurred. " + exception2.getMessage());
            exception2.printStackTrace();
        } 

        /* Handling illegal state exception in case of no feasible path is found or start/end point of graph is invalid */
        catch (IllegalStateException exception3) {
            System.err.println("Error for " + FileName + " : " + exception3.getMessage());
            exception3.printStackTrace();
        }         

        /* Handling illegal argument exception in case of invalid int argument (0, 1 and 2) */
        catch (IllegalArgumentException exception4) {
            System.err.println("Error for " + FileName + " : " + exception4.getMessage());
            exception4.printStackTrace();
        } 

        /* Handling index out of bounds exception */
        catch (IndexOutOfBoundsException exception5) {  
            System.err.println("Error for " + FileName + " : " + "Index out of bounds. " + exception5.getMessage());
            exception5.printStackTrace();
        } 

        /* Handling any other exceptions */
        catch (Exception exception6) {
            System.err.println("Error for " + FileName +" : " +  "An unexpected error occurred. " + exception6.getMessage());
            exception6.printStackTrace();
        }
    }
    

    /** This method is used to run the test cases. */
    @Override
    public void run() {
        test();
    }
}

