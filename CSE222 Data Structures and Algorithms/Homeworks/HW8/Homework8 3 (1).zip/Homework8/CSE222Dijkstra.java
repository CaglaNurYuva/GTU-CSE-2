
import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;


/**
 * CSE222Dijkstra class is used to implement Dijkstra's algorithm
 * on a given graph and find the shortest path.
 * 
 * @file    CSE222Dijkstra.java
 * @author  Çağla Nur Yuva
 * @brief   Performs Dijkstra's algorithm on a graph.
 * @version 1.0
 * @date    2023-06-04
 */
public class CSE222Dijkstra {

    /** The graph on which the algorithm is applied */
    private CSE222Graph Graph;
    
    /** VertexInfo class represents a vertex and its distance from the source */
    private class VertexInfo implements Comparable<VertexInfo> {

        /** The distance from the source vertex */
        private int distance;

        /** The vertex number */
        private int vertex;

        /**
         * A constructor that creates a VertexInfo object with a given vertex and distance
         * @param newVertex The vertex number
         * @param newDistance The distance from the source vertex
         */
        VertexInfo(int newVertex, int newDistance) {
            this.distance = newDistance;
            this.vertex = newVertex;
        }

        /**
         * A method that compares two VertexInfo objects based on their distances
         * @param otherVertex The other VertexInfo object to compare with
         * @return the distance between this vertex and other vertex 
         */
        public int compareTo(VertexInfo otherVertex) {
            return this.distance - otherVertex.distance;
        }
    }


    /**
     * A constructor that creates a CSE222Dijkstra object with a given graph
     * @param graph The graph on which the algorithm is applied
     */
    public CSE222Dijkstra(CSE222Graph graph) {
        this.Graph = graph;
    }


    /**
     * Performs Dijkstra's algorithm on the graph.
     * @return An array of distances from the source vertex to all other vertices
     */
    private int[] dijkstraAlgorithm() {

        /* Storing the distances from the source vertex to all other vertices */
        int[] allDistances = new int[Graph.getNumVertices()];
     
        /* An array to mark the visited vertices as true */
        boolean[] visitedVertexes = new boolean[Graph.getNumVertices()];

        /* Storing the vertices and their distances */
        PriorityQueue<VertexInfo> checkVertexes = new PriorityQueue<>();
        
        /* Initializing the distances to infinity and the visited vertices to false */
        for (int i = 0; i < allDistances.length; i++) {
            allDistances[i] = Integer.MAX_VALUE;
            visitedVertexes[i] = false;
        }
        
    
        /* Setting distance of source vertex to zero and add it to the priority queue */
        allDistances[Graph.getSource()] = 0;
        VertexInfo newVertex = new VertexInfo(Graph.getSource(), 0);
        checkVertexes.add(newVertex);
        
        /* Iterating through priority queue until it is empty */
        while (!checkVertexes.isEmpty()) {
    
            /* Getting the vertex with the minimum distance and marking it as visited */
            VertexInfo minVertex = checkVertexes.poll();
            visitedVertexes[minVertex.vertex] = true;
    
            /* Iterating through its neighbors in the graph */
            for (int neighbor: Graph.getNeighbors().get(minVertex.vertex)) {
             
                /* Checking if the neighbor is visited or not */
                if (visitedVertexes[neighbor] == false) {
    
                    /* Calculating distance from source vertex to neighbor by adding one (as weigh) to current distance */
                    int distance = allDistances[minVertex.vertex] + 1;
    
                    /* Checking if this distance is smaller than previous distance stored in array */
                    if (distance < allDistances[neighbor]) {
               
                        /* Updating distance in array and adding new VertexInfo object with neighbor and its distance */
                        allDistances[neighbor] = distance;
                        newVertex = new VertexInfo(neighbor, distance);
                        checkVertexes.add(newVertex);
                    }
                }
            }
        }

        return allDistances;
    }


    /**
     * Finds and returns the shortest path by using Dijkstra's algorithm.
     * @return A list of vertices that form the shortest path from the source vertex to the destination vertex
     * @throws IllegalStateException If no feasible path is found by using Dijkstra's algorithm.
     */
    public List<Integer> findPath() throws IllegalStateException  {
 
        /* Storing the shortest path from the source vertex to the destination vertex */
        List<Integer> shortestPath = new ArrayList<>();

        /* Applying Dijkstra's algorithm */
        int[] allDistances = dijkstraAlgorithm(); 

        /* If no feasible path (the distance is infinity) is found, throw IllegalStateException exception. */
        if (allDistances[Graph.getDestination()] == Integer.MAX_VALUE) {
            throw new IllegalStateException("No feasible path is found by using dijkstra algorithm.");	
        }


        /* Starting from destination vertex and tracing back to source vertex */
        int currentVertex = Graph.getDestination();
        while (currentVertex != Graph.getSource()) {
        
            /* Adding the current vertex to the shortest path list */
            shortestPath.add(currentVertex);
      
            /* Iterating through its neighbors in graph */
            for (int neighbor: Graph.getNeighbors().get(currentVertex)) {

                /* Checking if this neighbor has distance that is one less than current vertex's distance */
                if (allDistances[neighbor] == allDistances[currentVertex] - 1) {
                
                    /* Setting it as current vertex */
                    currentVertex = neighbor;
                    break;
                }
            }
        }

        /* Adding source vertex to the shortest path list */
        shortestPath.add(Graph.getSource());
      
        /* Reversing the order of elements in the shortest path list */
        int size = shortestPath.size();
        for (int i = 0; i < size/2; i++) {
            int temp = shortestPath.get(i);
            shortestPath.set(i, shortestPath.get(size-1-i));
            shortestPath.set(size-1-i, temp);
        }
    
        return shortestPath;
    }
}

