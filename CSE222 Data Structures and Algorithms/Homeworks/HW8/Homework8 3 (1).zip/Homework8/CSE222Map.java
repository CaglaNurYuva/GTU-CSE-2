
import java.io.File;   
import java.io.FileNotFoundException;  
import java.io.IOException;
import java.io.FileWriter;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

import java.awt.Color;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;


/**
 * CSE222Map class is used to represent a map.
 * 
 * @file    CSE222Map.java
 * @author  Çağla Nur Yuva
 * @brief   Represents a map. 
 * @version 1.0
 * @date    2023-06-04
 */
public class CSE222Map {

    /** The vertex index of the end point on the map. */
    private int endPoint;

    /** The vertex index of the start point on the map. */
    private int startPoint;

    /** The length of the map in the x direction. */
    private int X_LENGTH;

    /** The length of the map in the y direction. */
    private int Y_LENGTH;

    /** The 2D array list that represents the map. */
    private ArrayList <ArrayList<Integer> > map;  
    

    /**
     * Constructor for the CSE222Map class.
     * @param inputFile The name of the input file that contains the map data.
     * @param x_length The length of the map in the x direction.
     * @param y_length The length of the map in the y direction.
     * @throws FileNotFoundException If the input file is not found.
     */ 
    public CSE222Map(String inputFile, int x_length, int y_length) throws FileNotFoundException {

        /* Initializing data fields of the class */
        this.endPoint = -1;
        this.startPoint = -1;
        this.X_LENGTH = x_length;
        this.Y_LENGTH = y_length;
        this.map = new ArrayList<ArrayList<Integer> >();  

        createMap(inputFile);  /* Creating map */
    }


    /**
     * Converts the map into a PNG image file.
     * @param inputFile The name of the input file that contains the map data.
     * @param algorithm the algorithm info used to find shortest path, 1 for dijkstra, 2 for bfs, 0 for none.
     * @throws IOException If there is an error while reading or writing the image file.
     * @throws IllegalArgumentException If algorithm value is not 0,1 or 2.
     */ 
    public void convertPNG(String inputFile, int algorithm) throws IOException, IllegalArgumentException {

        BufferedImage image = new BufferedImage(X_LENGTH, Y_LENGTH, BufferedImage.TYPE_INT_RGB);
        String outputFileName;

        /* Looping through map cells and set the pixel colors according to their values */
        for (int i = 0; i < map.size(); i++) {
            for (int j = 0; j < map.get(i).size(); j++) {
                int pixelColor = (map.get(i).get(j) == 0) ? Color.WHITE.getRGB() : Color.GRAY.getRGB();
                image.setRGB(i, j, pixelColor);
            }
        }
        

        /* Generating the output file name */
        if (algorithm == 0) {
            outputFileName = inputFile.substring(0, inputFile.lastIndexOf(".")) + "_Image.png";
        }

        else if (algorithm == 1) { 
            outputFileName = inputFile.substring(0, inputFile.lastIndexOf(".")) + "_Dijkstra_solution.png";
        }

        else if (algorithm == 2) { 
            outputFileName = inputFile.substring(0, inputFile.lastIndexOf(".")) + "_BFS_solution.png"; 
        }

        /* Throwing IllegalArgumentException exception */
        else { throw new IllegalArgumentException("Error: Invalid algorithm value: " + algorithm); }

        /* Creating a new file object */
        File outputFile = new File(outputFileName);

        /* Writing the image to the output file */ 
        ImageIO.write(image, "png", outputFile);
    }


    /**
     * Writes the shortest path found to the text file.
     * @param Path The list of vertices that form the path.
     * @param inputFile The name of the input file that contains the map data.
     * @param algorithm the algorithm info used to find shortest path, 1 for dijkstra, 2 for bfs.
     * @throws IOException If there is an error while writing the path data to the file.
     * @throws IllegalArgumentException If algorithm value is not 1 or 2.
     */ 
    public void writePath(List<Integer> Path, String inputFile, int algorithm) throws IOException, IllegalArgumentException {

	    int vertex = 0;
	    boolean quit = false;
	    String outputFile;

        /* Removing the extension from the input file name */
        inputFile = inputFile.substring(0, inputFile.lastIndexOf("."));
        File fileTest = new File(inputFile + "_dijkstra_path.txt");

        /* Deciding output file name */
        if (algorithm == 1) { outputFile = inputFile + "_dijkstra_path.txt"; }
        else if (algorithm == 2) { outputFile = inputFile + "_bfs_path.txt"; }

        /* Throwing IllegalArgumentException exception */
        else { throw new IllegalArgumentException("Error: Invalid algorithm value: " + algorithm); }

        /* Initializing a file writer for output file */
        File file = new File(outputFile);
        FileWriter writer = new FileWriter(file);


        /* Looping through the path indices */ 
        for (int k = 0; k < Path.size(); k++) {
            int vertexToFind = Path.get(k);
            quit = false;
            vertex = 0;

            /* Finding the path indices' corresponding coordinates in the map */
            for (int i = 0; i < map.size() && quit == false; i++) {
                for (int j = 0; j < map.get(i).size(); j++) {

                    if (map.get(i).get(j) == 0) {
                        if (vertex == vertexToFind) {
                            quit = true;

                            /* Writing the coordinates to the output file */
                            writer.write(i + "," + j + "\n");
                            break;
                        }

                        else {
                            vertex++;
                        }
                    }
                }
            }
        }

        writer.close();   
    }


    /**
     * Draws a line on the PNG image along the shortest path.
     * @param Path A list of integers that represents the path indices in the map.
     * @param inputFile The name of the input file that contains the map data.
     * @param algorithm the algorithm info used to find shortest path, 1 for dijkstra, 2 for bfs.
     * @throws IOException If there is an error while writing/reading from the image files.
     * @throws IllegalArgumentException If algorithm value is not 1 or 2.
     */
    public void drawLine(List<Integer> Path, String inputFile, int algorithm) throws IOException, IllegalArgumentException {

	    int vertex = 0;
	    int RGBValue;  
        File imageFile; 

        /* Removing the extension from the input file name */
        inputFile = inputFile.substring(0, inputFile.lastIndexOf("."));	

        /* Deciding output file name */
        if (algorithm == 1) {

            /* Output file name and color indicates Dijkstra algorithm since algorithm equals 1 */
            imageFile = new File(inputFile + "_Dijkstra_solution.png"); 
            RGBValue = Color.RED.getRGB();   
        } 

        else if (algorithm == 2){

            /* Output file name and color indicates BFS algorithm since algorithm equals 2 */
            imageFile = new File(inputFile + "_BFS_solution.png");
      	    RGBValue = Color.BLUE.getRGB();
        }

        /* Throwing IllegalArgumentException exception */
        else { throw new IllegalArgumentException("Error: Invalid algorithm value: " + algorithm); }


        /* Reading the image file */
		BufferedImage image = ImageIO.read(imageFile);

        /* Looping through map cells and find their corresponding indices in Path list */
		for (int j = 0; j < map.size(); j++) {
			for (int k = 0; k < map.get(j).size(); k++) {						
				if (map.get(j).get(k) == 0) {

					if (Path.contains(vertex)) {
						image.setRGB(j, k, RGBValue);  /* Coloring particular pixel */
					}
					vertex++;	                                        
				}
			}
		}

        /* Saving the image to a file in PNG format */
		ImageIO.write(image, "png", imageFile);

		if(algorithm == 1) {
            System.out.println("Dijkstra Algorithm Path has been drawn on the image.");
        }

        else System.out.println("BFS Algorithm Path has been drawn on the image.");
    }


    /**
     * Creates a map from an input file. 
     * @param inputFile The name of the input file that contains the map data 
     * @throws FileNotFoundException If the input file is not found. 
     */
    private void createMap(String inputFile) throws FileNotFoundException {
      
        File file = new File(inputFile);  
        Scanner readFile = new Scanner(file);  
        int row = 0, col = 0;
        int x1 = 0, y1 = 0, x2 = 0, y2 = 0;

        /* Iterating through lines of the file */
        while (readFile.hasNextLine()) {  

            String dataToRead = readFile.nextLine();  /* Reading next line of the file */
            String[] parts = dataToRead.split(",");   /* Splitting the line into an array of strings */
            int num = 0;
            col = 0;

            if (row == 0) {

                /* Reading and storing the coordinates of start point from first line */
                x1 = Integer.parseInt(parts[0]); 
                y1 = Integer.parseInt(parts[1]); 
                row++;
            }

            else if (row == 1) {

                /* Reading and storing coordinates of end point from second line */
                x2 = Integer.parseInt(parts[0]); 
                y2 = Integer.parseInt(parts[1]); 
                row++;
            }   

            else {

                /* Reading and storing the values of map cells from the rest of the lines */
                ArrayList<Integer> rowList = new ArrayList<Integer>();
                for (int k = 0; k < parts.length; k++) {
                    num = Integer.parseInt(parts[k]); 

                    if (num == -1) num = 1;  /* Replacing -1 with 1 to indicate obstacles */
                    rowList.add(num);
                }
                map.add(rowList);
            }
        }  
            
        calculateStartEnd(x1, y1, x2, y2);  /* Calculating the start and end point indices based on their coordinates */
        readFile.close();  /* Closing the Scanner object */
    }
    

    /**
     * Calculates the start and end point indices based on their coordinates.
     * @param x1 The x coordinate of the start point
     * @param y1 The y coordinate of the start point
     * @param x2 The x coordinate of the end point
     * @param y2 The y coordinate of the end point
     * @throws IllegalStateException If the start or end point is not available in the map.
     */
    private void calculateStartEnd(int x1, int y1, int x2, int y2) throws IllegalStateException  {
    
    	int vertex = 0;

        /* Iterating through map */
    	for (int i = 0; i < map.size() ; i++) { 
			for (int j = 0; j < map.get(i).size(); j++) { 
							
				if (map.get(i).get(j) == 0) {

                    /* Storing start point's index */
					if (i == x1 && j == y1) { startPoint = vertex; }

                    /* Storing end point's index */
					else if (i == x2 && j == y2) { endPoint = vertex; }
				
					vertex++;
				}
			}
	    }

        /* Throwing IllegalStateException exception if start or end point is not available */
        if (startPoint == -1) {
            throw new IllegalStateException("Error: Start point is not available.");
        }
        
        if (endPoint == -1) {
            throw new IllegalStateException("Error: End point is not available.");
        }
    }
    

    /**
     * Returns the index of the start point in the map
     * @return The index of the start point in the map
     */
    public int getSource() { return startPoint; }
    

    /**
     * Returns the index of the end point in the map
     * @return The index of the end point in the map
     */
    public int getDestination() { return endPoint; }


    /**
     * Returns the 2D arrayList that stores the values of the map cells
     * @return The 2D arrayList that stores the values of the map cells
     */
    public ArrayList<ArrayList<Integer> > getMap() { return map; }

}

