
/**
 * This class containts methods to apply bubble sort
 * algorithm to a custom map.
 * 
 * @file    BubbleSort.java
 * @author  Çağla Nur Yuva
 * @brief   Applies bubble sort algorithm to a custom map.
 * @version 1.0
 * @date    2023-05-20
 */
public class BubbleSort {

    /** Keeps original custom map */
    private myMap originalMap;

    /** Keeps sorted custom map */
    private myMap sortedMap;

    /** It keeps track of sorted keys of a custom map */
    private String [] aux;

 
    /**
     * Constructs a new BubbleSort object. 
     * Initializes originalMap, sortedMap and aux array.
     */
    private BubbleSort() {
        
        /* Initializing originalMap, sortedMap and aux array */
        originalMap = new myMap();
        sortedMap = new myMap();
        aux = new String[0];
    }

    
    /**
     * Constructs a new BubbleSort object with the specified custom map.
     * Initializes originalMap, sortedMap and aux array
     * @param map the custom map
     */
    public BubbleSort(final myMap map) {

        /* Initializing originalMap, sortedMap and aux array */
        originalMap = new myMap(map);
        sortedMap = new myMap();
        aux = new String[map.getSize()];

        /* Copying the keys from the original map to the aux array */
        int i = 0;
        for (String key : (originalMap.getMap()).keySet()) {
            aux[i] = key;
            i++;
        }
    }


    /**
     * Sorts aux array using the bubble sort algorithm.
     * Generates sortedMap using sorted aux array.
     * Calculates elapsed time during the algorithm.
     */
    public void bubbleSort() {
        long startTime = System.nanoTime();
        bubbleSortMap();     /* Sorting aux array */
        generateNewMap();    /* Generating sortedMap using aux array */
        
        long elapsedTime = System.nanoTime() - startTime;
        System.out.println("Bubble sort time: " + elapsedTime + " ns");
        
    }

    
    /** Sorts aux array using the bubble sort algorithm. */
    private void bubbleSortMap() {

        /* Iterating through aux array */
        
        boolean swapped = false;
        for (int i = 0; i < aux.length - 1; i++) {
        
            swapped = false;
            for (int j = 0; j < aux.length - i - 1; j++) {
                int num1 = (originalMap.getValue(aux[j])).getCount();
                int num2 = (originalMap.getValue(aux[j+1])).getCount();

                /* Comparing adjacent elements in aux array */
                if (num1 > num2) {
                    
                    /* Swapping adjacent elements */
                    String temp = aux[j];
                    aux[j] = aux[j + 1];
                    aux[j + 1] = temp;
                    swapped = true;
                }
            }
            
            if (swapped == false) break;		
        }
    }


    /** Generates sortedMap by using aux array for keys and originalMap for values. */
    private void generateNewMap() {
        for (int i = 0; i < originalMap.getSize(); i++) {
            sortedMap.add(aux[i], originalMap.getMap().get(aux[i]));
        }
    }


    /**
     * Returns orijinal custom map.
     * @return the original custom map
     */
    public myMap getOriginalMap() { return originalMap; }

    /**
     * Returns sorted custom map.
     * @return the sorted custom map
     */
    public myMap getSortedMap() { return sortedMap; }

}

