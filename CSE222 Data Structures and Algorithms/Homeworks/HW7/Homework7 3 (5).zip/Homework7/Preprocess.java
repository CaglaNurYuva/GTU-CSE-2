
/**
 * This class preprocesses and validates a given
 * String and validates a preprocessed String.
 * 
 * @file    Preprocess.java
 * @author  Çağla Nur Yuva
 * @brief   Preprocesses and validates a String.
 * @version 1.0
 * @date    2023-05-20
 */
public class Preprocess {  
    
    /**
     * Preprocesses and validates the given String
     * and validates preprocessed String.
     * @param input the String to preprocess
     */
    public String preprocessStr(String input) {
        boolean valid = false;

        /* Printing the original String */
        System.out.printf("\n%-27s", "Original String: ");
        System.out.println(input);

        /* Validating original String checking if it is full of whitespaces or null or empty */
        if (isValid(input)) {
            String temp = new String(input.trim());
            if (isValid(temp)) valid = true;   
        }

        /* Printing error message if the original String is invalid */
        if (!valid) {
            System.out.print("Original string given above is invalid since ");
            System.out.println("there is no word to preprocess and create a map...");
            return null;
        }


        /* Iterating through the given input String */
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);

            /* Removing an element if it is not a letter or space */
            if (!(isLetter(c) || c == ' ')) {
                String newStr = input.substring(0, i) + input.substring(i + 1);
                i--;
                input = newStr;
            }

            /* Converting uppercase letters to lowercase letters */
            else if (isUpperCase(c)) {
                c = toLowerCase(c);
                String newStr = input.substring(0, i) + c + input.substring(i + 1);
                input = newStr;
            }
        }

        
        /* Printing preprocessed String */
        System.out.printf("%-27s", "Preprocessed String: ");
        System.out.println(input);
        valid = false;

        /* Validating preprocessed String checking if it is full of whitespaces or null or empty */
        if (isValid(input)) {
            String temp = new String(input.trim());
            if (isValid(temp)) valid = true;
        }

        /* Printing error message if the preprocessed String is invalid */
        if (!valid) {
            System.out.print("Preprocessed string given above is invalid ");
            System.out.println("since there is no word to create a map...");
            return null;
        }
        
        return input;
    }


    /**
     * Checks if the input string is not null and not empty.
     * @param str the string to be checked
     * @return true if the string is not null and not empty, false otherwise.
     */
    private boolean isValid(final String str) {
        if (str == null || str.isEmpty()) return false;
        return true;
    }


    /**
     * Returns true if the given character is letter.
     * @param c the character to check
     * @return true if the given character is a letter.
     */
    private boolean isLetter(final char c) {
        return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
    }


    /**
     * Returns true if the given character is uppercase letter.
     * @param c the character to check
     * @return true if the given character is uppercase.
     */
    private boolean isUpperCase(final char c) { return (c >= 'A' && c <= 'Z'); }


    /**
     * Converts the given character to lowercase letter.
     * @param c the character to convert
     * @return the lowercase equivalent of the given character.
     */
    private char toLowerCase(final char c) { return (char)(c + ('a' - 'A')); }

}

