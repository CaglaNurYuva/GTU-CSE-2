
/**
 * This class containts methods to apply quick sort
 * algorithm to a custom map.
 * 
 * @file    QuickSort.java
 * @author  Çağla Nur Yuva
 * @brief   Applies quick sort algorithm to a custom map.
 * @version 1.0
 * @date    2023-05-20
 */
public class QuickSort {

    /** Keeps original custom map */
    private myMap originalMap;

    /** Keeps sorted custom map */
    private myMap sortedMap;

    /** It keeps track of sorted keys of a custom map */
    private String [] aux;

    
    /**
     * Constructs a new QuickSort object. 
     * Initializes originalMap, sortedMap and aux array.
     */
    private QuickSort() {

        /* Initializing originalMap, sortedMap and aux array */
        originalMap = new myMap();
        sortedMap = new myMap();
        aux = new String[0];
    }

    
    /**
     * Constructs a new QuickSort object with the specified custom map.
     * Initializes originalMap, sortedMap and aux array.
     * @param map the custom map
     */
    public QuickSort(final myMap map) {

        /* Initializing originalMap, sortedMap and aux array */
        originalMap = new myMap(map);
        sortedMap = new myMap();
        aux = new String[map.getSize()];

        /* Copying the keys from the original map to the aux array */
        int i = 0;
        for (String key : (originalMap.getMap()).keySet()) {
            aux[i] = key;
            i++;
        }
    }


    /**
     * Sorts aux array using the quick sort algorithm.
     * Generates sortedMap using sorted aux array.
     * Calculates elapsed time during the algorithm.
     */
    public void quickSort() {
        long startTime = System.nanoTime();
        quickSortMap(0, aux.length - 1);    /* Sorting aux array */
        generateNewMap();                        /* Generating sortedMap using aux array */
        
        long elapsedTime = System.nanoTime() - startTime;
        System.out.println("Quick sort time: " + elapsedTime + " ns");
    }

    
    /** Generates sortedMap by using aux array for keys and originalMap for values. */
    private void generateNewMap() {
        for (int i = 0; i < originalMap.getSize(); i++) {
            sortedMap.add(aux[i], originalMap.getMap().get(aux[i]));
        }
    }
    

    /**
     * Sorts elements in the specified subarray of aux array using quick sort algorithm.
     * @param left the left index of the subarray 
     * @param right the right index of the subarray
     */
    private void quickSortMap(final int left, final int right) {

        /* If the subarray has length 1 or less, it is already sorted */
        if (left < right) {
            
            /* Getting pivot index and recursively sorting left and right subarrays  */
            int pivotIndex = partition(left, right);  
            quickSortMap(left, pivotIndex - 1);
            quickSortMap(pivotIndex + 1, right);
        }
    }


    /**
     * Chooses the pivot element and partitions the aux array around it.
     * @param left the left index of subarray of aux array.
     * @param right the right index of subarray of aux array
     * @return the index of the pivot element
     */
    private int partition(final int left, final int right) {
        int pivotValue = originalMap.getValue(aux[right]).getCount();
        int i = left - 1;

        /* Iterating through the subarray */
        for (int j = left; j < right; j++) {

            /* Comparing the current element with the pivot element */
            int numToCompare = originalMap.getValue(aux[j]).getCount();
            if (numToCompare <= pivotValue) {
                i++;
                swap(i, j);
            }
        }

        swap(i + 1, right);
        return i + 1;
    }

    
    /**
     * Swaps the elements at the given indexes in aux array.
     * @param i the index of one element to be swapped
     * @param j the index of the other element to be swapped
     */
    private void swap(final int i, final int j) {
        String temp = aux[i];
        aux[i] = aux[j];
        aux[j] = temp;
    }

    
    /**
     * Returns orijinal custom map.
     * @return the original custom map
     */
    public myMap getOriginalMap() { return originalMap; }

    
    /**
     * Returns sorted custom map.
     * @return the sorted custom map
     */
    public myMap getSortedMap() { return sortedMap; }

}

