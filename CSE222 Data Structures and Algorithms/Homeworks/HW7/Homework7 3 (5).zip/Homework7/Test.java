
/**
 * Test class is used to test myMap, mergeSort
 * info and Preprocess classes and their functionality.
 * 
 * @file    Test.java
 * @author  Çağla Nur Yuva
 * @brief   Tests the classes and their functionality.
 * @version 1.0
 * @date    2023-05-20
 */
public class Test {  

    /**
     * It tests myMap, mergeSort, info and Preprocess classes. 
     * @param args An array of strings for command-line arguments.
     */
    public static void main(String[] args) {  
    
        String sorted = "a bb ccc dddd eeeee ffffff ggggggg hhhhhhhh iiiiiiiii jjjjjjjjjj kkkkkkkkkkk llllllllllll mmmmmmmmmmmmm" +
    	" nnnnnnnnnnnnnn ooooooooooooooo pppppppppppppppp rrrrrrrrrrrrrrrrr ssssssssssssssssss ttttttttttttttttttt";
    	
    	String reverselySorted = "ttttttttttttttttttt ssssssssssssssssss rrrrrrrrrrrrrrrrr pppppppppppppppp ooooooooooooooo" +
    	" nnnnnnnnnnnnnn mmmmmmmmmmmmm llllllllllll kkkkkkkkkkk jjjjjjjjjj iiiiiiiii hhhhhhhh ggggggg ffffff eeeee dddd ccc bb a";
    		
    	String random = "ffffff pppppppppppppppp jjjjjjjjjj hhhhhhhh nnnnnnnnnnnnnn ccc a ssssssssssssssssss llllllllllll" +
    	" dddd iiiiiiiii bb ooooooooooooooo eeeee rrrrrrrrrrrrrrrrr ggggggg mmmmmmmmmmmmm kkkkkkkkkkk ttttttttttttttttttt";
    
    	String bestForQuick = "a bb ccc dddd ffffff ggggggg hhhhhhhh eeeee jjjjjjjjjj kkkkkkkkkkk llllllllllll mmmmmmmmmmmmm" + 
    	" nnnnnnnnnnnnnn pppppppppppppppp rrrrrrrrrrrrrrrrr ssssssssssssssssss ttttttttttttttttttt ooooooooooooooo iiiiiiiii";
    	
    	String worstForMerge = "rrrrrrrrrrrrrrrrr a iiiiiiiii mmmmmmmmmmmmm eeeee ttttttttttttttttttt ccc kkkkkkkkkkk ooooooooooooooo" +
    	" ggggggg ssssssssssssssssss bb jjjjjjjjjj nnnnnnnnnnnnnn ffffff llllllllllll dddd pppppppppppppppp hhhhhhhh" ;
    	
    	/* sorted => 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19 */
    	/* reverselySorted => 19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,4,3,2,1 */
    	/* random => 6,16,10,8,14,3,1,18,12,4,9,2,15,5,17,7,13,11,19 */
    	/* bestForQuick => 1,2,3,4,6,7,8,5,10,11,12,13,14,16,17,18,19,15,9 */
    	/* worstForMerge => 17,1,9,13,5,19,3,11,15,7,18,2,10,14,6,12,4,16,8 */
    	
    	/* Testing Algorithms  */
        System.out.println("****************************************************************************");
    	System.out.println("Testing Merge Sort algorithm...");
    	
    	Preprocess prep = new Preprocess();
    	String preprocessed;
    	myMap map;
    	
        mergeSort sort1;
        SelectionSort sort2;
        InsertionSort sort3;
        BubbleSort sort4;
        QuickSort sort5;
        
    	
    	System.out.println("Testing Merge Sort Best Case...");
        preprocessed = prep.preprocessStr(sorted);
      
        if(preprocessed != null) {
        	map = new myMap(preprocessed); 
        	sort1 = new mergeSort(map); 
  		    sort1.MergeSort();
  		
  		    System.out.println("\nOriginal Map:");
  		    sort1.getOriginalMap().printMap();
  		    System.out.println("\nSorted Map:");
  		    sort1.getSortedMap().printMap();
        }
        System.out.println("------------------------------------------------------------");

        
        System.out.println("Testing Merge Sort Average Case...");
        preprocessed = prep.preprocessStr(random);
      
        if(preprocessed != null) {
        	map = new myMap(preprocessed); 
        	sort1 = new mergeSort(map); 
  		    sort1.MergeSort();
  		
  		    System.out.println("\nOriginal Map:");
  		    sort1.getOriginalMap().printMap();
  		    System.out.println("\nSorted Map:");
  		    sort1.getSortedMap().printMap();
        }
        System.out.println("------------------------------------------------------------");

        
        System.out.println("Testing Merge Sort Worst Case...");
        preprocessed = prep.preprocessStr(worstForMerge);
      
        if(preprocessed != null) {
        	map = new myMap(preprocessed); 
        	sort1 = new mergeSort(map); 
  		    sort1.MergeSort();
  		
  		    System.out.println("\nOriginal Map:");
  		    sort1.getOriginalMap().printMap();
  		    System.out.println("\nSorted Map:");
  		    sort1.getSortedMap().printMap();
        }
        System.out.println("------------------------------------------------------------");

        
        
        System.out.println("****************************************************************************");
        System.out.println("Testing Selection Sort algorithm...");
        
        
        System.out.println("Testing Selection Sort Best Case...");
        preprocessed = prep.preprocessStr(sorted);
      
        if(preprocessed != null) {
        	map = new myMap(preprocessed); 
        	sort2 = new SelectionSort(map); 
  		    sort2.selectionSort();
  		
  		    System.out.println("\nOriginal Map:");
  		    sort2.getOriginalMap().printMap();
  		    System.out.println("\nSorted Map:");
  		    sort2.getSortedMap().printMap();
        }
        System.out.println("------------------------------------------------------------");

        
        System.out.println("Testing Selection Sort Average Case...");
        preprocessed = prep.preprocessStr(random);
      
        if(preprocessed != null) {
        	map = new myMap(preprocessed); 
        	sort2 = new SelectionSort(map); 
  		    sort2.selectionSort();
  		
  		    System.out.println("\nOriginal Map:");
  		    sort2.getOriginalMap().printMap();
  		    System.out.println("\nSorted Map:");
  		    sort2.getSortedMap().printMap();
        }
        System.out.println("------------------------------------------------------------");

        
        System.out.println("Testing Selection Sort Worst Case...");
        preprocessed = prep.preprocessStr(reverselySorted);
      
        if(preprocessed != null) {
        	map = new myMap(preprocessed); 
        	sort2 = new SelectionSort(map); 
  		    sort2.selectionSort();
  		
  		    System.out.println("\nOriginal Map:");
  		    sort2.getOriginalMap().printMap();
  		    System.out.println("\nSorted Map:");
  		    sort2.getSortedMap().printMap();
        }
        System.out.println("------------------------------------------------------------");

        System.out.println("****************************************************************************");
        System.out.println("Testing Insertion Sort algorithm...");
        
        System.out.println("Testing Insertion Sort Best Case...");
        preprocessed = prep.preprocessStr(sorted);
      
        if(preprocessed != null) {
        	map = new myMap(preprocessed); 
        	sort3 = new InsertionSort(map); 
  		    sort3.insertionSort();
  		
  		    System.out.println("\nOriginal Map:");
  		    sort3.getOriginalMap().printMap();
  		    System.out.println("\nSorted Map:");
  		    sort3.getSortedMap().printMap();
        }
        System.out.println("------------------------------------------------------------");

        
        System.out.println("Testing Insertion Sort Average Case...");
        preprocessed = prep.preprocessStr(random);
      
        if(preprocessed != null) {
        	map = new myMap(preprocessed); 
        	sort3 = new InsertionSort(map); 
  		    sort3.insertionSort();
  		
  		    System.out.println("\nOriginal Map:");
  		    sort3.getOriginalMap().printMap();
  		    System.out.println("\nSorted Map:");
  		    sort3.getSortedMap().printMap();
        }
        System.out.println("------------------------------------------------------------");

        
        System.out.println("Testing Insertion Sort Worst Case...");
        preprocessed = prep.preprocessStr(reverselySorted);
      
        if(preprocessed != null) {
        	map = new myMap(preprocessed); 
        	sort3 = new InsertionSort(map); 
  		    sort3.insertionSort();
  		
  		    System.out.println("\nOriginal Map:");
  		    sort3.getOriginalMap().printMap();
  		    System.out.println("\nSorted Map:");
  		    sort3.getSortedMap().printMap();
        }
        System.out.println("------------------------------------------------------------");

        System.out.println("****************************************************************************");
        System.out.println("Testing Bubble Sort algorithm...");
        
        System.out.println("Testing Bubble Sort Best Case...");
        preprocessed = prep.preprocessStr(sorted);
      
        if(preprocessed != null) {
        	map = new myMap(preprocessed); 
        	sort4 = new BubbleSort(map); 
  		    sort4.bubbleSort();
  		
  		    System.out.println("\nOriginal Map:");
  		    sort4.getOriginalMap().printMap();
  		    System.out.println("\nSorted Map:");
  		    sort4.getSortedMap().printMap();
        }
        System.out.println("------------------------------------------------------------");

        
        System.out.println("Testing Bubble Sort Average Case...");
        preprocessed = prep.preprocessStr(random);
      
        if(preprocessed != null) {
        	map = new myMap(preprocessed); 
        	sort4 = new BubbleSort(map); 
  		    sort4.bubbleSort();
  		
  		    System.out.println("\nOriginal Map:");
  		    sort4.getOriginalMap().printMap();
  		    System.out.println("\nSorted Map:");
  		    sort4.getSortedMap().printMap();
        }
        System.out.println("------------------------------------------------------------");

        
        System.out.println("Testing Bubble Sort Worst Case...");
        preprocessed = prep.preprocessStr(reverselySorted);
      
        if(preprocessed != null) {
        	map = new myMap(preprocessed); 
        	sort4 = new BubbleSort(map); 
  		    sort4.bubbleSort();
  		
  		    System.out.println("\nOriginal Map:");
  		    sort4.getOriginalMap().printMap();
  		    System.out.println("\nSorted Map:");
  		    sort4.getSortedMap().printMap();
        }
        System.out.println("------------------------------------------------------------");

        System.out.println("****************************************************************************");
        System.out.println("Testing Quick Sort algorithm...");
        
        System.out.println("Testing Quick Sort Best Case...");
        preprocessed = prep.preprocessStr(bestForQuick);
      
        if(preprocessed != null) {
        	map = new myMap(preprocessed); 
        	sort5 = new QuickSort(map); 
  		    sort5.quickSort();
  		
  		    System.out.println("\nOriginal Map:");
  		    sort5.getOriginalMap().printMap();
  		    System.out.println("\nSorted Map:");
  		    sort5.getSortedMap().printMap();
        }
        System.out.println("------------------------------------------------------------");

        
        System.out.println("Testing Quick Sort Average Case...");
        preprocessed = prep.preprocessStr(random);
      
        if(preprocessed != null) {
        	map = new myMap(preprocessed); 
        	sort5 = new QuickSort(map); 
  		    sort5.quickSort();
  		
  		    System.out.println("\nOriginal Map:");
  		    sort5.getOriginalMap().printMap();
  		    System.out.println("\nSorted Map:");
  		    sort5.getSortedMap().printMap();
        }
        System.out.println("------------------------------------------------------------");
        
        
        System.out.println("Testing Quick Sort Worst Case...");
        preprocessed = prep.preprocessStr(sorted);
      
        if(preprocessed != null) {
        	map = new myMap(preprocessed); 
        	sort5 = new QuickSort(map); 
  		    sort5.quickSort();
  		
  		    System.out.println("\nOriginal Map:");
  		    sort5.getOriginalMap().printMap();
  		    System.out.println("\nSorted Map:");
  		    sort5.getSortedMap().printMap();
        }
        System.out.println("------------------------------------------------------------");
    }
    
}

