
/**
 * This class containts methods to apply insertion sort
 * algorithm to a custom map.
 * 
 * @file    InsertionSort.java
 * @author  Çağla Nur Yuva
 * @brief   Applies insertion sort algorithm to a custom map.
 * @version 1.0
 * @date    2023-05-20
 */
public class InsertionSort {

    /** Keeps original custom map */
    private myMap originalMap;

    /** Keeps sorted custom map */
    private myMap sortedMap;

    /** It keeps track of sorted keys of a custom map */
    private String[] aux;

    
    /**
     * Constructs a new InsertionSort object. 
     * Initializes originalMap, sortedMap and aux array.
     */
    private InsertionSort() {

        /* Initializing originalMap, sortedMap and aux array */
        originalMap = new myMap();
        sortedMap = new myMap();
        aux = new String[0];
    }


    /**
     * Constructs a new InsertionSort object with the specified custom map.
     * Initializes originalMap, sortedMap and aux array
     * @param map the custom map
     */
    public InsertionSort(final myMap map) {

        /* Initializing originalMap, sortedMap and aux array */
        originalMap = new myMap(map);
        sortedMap = new myMap();
        aux = new String[map.getSize()];
        
        /* Copying the keys from the original map to the aux array */
        int i = 0;
        for (String key : (originalMap.getMap()).keySet()) {
            aux[i] = key;
            i++;
        }
    }


    /**
     * Sorts aux array using the insertion sort algorithm.
     * Generates sortedMap using sorted aux array.
     * Calculates elapsed time during the algorithm.
     */
    public void insertionSort(){
    	long startTime = System.nanoTime();
        insertionSortMap();     /* Sorting aux array */
        generateNewMap();       /* Generating sortedMap using aux array */
        
        long elapsedTime = System.nanoTime() - startTime;
        System.out.println("Insertion sort time: " + elapsedTime + " ns");
    }
    

    /** Sorts aux array using the insertion sort algorithm. */
    private void insertionSortMap() {

        /* Iterating through aux array */
        for (int i = 1; i < aux.length; i++) {
            String key = aux[i];
            int j = i - 1;

            /* Shifting the elements to the right until the correct position is found for the current key */
            while (j >= 0 && originalMap.getValue(aux[j]).getCount() > originalMap.getValue(key).getCount()) {
          
                aux[j + 1] = aux[j];
                j = j - 1;
            }

            /* Placing the key at the correct position */
            aux[j + 1] = key; 
        }
    }


    /** Generates sortedMap by using aux array for keys and originalMap for values. */
    private void generateNewMap() {
        for (int i = 0; i < originalMap.getSize(); i++) {
            sortedMap.add(aux[i], originalMap.getMap().get(aux[i]));
        }
    }


    /**
     * Returns orijinal custom map.
     * @return the original custom map
     */
    public myMap getOriginalMap() { return originalMap; }


    /**
     * Returns sorted custom map.
     * @return the sorted custom map
     */
    public myMap getSortedMap() { return sortedMap; }

}

