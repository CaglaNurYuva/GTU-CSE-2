
import java.lang.InterruptedException;
/**
 * This class containts methods to apply selection sort
 * algorithm to a custom map.
 * 
 * @file    SelectionSort.java
 * @author  Çağla Nur Yuva
 * @brief   Applies selection sort algorithm to a custom map.
 * @version 1.0
 * @date    2023-05-20
 */
public class SelectionSort {
    
    /** Keeps original custom map */
    private myMap originalMap;

    /** Keeps sorted custom map */
    private myMap sortedMap;

    /** It keeps track of sorted keys of a custom map */
    private String [] aux;

    
    /**
     * Constructs a new SelectionSort object. 
     * Initializes originalMap, sortedMap and aux array.
     */
    private SelectionSort() {

        /* Initializing originalMap, sortedMap and aux array */
        originalMap = new myMap();
        sortedMap = new myMap();
        aux = new String[0];
    }

    
    /**
     * Constructs a new SelectionSort object with the specified custom map.
     * Initializes originalMap, sortedMap and aux array.
     * @param map the custom map
     */
    public SelectionSort(final myMap map) {

        /* Initializing originalMap, sortedMap and aux array */
        originalMap = new myMap(map);
        sortedMap = new myMap();
        aux = new String[map.getSize()];
        
        /* Copying the keys from the original map to the aux array */
        int i = 0;
        for (String key : (originalMap.getMap()).keySet()) {
            aux[i] = key;
            i++;
        }
    }


    /**
     * Sorts aux array using the selection sort algorithm.
     * Generates sortedMap using sorted aux array.
     * Calculates elapsed time during the algorithm.
     */
    public void selectionSort() {
   
        long startTime = System.nanoTime();
        selectionSortMap();     /* Sorting aux array */
        generateNewMap();       /* Generating sortedMap using aux array */
        
        long elapsedTime = System.nanoTime() - startTime;
        System.out.println("Selection sort time: " + elapsedTime + " ns");
    }


    /** Sorts the aux array by using the selection sort algorithm. */
    private void selectionSortMap() {

	int n = aux.length;
        /* Iterating through aux array */
        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;

            /* Finding minimum element's index in unsorted part of aux array */
            for (int j = i + 1; j < n; j++) {
                int num = originalMap.getValue(aux[j]).getCount();
                int minValue = originalMap.getValue(aux[minIndex]).getCount();
                
                if (num < minValue) minIndex = j;
            }

            /* Swap minimum element with first element of unsorted part of aux array */
            if(minIndex != i) {
            	String temp = aux[minIndex];
            	aux[minIndex] = aux[i];
            	aux[i] = temp;
            }
            
        }
    }

    
    /** Generates sortedMap by using aux array for keys and originalMap for values. */
    private void generateNewMap() {
        for (int i = 0; i < originalMap.getSize(); i++) {
            sortedMap.add(aux[i], originalMap.getMap().get(aux[i]));
        }
    }


    /**
     * Returns orijinal custom map.
     * @return the original custom map
     */
    public myMap getOriginalMap() { return originalMap; }


    /**
     * Returns sorted custom map.
     * @return the sorted custom map
     */
    public myMap getSortedMap() { return sortedMap; }

}

