
/**
 * This class containts methods to apply merge sort
 * algorithm to a custom map.
 * 
 * @file    mergeSort.java
 * @author  Çağla Nur Yuva
 * @brief   Applies merge sort algorithm to a custom map.
 * @version 1.0
 * @date    2023-05-20
 */
public class mergeSort {

    /** Keeps original custom map */
    private myMap originalMap;
    
    /** Keeps sorted custom map */
    private myMap sortedMap;

    /** It keeps track of sorted keys of a custom map */
    private String [] aux;


    /**
     * Constructs a new mergeSort object. 
     * Initializes originalMap, sortedMap and aux array.
     */
    private mergeSort() {

        /* Initializing originalMap, sortedMap and aux array */
        originalMap = new myMap();
        sortedMap = new myMap();
        aux = new String[0];
    }


    /**
     * Constructs a new mergeSort object with the specified custom map.
     * Initializes originalMap, sortedMap and aux array.
     * @param map the custom map
     */
    public mergeSort(final myMap map) {

        /* Initializing originalMap, sortedMap and aux array */
        originalMap = new myMap(map);
        sortedMap = new myMap();
        aux = new String[map.getSize()];
   

        /* Copying the keys from the original map into the aux array */
        int i = 0;
        for (String key : (originalMap.getMap()).keySet()) {
            aux[i] = key;
            i++;
        }
    }


    /** Generates sortedMap by using aux array for keys and originalMap for values. */
    private void generateNewMap() {
        for (int i = 0; i < originalMap.getSize(); i++) {
            sortedMap.add(aux[i], originalMap.getMap().get(aux[i]));
        }
    }


    /**
     * Sorts aux array using the merge sort algorithm.
     * Generates sortedMap using sorted aux array.
     * Calculates elapsed time during the algorithm.
     */
    public void MergeSort() {
        long startTime = System.nanoTime();
        mergeSortMap(0, aux.length - 1);     /* Sorting aux array */
        generateNewMap();                    /* Generating sortedMap using aux array */
        
        long elapsedTime = System.nanoTime() - startTime;
        System.out.println("Merge sort time: " + elapsedTime + " ns");
    }


    /**
     * Sorts aux array using the merge sort algorithm.
     * @param left the left index of subarray of aux array.
     * @param right the right index of subarray of aux array
     */
    private void mergeSortMap(final int left, final int right) {

        /* If the subarray has length 1 or less, it is already sorted */
        if (left < right) {
            int mid = (left + right) / 2;

            /* Dividing the aux array in half and recursively sort each half */
            mergeSortMap(left, mid);
            mergeSortMap(mid + 1, right);

            /* Merging the sorted halves into a single sorted subarray */
            merge(left, mid, right);
        }
    }

    
    /**
     * Merges two sorted subarrays of aux array.
     * @param left the left index of the first subarray
     * @param mid the index of the element that separates the two subarrays
     * @param right the right index of the second subarray
     */
    private void merge(final int left, final int mid, final int right) {
        int n1 = mid - left + 1;
        int n2 = right - mid;

        int[] leftArr = new int[n1];
        String Left[] = new String[n1];
        
        int[] rightArr = new int[n2];
        String Right[] = new String[n2];
        

        /* Copying keys and count value of values of originalMap to the two subarrays of aux array */
        for (int i = 0; i < n1; ++i) {
            leftArr[i] = originalMap.getValue(aux[left + i]).getCount();
            Left[i] = aux[left + i];
        }

        for (int j = 0; j < n2; ++j) {
            rightArr[j] = originalMap.getValue(aux[mid + 1 + j]).getCount();
            Right[j] = aux[mid + 1 + j];
        }


        /* Initializing variables to keep track of indexes of subarrays and aux array */
        int i = 0, j = 0;
        int k = left;

        /* Iterating through the two subarrays and comparing the elements at each index */
        while (i < n1 && j < n2) {
            
            if (leftArr[i] <= rightArr[j]) {
                aux[k] = Left[i];
                i++;
            } 
                
            else {
                aux[k] = Right[j];
                j++;
            }
            k++;
        }

        /* Copying any remaining elements from the left subarray to aux array. */
        while (i < n1) {
            aux[k] =  Left[i];
            i++;
            k++;
        }

        /* Copying any remaining elements from the right subarray to aux array. */
        while (j < n2) {
            aux[k] = Right[j];
            j++;
            k++;
        }
    }

    
    /**
     * Returns orijinal custom map.
     * @return the original custom map
     */
    public myMap getOriginalMap() { return originalMap; }


    /**
     * Returns sorted custom map.
     * @return the sorted custom map
     */
    public myMap getSortedMap() { return sortedMap; }

}

