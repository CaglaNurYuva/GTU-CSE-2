
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * This class represents a custom map data structure and
 * implements methods for it.
 * 
 * @file    myMap.java
 * @author  Çağla Nur Yuva
 * @brief   Represents a custom map data structure.
 * @version 1.0
 * @date    2023-05-20
 */
public class myMap {  

    /* Keeps preprocessed string */
    private String str; 

    /** Keeps the size of custom map */
    private int mapSize = 0;

    /** Keeps a LinkedHashMap for the custom map */
    private LinkedHashMap <String,info> map;
 

    /**
     * Copy constructor to copy one custom map to another.
     * @param otherMap the custom map to copy.
     */
    public myMap(final myMap otherMap) {

        /* Creating a new LinkedHashMap for custom map */
        map = new LinkedHashMap <String, info>();

        /* Copying the entries of the otherMap to this map */
        for (Map.Entry <String, info> entry : (otherMap.getMap()).entrySet()) {
            String key = entry.getKey();
            info value = new info(entry.getValue());
            map.put(key, value);
        }

        mapSize = otherMap.getSize();
    }


    /** Constructs a new myMap object. */
    public myMap() {

        /* Creating a new LinkedHashMap for custom map */
        map = new LinkedHashMap <String,info>();
        mapSize = 0;
    }
 
     
    /**
     * Constructs a new myMap object with the given string.
     * @param preprocessed the string to create the custom map from.
     */
    public myMap(final String preprocessed) {

        /* Creating a new LinkedHashMap for custom map */
        map = new LinkedHashMap <String,info>();

        /* Storing preprocessed string */
        str = preprocessed;

        mapSize = 0;

        /* Creating custom map using preprocessed string */
        createMap();
    }
 

    /** Creates a custom map using preprocessed string */
    private void createMap() {

        for (int i = 0; i < str.length(); i++) {
 
            /* Getting the character as String at the current index */
            String ch = new String(str.substring(i, i + 1));

            /* Ignoring spaces */
            if (!ch.equals(" ")) {
                 
                info allInfo; 

                /* If the character exists in the map as a key, get and update its associated info object */
                if (map.containsKey(ch)) {
                    allInfo = getInfo(ch);
                    allInfo.createWord(str, i);  /* Updating words array */
                }
 
                /* If the character doesn't exist in the map as a key, create a new info object and add it to the map */
                else {
                    allInfo = new info(); 
                    allInfo.createWord(str, i);  /* Updating words array */
                    map.put(ch, allInfo);
                    mapSize++;
                }
            }
        }
    }
     
   
    /**
     * Returns info object associated with the
     * given string, which is a key of an entry.
     * @param c the string to search for.
     * @return the info object associated with the given string.
     */
    public info getInfo(final String c) {

        /* Iterating through entries of map */
        for (Map.Entry <String, info> entry : map.entrySet()) {

            String key = entry.getKey();
            if (key.equals(c)) {
                info value = entry.getValue();
                return value;
            }
        }

        return null;
    }
 

    /** Prints the custom map to the console. */
    public void printMap() {
   
        /* Iterating through entries of map */
        for (Map.Entry <String, info> entry : map.entrySet()) {
 
            /* Getting info object as a value of an entry */
            info value = entry.getValue();

            /* Printing keys and values of map as an entry */
            System.out.print("Letter: " + entry.getKey());
            System.out.print(" - Count: " + value.getCount());
            System.out.print(" - Words: [");
 
            int length = value.getCount();
  
            /* Printing words array */
            for (int i = 0; i < length; i++) {
                System.out.print((value.getWords())[i]);
                if (i != length - 1) System.out.print(", ");
            }
            
            System.out.println("]");
        }  
    }
 

    /**
     * Returns the map kept by custom map.
     * @return the map kepty by custom map.
     */
    public LinkedHashMap <String,info> getMap() { return map; }
   
 
    /**
     * Returns the size of custom map.
     * @return the size of custom map
     */
    public int getSize() { return mapSize; }
 

    /** Clears the map. */
    public void clearMap() { 
        map.clear();  
        mapSize = 0; 
    }
     

    /**
     * Adds a key-value pair to the custom map.
     * @param key the key to add.
     * @param value the value to add.
     */
    public void add(final String key, final info value) {

        /* Increasing size of the map if the key is not already in map */
        if (getValue(key) == null) mapSize++;

        /* Adding the key-value pair to map as an entry */
        map.put(key,value);
    }
 

    /**
     * Returns info object associated with given key.
     * @param key the key to search for.
     * @return the info object associated with given key.
     */
    public info getValue(final String key) { return map.get(key); }
 
  
    /**
     * Returns the key at given index.
     * @param index the index of the key to return.
     * @return the key at the given index.
     */
    public String getKey(final int index) {
 
        int i = 0;

        /* Iterating through keys of map */
        for (String key : map.keySet()) {
            if (i == index) return key;
            i++;
        }
        return null;
    }
    
}

