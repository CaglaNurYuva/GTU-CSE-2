
import javax.swing.tree.DefaultMutableTreeNode;  
import java.io.File;   
import java.io.FileNotFoundException;    
import java.util.Scanner;   
import java.util.Queue;
import java.util.LinkedList;
import java.util.Stack;
import javax.swing.JTree;
import javax.swing.JFrame;
import javax.swing.JScrollPane;

/**
 * The Tree class represents tree data structure and implements methods 
 * to create a JTree and perform some operations on it.
 * 
 * @file    Tree.java
 * @author  Çağla Nur Yuva
 * @brief   Creates JTree and perform operations on it.
 * @version 1.0
 * @date    2023-05-04
 */
public class Tree {  

    /** Keeps the data that is read from text file. */
    private String[][] treeData = new String[1][1]; 

    /** Represents the root node of the JTree. */
    private DefaultMutableTreeNode Root = new DefaultMutableTreeNode("Root");

    /** The JFrame object to keep the JTree. */
    private JFrame frame;  

    /** The JTree object to display tree data structure. */
    private JTree tree; 
    
    /**
     * Reallocates the treeData array to a new size.
     * @param newRowSize The new number of rows of treeData array.
     * @param newColSize The new number of colums of treeData array.
     */
    private void reallocate(final int newRowSize, final int newColSize) {

        int i = 0;  
        String[][] newArray = new String[newRowSize][];
        boolean flag = newRowSize > treeData.length ? true : false;  /* Keeps if row size will be changed */
          
        /* Iterating through 2D String array */
        for (i = 0; i < treeData.length; i++) {
            if (flag == false && i == newRowSize - 1) {
                newArray[i] = new String[newColSize];
                break;
            }

            newArray[i] = new String[treeData[i].length];
            
            /* Copying the values from treeData array to newArray array */
            for (int j = 0; j < treeData[i].length; j++) newArray[i][j] = treeData[i][j];
        }
        
        if (flag == true) newArray[i] = new String[newColSize];   
        treeData = newArray;  /* Assigning newArray to treeData array */ 
    }


    /**
     * Reads the data from the text file and stores the data in treeData array.
     */
    private void FileToString() {
        try {  

            File file = new File("../Homework5/tree.txt");  
            Scanner readFile = new Scanner(file);  
            int row = 0, col = 0;

            /* Iterate through lines of the file */
            while (readFile.hasNextLine()) {  
                String dataToRead = readFile.nextLine();  /* Reading next line of the file */
                String[] parts = dataToRead.split(";");   /* Splitting the line into an array of strings */
                col = 0;

                /* Reallocating treeData array */
                if (row == treeData.length) reallocate(treeData.length + 1, parts.length); 
                else if (parts.length > treeData[row].length) reallocate(treeData.length, parts.length);

                /* Iterating through parts array to copy parts array to treeData array */ 
                for (int k = 0; k < parts.length; k++) {
                    treeData[row][col] = parts[k]; 
                    col++;
                }
                row++;
            }  
            readFile.close();   /* Closing the Scanner object */
        } 

        /* Catching FileNotFoundException, if the file cannot be found. */
        catch (FileNotFoundException exception) {  

            System.out.println("File cannot be found!");  
            exception.printStackTrace();
            System.out.println("Quitting the program..."); 
            System.exit(1); 
        } 
    }


    /**
     * Creates a JTree by using the data in treeData array as nodes of JTree.
     * @throws FileNotFoundException if the specified file cannot be found.
     */
    public void createTree() {
        
        boolean flag = false;
        FileToString();  /* Reading file and store it in treeData array as nodes */

        /* Iterating through columns of treeData array */
        for (int j = 0; flag == false; j++) {
            flag = true;

            /* Iterating through rows of treeData array */
            for (int i = 0; i < treeData.length; i++) {
                if (j < treeData[i].length) {

                    /* Creating a new node */
                    DefaultMutableTreeNode newNode = new DefaultMutableTreeNode(treeData[i][j]);
                    
                    /* Finding new node's parent node */
                    DefaultMutableTreeNode newParent = Root;
                    for (int k = 0; k < j; k++) newParent = searchNode(newParent,treeData[i][k]);
                    
                    /* Checking if the parent node already has a child node with this name */ 
                    if (searchNode(newParent,newNode.getUserObject().toString()) == null) { newParent.add(newNode); }
                    flag = false;
                } 
            }
        }
        
        /* Creating JFrame and JTree to display the tree structure */ 
        frame = new JFrame();   
        tree = new JTree(Root);

        frame.add(tree);  
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(200,400);  
        frame.getContentPane().add(new JScrollPane(tree));
    }

    
    /**
     * Searches for a node with certain name only among the child nodes of root node.
     * @param root The root node to start the search from.
     * @param nodeName The name of the node to search for.
     * @return The node with the certain name, or null if the node cannot be found.
     */
    private DefaultMutableTreeNode searchNode(final DefaultMutableTreeNode root, final String nodeName) {
         
        /* Iterating through child nodes of the root node */
        for (int i = 0; i < root.getChildCount(); i++) {

            /* Getting current child node */
            DefaultMutableTreeNode node = (DefaultMutableTreeNode) root.getChildAt(i);

            /* If a node with certain name is found, return the node */
            if (nodeName.equals(node.getUserObject().toString())) return node;
        }

        /* If a node with certain name is not found, return null */
        return null;
    }


    /**
     * Searches for a node with certain name in JTree using the Breadth-First search algorithm.
     * @param input The name of the node to search for.
     * @return The node with the certain name, or null if the node cannot be found.
     */
    public DefaultMutableTreeNode searchWithBFS(final String input) {

        Queue<DefaultMutableTreeNode> queue = new LinkedList<DefaultMutableTreeNode>();
        int step = 1;

        queue.add(Root); 
        System.out.println("\nUsing BFS to find '" + input + "' in the tree...\n");

        while (!queue.isEmpty()) {
            DefaultMutableTreeNode tempNode = queue.poll();  /* Getting the first node in the queue */
            
            /* If current node's name is the same as the node's name we look for, return the node. */
            if (input.equals(tempNode.getUserObject().toString())) {
                System.out.println("Step " + step + " -> " + tempNode.getUserObject().toString() + " (Found!)");
                return tempNode;
            }    
                
            System.out.println("Step " + step + " -> " + tempNode.getUserObject().toString());
            step++;
         
            /* Adding all child nodes of the current node to the queue */
            for (int i = 0; i < tempNode.getChildCount(); i++) {
                DefaultMutableTreeNode child = (DefaultMutableTreeNode) tempNode.getChildAt(i);
                queue.add(child);
            }
        }

        System.out.println("Not found.");
        return null;  /* Returning null since the node is not found. */
    }


    /**
     * Searches for a node with certain name in JTree using the Depth-First search algorithm.
     * @param input The name of the node to search for.
     * @return The node with the certain name, or null if the node cannot be found.
     */
    public DefaultMutableTreeNode searchWithDFS(final String input) {

        Stack<DefaultMutableTreeNode> stack = new Stack<DefaultMutableTreeNode>();
        int step = 1;

        stack.add(Root);
        System.out.println("\nUsing DFS to find '" + input + "' in the tree...\n");

        while (!stack.isEmpty()) {
            DefaultMutableTreeNode tempNode = stack.pop();  /* Getting the first node in the stack */

            /* If current node's name is the same as the node's name we look for, return the node. */
            if (input.equals(tempNode.getUserObject().toString())) {
                System.out.println("Step " + step + " -> " + tempNode.getUserObject().toString() + " (Found!)");
                return tempNode;
            }   

            System.out.println("Step " + step + " -> " + tempNode.getUserObject().toString());
            step++;

            /* Adding all child nodes of the current node to the stack */
            for (int i = 0; i < tempNode.getChildCount(); i++) {
                DefaultMutableTreeNode child = (DefaultMutableTreeNode) tempNode.getChildAt(i);
                stack.push(child);
            }

        }

        System.out.println("Not found.");
        return null;  /* Returning null since the node is not found. */
    }
    

    /**
     * Searches for a node with certain name in JTree using the Post-Order traversal search algorithm.
     * @param input The name of the node to search for.
     * @return The node with the certain name, or null if the node cannot be found.
     */
    public DefaultMutableTreeNode searchWithPostOrder(final String input) {

        Stack<DefaultMutableTreeNode> stack = new Stack<>();
        int step = 1;

        /* Filling the stack with all nodes in the correct order for a Post-Order traversal algorithm. */
        stack = createStack(Root,stack);
        
        System.out.println("\nUsing Post-Order traversal to find '" + input + "' in the tree...\n");
        while (!stack.isEmpty()) {
            DefaultMutableTreeNode tempNode = stack.pop();  /* Getting the next node in the stack */

            /* If current node's name is the same as the node's name we look for, return the node. */
            if (input.equals(tempNode.getUserObject().toString())) {
                System.out.println("Step " + step + " -> " + tempNode.getUserObject().toString() + " (Found!)");
                return tempNode;
            }   

            System.out.println("Step " + step + " -> " + tempNode.getUserObject().toString());
            step++;
        }

        System.out.println("Not found.");
        return null;  /* Returning null since the node is not found. */
    }


    /**
     * Creates a stack of nodes in JTree to use with Post-Order traversal search algorithm.
     * @param parent The parent node to start filling the stack with its child nodes.
     * @param stack The stack to add the nodes in.
     * @return The stack of nodes.
     */
    private Stack<DefaultMutableTreeNode> createStack(final DefaultMutableTreeNode parent, final Stack<DefaultMutableTreeNode> stack) {

        for (int i = parent.getChildCount() - 1; i >= 0; i--) {
            DefaultMutableTreeNode child = (DefaultMutableTreeNode) parent.getChildAt(i);  /* Getting the current child node */
            stack.push(child);  /* Pushing the child node to the stack */
            createStack(child,stack);  
        }
        
        return stack;  /* Returning stack */
    }
    

    /**
     * Moves a node in the JTree to a new parent node.
     * @param partsSource An array of strings to represent the path to the node that will move.
     * @param destination String for new parent node's name to move the node to.
     */
    public void moveNode(final String[] partsSource, final String destination) {

        /* Checking if the partsSource array has at least two elements */
        if (partsSource.length < 2) {
            System.out.println("Invalid entry for source node path, you have to enter at least 2 nodes' name...");
            return;
        }

        /* Finding the node to be moved */
        DefaultMutableTreeNode nodeToMove = searchNode(Root, partsSource[0]);
        boolean valid = true;

        /* Checking validity of input nodes that are get from the user */
        if (nodeToMove == null) valid = false;
        else {
            for (int i = 1; i < partsSource.length; i++) {
                nodeToMove = searchNode(nodeToMove, partsSource[i]);
                if (nodeToMove == null) {
                    valid = false;
                    break;
                }
            }
        }

        if (valid == false) {
            System.out.print("Cannot move "); 
            for (int j = 0; j < partsSource.length; j++) {
                System.out.print(partsSource[j]);
                if (j != partsSource.length - 1) System.out.print("->");
            }

            System.out.println(" because it doesn't exist in the tree.");
            return;
        }

        /* Checking destination node */
        try { int check = Integer.parseInt(destination); } 

        catch (NumberFormatException Exception) {
            System.out.println("Invalid input! destination node is not an integer...");
            return;
        }
        

        /* Removing the node to be moved and the nodes that will be empty after moving the node */
        removeEmptyNodes((DefaultMutableTreeNode) nodeToMove.getParent(), nodeToMove);

        /* Finding parent node of the node that is moved */
        DefaultMutableTreeNode newParent = searchNode(Root,destination);
        
        if (newParent == null) {
            DefaultMutableTreeNode newNode = new DefaultMutableTreeNode(destination);
            Root.add(newNode);
            newParent = (DefaultMutableTreeNode) Root.getChildAt(Root.getChildCount() - 1);
        }
        

        /* Iterating through partsSource array to create nodes that are absent in destination directory */
        for (int i = 1; i < (partsSource.length - 1); i++) {
            DefaultMutableTreeNode newNode = searchNode(newParent, partsSource[i]);   

            if (newNode == null) {
                newNode = new DefaultMutableTreeNode(partsSource[i]);
                newParent.add(newNode);
            }
            newParent = newNode;
        }


        /* Check if newParent node has a child node that is the same as the node to be moved. */
        boolean overwritten = false;
        for (int i = 0; i < newParent.getChildCount(); i++) {
            DefaultMutableTreeNode child = (DefaultMutableTreeNode) newParent.getChildAt(i);

            /* Comparing child node and the node to be moved */
            if (nodeToMove.getUserObject().toString().equals((child.getUserObject().toString()))) {
                overwritten = true;

                /* Overwriting the node */
                if (nodeToMove.getChildCount() == 0) child = nodeToMove;
                 
                else {

                    /* Removing nodes to be overwritten */
                    for (int j = 0; j < child.getChildCount(); j++) {
                        removeWholeNode((DefaultMutableTreeNode) child.getChildAt(j)); 
                    }

                    for (int k = child.getChildCount() - 1; k >= 0; k--) {
                        child.remove(k);
                    }
                    
                    /* Adding nodes to overwrite */
                    addAllChilds(child, nodeToMove);
                }

                break;
            }
        }


        /* Adding node to be moved as a child node of the newParent node since it does not exist there. */
        if (!overwritten) newParent.add(nodeToMove);
        
        /* Checking if the node has been moved to where it was at or not. */
        if(destination.equals(partsSource[0])) overwritten = true;


        /* Printing informative messages */
        System.out.print("Moved ");
        for (int i = 0; i < partsSource.length; i++) {
            System.out.print(partsSource[i]);
            if (i != partsSource.length - 1) System.out.print("->");
        }
        System.out.println(" to " + destination + ".");

        if (overwritten) {
            System.out.print(destination);
            for (int i = 1; i < partsSource.length; i++) System.out.print("->" + partsSource[i]);
            System.out.println(" has been overwritten.");
        }
        
        /* Creating a new JFrame and JTree and adding tree in frame */
        frame.setVisible(false);
        frame = new JFrame();
        tree = new JTree(Root);
        frame.add(tree);  
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(200,400);  
        frame.getContentPane().add(new JScrollPane(tree));
    }

    /**
     * Removes empty directories above the node that will be moved.
     * @param parent The parent node of the node to be checked if it has any child nodes.
     * @param node The node to be checked if it has any child nodes.
     */
    private void removeEmptyNodes(final DefaultMutableTreeNode parent, final DefaultMutableTreeNode node) {

        /* If the node has siblings, its parent will not be empty after removing the node. */
        if (node.getNextSibling() != null || node.getPreviousSibling() != null) {
            parent.remove(node);  
            return;
        }
        
        parent.remove(node);  /* Removing the node */
        removeEmptyNodes((DefaultMutableTreeNode) parent.getParent(), parent);  /* Keep removing empty nodes */
    }


    /**
     * Removes the given node's entire subtree from the JTree.
     * @param rootOfSubtree The root node of the subtree to be removed.
     */
    private void removeWholeNode(final DefaultMutableTreeNode rootOfSubtree) {

        for (int i = 0; i < rootOfSubtree.getChildCount(); i++) {

            /* Recursively calling the method on all child nodes */
            removeWholeNode((DefaultMutableTreeNode) rootOfSubtree.getChildAt(i));
        }

        /* Removing all child nodes of rootOfSubtree node */    
        for (int j = rootOfSubtree.getChildCount() - 1; j >= 0; j--) {
            rootOfSubtree.remove(j);
        }
    }


    /**
     * Adds all child nodes of the source root to the destination node in the JTree.
     * @param rootDestination The root node of the destination subtree.
     * @param rootSource The root node of the source subtree.
     */
    private void addAllChilds(final DefaultMutableTreeNode rootDestination, final DefaultMutableTreeNode rootSource) {

        /* Iterating through all child nodes of the rootSource node */
        for (int i = 0; i < rootSource.getChildCount(); i++) {

            /* Getting child node */
            DefaultMutableTreeNode childOfSource = (DefaultMutableTreeNode) rootSource.getChildAt(i);

            /* Creating copy of the child node */
            DefaultMutableTreeNode tempOfChild = new DefaultMutableTreeNode();
            tempOfChild.setUserObject(childOfSource.getUserObject());
            
            /* Adding tempOfChild node as a child of rootDestination node */
            rootDestination.add(tempOfChild);
            addAllChilds(tempOfChild, childOfSource);
        }
    }


    /**
     * Gets a sequence of strings from user and returns them as an array.
     * @return An array of strings that is get from user.
     */
    public String[] getPathInput() {

        String[] parts = new String[0];
        Scanner scanner = new Scanner(System.in);
        String input = "x";
        
        System.out.print("\nEnter source node path in order, enter ':q' to finish giving input");
        System.out.print(" (Make sure you enter the name of only one node at once.):");
        
        /* Keep getting input from the user until ':q' is entered. */
        while (input != ":q") {

            input = scanner.nextLine();  /* Reading input from the user */
            if (input.equals(":q")) break;

            /* Creating new array */
            String[] newArray = new String[parts.length + 1];

            /* Copying elements of parts array to newArray array */
            for (int i = 0; i < parts.length; i++) newArray[i] = parts[i];
            
            newArray[parts.length] = input;
            parts = newArray;
        }

        return parts;
    } 

    /**
     * Sets the visibility of the JFrame window.
     * @param value A boolean indicating if the JFrame window will be visible or hidden.
     */
    public void setFrameVisibility(final boolean value) { frame.setVisible(value); }
    
   
}  

