
import java.util.Scanner;  

/**
 * The Test class is used to test the methods of the Tree class.
 * 
 * @file    Test.java
 * @author  Çağla Nur Yuva
 * @brief   Tests Tree class' methods.
 * @version 1.0
 * @date    2023-05-04
 */
public class Test {  

    /**
     * It tests methods of Tree class and prints/shows results.
     * @param args An array of strings for command-line arguments.
     */
    public static void main(String[] args) {  

        /* Creating Tree class object */
        Tree treeTest = new Tree();  
        
        /* Testing Part A */
        System.out.println("Part A: Creating a JTree by using input in the text file...");
        treeTest.createTree();
        treeTest.setFrameVisibility(true);

        /* Getting input from user to test search algoritms */
        System.out.print("\nEnter input for three search algorithms: ");
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();
        treeTest.setFrameVisibility(false);

        /* Testing Part B */
        System.out.println("----------------------------------");
        System.out.println("Part B: Testing BFS algorithm...");
        treeTest.searchWithBFS(input);
        System.out.println("----------------------------------");

        /* Testing Part C */
        System.out.println("Part C: Testing DFS algorithm...");
        treeTest.searchWithDFS(input);
        System.out.println("----------------------------------");

        /* Testing Part D */
        System.out.println("Part D: Testing Post-Order Traversal algorithm...");
        treeTest.searchWithPostOrder(input);
        System.out.println("----------------------------------");

        /* Testing Part E */
        System.out.println("Part E: Testing moveNode() function...");

        /* Getting input from user to test moving node */
        String[] inputNodePath = treeTest.getPathInput();

        System.out.print("Enter destination node: ");
        input = scanner.nextLine();
    
        treeTest.moveNode(inputNodePath, input);
        treeTest.setFrameVisibility(true);

        System.out.println("Click cross (X) symbol on the top of JFrame to end the program...");
        scanner.close();
        System.out.println("----------------------------------");
        
    }
}  

