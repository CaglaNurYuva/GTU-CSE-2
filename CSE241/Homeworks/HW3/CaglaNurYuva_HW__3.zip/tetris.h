#ifndef TETRIS_H
#define TETRIS_H

#include <iostream>

#include <chrono>

#include <thread>

#include <stdlib.h>

#include <ctime>

#include "tetromino.h"

using std::cout;
using std::cin;
using std::endl;

class game_ns::Tetris {
    public:
        ~Tetris(); /* Tetris class destructor */
        Tetris(const int board_row_x, const int board_col_y); /* Tetris class constructor */
        Tetris(); /* Tetris class constructor */
        Tetris& operator+=(const Tetromino &obj); /* Adding a new tetromino to the tetris board */
        void Draw_Tetris_Board() const; /* Drawing tetris board */
        bool Animate(Tetromino &tetromino_obj, int rotating_times, int** temp1,const char c); /* Animating a dropping tetromino */
        bool Move_Tetromino(char c, int** temp1, int rotating_times, Tetromino &obj); /* Rotating tetromino as desired and moving it to the desired location */
        int Animation_row_limit(int** temp1) const; /* Returning the index of last row on which animation will be seen */
        bool Validate_input(int &input) const ; /* Getting and validating user integer input */
        void Tetris_Game(); /* Starting the game */
        inline int** getter_current_ind() const{return current_indexes_of_blocks;} /* Returning current_indexes_of_blocks array */
      

    private:
        int board_row; /* Keeping board row */
        int board_col; /* Keeping board col */
        char** tetris_board;  /* Keeping tetris board */
        bool adding_success = true; /* Indicating whether adding is successful or not */
        int** current_indexes_of_blocks; /* Keeping the current indexes of tetromino blocks */
        

};

#endif
