#ifndef TETROMINO_H
#define TETROMINO_H


#include <iostream>

using std::cout;
using std::cin;
using std::endl;


enum Directions {LEFT, RIGHT}; /* It represents to which direction the tetromino is rotated */
enum Positions{BOTTOM_POS,LEFT_POS,UP_POS,RIGHT_POS}; /* It represents current position of a tetromino */
enum class Tetrominos {I,O,T,J,L,S,Z}; /* It represents the types of tetrominos */


/* Namespace definition for two classes */
namespace game_ns {
    class Tetromino;
    class Tetris;
}


class game_ns::Tetromino { 
    public:
        Tetromino();  /* Tetromino class constructor */
        ~Tetromino(); /* Tetromino class destructor */
        Tetromino(const Tetrominos current_tetro, const Positions current_pos);  /* Tetromino class constructor */
        void rotate(Directions const rotation_direction, const int rotation_count); /* Rotating a tetromino */
        void initially_construct_tetromino(); /* Constructing a tetromino initially which is in bottom position */
        
        Tetrominos current_tetromino; /* Keeping the type of a tetromino */
        char change; /* Indicating whether operator+= function will cause change on tetris board or not */
        char** my_tetromino; /* Keeping tetromino as a 2D array*/
        Positions current_position; /* Keeping the current position of a tetromino */
    
};



#endif
