#include "tetromino.h"



/* Constructing a tetromino initially which is in bottom position */
void game_ns::Tetromino:: initially_construct_tetromino() {
    int row,col;

    /* Cleaning old values kept in my_tetromino array */    
    for(row=0; row<4; row++) {
        for(col=0; col<4; col++) {
            my_tetromino[row][col] = ' ';
        }
        my_tetromino[row][col] = '\0';      
    }
        
    /* Initializing my_tetromino array by checking its type */
    if(current_tetromino == Tetrominos::I){ 
        my_tetromino[3][0] = 'I';
        my_tetromino[3][1] = 'I';
        my_tetromino[3][2] = 'I';
        my_tetromino[3][3] = 'I';
    } 


    else if(current_tetromino  == Tetrominos::O){ 
        my_tetromino[2][0] = 'O';
        my_tetromino[2][1] = 'O';
        my_tetromino[3][0] = 'O';
        my_tetromino[3][1] = 'O';
        
    } 

 
    else if(current_tetromino  == Tetrominos::T){ 
        my_tetromino[2][0] = 'T';
        my_tetromino[2][1] = 'T';
        my_tetromino[2][2] = 'T';
        my_tetromino[3][1] = 'T';

    } 


    else if(current_tetromino == Tetrominos::J){ 
        my_tetromino[1][1] = 'J';
        my_tetromino[2][1] = 'J';
        my_tetromino[3][0] = 'J';
        my_tetromino[3][1] = 'J';

    } 


    else if(current_tetromino  == Tetrominos::L){ 
        my_tetromino[1][0] = 'L';
        my_tetromino[2][0] = 'L';
        my_tetromino[3][0] = 'L';
        my_tetromino[3][1] = 'L';

    } 


    else if(current_tetromino  == Tetrominos::S){ 
        my_tetromino[2][1] = 'S';
        my_tetromino[2][2] = 'S';
        my_tetromino[3][0] = 'S';
        my_tetromino[3][1] = 'S';

    } 

 
    else if(current_tetromino  == Tetrominos::Z){ 
        my_tetromino[2][0] = 'Z';
        my_tetromino[2][1] = 'Z';
        my_tetromino[3][1] = 'Z';
        my_tetromino[3][2] = 'Z';
        
    } 

}


/* Tetromino class constructor */
game_ns::Tetromino:: Tetromino() {
    int j;
    my_tetromino = new char*[4]; /* Allocating memory for my_tetromino array */

    for(auto i=0; i<4; i++){
        my_tetromino[i] = new char[5];
        for(j=0; j<4; j++) {
            my_tetromino[i][j] = ' '; /* Initializing my_tetromino array */
        }
      
        my_tetromino[i][j] = '\0';
    }

    current_tetromino = Tetrominos::I; /* Initializing current_tetromino variable */
    current_position = Positions:: BOTTOM_POS; /* Initializing current_position variable */
    change = 'Y';  /* Indicating whether operator+= function will cause change on tetris board or not */

}


/* Tetromino class constructor */
game_ns::Tetromino:: Tetromino(const Tetrominos current_tetro, const Positions current_pos) {
    my_tetromino = new char*[4]; /* Allocating memory for my_tetromino array */
    int j;

    for(auto i=0; i<4; i++){
        my_tetromino[i] = new char[5];
        for(j=0; j<4; j++) {
            my_tetromino[i][j] = ' '; /* Initializing my_tetromino array */
        }
      
        my_tetromino[i][j] = '\0';
    }

  
    current_tetromino = current_tetro; /* Initializing current_tetromino variable */
    current_position = current_pos; /* Initializing current_position variable */
    change = 'Y';  /* Indicating whether operator+= function will cause change on tetris board or not */

    cout << "The array that keeps tetromino array has been allocated" << endl;
    cout << "Current tetromino type and current position of it have been initialized" << endl;
    
}


/* Rotating a tetromino */
void game_ns::Tetromino:: rotate(Directions const rotation_direction, const int rotation_count) { 
    int precise_rotate_count = rotation_count % 4;
    int row,col;

    /* Cleaning old values kept in my_tetromino array */
    for(row=0; row<4; row++) {
        for(col=0; col<4; col++) {
            my_tetromino[row][col] = ' ';
        }
        my_tetromino[row][col] = '\0';
       
    }
    
    

    /* Handling the case there is no rotating happening */
    if(precise_rotate_count == 0) {
        initially_construct_tetromino();
        return;
    }

    
    /* Rotating the tetromino by checking its type, how many times it will be rotated and to which direction it will be rotated */
    if(current_tetromino == Tetrominos::I){ 
        
        if(precise_rotate_count == 1 ||  precise_rotate_count == 3) { 
            my_tetromino[0][0] = 'I';
            my_tetromino[1][0] = 'I';
            my_tetromino[2][0] = 'I';
            my_tetromino[3][0] = 'I';
            current_position = RIGHT_POS;
        }      

        else if(precise_rotate_count == 2) { 
            my_tetromino[3][0] = 'I';
            my_tetromino[3][1] = 'I';
            my_tetromino[3][2] = 'I';
            my_tetromino[3][3] = 'I';
            current_position = BOTTOM_POS;
        } 
    
    } 

 
    else if(current_tetromino == Tetrominos::O){ 
        my_tetromino[2][0] = 'O';
        my_tetromino[2][1] = 'O';
        my_tetromino[3][0] = 'O';
        my_tetromino[3][1] = 'O'; 
        current_position = BOTTOM_POS;
    } 

 
    else if(current_tetromino == Tetrominos::T){ 

        if(precise_rotate_count == 2) {
            my_tetromino[2][1] = 'T';
            my_tetromino[3][0] = 'T';
            my_tetromino[3][1] = 'T';
            my_tetromino[3][2] = 'T';
            current_position = UP_POS; 
        }

        else {
            if(precise_rotate_count == 1) {
                if(rotation_direction == RIGHT) {
                    my_tetromino[1][1] = 'T';
                    my_tetromino[2][0] = 'T';
                    my_tetromino[2][1] = 'T';
                    my_tetromino[3][1] = 'T';
                    current_position = RIGHT_POS; 
                }

                else if(rotation_direction == LEFT) {
                    my_tetromino[1][0] = 'T';
                    my_tetromino[2][0] = 'T';
                    my_tetromino[2][1] = 'T';
                    my_tetromino[3][0] = 'T';
                    current_position = LEFT_POS; 
                }
            }

            else if(precise_rotate_count == 3) {
                if(rotation_direction == RIGHT) {
                    my_tetromino[1][0] = 'T';
                    my_tetromino[2][0] = 'T';
                    my_tetromino[2][1] = 'T';
                    my_tetromino[3][0] = 'T';
                    current_position = LEFT_POS;
                }

                else if(rotation_direction == LEFT) {
                    my_tetromino[1][1] = 'T';
                    my_tetromino[2][0] = 'T';
                    my_tetromino[2][1] = 'T';
                    my_tetromino[3][1] = 'T';
                    current_position = RIGHT_POS;  
                }
            }
        }   
    } 


    else if(current_tetromino == Tetrominos::J){ 

        if(precise_rotate_count == 2) {
            my_tetromino[1][0] = 'J';
            my_tetromino[1][1] = 'J';
            my_tetromino[2][0] = 'J';
            my_tetromino[3][0] = 'J';
            current_position = UP_POS;
        }

        else {
            if(precise_rotate_count == 1) {
                if(rotation_direction == RIGHT) {
                    my_tetromino[2][0] = 'J';
                    my_tetromino[3][0] = 'J';
                    my_tetromino[3][1] = 'J';
                    my_tetromino[3][2] = 'J';
                    current_position = RIGHT_POS;
                }

                else if(rotation_direction == LEFT) {
                    my_tetromino[2][0] = 'J';
                    my_tetromino[2][1] = 'J';
                    my_tetromino[2][2] = 'J';
                    my_tetromino[3][2] = 'J';
                    current_position = LEFT_POS;  
                }
            }

            else if(precise_rotate_count == 3) {
                if(rotation_direction == RIGHT) {
                    my_tetromino[2][0] = 'J';
                    my_tetromino[2][1] = 'J';
                    my_tetromino[2][2] = 'J';
                    my_tetromino[3][2] = 'J';
                    current_position = LEFT_POS;
                }

                else if(rotation_direction == LEFT) {
                    my_tetromino[2][0] = 'J';
                    my_tetromino[3][0] = 'J';
                    my_tetromino[3][1] = 'J';
                    my_tetromino[3][2] = 'J';
                    current_position = RIGHT_POS;
                }
            }
        } 
         
    } 

    else if(current_tetromino == Tetrominos::L){ 

        if(precise_rotate_count == 2) {
            my_tetromino[1][0] = 'L';
            my_tetromino[1][1] = 'L';
            my_tetromino[2][1] = 'L';
            my_tetromino[3][1] = 'L';
            current_position = UP_POS;
        }

        else {
            if(precise_rotate_count == 1) {
                if(rotation_direction == RIGHT) {
                    my_tetromino[2][0] = 'L';
                    my_tetromino[2][1] = 'L';
                    my_tetromino[2][2] = 'L';
                    my_tetromino[3][0] = 'L';
                    current_position = RIGHT_POS;
                }

                else if(rotation_direction == LEFT) {
                    my_tetromino[2][2] = 'L';
                    my_tetromino[3][0] = 'L';
                    my_tetromino[3][1] = 'L';
                    my_tetromino[3][2] = 'L';
                    current_position = LEFT_POS; 
                }
            }

            else if(precise_rotate_count == 3) {
                if(rotation_direction == RIGHT) {
                    my_tetromino[2][2] = 'L';
                    my_tetromino[3][0] = 'L';
                    my_tetromino[3][1] = 'L';
                    my_tetromino[3][2] = 'L'; 
                    current_position = LEFT_POS;
                }

                else if(rotation_direction == LEFT) {
                    my_tetromino[2][0] = 'L';
                    my_tetromino[2][1] = 'L';
                    my_tetromino[2][2] = 'L';
                    my_tetromino[3][0] = 'L';   
                    current_position = RIGHT_POS;
                }
            }
        } 
         
    } 
     

    else if(current_tetromino == Tetrominos::S){ 

        if(precise_rotate_count == 2) {
            my_tetromino[2][1] = 'S';
            my_tetromino[2][2] = 'S';
            my_tetromino[3][0] = 'S';
            my_tetromino[3][1] = 'S';  
            current_position = BOTTOM_POS;
        }

        else {
            my_tetromino[1][0] = 'S';
            my_tetromino[2][0] = 'S';
            my_tetromino[2][1] = 'S';
            my_tetromino[3][1] = 'S';  
            current_position = RIGHT_POS;   
        } 
         
    } 

  

    else if(current_tetromino == Tetrominos::Z){ 

        if(precise_rotate_count == 2) {
            my_tetromino[2][0] = 'Z';
            my_tetromino[2][1] = 'Z';
            my_tetromino[3][1] = 'Z';
            my_tetromino[3][2] = 'Z';  
            current_position = BOTTOM_POS;
        }

        else {
            my_tetromino[1][1] = 'Z';
            my_tetromino[2][0] = 'Z';
            my_tetromino[2][1] = 'Z';
            my_tetromino[3][0] = 'Z';  
             
            current_position = RIGHT_POS;
        } 
         
    } 

} 


/* Tetromino class destructor */
game_ns::Tetromino:: ~Tetromino() {

    /* Deallocating memory belonging to my_tetromino array */
    for(auto i=0; i<4; i++) {  
        delete[] my_tetromino[i];
    }
    delete[] my_tetromino;
    cout << endl << "~Tetromino() destructor has been called." << endl;

}


