#include "tetromino.h"

#include "tetris.h"

#include <iostream>

using namespace game_ns;

using std::cout;
using std::cin;
using std::endl;

int main() {
   
    game_ns::Tetris obj;
    srand(time(NULL));
    obj.Tetris_Game();  /* Starting tetris game */
    return (0);
}
    

