#include "tetromino.h"

#include "tetris.h"

#include <iostream>


using std::cout;
using std::cin;
using std::endl;
using namespace game_ns;


int main(){
    int i,j;
    char c;
    int** temp1 = new int*[4];
    for(i=0; i<4; i++) temp1[i] = new int[2];
    srand(time(NULL));

    /* Testing Tetromino(const Tetrominos current_tetro, const Positions current_pos) constructor */
    cout << "---------------------------------------------------" << endl;
    cout << "Testing Tetromino(const Tetrominos current_tetro, const Positions current_pos) constructor..." << endl;
    game_ns::Tetromino tetro_obj(Tetrominos::T,Positions::BOTTOM_POS);  /* Creating a tetromino object */
    cout << endl << "---------------------------------------------------" << endl;

    /* Assigning value to c variable by checking current_tetromino variable */
    if(tetro_obj.current_tetromino == Tetrominos::I) c = 'I';
    else if(tetro_obj.current_tetromino == Tetrominos::O) c = 'O';
    else if(tetro_obj.current_tetromino == Tetrominos::T) c = 'T';
    else if(tetro_obj.current_tetromino == Tetrominos::J) c = 'J';
    else if(tetro_obj.current_tetromino == Tetrominos::L) c = 'L';
    else if(tetro_obj.current_tetromino == Tetrominos::S) c = 'S';
    else if(tetro_obj.current_tetromino == Tetrominos::Z) c = 'Z';


    /* Testing Tetris(const int board_row_x, const int board_col_y) constructor */
    cout << "Testing Tetris(const int board_row_x, const int board_col_y) constructor..." << endl;
    game_ns::Tetris tet_obj(10,10); /* Creating a tetris object */
    cout << endl << "---------------------------------------------------" << endl;

    /* Testing initially_construct_tetromino() function */
    cout << "Testing initially_construct_tetromino() function..." << endl;
    tetro_obj.initially_construct_tetromino(); 
    cout << "Printing having constructed tetromino:" << endl;
    for(i=0; i<4; i++) {
        for(j=0; j<4; j++) {
            cout << tetro_obj.my_tetromino[i][j];
        }
        cout << endl;
    }
    cout << endl << "---------------------------------------------------" << endl;


    /* Testing operator+=() function */
    cout << "Testing operator+=() function..." << endl;
    tet_obj += tetro_obj; 
    cout << "Printing tetris board to show having added tetromino: " << endl;
    tet_obj.Draw_Tetris_Board();
    cout << endl << "---------------------------------------------------" << endl;


    /* Testing Move_Tetromino() function */
    cout << "Testing Move_Tetromino() function..." << endl;
    cout << "Printing tetris board before moving tetromino: " << endl;
    tet_obj.Draw_Tetris_Board();
    tet_obj.Move_Tetromino(c,temp1,0,tetro_obj);
    cout << endl << "---------------------------------------------------" << endl; 


    /* Testing Animate() function */
    cout << "Testing Animate() function... " << endl;
    tet_obj.Animate(tetro_obj,0,temp1,c);
    cout << endl << "---------------------------------------------------" << endl; 
    tetro_obj.initially_construct_tetromino(); 
   

    /* Testing rotate() function */
    cout << "Testing rotate() function..." << endl;
    cout << "Tetromino before rotating: " << endl;
    for(i=0; i<4; i++) {
        for(j=0; j<4; j++) {
            cout << tetro_obj.my_tetromino[i][j];
        }
        cout << endl;
    } 
    tetro_obj.rotate(Directions::RIGHT,2);
    cout << "Tetromino after rotating to the right 2 times: " << endl;
    for(i=0; i<4; i++) {
        for(j=0; j<4; j++) {
            cout << tetro_obj.my_tetromino[i][j];
        }
        cout << endl;
    } 
    cout << endl << "---------------------------------------------------" << endl; 


    /* Testing Draw_Tetris_Board() function */
    cout << "Testing Draw_Tetris_Board() function..." << endl;
    tet_obj.Draw_Tetris_Board();
    cout << endl << "---------------------------------------------------" << endl; 
    temp1 = tet_obj.getter_current_ind();


    /* Testing Animation_row_limit() function */
    cout << "Testing Animation_row_limit() function..." << endl;
    cout << "Limit = " << tet_obj.Animation_row_limit(temp1) << endl;
    cout << endl << "---------------------------------------------------" << endl; 
    int input;


    /* Testing Validate_input() function */
    cout << "Testing Validate_input() function..." << endl;
    cout << "Enter integer input: " ;
    if((tet_obj.Validate_input(input)) == true) cout << "Input is valid" << endl;
    cout << endl << "---------------------------------------------------" << endl; 


    /* Testing getter_current_ind() function */
    cout << "Testing getter_current_ind() function..." << endl;
    temp1 = tet_obj.getter_current_ind();
    cout << "current_indexes_of_blocks array elements = " ;
    for(i=0; i<4; i++){
        cout << temp1[i][0] << "," << temp1[i][1] << endl;
    }
    cout << endl << "---------------------------------------------------" << endl; 
    
    /* Testing Tetromino() constructor */
    cout << "Testing Tetromino() constructor..." << endl;
    game_ns::Tetromino tetro_obj2; /* Creating a tetromino object */
    cout << "Printing newly constructed empty tetromino array: " << endl;
    for(i=0; i<4; i++) {
        for(j=0; j<4; j++) {
            cout << tetro_obj2.my_tetromino[i][j];
        }
        cout << endl;
    } 

    if(tetro_obj2.current_position == Positions::BOTTOM_POS) cout << "current_position = BOTTOM_POS" << endl;
    if(tetro_obj2.current_tetromino == Tetrominos::I) cout << "current_tetromino = I" << endl;

    cout << endl << "---------------------------------------------------" << endl; 
    
    /* Testing Tetris() constructor */
    cout << "Testing Tetris() constructor..." << endl;
    game_ns::Tetris tet_obj2; /* Creating a tetris object */

    cout << endl << "---------------------------------------------------" << endl; 
    
    /* Testing Tetris_Game() function */
    cout << "Testing Tetris_Game() function..." << endl;
    tet_obj2.Tetris_Game();
    

    return (0);

}
