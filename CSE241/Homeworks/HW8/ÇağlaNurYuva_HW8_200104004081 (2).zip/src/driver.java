/**
 * This class is the starting point of the Tetris game, 
 * it contains main method to test methods of Tetris
 * and Tetromino classes.
 * 
 * @file    driver.java
 * @author  Çağla Nur Yuva
 * @brief   Tetris Game Driver/Test
 * @version 1.0
 * @date    2022-01-24
 */
public class driver {
    
    public static void main(String args[]) {

        Tetris game = new Tetris();
        game.Tetris_Game();  /* Starting Tetris game loop */
    }
}