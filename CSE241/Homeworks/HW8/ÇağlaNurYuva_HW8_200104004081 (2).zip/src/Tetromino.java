import java.awt.Color;
import java.util.Arrays;
import java.util.Random;

/**
 * Tetromino class for the Tetris game.
 * Implements functions needed for tetrominos of Tetris Game.
 *
 * @file     Tetromino.java
 * @author   Çağla Nur Yuva
 * @brief    Function implementations related to tetrominos 
 * @version  1.0
 * @date     2022-01-24
 */
public class Tetromino {

    /** It represents the types of tetrominos */
    public enum TetrominoType {
        /** Tetromino I */
        I,
        /** Tetromino O */
        O, 
        /** Tetromino T */
        T,
        /** Tetromino J */
        J, 
        /** Tetromino L */
        L,
        /** Tetromino S */
        S,
        /** Tetromino Z */
        Z
    };

    /** It represents current position of a tetromino */
    public enum Positions{
        /** Bottom position */
        BOTTOM_POS,
        /** Right position */
        RIGHT_POS,
        /** Up position */
        UP_POS,
        /** Left position */
        LEFT_POS
    };
  
    /** Keeps blocks of a tetromino's indexes relative to each other on Tetris board */
    private int[][] current_indexes_of_blocks = new int[4][2];

    /** Keeps how many times a tetromino moved to the right on tetris board */
    private int right = 5;

    /** Keeps how many times a tetromino moved to the down on tetris board */
    private int down = 0;

    /** Keeps how many times a tetromino rotated to the right */
    private int total_rotation = 0;

    /** Keeps tetromino type */
    private TetrominoType type = TetrominoType.values()[0];

    /** Keeps tetromino position */
    private Positions pos = Positions.BOTTOM_POS;

    /** Keeps tetromino color */
    private Color color = Color.CYAN;

  

    /**
     * Constructor of Tetromino class. Initializes the following properties:
     * The x-coordinate of the Tetromino's position on tetris board 
     * The y-coordinate of the Tetromino's position on tetris board 
     * The current rotation of the Tetromino 
     * 2D array representing the current indexes of the blocks in the Tetromino 
     * The type of Tetromino 
     * The position of the Tetromino on tetris board 
     * The color of the Tetromino 
     */
    public Tetromino() {
        
        right = 5;
        down = 0;
        total_rotation = 0;
        current_indexes_of_blocks = new int[][]{{0, 0}, {0, 0}, {0, 0}, {0, 0}};
        type = TetrominoType.values()[0];
        pos = Positions.BOTTOM_POS;
        color = Color.CYAN;
    }


    /** Creates a new tetromino randomly, initializes necessary properties of a tetromino. */
    public void createTetromino() {

        /* Initializing necessary properties of a tetromino */
        type = TetrominoType.values()[(int)(Math.random()*(TetrominoType.values().length))];
        right = 5;  
        down = 0;
        total_rotation = 0;
        pos = Positions.BOTTOM_POS;
        color = Color.CYAN;
        int[][] temp100 = new int[][]{{0, 0}, {0, 0}, {0, 0}, {0, 0}};
        copyArray(temp100,current_indexes_of_blocks);
        
        /* Creating tetromino according to its type by initializing its properties */
        switch (type) {

            /* Creating tetromino I */    
            case I:
                int[][] temp1 = new int[][]{{0, -2}, {0, -1}, {0, 0}, {0, 1}};
                copyArray(temp1,current_indexes_of_blocks);
                color = Color.CYAN;
                break;

            /* Creating tetromino O */    
            case O:
                int[][] temp2 = new int[][]{{0,-1},{0,0},{1,-1},{1,0}};
                copyArray(temp2,current_indexes_of_blocks);
                color = Color.YELLOW;
                break;

            /* Creating tetromino T */    
            case T:
                int[][] temp3 = new int[][]{{0, -2}, {0, -1}, {0, 0}, {1, -1}};
                copyArray(temp3,current_indexes_of_blocks);
                color = Color.MAGENTA;
                break;

            /* Creating tetromino J */    
            case J:
                int[][] temp4 = new int[][]{{0, 0}, {1, 0}, {2, -1}, {2, 0}};
                copyArray(temp4,current_indexes_of_blocks);
                color = Color.BLUE;
                break;

            /* Creating tetromino L */    
            case L:
                int[][] temp5 = new int[][]{{0, -1}, {1, -1}, {2, -1}, {2, 0}};
                copyArray(temp5,current_indexes_of_blocks);
                color = Color.ORANGE;
                break;

            /* Creating tetromino S */    
            case S:
                int[][] temp6 = new int[][]{{0, -1}, {0, 0}, {1, -2}, {1, -1}};
                copyArray(temp6,current_indexes_of_blocks);
                color = Color.GREEN;
                break;

            /* Creating tetromino Z */    
            case Z:
                int[][] temp7 = new int[][]{{0, -2}, {0, -1}, {1, -1}, {1, 0}};
                copyArray(temp7,current_indexes_of_blocks);
                color = Color.RED;
                break;
        }
    }

  
    /**
     * Returns the current index of the block at the specified position in the current_indexes_of_blocks 2D array.
     * @param i The row index of the block
     * @param j The column index of the block
     * @return int The current index of the block at position (i, j) in the current_indexes_of_blocks array
     */
    public int getCurrIndex(final int i, final int j) {return current_indexes_of_blocks[i][j];}

    /**
     * Sets the current index of a block at the specified position in the current_indexes_of_blocks 2D array.
     * @param num The new index to set for the block
     * @param i The row index of the block
     * @param j The column index of the block
     */
    public void setCurrIndex(final int num, final int i, final int j) {current_indexes_of_blocks[i][j] = num;}

    /**
     * Returns the value of the right property Tetromino object.
     * @return int the value of the right property Tetromino object.
     */
    public int getRight() {return right;}

    /**
     * Returns the value of the down property of Tetromino object.
     * @return int the value of the down property of Tetromino object.
     */
    public int getDown() {return down;}

    /**
     * Sets the value of the right property of Tetromino object.
     * @param other the value to set the right property to.
     */
    public void setRight(final int other) {right = other;}

     /**
     * Sets the value of the down property of Tetromino object.
     * @param other the value to set the down property to.
     */
    public void setDown(final int other) {down = other;}

    /** Increment the value of the right property of the Tetromino object by 1. */
    public void IncrementRight() {right++;}

    /** Decrement the value of the right property of the Tetromino object by 1. */
    public void IncrementLeft() {right--;}

    /** Increment the value of the down property of the Tetromino object by 1. */
    public void IncrementDown() {down++;}

    /** Decrement the value of the down property of the Tetromino object by 1. */
    public void DecrementDown() {down--;}

    /**
     * Returns the value of tetromino color.
     * @return Color the value of tetromino color.
     */
    public Color getColor() {return color;}

    /**
     * Sets the value of tetromino color.
     * @param other the value to set the tetromino color to.
     */
    public void setColor(Color other) {color = other;}

    /**
     * Returns tetromino type.
     * @return TetrominoType tetromino type.
     */
    public TetrominoType getType() {return type;}

    /**
     * Sets the value of tetromino type.
     * @param other the value to set tetromino type to.
     */
    public void setType(TetrominoType other) {type = other;}

    /**
     * Returns the value of current position of tetromino.
     * @return Positions the value of current position of tetromino.
     */
    public Positions getPosition() {return pos;}

    /**
     * Sets the value of current position of tetromino.
     * @param other_pos the value to set current position of tetromino to.
     */
    public void setPosition(final Positions other_pos) {pos = other_pos;}

    /**
     * Returns the value of the total rotation of tetromino.
     * @return int the value of the total rotation of tetromino.
     */
    public int getRotation() {return total_rotation;}

  
    /**
     * Sets the value of the total rotation of tetromino.
     * @param size the value to set the total rotation of tetromino to.
     */
    public void setRotation(final int size) {total_rotation = size;}
  


    /**
     * Copies the values of one 2D int array to another.
     * @param source the source array to copy from
     * @param destination the destination array to copy to
     */
    private void copyArray(final int[][] source,int[][] destination) {
        for(int i = 0; i < 4; ++i) {
            for(int j = 0; j < 2; j++) {
                destination[i][j] = source[i][j];
            }
        }
    }
    
  

    /**
     * A method that rotates the arrangement of blocks of tetromino relative to each other in a given direction.
     * @param direction the direction of rotation, either "RIGHT" or "LEFT"
     */
    public void rotate_Arrangement(String direction) {
        int i = 0 ;  

        /* Calculating total rotation */
        if(pos == Positions.RIGHT_POS) i++;  
        else if(pos == Positions.UP_POS) i += 2;
        else if(pos == Positions.LEFT_POS) i += 3;
        
        if(direction == "RIGHT"){total_rotation = 1 ;}
        else if(direction == "LEFT"){total_rotation = 3;}
        
        
        total_rotation = (total_rotation + i)%4;
        pos = Positions.values()[total_rotation];  /* Finding current position using total rotation */

        /* Rotating blocks of tetromino relative to each other */
        switch (type) {

            /* Rotating tetromino I */  
            case I:
                if(total_rotation == 0 || total_rotation == 2) {
                    int[][] temp8 = new int[][]{{0,-2},{0,-1},{0,0},{0,1}};
                    copyArray(temp8,current_indexes_of_blocks);
                }

                else if(total_rotation == 1 || total_rotation == 3) {
                    int[][] temp9 = new int[][]{{0,-1},{1,-1},{2,-1},{3,-1}};
                    copyArray(temp9,current_indexes_of_blocks);
                }
                break;

            /* Rotating tetromino O */    
            case O:
                int[][] temp10 = new int[][]{{0,-1},{0,0},{1,-1},{1,0}};
                copyArray(temp10,current_indexes_of_blocks);
                break;

            /* Rotating tetromino T */  
            case T:
                if(total_rotation == 0) {
                    int[][] temp11 = new int[][]{{0,-2},{0,-1},{0,0},{1,-1}};
                    copyArray(temp11,current_indexes_of_blocks);
                }

                else if(total_rotation == 1) {
                    int[][] temp12 = new int[][]{{0,0},{1,-1},{1,0},{2,0}};
                    copyArray(temp12,current_indexes_of_blocks);
                }

                else if(total_rotation == 2) {
                    int[][] temp13 = new int[][]{{0,-1},{1,-2},{1,-1},{1,0}};
                    copyArray(temp13,current_indexes_of_blocks);
                }

                else if(total_rotation == 3) {
                    int[][] temp14 = new int[][]{{0,-1},{1,-1},{1,0},{2,-1}};
                    copyArray(temp14,current_indexes_of_blocks);
                }
                break;

            /* Rotating tetromino J */   
            case J:
                if(total_rotation == 0) {
                    int[][] temp15 = new int[][]{{0,0},{1,0},{2,-1},{2,0}};
                    copyArray(temp15,current_indexes_of_blocks);
                }

                else if(total_rotation == 1) {
                    int[][] temp16 = new int[][]{{0,-2},{1,-2},{1,-1},{1,0}};
                    copyArray(temp16,current_indexes_of_blocks);
                }

                else if(total_rotation == 2) {
                    int[][] temp17 = new int[][]{{0,-1},{0,0},{1,-1},{2,-1}};
                    copyArray(temp17,current_indexes_of_blocks);
                }

                else if(total_rotation == 3) {
                    int[][] temp18 = new int[][]{{0,-2},{0,-1},{0,0},{1,0}};
                    copyArray(temp18,current_indexes_of_blocks);
                }
                break;

            /* Rotating tetromino L */  
            case L: 
                if(total_rotation == 0) {
                    int[][] temp19 = new int[][]{{0,-1},{1,-1},{2,-1},{2,0}};
                    copyArray(temp19,current_indexes_of_blocks);
                }

                else if(total_rotation == 1) {
                    int[][] temp20 = new int[][]{{0,-2},{0,-1},{0,0},{1,-2}};
                    copyArray(temp20,current_indexes_of_blocks);
                }

                else if(total_rotation == 2) {
                    int[][] temp21 = new int[][]{{0,-1},{0,0},{1,0},{2,0}};
                    copyArray(temp21,current_indexes_of_blocks);
                }

                else if(total_rotation == 3) {
                    int[][] temp22 = new int[][]{{0,0},{1,-2},{1,-1},{1,0}};
                    copyArray(temp22,current_indexes_of_blocks);
                }
                break;

            /* Rotating tetromino S */
            case S: 
                if(total_rotation == 0 || total_rotation == 2) {
                    int[][] temp23 = new int[][]{{0,-1},{0,0},{1,-2},{1,-1}};
                    copyArray(temp23,current_indexes_of_blocks);
                }

                else if(total_rotation == 1 || total_rotation == 3) {
                    int[][] temp24 = new int[][]{{0,-1},{1,-1},{1,0},{2,0}};
                    copyArray(temp24,current_indexes_of_blocks);
                }
                break;

            /* Rotating tetromino Z */    
            case Z:
                if(total_rotation == 0 || total_rotation == 2){
                    int[][] temp25 = new int[][]{{0,-2},{0,-1},{1,-1},{1,0}};
                    copyArray(temp25,current_indexes_of_blocks);
                }

                else if(total_rotation == 1 || total_rotation == 3){
                    int[][] temp26 = new int[][]{{0,0},{1,-1},{1,0},{2,-1}};
                    copyArray(temp26,current_indexes_of_blocks);
                }
                break;
            

        }
      
    }

}