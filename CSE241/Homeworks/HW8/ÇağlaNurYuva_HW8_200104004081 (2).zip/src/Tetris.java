import java.awt.*;
import javax.swing.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Tetris class for the Tetris game.
 * Implements functions needed for Tetris Game.
 * Creates Java GUI components needed for Tetris Game.
 *
 * @file     Tetris.java
 * @author   Çağla Nur Yuva
 * @brief    Function implementations and GUI components related to Tetris Game.
 * @version  1.0
 * @date     2022-01-24
 */
public class Tetris extends JPanel {

    /** Keeps tetris board's row size */
    private static final int ROWS = 20;

    /** Keeps tetris board's column size */
    private static final int COLS = 10;

    /** Keeps current state of program */
    private  boolean running = true;

    /** Keeps whether adding a new tetromino is successful or not */
    private  boolean adding_success = true;

    /** Keeps whether moving a tetromino is successful or not */
    private  boolean moving_success = true;

    /** Keeps state of reset button */
    private boolean resetx = false;

    /** Keeps JButtons to create Tetris board */
    private JButton[][] buttons = new JButton[ROWS][COLS];

    /** Keeps background color */
    private static final Color BACKGROUND_COLOR = Color.WHITE;

    /** Keeps frame which containts tetris board and three buttons */
    private JFrame frame = new JFrame("Tetris");

    /** Keeps panel which contains tetris board */
    private JPanel tetris_board = new JPanel();

    /** Keeps panel which contains button panel */
    private JPanel buttonsPanel = new JPanel();

    /** Keeps reset button */
    private JButton resetButton = new JButton("Reset");

    /** Keeps start button */
    private JButton startButton= new JButton("Start");

    /** Keeps end button */
    private JButton endButton= new JButton("End");

    /** Keeps a tetromino */
    Tetromino tetro = new Tetromino();
    private boolean start_button_state = false;

    /**
     * ButtonListener class for the Tetris game.
     * Implements a function to handle three buttons'functionalities.
     *
     * @author   Çağla Nur Yuva
     * @brief    Handles three buttons' functionalities.
     * @version  1.0
     * @date     2022-01-24
     */
    public class ButtonListener implements ActionListener {
 
        /** 
         * Handles three buttons'functionalities 
         * @param e the ActionEvent object that contains information about the button event
         */
        public void actionPerformed(ActionEvent e) {
            String command = e.getActionCommand();
      
            if(command.equals("Reset")) {
                reset();
            }
          
            else if(command.equals("Start")) {
                start_button_state = true;
                startButton.setEnabled(false);
                resetButton.setEnabled(true);
                endButton.setEnabled(true);
              
            }
            else if(command.equals("End")) {
                end();
            }
        }
    }

    /** Keeps ButtonListener class object to handle three buttons' functionalities */
    ButtonListener listener = new ButtonListener();

    /**
     * KeyboardHandler class for the Tetris game.
     * Overrides functions to handle keyboard events.
     *
     * @author   Çağla Nur Yuva
     * @brief    Overrides functions to handle keyboard events.
     * @version  1.0
     * @date     2022-01-24
     */    
    public class KeyboardHandler implements KeyListener {
   
        /**
         * {@inheritDoc}
         * Handles the key press events.
         * @param e the KeyEvent object that contains information about the key press event
         */
        @Override
        public void keyPressed(KeyEvent e) {
            switch (e.getKeyCode()) {
                case KeyEvent.VK_LEFT:  /* Handling left arrow on keyboard */
                    if(start_button_state == true) MoveLeft();
                    break;
            
                case KeyEvent.VK_RIGHT: /* Handling right arrow on keyboard */
  
                    if(start_button_state == true)MoveRight();
                    break;
                case KeyEvent.VK_DOWN: /* Handling down arrow on keyboard */
         
                    if(start_button_state == true)MoveDown();
                    break;
                case KeyEvent.VK_UP:  /* Handling up arrow on keyboard */
                    if(start_button_state == true)Rotate("RIGHT");
                    break;
            }
        }

        /**
         * {@inheritDoc}
         * Handles the key release events.
         * @param e the KeyEvent object that contains information about the key release event.
         */
        @Override
        public void keyReleased(KeyEvent e) {
   
        }

    
        /**
         * {@inheritDoc}
         * Handles the key type events.
         * @param e the KeyEvent object that contains information about the key type event.
         */ 
        @Override
        public void keyTyped(KeyEvent e) {
        }
    }

    /** Keeps KeyboardHandler object to handle keyboard events */
    KeyboardHandler keyboardHandler = new KeyboardHandler();


  
    /**
     * Constructor of Tetris class.
     * Implements functions needed for Tetris Game.
     * Creates Java GUI components needed for Tetris Game.
     */
    public Tetris() {
      
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        tetris_board.addKeyListener(keyboardHandler);   /* Adding key listener to tetris board */
        tetris_board.setFocusable(true); /* Enables focus on tetris board allowing for user input and interaction */
        tetris_board.setLayout(new GridLayout(ROWS, COLS));  /* Setting layout as GridLayout for tetris board */

        /* Filling GridLayout with JButtons */
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS; col++) {
                buttons[row][col] = new JButton();
                buttons[row][col].setBackground(Color.WHITE);
                tetris_board.add(buttons[row][col]);
                buttons[row][col].setFocusable(false);
                buttons[row][col].setEnabled(false);
              
            }
        }
      
        /* Setting layout for the panel including start,end,reset buttons */
        buttonsPanel.setLayout(new BoxLayout(buttonsPanel, BoxLayout.Y_AXIS)); 

      
        /* The action command for each button is set to its corresponding label symbolizing its functionality */
        resetButton.setActionCommand("Reset");
        startButton.setActionCommand("Start");
        endButton.setActionCommand("End");

        /* Adding ActionListener to start, reset, end buttons */
        startButton.addActionListener(listener);
        resetButton.addActionListener(listener);
        endButton.addActionListener(listener);

        /* Adding start, reset, end buttons to panel */
        buttonsPanel.add(resetButton);
        buttonsPanel.add(startButton);
        buttonsPanel.add(endButton);
      
        resetButton.setEnabled(false);
        endButton.setEnabled(false);

      
        frame.add(tetris_board, BorderLayout.CENTER); /* Adding tetris board to frame */
        frame.add(buttonsPanel, BorderLayout.EAST);  /* Adding panel including start,end,reset buttons to frame */
        frame.setSize(500, 800);  /* Setting size of frame */
        frame.setResizable(false);  /* Disabling resizability of frame */
 
        frame.setVisible(true);  /* Displaying frame on screen */
    }

  
    /**
     * Handles the functionality of the reset button. 
     * It resets the state of Tetris Game.
     */
    public void reset() {

      /* Resetting tetris game loop */
      running = false;
      adding_success = false;
      moving_success = false;
      resetx = true;
      
    }

    /** Clears tetris board */
    public void ClearTetrisBoard() {

        /* Making JButtons white to clear tetris board */
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS; col++) {
                buttons[row][col].setBackground(Color.WHITE);
            }
        }

    }

    /** 
     * Manages game process 
     * @throws InterruptedException 
     */
    public void Tetris_Game() {
        boolean result = false;

        while(start_button_state == false) {
            try{
            Thread.sleep(500);
        
            }
            catch(InterruptedException e) {
              System.out.println("400 MILLISECOND HAS NOT ELAPSED YET...");
            }
        }
      
        frame.dispose();
        tetris_board.removeKeyListener(keyboardHandler);
        tetris_board.addKeyListener(keyboardHandler); 
        tetris_board.setFocusable(true);
        frame.setVisible(true);
        /* Tetris game loop */

        do{
        
            /* Starting tetris game */
            result = start(); 

            /* Resetting tetris game */
            if(result == false) {
                ClearTetrisBoard(); 
                frame.dispose();
                tetris_board.setFocusable(true); 
                frame.setVisible(true);
            }
     
         
        
        }while(result == false);
        end();
    }

    /**
     * Handles the functionality of the end button. 
     * Ends the game.
     * @throws InterruptedException 
     */
    public void end() { 

        /* Sleeping 400 milliseconds and throwing error in the case of error */
        try{
            Thread.sleep(400);
        
        }

        catch(InterruptedException e) {
            System.out.println("400 MILLISECOND HAS NOT ELAPSED YET...");
        }

        frame.dispose();  /* Disabling displaying of frame */
        System.exit(0);  /* Ending program */
    }

    /**
     * Handles the functionality of the start button. 
     * Starts the game.
     * @throws InterruptedException 
     */
    public boolean start() {
        resetx = false;
        running = true;
        adding_success = true;
        moving_success = true;

        /* Starting movement of a tetromino from top row to down row */
        while(running == true) {
        
            /* Creating a new tetromino */
            tetro.createTetromino();  
            /* Adding a new tetromino */
            adding_success = Add_Tetromino();

            /* Checking reset condition */
            if(resetx == true)  return false; 
         
            /* Handling the case in which adding a new tetromino is unsuccessful */
            if(adding_success == false) {
                running = false;
                break;
            }
        
            moving_success = true;

            /* Checking reset condition */
            if(resetx == true)  return false;

            while(moving_success == true) {

                /* Sleeping 1 second and throwing error in the case of error */
                try{
                    Thread.sleep(1000); 
                    moving_success = MoveDown();  /* Dropping tetromino by one row */

                    if(resetx == true)  return false; /* Checking reset condition */
             
                }
                catch(InterruptedException e) {
                    System.out.println("1 SECOND HAS NOT ELAPSED YET...");
                }
            
            } 

          
            clearCompletedRows(); /* Clearing completed rows */
            if(resetx == true)  return false; /* Checking reset condition */
    
        }

        /* Sleeping 2 second and throwing error in the case of error */
        try{

            Thread.sleep(2000);  
            if(resetx == true)  return false; /* Checking reset condition */
        }
          
        catch(InterruptedException e) {
            System.out.println("1 SECOND HAS NOT ELAPSED YET...");
        } 

        /* Handling the case reset button has not been pressed */
        if(resetx == false)  {
            frame.dispose(); 
            return true;
        }

        /* Handling the case reset button has been pressed */  
        else return false;
        
    }

    /** Places a tetromino to tetris board */
    public void placeTetromino() {
        for(int i=0; i<4; i++) {

            /* Changing color of one JButton to symbolize one block of a tetromino */
            buttons[tetro.getCurrIndex(i,0) + tetro.getDown()][tetro.getCurrIndex(i,1) + tetro.getRight()].setBackground(tetro.getColor());
        }
    }

    /** Adds a tetromino to tetris board */
    public boolean Add_Tetromino() {

        int[][] temp = new int[4][2];

        /* Storing current indexes */
        for(int i=0; i<4; i++){
          temp[i][0] = tetro.getCurrIndex(i,0) + tetro.getDown();
          temp[i][1] = tetro.getCurrIndex(i,1) + tetro.getRight();
        }
      
        boolean collision = checkCollision(temp,"Add");  /* Checking collision */
        if(collision == true) return false;
        else placeTetromino();  /* Placing tetromino */
        return true;
    }

    /** Moves a tetromino to the right */
    public void MoveRight() {

        int[][] temp = new int[4][2];

        /* Storing current indexes */
        for(int i=0; i<4; i++){
            temp[i][0] = tetro.getCurrIndex(i,0) + tetro.getDown();
            temp[i][1] = tetro.getCurrIndex(i,1) + tetro.getRight();
        }
      
        tetro.IncrementRight();  /* Moving to right by one */
        boolean check = checkCollision(temp,"moveRight");  /* Checking collision */
        if(check == false) {

            clearCurrPlace("MOVE RIGHT"); /* Clearing current place */
            placeTetromino(); /* Placing tetromino */
        }
          
        /* Restoring tetromino location */
        else {
          tetro.IncrementLeft(); 
        }
    }

    /** Moves a tetromino to the left */
    public void MoveLeft() {

        int[][] temp = new int[4][2];

        /* Storing current indexes */
        for(int i=0; i<4; i++){
            temp[i][0] = tetro.getCurrIndex(i,0) + tetro.getDown();
            temp[i][1] = tetro.getCurrIndex(i,1) + tetro.getRight();
        }
        
        tetro.IncrementLeft(); /* Moving to left by one */
        boolean check = checkCollision(temp,"moveLeft");  /* Checking collision */

        if(check == false) {

            clearCurrPlace("MOVE LEFT"); /* Clearing current place */
            placeTetromino(); /* Placing tetromino */
        }

        /* Restoring tetromino location */  
        else {
            tetro.IncrementRight();
        }
    }

    /** Moves a tetromino to the down */
    public boolean MoveDown() {

        int[][] temp = new int[4][2];

        /* Storing current indexes */
        for(int i=0; i<4; i++){
            temp[i][0] = tetro.getCurrIndex(i,0) + tetro.getDown();
            temp[i][1] = tetro.getCurrIndex(i,1) + tetro.getRight();
        }

        tetro.IncrementDown(); /* Moving to down by one */
        boolean check = checkCollision(temp,"moveDown"); /* Checking collision */

        if(check == false) {
  
            clearCurrPlace("MOVE DOWN"); /* Clearing current place */
            placeTetromino(); /* Placing tetromino */
            return true;
        }

        /* Restoring tetromino location */    
        else {
  
            tetro. DecrementDown();
            return false;
        }
  
    }

    /**
     * Rotates a tetromino 
     * @param direction direction of rotation 
     */
    public void Rotate(String direction) {
      
        int[][] temp = new int[4][2];
        Tetromino.Positions pos_temp = tetro.getPosition(); /* Storing current position */
        int rotation = tetro.getRotation();  /* Storing current total rotation */
     
        /* Storing current indexes */
        for(int i=0; i<4; i++){
            temp[i][0] = tetro.getCurrIndex(i,0) + tetro.getDown();
            temp[i][1] = tetro.getCurrIndex(i,1) + tetro.getRight();
        }

        tetro.rotate_Arrangement(direction);  /* Arranging rotate */
      
        boolean check = checkCollision(temp,"Rotate"); /* Checking collision */

        if(check == false) {
            for(int i=0; i<4; i++) {
                buttons[ temp[i][0] ][ temp[i][1] ].setBackground(BACKGROUND_COLOR);
            }
            placeTetromino();  /* Placing tetromino */
        }

        /* Restoring tetromino location */   
        else {
            for(int i=0; i<4; i++){
                tetro.setCurrIndex(temp[i][0] - tetro.getDown(),i,0);
                tetro.setCurrIndex(temp[i][1] - tetro.getRight(),i,1);
            }
            tetro.setPosition(pos_temp);
            tetro.setRotation(rotation);
        }
    
    }

    /**
     * Check for collision with other pieces on the board.
     * @param temp the temporary matrix representing the current location of tetromino
     * @param operation the current operation being performed 
     * @return true if there is a collision, false otherwise
     */
    public boolean checkCollision(final int[][] temp, String operation ) {
        int x = 0;
        int y = 0; 
        
        for(int i=0; i<4; i++) {
     
            x = tetro.getCurrIndex(i,0) + tetro.getDown();
            y = tetro.getCurrIndex(i,1) + tetro.getRight();

            /* Handling the case in which tetris board borders have been exceeded */
            if (x < 0 || x >= ROWS || y >= COLS || y < 0) {
                return true;
            }

            /* Handling the case in which a JButton that is not white has been spotted */
            if (buttons[x][y].getBackground() != Color.WHITE) {

                /* If operation is not Add, check for overlapping */
                if(operation != "Add") {
                    boolean overlapping = false;
                    for(int j=0; j<4; j++){
                        if(x == temp[j][0] && y == temp[j][1]) {
                            overlapping = true;
                            break;
                        }
                    }

                    if(overlapping == false) {
                        return true;
                    }
                }

                /* Collision spotted */    
                else {
                    return true;
                }
               
            }
        }

        /* Collision is not spotted */
        return false;
    }

  
    /** Clear any completed rows on the board. */
    public void clearCompletedRows() {
        boolean complete = true;

        /* Checking rows whether they are completed or not */
        for (int row = 0; row < ROWS; row++) {
           complete = true;
            for (int col = 0; col < COLS; col++) {
                if (buttons[row][col].getBackground() == Color.WHITE) {
                    complete = false;
                    break;
                }
            }
            if (complete == true) {
                clearRow(row);  /* Clearing certain row */
            }
        }
    }

  
    /**
     * Clear a specific row on the board.
     * @param row the row to be cleared
     */
    public void clearRow(int row) {

        /* Shifting rows */  
        for (int i = row; i > 0; i--) {
            for (int j = 0; j < COLS; j++) {
                buttons[i][j].setBackground(buttons[i - 1][j].getBackground());
            }
        }

        /* Clearing the top row */  
        for (int j = 0; j < COLS; j++) {
            buttons[0][j].setBackground(Color.WHITE);
        }
    }


    /**
     * Clear the current position of the piece on the board before moving or rotating.
     * @param operation the current operation being performed 
     */
    public void clearCurrPlace(String operation) {

        /* Clearing current place */ 
        for(int i=0; i<4; i++) {
          
            if(operation == "MOVE RIGHT") {
                buttons[tetro.getCurrIndex(i,0) + tetro.getDown()][tetro.getCurrIndex(i,1) + tetro.getRight() - 1].setBackground(BACKGROUND_COLOR);
            }

            else if(operation == "MOVE LEFT") {
                buttons[tetro.getCurrIndex(i,0) + tetro.getDown()][tetro.getCurrIndex(i,1) + tetro.getRight() + 1].setBackground(BACKGROUND_COLOR);
            }

            else if(operation == "MOVE DOWN") {
                int x = tetro.getCurrIndex(i,0) + tetro.getDown() - 1;
                int y = tetro.getCurrIndex(i,1) + tetro.getRight();
                buttons[x][y].setBackground(BACKGROUND_COLOR);
            }
        }
    }

  
}








