
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Random;
import java.util.concurrent.TimeUnit;


/**
 * Tetris class for the Tetris game.
 * Implements functions related to Tetris Game.
 *
 * @file     Tetris.java
 * @author   Çağla Nur Yuva
 * @brief    Function implementations related to Tetris Game
 * @version  1.0
 * @date     2022-01-24
 */
public class Tetris {
  
    /** Keeps tetris board's row size */
    private int board_row;
    
    /** Keeps tetris board's column size */
    private int board_col;  
    
    /** Keeps tetris board */
    private ArrayList<ArrayList<Character>> tetris_board = new ArrayList<ArrayList<Character>>();  
    
    /** Keeps whether adding tetromino to the board is successful or not */
    private boolean adding_success = true;  
    
    /** Keeps blocks of a tetromino's indexes on Tetris board */
    private int[][] current_indexes_of_blocks = new int[4][2]; 
    

    /**
     * Constructor of Tetris class.
     * Initializes and fills arrays keeping current indexes of blocks and tetris board using its parameters.
     * @param board_row_x  Row size of tetris board.
     * @param board_col_y  Column size of tetris board.
     */
    public Tetris(final int board_row_x, final int board_col_y){

        board_row = board_row_x;
        board_col = board_col_y;
	
	    /* Creating rows of tetris board and adding them to tetris board */
        for (int i = 0; i < board_row_x + 2; i++) {
            ArrayList<Character> row = new ArrayList<Character>();
            for (int j = 0; j < board_col_y + 2; j++) {
                row.add(' ');
            }
            tetris_board.add(row);
        }
	
	    /* Filling current_indexes_of_blocks array with 0 */
        for(int i=0; i<4; i++){                                     
            current_indexes_of_blocks[i][0] = 0;
            current_indexes_of_blocks[i][1] = 0;
        }

	    /* Filling tetris array with characters */
        for(int i=0; i<board_row+2; i++){
            for(int j=0; j<board_col+2; j++){
                if(i == (board_row+1)) {
                    tetris_board.get(i).set(j,'#');
                }
            
                else if(i == 0){
                    tetris_board.get(i).set(j,'#');
                }
            

                else if(j == 0 || j == (board_col+1)){
                   tetris_board.get(i).set(j,'#');
                }
            
                else  tetris_board.get(i).set(j,' ');
            
            }
        } 

        System.out.println("Tetris board and an array have been allocated");
        System.out.println("Tetris board's row = " + board_row);
        System.out.println("Tetris board's col = " + board_col);
    }
    
    
    /**
     * Constructor of Tetris class.
     * Initializes and fills arrays keeping current indexes of blocks and tetris board by getting input from user.
     */
    public Tetris() {

        Scanner my_scanner = new Scanner(System.in);
        boolean flag = false;
	
	    /* Getting row of tetris board as an input from user and validating it */
        while (true) {
            System.out.print("Enter the number of rows: ");
            if (my_scanner.hasNextInt()) {
                board_row = my_scanner.nextInt();
                if (board_row <= 0) {
                    System.out.println("Unvalid input.");
                    my_scanner.nextLine();
                    continue;
                }
                break;
            } 

            else {
                System.out.println("Unvalid input.");
                my_scanner.nextLine();
            }
        }

	
	    /* Getting column of tetris board as an input from user and validating it */
        while (true) {
            System.out.print("Enter the number of columns: ");
            if (my_scanner.hasNextInt()) {
                board_col = my_scanner.nextInt();
                if (board_col <= 0) {
                    System.out.println("Unvalid input.");
                    my_scanner.nextLine();
                    continue;
                }
                break;
            } 

            else {
                System.out.println("Unvalid input.");
                my_scanner.nextLine();
            }
        }


	    /* Creating rows of tetris board and adding them to tetris board */
        for (int i = 0; i < board_row + 2; i++) {
            ArrayList<Character> row = new ArrayList<Character>();
            for (int j = 0; j < board_col + 2; j++) {
                row.add(' ');
            }
            tetris_board.add(row);
        }
	
	
	    /* Filling current_indexes_of_blocks array with 0 */
        for(int i=0; i<4; i++){                                     
            current_indexes_of_blocks[i][0] = 0;
            current_indexes_of_blocks[i][1] = 0;
        }
	
	
	    /* Filling tetris board with characters */
        for(int i=0; i<board_row+2; i++){
            for(int j=0; j<board_col+2; j++){
                if(i == (board_row+1)) {
                    tetris_board.get(i).set(j,'#');
                }
            
                else if(i == 0){
                    tetris_board.get(i).set(j,'#');
                }
            

                else if(j == 0 || j == (board_col+1)){
                    tetris_board.get(i).set(j,'#');
                }
            
                else tetris_board.get(i).set(j,' ');
            
            }
        } 

    }
    
    
    /**
     * Adding a new tetromino to the tetris board.
     * 
     * @param obj  Tetromino object keeping tetromino
     */
    public void Add_Tetromino(final Tetromino obj) {
      
        int width_of_tetromino;
        boolean first_block_found = false;
        int i,j,board_x, board_y;
        int keep_indexes_x=0;
        int biggest_b=0, least_b=0;
        int a,b;
  
    
        /* Looking for the first block starting from the top */
        for(i=0; i<4 && first_block_found == false ; i++){
            for(j=0; j<4 && first_block_found == false; j++){
                if(obj.my_tetromino[i][j] != ' ') {
                    first_block_found = true;
                    break;
                }
            }
        
            if(first_block_found == true) break;
        }
    
        first_block_found = false;
  
  
        /* Finding the most left and the most right blocks of a tetromino */
        for(a=0; a<4 ; a++){
            for(b=0; b<4 ; b++){
                if(obj.my_tetromino[a][b] != ' ') {
                    if(first_block_found==false) {
                        first_block_found = true;
                        least_b = b;
                        biggest_b = b;
                    }  
                
                    else {
                        if(b < least_b) least_b = b;
                        if(b > biggest_b) biggest_b = b;
                    }
              
                }
            } 
        }
    
    
        /* Checking whether adding is going to be successful or not */
        adding_success = true;
        width_of_tetromino = biggest_b - least_b + 1;
   
        board_x = 1;
        board_y = (board_col - width_of_tetromino )/2 + 1;
  
        for(int m=i; m<4 && adding_success == true; m++){
        
            board_y = (board_col - width_of_tetromino)/2 + 1;
            for(j=0; j<width_of_tetromino && adding_success == true; j++) {
                if(obj.my_tetromino[m][j] != ' ') {

                    /* If there is no available place, adding is not successful */
                    if(tetris_board.get(board_x).get(board_y)!= ' ' ) {
                        adding_success = false;
                        break;
                    }
                
                    /* If places don't fit in the tetris board, adding is not successful  */
                    if(board_x<=0 || board_x>board_row) {
                        adding_success = false;
                        break;
                    }
                           
                    if(board_y<=0 || board_y>board_col) {
                        adding_success = false;
                        break;
                    }
                }
                board_y++; /* Incrementing the tetris board's column value */
            }
            board_x++; /* Incrementing the tetris board's row value */
        }
    
        board_x = 1;
    
        /* Finding the indexes of blocks of a tetromino */
        for(int m=i; m<4; m++){
        
            board_y = (board_col - width_of_tetromino)/2 + 1;
     
            for(j=0; j<width_of_tetromino; j++){
            
                if(obj.my_tetromino[m][j] !=' '){

                    /* The char 'Y' indicates that indexes of the tetromino is going to be found and be written on the tetris board */
                    if(obj.change == 'Y' && adding_success == true) {
                        tetris_board.get(board_x).set(board_y,obj.my_tetromino[m][j]);
                    }
           
                    current_indexes_of_blocks[keep_indexes_x][0] = board_x;
                    current_indexes_of_blocks[keep_indexes_x][1] = board_y;               
                    keep_indexes_x++;
                
                }
          
                board_y++; /* Incrementing the tetris board's column value */
            }
            board_x++; /* Incrementing the tetris board's row value */
        }
 
    }
    
    
    /**
     * Drawing tetris board. 
     *
     */	
    public void Draw_Tetris_Board() {
    
        /* Going through elements of tetris board and printing them */		
        for (ArrayList<Character> row : tetris_board) {
            for (char element : row) {
                System.out.print(element);
            }
            System.out.println();
        }
    }
    
    
    /**
     * Animating a dropping tetromino 
     * 
     * @param rotating_times  how many times tetromino has been rotated to be added to tetris board
     * @param c               tetromino type as a char value
     * @return true           if animating is successful, otherwise false
     * @throws InterruptedException
     */	
    public boolean Animate(final int rotating_times,final char c) {

        boolean hitting_bottom = false;
        int[][] temp1 = new int[4][2];
      

        /* Keeping the indexes of tetromino's blocks just after having been moved */
        for(int i=0; i<4; i++){
            temp1[i][0] = current_indexes_of_blocks[i][0];
            temp1[i][1] = current_indexes_of_blocks[i][1];    
        }
    
        int limit = Animation_row_limit(); /* Deciding the index of last row on which animation will be seen */
        System.out.println("Animation is starting...");
  
        do{
        
            /* Handling the case in which program keeps being executed before 50 ms has not been elapsed by throwing error */
            try {
                TimeUnit.MILLISECONDS.sleep(50); /* Sleeping for 50 miliseconds */
            } 
            catch (InterruptedException e) {
                System.err.println("THROWING ERROR: PROGRAM WILL BE EXECUTED EVEN THOUGH 50 MILLISECONDS HAS NOT BEEN ELAPSED...");
            }
        
        
            /* Checking whether bottom has been reached or not */
            if((current_indexes_of_blocks[3][0] + 1) <= limit) {
                for(int i=0; i<4; i++) {
                    tetris_board.get(current_indexes_of_blocks[i][0]).set(current_indexes_of_blocks[i][1],' ');
                    (current_indexes_of_blocks[i][0])++ ;
                }

                for(int i=0; i<4; i++) {
                    tetris_board.get(current_indexes_of_blocks[i][0]).set(current_indexes_of_blocks[i][1],c);
                }

                /* Drawing tetris board */
                Draw_Tetris_Board();
            }
        
            /* When the bottom has been reached, animation ends */
            else {
                hitting_bottom = true;
                break;
            }

        }while(hitting_bottom == false); /* Keep animating until the block hits the bottom of the tetris board */

        System.out.println("Animation has ended...");
        return true; 
 
    }
    
    
    /**
     * Changing location of tetromino on tetris board randomly
     * 
     * @param rotating_times  how many times tetromino has been rotated to be added to tetris board
     * @param obj             Tetromino object keeping tetromino
     * @return true           if moving is successful, otherwise false
     */		
    public boolean Move_Tetromino(final int rotating_times, Tetromino obj) {
      
        int rotation_count=0, move_count=0;
        int move_direction=0, rotation_direction=0;
        int theLeastCol=1, theGreatestCol=1, counter=0;
        boolean flag = false;
        int[][] temp1 = new int[4][2];
      
    
        /* Keeping the indexes of tetromino's blocks just after having added to the tetris board */
        for(int i=0; i<4; i++){
            temp1[i][0] = current_indexes_of_blocks[i][0];
            temp1[i][1] = current_indexes_of_blocks[i][1];
        }

    
        /* Making sure rotated tetromino is still at tetris board's top row */
        do{
            /* Getting rotation direction randomly */
            rotation_direction = (int)(Math.random()*2); 
    
            /* Getting rotation count randomly */
            rotation_count = (int)(Math.random()*4);  
      
            counter++;  /* Incrementing counter */
      
            /* Counting how many times the tetromino has been rotated so far and deciding to which direction it has been rotated */
            int send=0;
            Tetromino.Directions send_direct = Tetromino.Directions.RIGHT;  

            /* Handling the case if the desired rotation direction is to the right */
            if(rotation_direction == 1) {
                send = rotation_count + rotating_times;
                rotation_direction = 1;
                send_direct = Tetromino.Directions.RIGHT;
            }

            /* Handling the case if the desired rotation direction is to the left */
            else if(rotation_direction == 0){
                if(rotating_times - rotation_count >= 0) {
                    send = rotating_times - rotation_count;
                    rotation_direction = 1;
                    send_direct = Tetromino.Directions.RIGHT;
                }

                else {
                    send = rotation_count - rotating_times;
                    rotation_direction = 0;
                    send_direct = Tetromino.Directions.LEFT;
                }
            }
      
            obj.rotate(send_direct,send); /* Rotating the tetromino */
            obj.change = 'N'; /* Indicating Add_Tetromino function will not cause any change on tetris board */
            Add_Tetromino(obj); /* Adding tetromino to the board */
    
    
   	        /* Finding the most left and the most right blocks of a tetromino */
            for(int x=0; x<4; x++){     
           
                if(flag == false){
                    flag = true;
                    theLeastCol = current_indexes_of_blocks[x][1];
                    theGreatestCol = theLeastCol;
                }
                
                else {
         
                    if(current_indexes_of_blocks[x][1] < theLeastCol) theLeastCol = current_indexes_of_blocks[x][1];
                    if(current_indexes_of_blocks[x][1] > theGreatestCol) theGreatestCol = current_indexes_of_blocks[x][1];    
                }
            }
        
            if(theLeastCol < 1 || theLeastCol > board_col ||  theGreatestCol > board_col || theGreatestCol < 1) continue;
            else if(counter == 4) return false;
            else break;
        
      
        }while(theLeastCol < 1 || theLeastCol > board_col ||  theGreatestCol > board_col || theGreatestCol < 1);
  
        
        /* Getting move direction randomly */
        move_direction = (int)(Math.random()*2); 
      
        /* Getting move count randomly while making sure moved tetromino is still at tetris board's top row */
        if(move_direction == 0) { 
            move_count = (int)(Math.random()*(theLeastCol));  
        }
        
        else if(move_direction == 1) { 
            ArrayList<Integer> possibilities = new ArrayList<Integer>();  /* Keeps all possible locations in array */
            int ind = 0;
         
            /* Filling possibilities array with all possible locations */
            for(int i=0; i<= board_col - theGreatestCol; i++){
         	    possibilities.add(i);
            }
         
            /* Chosing a location from array randomly */
            ind = (int)(Math.random()*(board_col - theGreatestCol + 1));  
            move_count = possibilities.get(ind);   
        }
        
        
   	    /* Printing information about randomly chosen move and rotate */
        System.out.print("The tetromino will be rotated to the ");

        if(rotation_direction == 0) System.out.print("LEFT ");
        else if(rotation_direction == 1) System.out.print("RIGHT ");
        System.out.print(rotation_count + " times and will be moved ");
        if(move_direction == 0) System.out.print("to the LEFT ");
        else if(move_direction == 1)  System.out.print("to the RIGHT ");

        System.out.println(move_count + " times...");
        System.out.println(" ");
  
    
        /* Moving the blocks of tetromino to the desired location */
        for(int j=0; j<move_count; j++){
            for(int i=0; i<4; i++) {
                if(move_direction == 1) (current_indexes_of_blocks[i][1])++;
                else if(move_direction == 0) (current_indexes_of_blocks[i][1])--;
            }
        }
    
        /* Checking whether the places of blocks are available or not */
        for(int i=0; i<4; i++){
            if(current_indexes_of_blocks[i][0]<=0 || current_indexes_of_blocks[i][0]>board_row) return false;
            else if(current_indexes_of_blocks[i][1]<=0 || current_indexes_of_blocks[i][1]>board_col) return false;
            else if(tetris_board.get(current_indexes_of_blocks[i][0]).get(current_indexes_of_blocks[i][1]) != ' ') {
                boolean found = false;
                for(int k=0; k<4 && found == false; k++) {
                    if((current_indexes_of_blocks[i][0] == temp1[k][0]) && (current_indexes_of_blocks[i][1] == temp1[k][1])) {
                        found = true;
                        break;
                    }
                }
            
                if(found == false) return false;
            }
        }
    
        /* Old locations of tetromino blocks are removed from the tetris board */
        for(int i=0; i<4; i++) {
            tetris_board.get(temp1[i][0]).set(temp1[i][1],' ');
        }
    
        /* New locations of tetromino blocks are indicated on the tetris board */
        for(int i=0; i<4; i++) {
            tetris_board.get(current_indexes_of_blocks[i][0]).set(current_indexes_of_blocks[i][1], obj.get_current_tetro());
        }
   
        System.out.print("\033[2J\033[H"); /* Cleaning terminal */
        System.out.println("Tetris board with the rotated and moved tetromino:");
        Draw_Tetris_Board(); /* Drawing tetris board */
        return true;
    }


    /**
     * Returning the index of last row on which animation will be seen
     * 
     * @return int   the index of last row on which animation will be seen
     */	
    public int Animation_row_limit() {

        int[][] temp2 = new int[4][2];
        boolean limit_reached = false;
        int value;
    
        /* Allocating memory for temp2 array and assigning the values of temp1 array to temp2 array */
        for(int i=0; i<4; i++){
            temp2[i][0] = current_indexes_of_blocks[i][0];
            temp2[i][1] = current_indexes_of_blocks[i][1];
        }
    
    
        while(limit_reached == false) {
            for(int i=0; i<4 && limit_reached == false; i++) {

                /* Handling the case in which tetris board are not empty on desired location*/
                if(tetris_board.get(temp2[i][0] + 1).get(temp2[i][1]) != ' ') {
                    boolean found = false;

                    /* Looking for an overlap with the tetromino blocks themselves on tetris board in order for the particular location to be valid */
                    for(int k=0; k<4; k++){
                        if((temp2[i][0] + 1) == current_indexes_of_blocks[k][0] && temp2[i][1] == current_indexes_of_blocks[k][1]) {
                            found = true;
                            break;
                        }
                    }

                    /* Handling the case in which there is no overlapping and the particular location is not valid */   
                    if(found == false){
                        limit_reached = true; 
                    }
                }
            
                /* Handling the case in which tetris board limits has been reached */
                else if((temp2[i][0]+1) <= 0 || (temp2[i][0]+1) > board_row) {
                    limit_reached = true;
                    break;
                }
            }
        
            /* As long as the last row is not reached, row values of tetromino blocks are incremented by one */
            if(limit_reached == false) {
                for(int k=0; k<4; k++) {
                    ++(temp2[k][0]);
                }
            }
        }

        /* When the last row has been reached, its value is returned */    
        value = temp2[3][0];  
        return value;
    }
    
    
    /**
     * Returning current_indexes_of_blocks array
     * 
     * @return int[][]   array keeping current indexes of blocks of tetromino in tetris board
     */	
    public int[][] getter_current_ind() { return current_indexes_of_blocks; }


    /**
     * Starting tetris game 
     * 
     */		
    public void Tetris_Game() {

        int[][] temp1 = new int[4][2];  /* Allocating memory for temp1 array*/
        char x = ' ';
        boolean tetro_checking = false;
        Scanner scanner = new Scanner(System.in);
        Tetromino obj = new Tetromino(); /* Creating a tetromino object */

        System.out.println("Tetris board:");
        Draw_Tetris_Board(); /* Drawing tetris board */

        do{

            /* Getting tetromino type from the user as an input*/
            System.out.println("What is the tetromino type? (I - O - T - J - L - S - Z - R)");
            String my_input = scanner.nextLine();
            if(my_input.length() == 1 && (my_input.charAt(0) >= 'a' && my_input.charAt(0) <= 'z' || my_input.charAt(0) >= 'A' && my_input.charAt(0) <= 'Z' )){
                x = my_input.charAt(0);
            }

            else {
                System.out.println("Invalid input.");
                x = ' ';
                continue;
            }


            /* Handling quitting case */       
            if(x == 'Q') {
                System.out.println("Quitting...");
                return;
            }
                          
            /* Handling choosing random tetromino case */
            else if(x == 'R') {
                int value = (int)(Math.random()*7);/* Getting a random number between 0-6 */

                /* Assigning a char value to x by using the random number selected above */
                if(value == 0) x = 'I';
                else if(value == 1) x = 'O';
                else if(value == 2) x = 'T';
                else if(value == 3) x = 'J';
                else if(value == 4) x = 'L';
                else if(value == 5) x = 'S';
                else if(value == 6) x = 'Z';
            
            }

            /* Assigning the chosen tetromino type to current_tetromino and validating it */
            tetro_checking = obj.set_current_tetro(x);

            /* Handling the case in which unvalid tetromino type is entered */
            if(tetro_checking == false) continue;          
        
            
            /* Constructing a tetromino initially which is in bottom position */
            obj.initially_construct_tetromino();
            obj.change = 'Y'; /* Indicating Add_Tetromino function will cause change on tetris board */
            obj.set_current_pos(4);/* Setting current position of the tetromino as bottom position */
            int rotating_times = 0; /* Keeping how many times the tetromino is rotated to the right to be added to the tetris board */

            do{
            
                /* Adding the tetromino to the tetris board */
                Add_Tetromino(obj); 

                /* Handling the case in which adding is successful */
                if(adding_success == true) {
                    System.out.println("Added tetromino:");
                    Draw_Tetris_Board(); /* Drawing the tetris board */
                    break;
                }

                /* Handling the case in which adding is not successful */
                else if(adding_success == false) {

                    /* Rotating the tetromino to the right to try to add to the tetris board again */
                    rotating_times++;
                    obj.rotate(Tetromino.Directions.RIGHT,rotating_times);
		            obj.set_current_pos(rotating_times);
                }
            
            }while(rotating_times < 4 && adding_success == false); /* Trying to add the tetromino in different positions */


            /* Handling the case in which adding is successful */
            if(adding_success == true) {
            
                /* Rotating tetromino as desired and moving it to the desired location */
                boolean flag = Move_Tetromino(rotating_times,obj);
            
                if(flag ==  false && x == 'Q')  break;

                /* Handling the case in which moving is not successful */
                if(flag == false) {

                    System.out.println(" ");
                    for(int z=0; z<4; z++){
                        System.out.print("(");
             
                        for(int y=0; y<2; y++){
                            System.out.print(current_indexes_of_blocks[z][y]);
                            if(y == 0) System.out.print(",");
                        }
                        System.out.print(")");
                        if(z != 3)  System.out.print(",");
                    }

                    System.out.println(" is not available on tetris board...");
                    x = 'Q';
                    break;
                }

                /* Animating a dropping tetromino */
                flag = Animate(rotating_times,x);

                /* Handling the case in which animating is not successful */
                if(flag == false) {
                    System.out.println("Animation of the tetromino is not successful");
                    x = 'Q';
                    break;
                }
            }

            /* Handling the case in which adding is not successful */
            else {
                System.out.println("There is not enough space to add a new tetromino...");
                x = 'Q';
                break;
            } 

        }while(x != 'Q'); /* Keep getting inputs from user until the user choose to quit */

        System.out.println("Quitting...");
 
    }
  

}
