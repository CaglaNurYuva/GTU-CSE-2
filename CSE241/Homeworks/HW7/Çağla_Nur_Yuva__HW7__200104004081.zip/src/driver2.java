/**
 * This class is the starting point of the Tetris game, 
 * it contains main method to start the game.
 *
 * @file    driver2.java
 * @author  Çağla Nur Yuva
 * @brief   Tetris Game Driver/Test
 * @version 1.0
 * @date    2022-01-24
 */


public class driver2 {

    /**
     * The main method creates a Tetris class object and starts Tetris Game 
     * by calling Tetris_Game() function.
     *
     * @param args The command-line arguments are unused.
     */
    public static void main(String[] args) {
        Tetris obj = new Tetris();  /* Creating tetris class object */
        obj.Tetris_Game();  /* Starting tetris game */
    }
}
