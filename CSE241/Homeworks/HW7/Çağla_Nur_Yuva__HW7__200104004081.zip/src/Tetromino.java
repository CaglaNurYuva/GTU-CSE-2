

/**
 * Tetromino class for the Tetris game.
 * Implements functions related to tetrominos of Tetris Game.
 *
 * @file     Tetromino.java
 * @author   Çağla Nur Yuva
 * @brief    Function implementations related to tetrominos 
 * @version  1.0
 * @date     2022-01-24
 */
public class Tetromino { 
    
    /** It represents to which direction the tetromino is rotated */
    public enum Directions {LEFT, RIGHT}; 
    
    /** It represents current position of a tetromino */
    public enum Positions{BOTTOM_POS,LEFT_POS,UP_POS,RIGHT_POS}; 
    
    /** It represents the types of tetrominos */
    public enum Tetrominos {I,O,T,J,L,S,Z}; 
     
    /** Keeping the type of a tetromino */
    private Tetrominos current_tetromino;  
    
    /** Keeping the current position of a tetromino */
    private Positions current_position; 
    
    /** Indicating whether Add_Tetromino function will cause change on tetris board or not */
    public char change; 
    
    /** Keeping tetromino as a 2D array */ 
    public char my_tetromino[][] = new char[4][5];  
     
     
    /**
     * Constructor of Tetromino class.
     * Initializes and fills the array that keeps tetromino.
     * Initializes current tetromino type and position as defult.
     *
     * Initializes a variable indicating whether Add_Tetromino
     * function will cause change on tetris board or not.
     */
    public Tetromino() {
        
        int i,j;

        for(i=0; i<4; i++){
            for(j=0; j<4; j++) {
                my_tetromino[i][j] = ' ';  /* Initializing my_tetromino array */
            }
      
            my_tetromino[i][j] = '\0';
        }
        
        
        current_tetromino = Tetrominos.I; /* Initializing current_tetromino variable */
        current_position = Positions.BOTTOM_POS; /* Initializing current_position variable */
        change = 'Y';  /* Indicating whether Add_Tetromino function will cause change on tetris board or not */    
    }
        
    
    
    /**
     * Constructor of Tetromino class.
     * Initializes and fills the array that keeps tetromino.
     * Initializes current tetromino type and position using its parameters.
     *
     * Initializes a variable indicating whether Add_Tetromino
     * function will cause change on tetris board or not.
     * @param current_tetro  Keeps current tetromino type
     * @param current_pos    Keeps current tetromino position
     */   
    public Tetromino(final Tetrominos current_tetro, final Positions current_pos){
       
        int i,j;

        for(i=0; i<4; i++){
            for(j=0; j<4; j++) {
                my_tetromino[i][j] = ' '; /* Initializing my_tetromino array */
            }
            
            my_tetromino[i][j] = '\0';
        }

        current_tetromino = current_tetro; /* Initializing current_tetromino variable */
        current_position = current_pos; /* Initializing current_position variable */
        change = 'Y';  /* Indicating whether Add_Tetromino function will cause change on tetris board or not */

        System.out.println("The array that keeps tetromino array has been allocated");
        System.out.println("Current tetromino type and current position of it have been initialized");   
            
    }
        
        
        
    /**
     * Rotating a tetromino.
     * 
     * @param rotation_direction  Keeps rotation direction of tetromino
     * @param rotation_count      Keeps rotation count of tetromino 
     */   
    public void rotate(final Directions rotation_direction, final int rotation_count) {

        int precise_rotate_count = rotation_count % 4;
        int row,col;

        /* Cleaning old values kept in my_tetromino array */
        for(row=0; row<4; row++) {
            for(col=0; col<4; col++) {
                my_tetromino[row][col] = ' ';
            }
            my_tetromino[row][col] = '\0';
       
        }
    
    

        /* Handling the case there is no rotating happening */
        if(precise_rotate_count == 0) {
            initially_construct_tetromino();
            return;
        }

    
        /* Rotating the tetromino by checking its type, how many times it will be rotated and to which direction it will be rotated */
        if(current_tetromino == Tetrominos.I){ 
        
            if(precise_rotate_count == 1 ||  precise_rotate_count == 3) { 
                my_tetromino[0][0] = 'I';
                my_tetromino[1][0] = 'I';
                my_tetromino[2][0] = 'I';
                my_tetromino[3][0] = 'I';
                current_position = Positions.RIGHT_POS;
            }      

            else if(precise_rotate_count == 2) { 
                my_tetromino[3][0] = 'I';
                my_tetromino[3][1] = 'I';
                my_tetromino[3][2] = 'I';
                my_tetromino[3][3] = 'I';
                current_position = Positions.BOTTOM_POS;
            } 
    
        } 

 
        else if(current_tetromino == Tetrominos.O){ 
            my_tetromino[2][0] = 'O';
            my_tetromino[2][1] = 'O';
            my_tetromino[3][0] = 'O';
            my_tetromino[3][1] = 'O'; 
            current_position = Positions.BOTTOM_POS;
        } 

 
        else if(current_tetromino == Tetrominos.T){ 

            if(precise_rotate_count == 2) {
                my_tetromino[2][1] = 'T';
                my_tetromino[3][0] = 'T';
                my_tetromino[3][1] = 'T';
                my_tetromino[3][2] = 'T';
                current_position = Positions.UP_POS; 
            }

            else {
                if(precise_rotate_count == 1) {
                    if(rotation_direction == Directions.RIGHT) {
                        my_tetromino[1][1] = 'T';
                        my_tetromino[2][0] = 'T';
                        my_tetromino[2][1] = 'T';
                        my_tetromino[3][1] = 'T';
                        current_position = Positions.RIGHT_POS; 
                    }

                    else if(rotation_direction == Directions.LEFT) {
                        my_tetromino[1][0] = 'T';
                        my_tetromino[2][0] = 'T';
                        my_tetromino[2][1] = 'T';
                        my_tetromino[3][0] = 'T';
                        current_position = Positions.LEFT_POS; 
                    }
                }

                else if(precise_rotate_count == 3) {
                    if(rotation_direction == Directions.RIGHT) {
                        my_tetromino[1][0] = 'T';
                        my_tetromino[2][0] = 'T';
                        my_tetromino[2][1] = 'T';
                        my_tetromino[3][0] = 'T';
                        current_position = Positions.LEFT_POS;
                    }

                    else if(rotation_direction == Directions.LEFT) {
                        my_tetromino[1][1] = 'T';
                        my_tetromino[2][0] = 'T';
                        my_tetromino[2][1] = 'T';
                        my_tetromino[3][1] = 'T';
                        current_position = Positions.RIGHT_POS;  
                    }
                }
            }   
        } 


        else if(current_tetromino == Tetrominos.J){ 

            if(precise_rotate_count == 2) {
                my_tetromino[1][0] = 'J';
                my_tetromino[1][1] = 'J';
                my_tetromino[2][0] = 'J';
                my_tetromino[3][0] = 'J';
                current_position = Positions.UP_POS;
            }

            else {
                if(precise_rotate_count == 1) {
                    if(rotation_direction == Directions.RIGHT) {
                        my_tetromino[2][0] = 'J';
                        my_tetromino[3][0] = 'J';
                        my_tetromino[3][1] = 'J';
                        my_tetromino[3][2] = 'J';
                        current_position = Positions.RIGHT_POS;
                    }

                    else if(rotation_direction == Directions.LEFT) {
                        my_tetromino[2][0] = 'J';
                        my_tetromino[2][1] = 'J';
                        my_tetromino[2][2] = 'J';
                        my_tetromino[3][2] = 'J';
                        current_position = Positions.LEFT_POS;  
                    }
                }

                else if(precise_rotate_count == 3) {
                    if(rotation_direction == Directions.RIGHT) {
                        my_tetromino[2][0] = 'J';
                        my_tetromino[2][1] = 'J';
                        my_tetromino[2][2] = 'J';
                        my_tetromino[3][2] = 'J';
                        current_position = Positions.LEFT_POS;
                    }

                    else if(rotation_direction == Directions.LEFT) {
                        my_tetromino[2][0] = 'J';
                        my_tetromino[3][0] = 'J';
                        my_tetromino[3][1] = 'J';
                        my_tetromino[3][2] = 'J';
                        current_position = Positions.RIGHT_POS;
                    }
                }
            } 
         
        } 

        else if(current_tetromino == Tetrominos.L){ 

            if(precise_rotate_count == 2) {
                my_tetromino[1][0] = 'L';
                my_tetromino[1][1] = 'L';
                my_tetromino[2][1] = 'L';
                my_tetromino[3][1] = 'L';
                current_position = Positions.UP_POS;
            }

            else {
                if(precise_rotate_count == 1) {
                    if(rotation_direction == Directions.RIGHT) {
                        my_tetromino[2][0] = 'L';
                        my_tetromino[2][1] = 'L';
                        my_tetromino[2][2] = 'L';
                        my_tetromino[3][0] = 'L';
                        current_position = Positions.RIGHT_POS;
                    }

                    else if(rotation_direction == Directions.LEFT) {
                        my_tetromino[2][2] = 'L';
                        my_tetromino[3][0] = 'L';
                        my_tetromino[3][1] = 'L';
                        my_tetromino[3][2] = 'L';
                        current_position = Positions.LEFT_POS; 
                    }
                }

                else if(precise_rotate_count == 3) {
                    if(rotation_direction == Directions.RIGHT) {
                        my_tetromino[2][2] = 'L';
                        my_tetromino[3][0] = 'L';
                        my_tetromino[3][1] = 'L';
                        my_tetromino[3][2] = 'L'; 
                        current_position = Positions.LEFT_POS;
                    }

                    else if(rotation_direction == Directions.LEFT) {
                        my_tetromino[2][0] = 'L';
                        my_tetromino[2][1] = 'L';
                        my_tetromino[2][2] = 'L';
                        my_tetromino[3][0] = 'L';   
                        current_position = Positions.RIGHT_POS;
                    }
                }
            } 
         
        } 
     

        else if(current_tetromino == Tetrominos.S){ 

            if(precise_rotate_count == 2) {
                my_tetromino[2][1] = 'S';
                my_tetromino[2][2] = 'S';
                my_tetromino[3][0] = 'S';
                my_tetromino[3][1] = 'S';  
                current_position = Positions.BOTTOM_POS;
            }

            else {
                my_tetromino[1][0] = 'S';
                my_tetromino[2][0] = 'S';
                my_tetromino[2][1] = 'S';
                my_tetromino[3][1] = 'S';  
                current_position = Positions.RIGHT_POS;   
            } 
         
        } 

  

        else if(current_tetromino == Tetrominos.Z){ 

            if(precise_rotate_count == 2) {
                my_tetromino[2][0] = 'Z';
                my_tetromino[2][1] = 'Z';
                my_tetromino[3][1] = 'Z';
                my_tetromino[3][2] = 'Z';  
                current_position = Positions.BOTTOM_POS;
            }

            else {
                my_tetromino[1][1] = 'Z';
                my_tetromino[2][0] = 'Z';
                my_tetromino[2][1] = 'Z';
                my_tetromino[3][0] = 'Z';  
             
                current_position = Positions.RIGHT_POS;
            } 
         
        } 

    }
    
    
    /**
     * Constructing a tetromino initially which is in bottom position.
     * 
     */ 
    public void initially_construct_tetromino() {
        int row,col;

        /* Cleaning old values kept in my_tetromino array */    
        for(row=0; row<4; row++) {
            for(col=0; col<4; col++) {
                my_tetromino[row][col] = ' ';
            }
            my_tetromino[row][col] = '\0';      
        }
        
        /* Initializing my_tetromino array by checking its type */
        if(current_tetromino == Tetrominos.I){ 
            my_tetromino[3][0] = 'I';
            my_tetromino[3][1] = 'I';
            my_tetromino[3][2] = 'I';
            my_tetromino[3][3] = 'I';
        } 


        else if(current_tetromino  == Tetrominos.O){ 
            my_tetromino[2][0] = 'O';
            my_tetromino[2][1] = 'O';
            my_tetromino[3][0] = 'O';
            my_tetromino[3][1] = 'O';
        
        } 

 
        else if(current_tetromino  == Tetrominos.T){ 
            my_tetromino[2][0] = 'T';
            my_tetromino[2][1] = 'T';
            my_tetromino[2][2] = 'T';
            my_tetromino[3][1] = 'T';

        } 


        else if(current_tetromino == Tetrominos.J){ 
            my_tetromino[1][1] = 'J';
            my_tetromino[2][1] = 'J';
            my_tetromino[3][0] = 'J';
            my_tetromino[3][1] = 'J';

        } 


        else if(current_tetromino  == Tetrominos.L){ 
            my_tetromino[1][0] = 'L';
            my_tetromino[2][0] = 'L';
            my_tetromino[3][0] = 'L';
            my_tetromino[3][1] = 'L';

        } 


        else if(current_tetromino  == Tetrominos.S){ 
            my_tetromino[2][1] = 'S';
            my_tetromino[2][2] = 'S';
            my_tetromino[3][0] = 'S';
            my_tetromino[3][1] = 'S';

        } 

 
        else if(current_tetromino  == Tetrominos.Z){ 
            my_tetromino[2][0] = 'Z';
            my_tetromino[2][1] = 'Z';
            my_tetromino[3][1] = 'Z';
            my_tetromino[3][2] = 'Z';
        
        } 

    }
    
    
    /**
     * Returning current tetromino type as char.
     * 
     * @return char  The current tetromino type
     */ 
    public char get_current_tetro() {
    	char c = 'I';
    	
    	/* Assigning a char to the variable according to current tetromino type */
     	if(current_tetromino == Tetrominos.I) c = 'I';
    	else if(current_tetromino == Tetrominos.O) c = 'O';
   	    else if(current_tetromino == Tetrominos.T) c = 'T';
    	else if(current_tetromino == Tetrominos.J) c = 'J';
    	else if(current_tetromino == Tetrominos.L) c = 'L';
    	else if(current_tetromino == Tetrominos.S) c = 'S';
    	else if(current_tetromino == Tetrominos.Z) c = 'Z';
    	return c;
    }
    
    
    /**
     * Returning current tetromino position as String.
     * 
     * @return String  The current tetromino position
     */ 
    public String get_current_pos() {
    	String tetro_pos = " ";
    	
    	/* Assigning a String to the variable according to current tetromino position */
    	if(current_position == Positions.BOTTOM_POS) tetro_pos = "BOTTOM_POS";
    	else if(current_position == Positions.LEFT_POS) tetro_pos = "LEFT_POS";
    	else if(current_position == Positions.UP_POS) tetro_pos = "UP_POS";
    	else if(current_position == Positions.RIGHT_POS) tetro_pos = "RIGHT_POS";
    	
    	return tetro_pos;
    }    
    
    
    /**
     * Setting current tetromino type using its parameter.
     * 
     * @param tetromino   Keeps current tetromino as char
     * @return true       If assigning current tetromino is successful, otherwise false
     */ 
    public boolean set_current_tetro(final char tetromino) {
    
    	/* Assigning current tetromino using tetromino char */
     	if(tetromino == 'I') current_tetromino  = Tetrominos.I;
        else if(tetromino == 'O') current_tetromino  = Tetrominos.O;
        else if(tetromino == 'T') current_tetromino  = Tetrominos.T;
        else if(tetromino == 'J') current_tetromino = Tetrominos.J;
        else if(tetromino == 'L') current_tetromino  = Tetrominos.L;
        else if(tetromino == 'S') current_tetromino = Tetrominos.S;
        else if(tetromino == 'Z') current_tetromino  = Tetrominos.Z;
        else {
            System.out.println("Invalid tetromino type."); 
            return false;  /* Returning false due to invalid tetromino type */
        }
        return true;  /* Returning true */
    
    }
    
    
    /**
     * Setting current tetromino position using its parameter.
     * 
     * @param num    Keeps how many times tetromino rotated so far.
     */
    public void set_current_pos(final int num) {
    	if(num == 1) current_position = Positions.RIGHT_POS;
        else if(num == 2) current_position = Positions.UP_POS;
        else if(num == 3) current_position = Positions.LEFT_POS;
        else if(num == 4) current_position = Positions.BOTTOM_POS;
    }
       
    
}

