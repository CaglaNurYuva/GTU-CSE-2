/**
 * This class is the starting point of the Tetris game, 
 * it contains main method to test methods of Tetris
 * and Tetromino classes.
 * 
 * @file    driver1.java
 * @author  Çağla Nur Yuva
 * @brief   Tetris Game Driver/Test
 * @version 1.0
 * @date    2022-01-24
 */
 
public class driver1 {

    /**
     * The main method tests all methods of Tetris and 
     * Tetromino classes by calling them one by one.
     * @param args The command-line arguments are unused.
     */
    public static void main(String[] args) {
      
        int i,j;
        char c = 'I';
        int[][] temp1 = new int[4][2];
        boolean check = false;
        String tetro_pos = " ";


        /* Testing public Tetromino(final Tetrominos current_tetro, final Positions current_pos) constructor */
        System.out.println("---------------------------------------------------");
        System.out.println("Testing public Tetromino(final Tetrominos current_tetro, final Positions current_pos) constructor...");
        Tetromino tetro_obj = new Tetromino(Tetromino.Tetrominos.T,Tetromino.Positions.BOTTOM_POS); /* Creating a tetromino object */
   

        /* Assigning value to c variable by checking current_tetromino variable */
        c = tetro_obj.get_current_tetro();
        tetro_pos = tetro_obj.get_current_pos();
   
        System.out.println("current tetromino type = " + c);
        System.out.println("current tetromino position = " + tetro_pos);
        System.out.println("---------------------------------------------------");
    
        /* Testing public char get_current_tetro() function */
        System.out.println("Testing public char get_current_tetro() function...");
        c = tetro_obj.get_current_tetro();
        System.out.println("current tetromino type = " + c);
        System.out.println("---------------------------------------------------");
    
        /* Testing public String get_current_pos() function */
        System.out.println("Testing public String get_current_pos() function...");
        tetro_pos = tetro_obj.get_current_pos();
        System.out.println("current tetromino position = " + tetro_pos);
        System.out.println("---------------------------------------------------");
    
    
        /* Testing public Tetris(final int board_row_x, final int board_col_y) constructor */
        System.out.println("Testing public Tetris(final int board_row_x, final int board_col_y) constructor...");
        Tetris tet_obj = new Tetris(10,10); /* Creating a tetris object */
        System.out.println(" ");
        System.out.println("---------------------------------------------------");


        /* Testing public void initially_construct_tetromino() function */
        System.out.println("Testing public void initially_construct_tetromino() function...");
        tetro_obj.initially_construct_tetromino(); 
        System.out.println("Printing having constructed tetromino:");

        for(i=0; i<4; i++) {
            for(j=0; j<4; j++) {
                System.out.print(tetro_obj.my_tetromino[i][j]);
            }
            System.out.println(" ");
        }
      
        System.out.println(" ");
        System.out.println("---------------------------------------------------");


        /* Testing public void Add_Tetromino(final Tetromino obj) function */
        System.out.println("Testing public void Add_Tetromino(final Tetromino obj) function...");
        tet_obj.Add_Tetromino(tetro_obj);
        System.out.println("Printing tetris board to show having added tetromino: ");
        tet_obj.Draw_Tetris_Board();
        System.out.println(" ");
        System.out.println("---------------------------------------------------");


        /* Testing public boolean Move_Tetromino() function */
        System.out.println("Testing public boolean Move_Tetromino() function...");
        System.out.println("Printing tetris board before moving tetromino: ");
        tet_obj.Draw_Tetris_Board();
        tet_obj.Move_Tetromino(0,tetro_obj);
        System.out.println(" ");
        System.out.println("---------------------------------------------------");


        /* Testing public boolean Animate(final int rotating_times,final char c) function */
        System.out.println("Testing public boolean Animate(final int rotating_times,final char c) function... ");
        tet_obj.Animate(0,c);
        System.out.println(" ");
        System.out.println("---------------------------------------------------");
        tetro_obj.initially_construct_tetromino(); 
   

        /* Testing public void rotate() function */
        System.out.println("Testing public void rotate() function...");
        System.out.println("Tetromino before rotating: ");
        for(i=0; i<4; i++) {
            for(j=0; j<4; j++) {
                System.out.print(tetro_obj.my_tetromino[i][j]);
            }
            System.out.println(" ");
        } 
        tetro_obj.rotate(Tetromino.Directions.RIGHT,2);
        System.out.println("Tetromino after rotating to the right 2 times: ");
 
        for(i=0; i<4; i++) {
            for(j=0; j<4; j++) {
                System.out.print(tetro_obj.my_tetromino[i][j]);
            }
            System.out.println(" ");
        } 
        System.out.println(" ");
        System.out.println("---------------------------------------------------");


        /* Testing public void Draw_Tetris_Board() function */
        System.out.println("Testing public void Draw_Tetris_Board() function...");
        tet_obj.Draw_Tetris_Board();
        System.out.println(" ");
        System.out.println("---------------------------------------------------");
        temp1 = tet_obj.getter_current_ind();


        /* Testing public int Animation_row_limit(final int[][] temp1) function */
        System.out.println("Testing public int Animation_row_limit(final int[][] temp1) function...");
        System.out.println("Limit = " + tet_obj.Animation_row_limit());
        System.out.println(" ");
        System.out.println("---------------------------------------------------");
 
        int input;


        /* Testing public int[][] getter_current_ind() function */
        System.out.println("Testing public int[][] getter_current_ind() function...");
        temp1 = tet_obj.getter_current_ind();
        System.out.print("current_indexes_of_blocks array elements = ");
   
        for(i=0; i<4; i++){
            System.out.println(temp1[i][0] + "," + temp1[i][1]);
        }
        System.out.println(" ");
        System.out.println("---------------------------------------------------");
    
        /* Testing public Tetromino() constructor */
        System.out.println("Testing public Tetromino() constructor...");
        Tetromino tetro_obj2 = new Tetromino(); /* Creating a tetromino object */
        System.out.println("Printing newly constructed empty tetromino array: ");
        for(i=0; i<4; i++) {
            for(j=0; j<4; j++) {
                System.out.print(tetro_obj2.my_tetromino[i][j]);
            }
            System.out.println(" ");
        } 
	
        System.out.println("current tetromino = " + tetro_obj2.get_current_tetro());
        System.out.println("current_position = " + tetro_obj2.get_current_pos());
        System.out.println(" ");
        System.out.println("---------------------------------------------------");
    
        /* Testing public Tetris() constructor */
        System.out.println("Testing public Tetris() constructor...");
        Tetris tet_obj2 = new Tetris();  /* Creating a tetris object */

        System.out.println(" ");
        System.out.println("---------------------------------------------------");
    
        /* Testing public void set_current_pos(final int num) function */
        System.out.println("Testing public void set_current_pos(final int num) function...");
        System.out.println("Setting current position of tetromino as UP_POS...");
        tetro_obj2.set_current_pos(2);
        System.out.println("current_position = " + tetro_obj2.get_current_pos());
        System.out.println("---------------------------------------------------");
    
        /* Testing public boolean set_current_tetro(final char tetromino) function */
        System.out.println("Testing public boolean set_current_tetro(final char tetromino) function...");
        System.out.println("Setting current tetromino as J...");
        check = tetro_obj2.set_current_tetro('J');
        if(check == true) System.out.println("current tetromino = " + tetro_obj2.get_current_tetro());
        System.out.println("Setting current tetromino as K...");
        check = tetro_obj2.set_current_tetro('K');
        if(check == true) System.out.println("current tetromino = " + tetro_obj2.get_current_tetro());
        System.out.println("---------------------------------------------------");

    
        /* Testing public void Tetris_Game() function */
        System.out.println("Testing public void Tetris_Game() function...");
        tet_obj2.Tetris_Game();
    
    }
}
