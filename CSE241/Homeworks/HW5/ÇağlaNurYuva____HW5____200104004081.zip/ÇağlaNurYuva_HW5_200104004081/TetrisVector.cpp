#include "TetrisVector.hpp"


/* Drawing tetris board */
void TetrisVector:: draw() const {

    cout << endl;

    for(auto i=0; i<boardRow+2; i++){
        for(auto j=0; j<boardCol+2; j++) {
            cout << TetrisBoard[i][j] ;
        }
        cout << endl;
    }
   

}

/* Creating and designing tetris board */
void TetrisVector:: CreateTetrisBoard(const vector<vector<char>>* MyTetrisBoard) {

    vector<vector<char>> temp(MyTetrisBoard->size());

    for (size_t i=0; i < MyTetrisBoard->size(); ++i) {
        temp[i].resize((*MyTetrisBoard)[i].size());
    }

    for (size_t i = 0; i < MyTetrisBoard->size(); ++i) {
        for (size_t j = 0; j < (*MyTetrisBoard)[i].size(); ++j) {
            temp[i][j] = (*MyTetrisBoard)[i][j];
        }
    }

    TetrisBoard = temp;


    for(auto i=0; i<boardRow+2; i++){
        for(auto j=0; j<boardCol+2; j++){

            if(i == (boardRow+1)) TetrisBoard[i][j] = '#';
            else if(i == 0) TetrisBoard[i][j] = '#';
            else if(j == 0 || j == (boardCol+1)) TetrisBoard[i][j] = '#';
            else TetrisBoard[i][j] = ' ';
        }
    }

}


/* Checking whether tetris board is available or not */
bool TetrisVector:: isBoardAvailable(const int row, const int col, const char value)const {

    /* Checking bounds */         
    if(row<=0 || row>boardRow) {
        return false;
       
    }
                           
    if(col<=0 || col>boardCol) {
        return false;                  
    }

    if(TetrisBoard[row][col] != value) {
        return false;
    }

    return true;
       
}


/* Reflecting change made by operator+= function on tetris board */
void TetrisVector::ReflectAddChangeOnBoard(const Tetromino &obj) {
 
    int board_x, board_y, tetro_x, tetro_y;
    for(auto i=0; i<4; i++) {
        board_x = AllMoves[MoveInd].currIndBlocksOnBoard[i][0];
        board_y = AllMoves[MoveInd].currIndBlocksOnBoard[i][1];
        tetro_x = obj.currIndBlocksOnTetro[i][0];
        tetro_y = obj.currIndBlocksOnTetro[i][1];

        TetrisBoard[board_x][board_y] = obj.my_tetromino[tetro_x][tetro_y];
   
    }

}



/* Reflecting change made by MoveTetromino function on tetris board */
void TetrisVector:: ReflectMoveChangeOnBoard(const char c, const int temp1[][2]) {
    for(auto i=0; i<4; i++) {
        if(TetrisBoard[(temp1[i][0])][(temp1[i][1])] != '#') {
        TetrisBoard[(temp1[i][0])][(temp1[i][1])] = ' '; }
    }

    for(auto i=0; i<4; i++) {
        if(TetrisBoard[AllMoves[MoveInd].currIndBlocksOnBoard[i][0]][AllMoves[MoveInd].currIndBlocksOnBoard[i][1]] != '#'){
        TetrisBoard[AllMoves[MoveInd].currIndBlocksOnBoard[i][0]][AllMoves[MoveInd].currIndBlocksOnBoard[i][1]] = c;}
    }

}


/* Reflecting change made by animate function on tetris board */
void TetrisVector:: ReflectAnimateChangeOnBoard(const char c) {
    for(auto i=0; i<4; i++) {
        if(TetrisBoard[AllMoves[MoveInd].currIndBlocksOnBoard[i][0]][AllMoves[MoveInd].currIndBlocksOnBoard[i][1]] != '#') {
        TetrisBoard[AllMoves[MoveInd].currIndBlocksOnBoard[i][0]][AllMoves[MoveInd].currIndBlocksOnBoard[i][1]] = ' '; }
        (AllMoves[MoveInd].currIndBlocksOnBoard[i][0])++ ;
    }

    for(auto i=0; i<4; i++) {
        if(TetrisBoard[AllMoves[MoveInd].currIndBlocksOnBoard[i][0]][AllMoves[MoveInd].currIndBlocksOnBoard[i][1]] != '#'){
        TetrisBoard[AllMoves[MoveInd].currIndBlocksOnBoard[i][0]][AllMoves[MoveInd].currIndBlocksOnBoard[i][1]] = c;}
    }

}





