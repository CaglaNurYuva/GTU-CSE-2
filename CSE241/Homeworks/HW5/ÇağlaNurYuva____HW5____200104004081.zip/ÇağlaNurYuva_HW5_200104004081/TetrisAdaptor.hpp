#ifndef TETRIS_ADAPTOR_HPP
#define TETRIS_ADAPTOR_HPP

#include "AbstractTetris.hpp"

namespace MyGame5 {


    /* Templated tetris adapter class */
    template <typename T>
    class TetrisAdapter : public AbstractTetris {
        public:
            TetrisAdapter(const int row_, const int col_) :  AbstractTetris(row_,col_) { MyVector.push_back(this); } /* TetrisAdapter class constructor */
            void CreateTetrisBoard(const T* MyTetrisBoard); /* Creating tetris board */
     

            void draw() const override ; /* Drawing tetris board */
            bool isBoardAvailable(const int row, const int col, const char value) const override ; /* Checking whether the particular location is available */
            void ReflectAddChangeOnBoard(const Tetromino &obj) override; /* Reflecting change made by operator+= function on tetris board */
            void ReflectMoveChangeOnBoard(const char c, const int temp1[][2]) override ; /* Reflecting change made by MoveTetromino function on tetris board */
            void ReflectAnimateChangeOnBoard(const char c) override; /* Reflecting change made by animate function on tetris board */
            ~TetrisAdapter() {/**/} /* TetrisAdapter class destructor */
 
       

        private: 
            T TetrisBoard; /* Keeps Tetris board */

    };

}

using namespace MyGame5;

#endif
