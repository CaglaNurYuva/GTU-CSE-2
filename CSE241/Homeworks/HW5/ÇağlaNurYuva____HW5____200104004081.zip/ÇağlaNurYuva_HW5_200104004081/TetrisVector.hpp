#ifndef TETRIS_VECTOR_HPP
#define TETRIS_VECTOR_HPP

#include "AbstractTetris.hpp"

namespace MyGame4 {
	

    /* TetrisVector class */
    class TetrisVector : public AbstractTetris {
        public:

            void CreateTetrisBoard(const vector<vector<char>>* MyTetrisBoard); /* Creating tetris board */

            TetrisVector(const int row_, const int col_) : AbstractTetris(row_,col_) { MyVector.push_back(this); } /* TetrisVector class constructor */
           
       

            bool isBoardAvailable(const int row, const int col, const char value) const override; /* Checking whether tetris board is available or not */
            void ReflectAddChangeOnBoard(const Tetromino &obj) override; /* Reflecting change made by operator+= function on tetris board */
            void draw() const override; // +
            void ReflectMoveChangeOnBoard(const char c, const int temp1[][2]) override; /* Reflecting change made by MoveTetromino function on tetris board */
            void ReflectAnimateChangeOnBoard(const char c) override; /* Reflecting change made by animate function on tetris board */
            ~TetrisVector(){/**/} /* TetrisVector class destructor */
       
       
        private:
            vector<vector<char>> TetrisBoard; /* Keeps tetris board */
     
    };

}

using namespace MyGame4;


#endif
