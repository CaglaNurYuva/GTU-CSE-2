

#include "AbstractTetris.hpp"



/* Returning the last move */
AbstractTetris::MoveInfo AbstractTetris:: lastMove() {
    bool last_move_exist = false;

    for(auto i=0; i<MoveInd; i++) {
        if(AllMoves[i].move_type != AbstractTetris::ROTATED) {
            last_move_exist = true;
            break;
        }
    }


    /* Handling exception by throwing error message */
    try {
       if(last_move_exist == false) throw ("LAST MOVE DOES NOT EXIST");
    }

    
    catch(const char* message) {
        std::cerr << "Throwing Error: "<< message <<  endl;
        cout << endl << "There is no successful move made on board." << endl;
        cout << endl << "The last unsuccessful move tried to be made:" << endl;
        return AllMoves.at(MoveInd);
   
    }  
    
    /* Returning the last move */
    if(QuitWay == "AddFail") {return AllMoves.at(MoveInd-5); }
    else if(QuitWay == "RotateFail") {return AllMoves.at(MoveInd-2); }
    return AllMoves.at(MoveInd-1);
}


/* Returning the number of steps (moves) this board made */
int AbstractTetris:: numberOfMoves() const {
    int k = 0;

    for(auto i=0; i<MoveInd; i++) {

        if((AllMoves[i].move_type != ROTATED && AllMoves[i-1].move_type == ROTATED)) {k++;}
        else if(!(AllMoves[i].move_type == ROTATED && AllMoves[i-1].move_type == ROTATED) || i == 0) continue;
        else k++;
        if(AllMoves[i].move_type == ROTATED) continue;
       
    }

    if(QuitWay == "choice") {
        try {
            if(MoveInd-k-1+1 == 0) throw ("THERE IS NO SUCCESSFUL MOVE MADE ON BOARD");
        }

    
        catch(const char* message) {
            std::cerr << "Throwing Error: "<< message <<  endl;
            return (MoveInd-k-1+1); 
        }  
        
    }

    try {
        if(MoveInd-k-1 == 0) throw ("THERE IS NO SUCCESSFUL MOVE MADE ON BOARD");
    }

    catch(const char* message) {
        std::cerr << "Throwing Error: "<< message <<  endl;
    }  


    return (MoveInd-k-1);
}





/* Animating a dropping tetromino */
bool AbstractTetris:: animate(const Tetromino &tetromino_obj,const int rotating_times, int temp1[][2], const char c) {
    bool hitting_bottom = false;
    int limit;

    /* Keeping the indexes of tetromino's blocks just after having been moved */
    for(auto i=0; i<4; i++){
        temp1[i][0] = AllMoves[MoveInd-1].currIndBlocksOnBoard[i][0];
        temp1[i][1] = AllMoves[MoveInd-1].currIndBlocksOnBoard[i][1];    
    }

    for(auto b=0; b<4; b++){
        MyVector[0]->AllMoves[MoveInd].currIndBlocksOnBoard[b][0] = MyVector[0]->AllMoves[MoveInd-1].currIndBlocksOnBoard[b][0];
        MyVector[0]->AllMoves[MoveInd].currIndBlocksOnBoard[b][1] = MyVector[0]->AllMoves[MoveInd-1].currIndBlocksOnBoard[b][1];
    }


    /* Deciding the index of last row on which animation will be seen */
    int **temp2 = new int*[4];
    bool limit_reached = false;
    int value;
   
    for(auto i=0; i<4; i++){
        temp2[i] = new int[2];
        temp2[i][0] = temp1[i][0];
        temp2[i][1] = temp1[i][1];
    }
   
   
    while(limit_reached == false) {
        for(auto i=0; i<4 && limit_reached == false; i++) {

            /* Handling the case in which tetris board are not empty on desired location*/
            if(!(MyVector[0]->isBoardAvailable(temp2[i][0] + 1, temp2[i][1], ' '))) {
                bool found = false;

                /* Looking for an overlap with the tetromino blocks themselves on tetris board in order for the particular location to be valid */
                for(auto k=0; k<4; k++){
                    if((temp2[i][0] + 1) == temp1[k][0] && temp2[i][1] == temp1[k][1]) {
                        found = true;
                        break;
                    }
                }

                /* Handling the case in which there is no overlapping and the particular location is not valid */   
                if(found == false){
                    limit_reached = true;
                }
               
            }
           
            /* Handling the case in which tetris board limits has been reached */
            else if((temp2[i][0]+1) <= 0 || (temp2[i][0]+1) > boardRow) {
                limit_reached = true;
                break;
            }
        }
       
        /* As long as the last row is not reached, row values of tetromino blocks are incremented by one */
        if(limit_reached == false) {
            for(auto k=0; k<4; k++) {
                ++(temp2[k][0]);
            }
        }
       
    }

     
    limit = temp2[3][0];  
    for(auto i = 0; i<4; i++) delete[ ] temp2[i];
    delete[ ]temp2;
   

    cout << "Animation is starting..." << endl;
    do{
       
        /* Sleeping for 50 seconds */
        std::this_thread::sleep_for(std::chrono::milliseconds(50));

     
        /* Checking whether bottom has been reached or not */
        if((AllMoves[MoveInd].currIndBlocksOnBoard[3][0] + 1) <= limit) {

            MyVector[0]->ReflectAnimateChangeOnBoard(c);

            /* Drawing tetris board */
            MyVector[0]->draw();
            (MyVector[0]->AllMoves[MoveInd].howManyTimes)++ ;
           
        }
       
        /* When the bottom has been reached, animation ends */
        else {
            hitting_bottom = true;
            break;
        }

    }while(hitting_bottom == false);
   
    cout << "Animation has ended..." << endl;

    /* Adding a move */
    MyVector[0]->AllMoves[MoveInd].move_type = AbstractTetris::DROPPED;
    MyVector[0]->AllMoves[MoveInd].direction_type = DOWN;
    AllMoves[MoveInd].TetroType = AllMoves[MoveInd-1].TetroType;

    MoveInd++;


    return true;
 
}





/* Reading the game from the file */
void AbstractTetris::readFromFile(const string& FileName) const {
    std::ifstream read_file;
    read_file.open(FileName);  /* Opening text file */


    /* Handling exception by throwing error message */
    try {
       if(!read_file) throw ("FILE CANNOT BE OPENED TO READ");
    }

    catch(const char* message) {
        std::cerr << "Throwing Error: "<< message <<  endl;
        return;
    }
    

    string line ;
    int index=0;
    bool empty = true;
    getline(read_file, line);
 
    /* Checking whether file is empty or not */      
    while(line[index] != '\0') {
        if(line[index] != '\n' && line[index] != '\t' && line[index] != ' ') {
            empty = false;
            break;
        }
        index++;
    }

    
    /* Handling exception by throwing error message */
    try {
       if(empty == true) throw ("FILE IS EMPTY, THERE IS NOTHING TO READ");
    }

    catch(const char* message) {
        std::cerr << "Throwing Error: "<< message <<  endl;
        read_file.close();
        return;
    }

    /* Reading file */
    string reading;
    cout << line << endl;
    while(getline(read_file, reading)) cout << reading << endl;
    

    read_file.close(); /* Closing file */

}


/* Writing the game to the file */
void AbstractTetris:: writeToFile(const string& FileName) const{

    /* Creating file */
    std::ofstream write_file_dummy;
    write_file_dummy.open(FileName); /* Opening text file */
        
        /* Handling exception by throwing error message */
        try {
            if(!write_file_dummy) throw ("FILE CANNOT BE OPENED TO REMOVE ITS CONTENTS");
        }

        catch(const char* message) {
            std::cerr << "Throwing Error: "<< message <<  endl;
            return;
        }
        
    write_file_dummy.close(); /* Closing text file */


    std::ifstream read_file;
    read_file.open(FileName);  /* Opening text file */

    /* Handling exception by throwing error message */
    try {
       if(!read_file) throw ("FILE CANNOT BE OPENED TO READ");
    }

    catch(const char* message) {
        std::cerr << "Throwing Error: "<< message <<  endl;
        return;
    }

    string line ;
    int index=0;
    bool empty = true;
    getline(read_file, line);
 
    /* Checking whether file is empty or not */      
    while(line[index] != '\0') {
        if(line[index] != '\n' && line[index] != '\t' && line[index] != ' ') {
            empty = false;
            break;
        }
        index++;
    }

    read_file.close();


    /* Handling the case in which file is empty by deleting the contents of file */
    if(empty == false) {
        cout << endl << "File is not empty, file contents are being removed..." << endl;
        std::ofstream write_file;
        write_file.open(FileName); /* Opening text file */
        
        /* Handling exception by throwing error message */
        try {
            if(!write_file) throw ("FILE CANNOT BE OPENED TO REMOVE ITS CONTENTS");
        }

        catch(const char* message) {
            std::cerr << "Throwing Error: "<< message <<  endl;
            return;
        }
        
        write_file.close(); /* Closing text file */
    }


    std::ofstream write_file;
    write_file.open(FileName); 

    /* Handling exception by throwing error message */
    try {
        if(!write_file) throw ("FILE CANNOT BE OPENED TO WRITE");
    }

    catch(const char* message) {
        std::cerr << "Throwing Error: "<< message <<  endl;
        return;
    }


    /* Creating and designing a dummy tetris board to write to file */
    vector<vector<char>> DummyTetrisBoard(boardRow+2, vector<char>(boardCol+2));
    int k=0;
    int numOfMoves = numberOfMoves();
    char c;
    
    /* Handling exception by throwing error message */
    try {
        if(numOfMoves == 0) throw ("There is no succesfull move made on tetris board therefore there is nothing to write to file...");
    }

    catch(const char* message) {
        std::cerr << "Throwing Error: "<< message <<  endl;
        write_file.close();
        return;
    }


    /* Designing dummy tetris board to write to file */
    for(auto i=0; i<boardRow+2; i++){
        for(auto j=0; j<boardCol+2; j++){

            if(i == (boardRow+1)) DummyTetrisBoard[i][j] = '#';
            else if(i == 0) DummyTetrisBoard[i][j] = '#';
            else if(j == 0 || j == (boardCol+1)) DummyTetrisBoard[i][j] = '#';
            else DummyTetrisBoard[i][j] = ' ';
        }
    }
    

    /* Arranging writing file details */
    for(auto i=0; i<MoveInd; i++) {
        
        if(AllMoves[i].TetroType == Tetrominos::I) c = 'I';
        else if(AllMoves[i].TetroType == Tetrominos::O) c = 'O';
        else if(AllMoves[i].TetroType == Tetrominos::T) c = 'T' ;
        else if(AllMoves[i].TetroType == Tetrominos::J) c = 'J' ;
        else if(AllMoves[i].TetroType == Tetrominos::L) c = 'L' ;
        else if(AllMoves[i].TetroType == Tetrominos::S) c = 'S' ;
        else if(AllMoves[i].TetroType == Tetrominos::Z) c = 'Z' ;

        
        if((AllMoves[i].move_type != ROTATED && AllMoves[i-1].move_type == ROTATED)) {k++;}

        else if(!(AllMoves[i].move_type == ROTATED && AllMoves[i-1].move_type == ROTATED) || i == 0) {
           
        
            if(i+1-k == (numOfMoves+1) && QuitWay != "choice") write_file << "UNSUCCESSFUL MOVE ATTEMPT";
            else write_file << i+1-k << "." << "Move ";
            write_file << endl;
            write_file << "Tetromino " ;

            write_file << c << " ";
        }

        else k++;
       
        /* Arranging writing details */
        if(AllMoves[i].move_type == ADDED) write_file << "ADDED ";
        else if(AllMoves[i].move_type == ROTATED) write_file << "ROTATED ";
        else if(AllMoves[i].move_type == MOVED) write_file << "MOVED ";
        else if(AllMoves[i].move_type == DROPPED) write_file << "DROPPED ";

       
        if(AllMoves[i].direction_type == DOWN) write_file << "TO THE DOWN ";
        else if(AllMoves[i].direction_type == LEFT) write_file << "TO THE LEFT ";
        else if(AllMoves[i].direction_type == UP) write_file << "TO THE UP ";
        else if(AllMoves[i].direction_type == RIGHT) write_file << "TO THE RIGHT ";

       
        write_file << AllMoves[i].howManyTimes << " TIMES ";

        if(AllMoves[i].move_type == ROTATED) {
            continue;
        }


        /* Printing current coordinates of tetromino */
        write_file << endl << "Current coordinates on Tetris Board: {" ;
        for(auto j=0; j<4; j++) {
            write_file << "(" << AllMoves[i].currIndBlocksOnBoard[j][0] << "," << AllMoves[i].currIndBlocksOnBoard[j][1] << ")";
            if(j != 3) write_file << ",";
        }
        write_file << "}" << endl;


        if(i != 0) {
            if(!(AllMoves[i-1].move_type == DROPPED)) {
                for(auto m=0; m<4; m++) {
                    if(DummyTetrisBoard[AllMoves[i-1].currIndBlocksOnBoard[m][0]][AllMoves[i-1].currIndBlocksOnBoard[m][1]] != '#'){
                        DummyTetrisBoard[AllMoves[i-1].currIndBlocksOnBoard[m][0]][AllMoves[i-1].currIndBlocksOnBoard[m][1]] = ' ';
                    }
                    
                }
            }
        }
        

       
        for(auto m=0; m<4; m++) {
            DummyTetrisBoard[AllMoves[i].currIndBlocksOnBoard[m][0]][AllMoves[i].currIndBlocksOnBoard[m][1]] = c;
        }


        for(auto i=0; i<boardRow+2; i++){
            for(auto j=0; j<boardCol+2; j++) {
                write_file << DummyTetrisBoard[i][j] ;
            }
            write_file << endl;
        }

        write_file << endl<< endl;
       
       
    }
    write_file << endl;

    write_file.close(); /* Closing file */
}


/* Interacting with player by getting input from user and showing results to her */
void AbstractTetris::InteractWithUser() {

    Tetromino TetrObj;
    bool quit = false;
    char type;
    int move_size = 0;
    int rotating_times = 0;


    int temp1[4][2];
   
    /* Drawing tetris board */
    cout << "Tetris board:" << endl; 
    MyVector[0]->draw();

    /* Keep playing game */
    while(quit == false) {
       
        move_size += 10;
        change = 'Y';
        adding_success = true;

       
        cout << "What is the tetromino type? (I - O - T - J - L - S - Z - R - Q(to quit)) " << endl;
        cin >> type;

         /* Validating input */
        if((cin.get() != '\n') || (cin.fail() == 1)) {
            cin.clear();
            cin.ignore(MaxIntVal,'\n');
            cout << "Unvalid input" << endl;  
            continue;
        }

        /* Quitting */
        if(type == 'Q') {
            cout << endl << "Quitting..." <<  endl;
            quit = true;
            QuitWay = "choice";
            return;
        }

        /* Choosing a random tetrmino */
        else if(type == 'R') {
            int value = rand()%7;
            TetrObj.current_tetromino = static_cast<Tetrominos>(value);

            if(value == 0) type = 'I';
            else if(value == 1) type = 'O';
            else if(value == 2) type = 'T';
            else if(value == 3) type = 'J';
            else if(value == 4) type = 'L';
            else if(value == 5) type = 'S';
            else if(value == 6) type = 'Z';


        }

        /* Assigning char value according to tetromino type */
        else if(type == 'I') TetrObj.current_tetromino  = Tetrominos::I;
        else if(type == 'O') TetrObj.current_tetromino  = Tetrominos::O;
        else if(type == 'T') TetrObj.current_tetromino  = Tetrominos::T;
        else if(type == 'J') TetrObj.current_tetromino = Tetrominos::J;
        else if(type == 'L') TetrObj.current_tetromino  = Tetrominos::L;
        else if(type == 'S') TetrObj.current_tetromino = Tetrominos::S;
        else if(type == 'Z') TetrObj.current_tetromino  = Tetrominos::Z;
       
     
        else {
            cout << "Unvalid input" << endl;
            continue;          
        }

        /* Initially constructing tetromino */
        TetrObj.initially_construct_tetromino();  
        AllMoves[MoveInd].TetroType = TetrObj.current_tetromino;
        change = 'Y';
        TetrObj.current_position = Positions::BOTTOM_POS;
        rotating_times = 0;

        AllMoves.resize(move_size);

  
        for(auto b=0; b<4; b++){
            AllMoves[MoveInd].currIndBlocksOnBoard[b][0] = 0;
            AllMoves[MoveInd].currIndBlocksOnBoard[b][1] = 0;
        }
        
        /* Adding a move */
        AllMoves[MoveInd].move_type = ADDED;
        AllMoves[MoveInd].direction_type = NONE;
        AllMoves[MoveInd].howManyTimes = 0;
     


        do{ 
            /* Adding tetromino to tetris board */
            (*MyVector[0]) += TetrObj;

          
            if(adding_success == true) {
                MyVector[0]->ReflectAddChangeOnBoard(TetrObj); /* Reflecting add change to tetris board */
                cout << "Added tetromino:" << endl;
                MyVector[0]->draw();

                AllMoves[MoveInd].move_type = AbstractTetris::ADDED;
                AllMoves[MoveInd].direction_type = NONE;
                AllMoves[MoveInd].howManyTimes = 1;
                AllMoves[MoveInd].TetroType = TetrObj.current_tetromino;
                MoveInd++;
                break;
            }

           
            /* Handling the case in which adding is not successful */
            else if(adding_success == false) {

                rotating_times++;
                TetrObj.rotate(RIGHT,rotating_times);

                if(rotating_times == 1) TetrObj.current_position = Positions::RIGHT_POS;
                else if(rotating_times == 2) TetrObj.current_position = Positions::UP_POS;
                else if(rotating_times == 3) TetrObj.current_position = Positions::LEFT_POS;
                else if(rotating_times == 4) TetrObj.current_position = Positions::BOTTOM_POS;

                /* Adding a move */
                AllMoves[MoveInd].move_type = AbstractTetris::ROTATED;
                AllMoves[MoveInd].direction_type = RIGHT;
                AllMoves[MoveInd].howManyTimes = 1;
                for(auto z=0; z<4; z++){
                    AllMoves[MoveInd].currIndBlocksOnBoard[z][0] = 0;
                    AllMoves[MoveInd].currIndBlocksOnBoard[z][1] = 0;
                }
        
                AllMoves[MoveInd].TetroType = TetrObj.current_tetromino;
                MoveInd++;

            }
           
        }while(rotating_times < 4 && adding_success == false); /* Trying to add the tetromino in different positions */

        if(adding_success == true) {
           
   
            bool flag = MoveTetromino(type,temp1,rotating_times,TetrObj);
            
            /* Handling the case in which moving is not successful */
            if(flag == false) {
                cout << "Moving the tetromino is not successful" << endl;
                if(QuitWay != "RotateFail") QuitWay = "MoveFail";
                else QuitWay = "RotateFail";
                quit = true;
                break;
            }

         
            flag = animate(TetrObj,rotating_times,temp1,type);

            /* Handling the case in which animating is not successful */
            if(flag == false) {
                cout << "Animation of the tetromino is not successful" << endl;
                QuitWay = "AnimateFail";
                quit = true;
                break;
            }
        }

        /* Handling the case in which adding is not successful */
        else {
            cout << "There is not enough space to add a new tetromino..." << endl;
            QuitWay = "AddFail";
            quit = true;
            break;
        }

    }


    cout << endl << "Quitting..." << endl;
    cout << endl << "----------------------------------------------------------" << endl;

}


/* Adding a tetromino to tetris board */
AbstractTetris* AbstractTetris:: operator+=( Tetromino &TetroObj) {

    int width_of_tetromino;
    bool first_block_found = false;
    int i,j,board_x, board_y;
    int biggest_b=0, least_b=0;
    int a,b;

    /* Looking for the first block starting from the top */
    for(i=0; i<4 && first_block_found == false ; i++){
        for(j=0; j<4 && first_block_found == false; j++){
            if(TetroObj.my_tetromino[i][j] != ' ') {
   
                first_block_found = true;
                break;
            }
        }
       
        if(first_block_found == true) break;
    }
   
    first_block_found = false;


    for(a=0; a<4 ; a++){
        for(b=0; b<4 ; b++){
            if(TetroObj.my_tetromino[a][b] != ' ') {
     
                if(first_block_found==false) {
                    first_block_found = true;
                    least_b = b;
                    biggest_b = b;
                }  
               
                else {
                    if(b < least_b) {
                        least_b = b;
                    }
                   
                    if(b > biggest_b) {
                        biggest_b = b;
                    }
                }
             
            }
        }
    }


    /* Checking whether adding is going to be successful or not */
    adding_success = true;
    width_of_tetromino = biggest_b - least_b + 1;
   
    board_x = 1;
    board_y = (boardCol - width_of_tetromino )/2 + 1;
 
    for(auto m=i; m<4 && adding_success == true; m++){
       
        board_y = (boardCol - width_of_tetromino)/2 + 1;
        for(j=0; j<width_of_tetromino && adding_success == true; j++) {
            if(TetroObj.my_tetromino[m][j] !=' ') {
                if(!(MyVector[0]->isBoardAvailable(board_x,board_y,' '))) {
                    adding_success = false;
                    break;
                }
               
            }

            board_y++; /* Incrementing the tetris board's column value */
        }
        board_x++; /* Incrementing the tetris board's row value */
    }
   
    board_x = 1;

    /* Finding the indexes of blocks of a tetromino */
    int ind_tet = 0, ind_board = 0;
    for(auto m=i; m<4; m++){
       
        board_y = (boardCol - width_of_tetromino)/2 + 1;
        for(j=0; j<width_of_tetromino; j++){
           
            if(TetroObj.my_tetromino[m][j] !=' '){
               
                /* The char 'Y' indicates that indexes of the tetromino is going to be found and be written on the tetris board */
                if(change == 'Y' && adding_success == true) {
                    TetroObj.currIndBlocksOnTetro[ind_tet][0] = m;
                    TetroObj.currIndBlocksOnTetro[ind_tet][1] = j;
                    ind_tet++;
                }

                AllMoves[MoveInd].currIndBlocksOnBoard[ind_board][0] = board_x;
                AllMoves[MoveInd].currIndBlocksOnBoard[ind_board][1] = board_y;
                ind_board++;
            }
         
            board_y++; /* Incrementing the tetris board's column value */
        }
        board_x++; /* Incrementing the tetris board's row value */
    }

    
    return (MyVector[0]);
}


/* Rotating tetromino as desired and moving it to the desired location */
bool AbstractTetris:: MoveTetromino(char c, int temp1[][2], int rotating_times, Tetromino &obj) {
    int rotation_count, move_count;
    int move_direction, rotation_direction;
    bool flag = false;

    /* Keeping the indexes of tetromino's blocks just after having added to the tetris board */
    for(auto i=0; i<4; i++){
        temp1[i][0] = AllMoves[MoveInd-1].currIndBlocksOnBoard[i][0];
        temp1[i][1] = AllMoves[MoveInd-1].currIndBlocksOnBoard[i][1];
    }

   
    /* Getting and validating user input */
    do{
        cout << "Enter rotation direction (enter 0 for left, enter 1 for right): ";
        flag = Validate_input(rotation_direction);
       
        if(rotation_direction != 0 && rotation_direction != 1 && flag == true) {
           cout << "Unvalid input" << endl;
           flag = false;
        }

    }while(flag == false);


    /* Getting and validating user input */
    do{
        cout << "Enter rotation count: ";
        flag = Validate_input(rotation_count);
       
        if(rotation_count<0 && flag == true) {
           cout << "Unvalid input" << endl;
           flag = false;
        }
       
    }while(flag == false);


    /* Getting and validating user input */
    do{
        cout << "Enter move direction (enter 0 for left, enter 1 for right, enter 2 for up, enter 3 for down): ";
        flag = Validate_input(move_direction);
       
        if((move_direction<0 || move_direction>3) && flag == true) {
           cout << "Unvalid input" << endl;
           flag = false;
        }
       
    }while(flag == false);


    /* Getting and validating user input */
    do{
        cout << "Enter move count: "; //valid input kontrol et
        flag = Validate_input(move_count);
       
        if(move_count<0 && flag == true) {
           cout << "Unvalid input" << endl;
           flag = false;
        }
       
    }while(flag == false);

   
    /* Counting how many times the tetromino has been rotated so far and deciding to which direction it has been rotated */
    int send;
    Directions send_direct;

    /* Handling the case if the desired rotation direction is to the right */
    if(rotation_direction== 1) {
        send = rotation_count + rotating_times;
        rotation_direction = 1;
        send_direct = RIGHT;
    }

    /* Handling the case if the desired rotation direction is to the left */
    else if(rotation_direction == 0){
        if(rotating_times - rotation_count >= 0) {
            send = rotating_times - rotation_count;
            rotation_direction = 1;
            send_direct = RIGHT;
        }

        else {
            send = rotation_count - rotating_times;
            rotation_direction = 0;
            send_direct = LEFT;
        }
    }
   
    obj.rotate(send_direct,send); /* Rotating the tetromino */


    MyVector[0]->AllMoves[MoveInd].move_type = AbstractTetris::ROTATED;
    MyVector[0]->AllMoves[MoveInd].direction_type = send_direct;
    MyVector[0]->AllMoves[MoveInd].howManyTimes = send;

    for(auto b=0; b<4; b++){
        MyVector[0]->AllMoves[MoveInd].currIndBlocksOnBoard[b][0] = MyVector[0]->AllMoves[MoveInd-1].currIndBlocksOnBoard[b][0];
        MyVector[0]->AllMoves[MoveInd].currIndBlocksOnBoard[b][1] = MyVector[0]->AllMoves[MoveInd-1].currIndBlocksOnBoard[b][1];
    }
        
 

    AllMoves[MoveInd].TetroType = AllMoves[MoveInd-1].TetroType;
    AllMoves[MoveInd+1].TetroType = AllMoves[MoveInd].TetroType;
    MoveInd++;



    change = 'N'; /* Indicating operator+= function will not cause any change on tetris board */
    MyVector[0]->operator+=(obj); /* Adding tetromino to the board */
    if(adding_success == false) QuitWay = "RotateFail";

    //CHECKING CURR INDEXES ON BOARD VALIDITY ASSIGN ROTATEFAIL ACCORDING TO IT
   
    /* Moving the blocks of tetromino to the desired location */
    for(auto j=0; j<move_count; j++){ //AllMoves[MoveInd].currIndBlocksOnBoard[i][0]
        for(auto i=0; i<4; i++) {
            if(move_direction == 1) (AllMoves[MoveInd].currIndBlocksOnBoard[i][1])++;
            else if(move_direction == 0) (AllMoves[MoveInd].currIndBlocksOnBoard[i][1])--;
            else if(move_direction == 2) (AllMoves[MoveInd].currIndBlocksOnBoard[i][0])--;
            else if(move_direction == 3) (AllMoves[MoveInd].currIndBlocksOnBoard[i][0])++;
        }
    }
   
   
    /* Checking whether the places of blocks are available or not */
    for(auto i=0; i<4; i++){
        if(AllMoves[MoveInd].currIndBlocksOnBoard[i][0]<=0 || AllMoves[MoveInd].currIndBlocksOnBoard[i][0]>boardRow) return false;

        else if(AllMoves[MoveInd].currIndBlocksOnBoard[i][1]<=0 || AllMoves[MoveInd].currIndBlocksOnBoard[i][1]>boardCol) return false;
       
        else if(!(MyVector[0]->isBoardAvailable(AllMoves[MoveInd].currIndBlocksOnBoard[i][0], AllMoves[MoveInd].currIndBlocksOnBoard[i][1], ' '))) {
            bool found = false;
            for(auto k=0; k<4 && found == false; k++) {
                if((AllMoves[MoveInd].currIndBlocksOnBoard[i][0] == temp1[k][0]) && (AllMoves[MoveInd].currIndBlocksOnBoard[i][1] == temp1[k][1])) {
                    found = true;
                    break;
                }
            }
           
            if(found == false) return false;

        }
    }
   
    MyVector[0]->ReflectMoveChangeOnBoard(c,temp1);
    MyVector[0]->AllMoves[MoveInd].move_type = AbstractTetris::MOVED;

    if(move_direction == 0) MyVector[0]->AllMoves[MoveInd].direction_type = LEFT;
    else if(move_direction == 1) MyVector[0]->AllMoves[MoveInd].direction_type = RIGHT;
    else if(move_direction == 2) MyVector[0]->AllMoves[MoveInd].direction_type = UP;
    else if(move_direction == 3) MyVector[0]->AllMoves[MoveInd].direction_type = DOWN;

    MyVector[0]->AllMoves[MoveInd].howManyTimes = move_count;
    MoveInd++;

   
    cout << "\x1B[2J";   /* Cleaning terminal */
    cout << "Tetris board with the rotated and moved tetromino:" << endl;
    MyVector[0]->draw(); /* Drawing tetris board */


    return true;
}


/* Validating input */
bool AbstractTetris::Validate_input(int& input) {

    cin >> input;

    if((cin.get() != '\n') || (cin.fail() == 1)) {
        cin.clear();
        cin.ignore(MaxIntVal,'\n');
        cout << "Unvalid input" << endl;  
        return false;
    }

    return true;
}



