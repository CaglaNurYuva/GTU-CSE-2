#include "AbstractTetris.hpp"
#include "TetrisArray1D.hpp"
#include "TetrisVector.hpp"
#include "TetrisAdaptor.hpp"
#include "tetromino.hpp"
#include "TetrisAdaptor.cpp"



int main() {
    string TypeOfBoard;
    bool checkValidity = false;
    int board_row, board_col;

    srand(time(NULL));

   /* Validating input */
    while(checkValidity == false) {
        cout << endl << "Enter the row of tetris board: ";
        cin >> board_row;

        if((cin.get() != '\n') || (cin.fail() == 1)) {
            cin.clear();
            cin.ignore(MaxIntVal,'\n');
            cout << "Unvalid input" << endl;  
            continue;
        }

        else if(board_row <= 0) {
            cout << "Unvalid input" << endl;  
            continue;
        }

        else checkValidity = true;
    }

 
    checkValidity = false;
    
    /* Validating input */	
    while(checkValidity == false) {
        cout << endl << "Enter the column of tetris board: ";
        cin >> board_col;

        if((cin.get() != '\n') || (cin.fail() == 1)) {
            cin.clear();
            cin.ignore(MaxIntVal,'\n');
            cout << "Unvalid input" << endl;  
            continue;
        }

        else if(board_col <= 0) {
            cout << "Unvalid input" << endl;  
            continue;
        }

        else checkValidity = true;
    }

 
    checkValidity = false;

    /* Getting tetris board type from user as input */	
    while(checkValidity == false) {

        checkValidity = true;
        cout << endl << "Enter the type of tetris board (V for vector, 1 for array1D, A for adaptor): " ;
        getline(cin,TypeOfBoard);
	
	/* Choosing desired tetris board */
        if(TypeOfBoard == "V") {
            vector<vector<char>> TetrisBoard(board_row+2, vector<char>(board_col+2));
            vector<vector<char>> *BoardPtr = &TetrisBoard;

            TetrisVector GameObj(board_row,board_col);
            PlayGame<vector<vector<char>>*, TetrisVector>(BoardPtr, GameObj);  /* Playing game */

        }


        else if(TypeOfBoard == "1") {
            char* TetrisBoard = new char[(board_row+2)*(board_col+2)];
            char* BoardPtr = TetrisBoard;

            TetrisArray1D GameObj(board_row,board_col);
            PlayGame<char*, TetrisArray1D>(BoardPtr,GameObj);  /* Playing game */
            delete[] TetrisBoard;
         
        }

        else if(TypeOfBoard == "A") {

            int input;
            checkValidity = false;

            while(checkValidity == false) {
                cout << endl << "   1. Vector" << endl;
                cout << "   2. Deque" << endl;
                cout << "Enter 1 or 2 to choose which class you want to use as a parameter for TetrisAdapter class: ";
                cin >> input;
		
		/* Validating input */
                if((cin.get() != '\n') || (cin.fail() == 1)) {
                    cin.clear();
                    cin.ignore(MaxIntVal,'\n');
                    cout << "Unvalid input" << endl;  
                    continue;
                }

                if(input != 1 && input != 2) {
                    cout << "Unvalid input" << endl;
                    continue;
                }

                else {
                    checkValidity = true;

                    if(input == 1) {
                        vector<char> TetrisBoard((board_row+2)*(board_col+2));
                        vector<char>* BoardPtr = &TetrisBoard;

                        TetrisAdapter<vector<char>> GameObj(board_row,board_col);
                        PlayGame<vector<char>*, TetrisAdapter<vector<char>>>(BoardPtr,GameObj);  /* Playing game */
                       
                    }

                    else if(input == 2) {
                        deque<char> TetrisBoard((board_row+2)*(board_col+2));
                        deque<char>* BoardPtr = &TetrisBoard;

                        TetrisAdapter<deque<char>> GameObj(board_row,board_col);
                        PlayGame<deque<char>*, TetrisAdapter<deque<char>>>(BoardPtr,GameObj);  /* Playing game */
                    }

                }
            }
           
        }

        else {
            cout << "You did not enter a valid type." << endl;
            checkValidity = false;
        }

    }
   
    return 0;
}





