#include "TetrisArray1D.hpp"





/* Creating and designing tetris board */
void TetrisArray1D:: CreateTetrisBoard(char* MyTetrisBoard) {  
    TetrisBoard = MyTetrisBoard;
   
    for(auto i=0; i<boardRow+2; i++){
        for(auto j=0; j<boardCol+2; j++){

            if(i == (boardRow+1)) TetrisBoard[i*(boardCol+2) + j] = '#';
            else if(i == 0) TetrisBoard[i*(boardCol+2) + j] = '#';
            else if(j == 0 || j == (boardCol+1)) TetrisBoard[i*(boardCol+2) + j] = '#';
            else TetrisBoard[i*(boardCol+2) + j] = ' ';
        }
    }
}


/* Drawing tetris board */
void TetrisArray1D:: draw() const { // +

    cout << endl;

    for (auto i=0; i < boardRow + 2; i++) {
        for (auto j = 0; j < boardCol + 2; j++) {
            cout << TetrisBoard[i * (boardCol+2) + j];
        }
        cout << endl;
    }
   
    cout << endl;

}


/* Checking whether the particular location is available */
bool TetrisArray1D:: isBoardAvailable(const int row, const int col,const char value) const {

    /* Checking bounds */         
    if(row<=0 || row>boardRow) {
        return false;
       
    }
                           
    if(col<=0 || col>boardCol) {
        return false;                  
    }

    if(TetrisBoard[row*(boardCol+2) + col] != value) {
        return false;
    }

    return true;
}


/* Reflecting change made by MoveTetromino function on tetris board */
void TetrisArray1D:: ReflectMoveChangeOnBoard(const char c, const int temp1[][2]) {
    for(auto i=0; i<4; i++) {
        if(TetrisBoard[(temp1[i][0])*(boardCol+2) + (temp1[i][1])] != '#') {
            TetrisBoard[(temp1[i][0])*(boardCol+2) + (temp1[i][1])] = ' '; 
        }
    }

    for(auto i=0; i<4; i++) {
        if(TetrisBoard[AllMoves[MoveInd].currIndBlocksOnBoard[i][0]*(boardCol+2) + AllMoves[MoveInd].currIndBlocksOnBoard[i][1]] != '#'){
            TetrisBoard[AllMoves[MoveInd].currIndBlocksOnBoard[i][0]*(boardCol+2) + AllMoves[MoveInd].currIndBlocksOnBoard[i][1]] = c;
        }
    }
}


/* Reflecting change made by operator+= function on tetris board */
void TetrisArray1D::ReflectAddChangeOnBoard(const Tetromino &obj) {
 
    int board_x, board_y, tetro_x, tetro_y;
    for(auto i=0; i<4; i++) {
        board_x = AllMoves[MoveInd].currIndBlocksOnBoard[i][0];
        board_y = AllMoves[MoveInd].currIndBlocksOnBoard[i][1];
        tetro_x = obj.currIndBlocksOnTetro[i][0];
        tetro_y = obj.currIndBlocksOnTetro[i][1];

        TetrisBoard[board_x*(boardCol+2) + board_y] = obj.my_tetromino[tetro_x][tetro_y];
   
    }

}


/* Reflecting change made by animate function on tetris board */
void TetrisArray1D:: ReflectAnimateChangeOnBoard(const char c) {
    for(auto i=0; i<4; i++) {
        if(TetrisBoard[AllMoves[MoveInd].currIndBlocksOnBoard[i][0]*(boardCol+2) + AllMoves[MoveInd].currIndBlocksOnBoard[i][1]] != '#') {
            TetrisBoard[AllMoves[MoveInd].currIndBlocksOnBoard[i][0]*(boardCol+2) + AllMoves[MoveInd].currIndBlocksOnBoard[i][1]] = ' '; 
        }
        (AllMoves[MoveInd].currIndBlocksOnBoard[i][0])++ ;
    }

    for(auto i=0; i<4; i++) {
        if(TetrisBoard[AllMoves[MoveInd].currIndBlocksOnBoard[i][0]*(boardCol+2) + AllMoves[MoveInd].currIndBlocksOnBoard[i][1]] != '#') {
            TetrisBoard[AllMoves[MoveInd].currIndBlocksOnBoard[i][0]*(boardCol+2) + AllMoves[MoveInd].currIndBlocksOnBoard[i][1]] = c;
        }
    }

}




