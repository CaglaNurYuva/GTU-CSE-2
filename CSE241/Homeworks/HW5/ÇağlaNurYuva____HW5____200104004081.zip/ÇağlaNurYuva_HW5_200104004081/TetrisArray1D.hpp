#ifndef TETRIS_ARRAY_1D_HPP
#define TETRIS_ARRAY_1D_HPP

#include "AbstractTetris.hpp"

namespace MyGame3 {


    /* TetrisArray1D class */
    class TetrisArray1D : public AbstractTetris {
        public:
     
            void CreateTetrisBoard(char* MyTetrisBoard); /* Creating tetris board */
            TetrisArray1D(const int row_, const int col_) : AbstractTetris(row_,col_) { MyVector.push_back(this); } /* TetrisArray1D class constructor */

            void draw() const override ; /* Drawing tetris board */
            bool isBoardAvailable(const int row, const int col, const char value) const override ; /* Checking whether the particular location is available */
            void ReflectAddChangeOnBoard(const Tetromino &obj) override; /* Reflecting change made by operator+= function on tetris board */
            void ReflectMoveChangeOnBoard(const char c, const int temp1[][2]) override ; /* Reflecting change made by MoveTetromino function on tetris board */
            void ReflectAnimateChangeOnBoard(const char c) override; /* Reflecting change made by animate function on tetris board */
            ~TetrisArray1D() {/**/} /* TetrisArray1D class destructor */
     

        private:
            char* TetrisBoard;  /* Keeps Tetris board */
   
    };


}


using namespace MyGame3;
#endif
