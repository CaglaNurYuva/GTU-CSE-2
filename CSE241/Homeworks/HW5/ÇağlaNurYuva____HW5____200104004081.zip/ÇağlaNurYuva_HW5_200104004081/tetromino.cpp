#include "tetromino.hpp"
#include "AbstractTetris.hpp"



/* Constructing a tetromino initially which is in bottom position */
void Tetromino:: initially_construct_tetromino() {
    int row,col;

    /* Cleaning old values kept in my_tetromino array */   
    for(row=0; row<4; row++) {
        for(col=0; col<4; col++) {
            my_tetromino[row][col] = ' ';
        }
        my_tetromino[row][col] = '\0';      
    }
       
    /* Initializing my_tetromino array by checking its type */
    if(current_tetromino == Tetrominos::I){
        my_tetromino[3][0] = 'I'; (*this).currIndBlocksOnTetro[0][0] = 3; (*this).currIndBlocksOnTetro[0][1] = 0;
        my_tetromino[3][1] = 'I'; (*this).currIndBlocksOnTetro[1][0] = 3; (*this).currIndBlocksOnTetro[1][1] = 1;
        my_tetromino[3][2] = 'I'; (*this).currIndBlocksOnTetro[2][0] = 3; (*this).currIndBlocksOnTetro[2][1] = 2;
        my_tetromino[3][3] = 'I'; (*this).currIndBlocksOnTetro[3][0] = 3; (*this).currIndBlocksOnTetro[3][1] = 3;
       

    }


    else if(current_tetromino  == Tetrominos::O){
        my_tetromino[2][0] = 'O'; (*this).currIndBlocksOnTetro[0][0] = 2; (*this).currIndBlocksOnTetro[0][1] = 0;
        my_tetromino[2][1] = 'O'; (*this).currIndBlocksOnTetro[1][0] = 2; (*this).currIndBlocksOnTetro[1][1] = 1;
        my_tetromino[3][0] = 'O'; (*this).currIndBlocksOnTetro[2][0] = 3; (*this).currIndBlocksOnTetro[2][1] = 0;
        my_tetromino[3][1] = 'O'; (*this).currIndBlocksOnTetro[3][0] = 3; (*this).currIndBlocksOnTetro[3][1] = 1;
       
    }

 
    else if(current_tetromino  == Tetrominos::T){
        my_tetromino[2][0] = 'T'; (*this).currIndBlocksOnTetro[0][0] = 2; (*this).currIndBlocksOnTetro[0][1] = 0;
        my_tetromino[2][1] = 'T'; (*this).currIndBlocksOnTetro[1][0] = 2; (*this).currIndBlocksOnTetro[1][1] = 1;
        my_tetromino[2][2] = 'T'; (*this).currIndBlocksOnTetro[2][0] = 2; (*this).currIndBlocksOnTetro[2][1] = 2;
        my_tetromino[3][1] = 'T'; (*this).currIndBlocksOnTetro[3][0] = 3; (*this).currIndBlocksOnTetro[3][1] = 1;

    }


    else if(current_tetromino == Tetrominos::J){
        my_tetromino[1][1] = 'J'; (*this).currIndBlocksOnTetro[0][0] = 1; (*this).currIndBlocksOnTetro[0][1] = 1;
        my_tetromino[2][1] = 'J'; (*this).currIndBlocksOnTetro[1][0] = 2; (*this).currIndBlocksOnTetro[1][1] = 1;
        my_tetromino[3][0] = 'J'; (*this).currIndBlocksOnTetro[2][0] = 3; (*this).currIndBlocksOnTetro[2][1] = 0;
        my_tetromino[3][1] = 'J'; (*this).currIndBlocksOnTetro[3][0] = 3; (*this).currIndBlocksOnTetro[3][1] = 1;

    }


    else if(current_tetromino  == Tetrominos::L){
        my_tetromino[1][0] = 'L'; (*this).currIndBlocksOnTetro[0][0] = 1; (*this).currIndBlocksOnTetro[0][1] = 0;
        my_tetromino[2][0] = 'L'; (*this).currIndBlocksOnTetro[1][0] = 2; (*this).currIndBlocksOnTetro[1][1] = 0;
        my_tetromino[3][0] = 'L'; (*this).currIndBlocksOnTetro[2][0] = 3; (*this).currIndBlocksOnTetro[2][1] = 0;
        my_tetromino[3][1] = 'L'; (*this).currIndBlocksOnTetro[3][0] = 3; (*this).currIndBlocksOnTetro[3][1] = 1;

    }


    else if(current_tetromino  == Tetrominos::S){
        my_tetromino[2][1] = 'S'; (*this).currIndBlocksOnTetro[0][0] = 2; (*this).currIndBlocksOnTetro[0][1] = 1;
        my_tetromino[2][2] = 'S'; (*this).currIndBlocksOnTetro[1][0] = 2; (*this).currIndBlocksOnTetro[1][1] = 2;
        my_tetromino[3][0] = 'S'; (*this).currIndBlocksOnTetro[2][0] = 3; (*this).currIndBlocksOnTetro[2][1] = 0;
        my_tetromino[3][1] = 'S'; (*this).currIndBlocksOnTetro[3][0] = 3; (*this).currIndBlocksOnTetro[3][1] = 1;

    }

 
    else if(current_tetromino  == Tetrominos::Z){
        my_tetromino[2][0] = 'Z'; (*this).currIndBlocksOnTetro[0][0] = 2; (*this).currIndBlocksOnTetro[0][1] = 0;
        my_tetromino[2][1] = 'Z'; (*this).currIndBlocksOnTetro[1][0] = 2; (*this).currIndBlocksOnTetro[1][1] = 1;
        my_tetromino[3][1] = 'Z'; (*this).currIndBlocksOnTetro[2][0] = 3; (*this).currIndBlocksOnTetro[2][1] = 1;
        my_tetromino[3][2] = 'Z'; (*this).currIndBlocksOnTetro[3][0] = 3; (*this).currIndBlocksOnTetro[3][1] = 2;
       
    }

}


/* Rotating tetromino */
void Tetromino:: rotate(Directions const rotation_direction, const int rotation_count) {
    int precise_rotate_count = rotation_count % 4;
    int row,col;

    /* Cleaning old values kept in my_tetromino array */
    for(row=0; row<4; row++) {
        for(col=0; col<4; col++) {
            my_tetromino[row][col] = ' ';
        }
        my_tetromino[row][col] = '\0';
       
    }
   
   

    /* Handling the case there is no rotating happening */
    if(precise_rotate_count == 0) {
        (*this).initially_construct_tetromino();
        return;
    }

   
    /* Rotating the tetromino by checking its type, how many times it will be rotated and to which direction it will be rotated */
    if(current_tetromino == Tetrominos::I){
       
        if(precise_rotate_count == 1 ||  precise_rotate_count == 3) {
            my_tetromino[0][0] = 'I';
            my_tetromino[1][0] = 'I';
            my_tetromino[2][0] = 'I';
            my_tetromino[3][0] = 'I';
            (*this).currIndBlocksOnTetro[0][0] = 0; (*this).currIndBlocksOnTetro[0][1] = 0;
            (*this).currIndBlocksOnTetro[1][0] = 1; (*this).currIndBlocksOnTetro[1][1] = 0;
            (*this).currIndBlocksOnTetro[2][0] = 2; (*this).currIndBlocksOnTetro[2][1] = 0;
            (*this).currIndBlocksOnTetro[3][0] = 3; (*this).currIndBlocksOnTetro[3][1] = 0;
            current_position = RIGHT_POS;
        }      

        else if(precise_rotate_count == 2) {
            my_tetromino[3][0] = 'I';
            my_tetromino[3][1] = 'I';
            my_tetromino[3][2] = 'I';
            my_tetromino[3][3] = 'I';
            (*this).currIndBlocksOnTetro[0][0] = 3; (*this).currIndBlocksOnTetro[0][1] = 0;
            (*this).currIndBlocksOnTetro[1][0] = 3; (*this).currIndBlocksOnTetro[1][1] = 1;
            (*this).currIndBlocksOnTetro[2][0] = 3; (*this).currIndBlocksOnTetro[2][1] = 2;
            (*this).currIndBlocksOnTetro[3][0] = 3; (*this).currIndBlocksOnTetro[3][1] = 3;

            current_position = BOTTOM_POS;
        }
   
    }

 
    else if(current_tetromino == Tetrominos::O){
        my_tetromino[2][0] = 'O';
        my_tetromino[2][1] = 'O';
        my_tetromino[3][0] = 'O';
        my_tetromino[3][1] = 'O';
        (*this).currIndBlocksOnTetro[0][0] = 2; (*this).currIndBlocksOnTetro[0][1] = 0;
        (*this).currIndBlocksOnTetro[1][0] = 2; (*this).currIndBlocksOnTetro[1][1] = 1;
        (*this).currIndBlocksOnTetro[2][0] = 3; (*this).currIndBlocksOnTetro[2][1] = 0;
        (*this).currIndBlocksOnTetro[3][0] = 3; (*this).currIndBlocksOnTetro[3][1] = 1;
        current_position = BOTTOM_POS;
    }

 
    else if(current_tetromino == Tetrominos::T){

        if(precise_rotate_count == 2) {
            my_tetromino[2][1] = 'T';
            my_tetromino[3][0] = 'T';
            my_tetromino[3][1] = 'T';
            my_tetromino[3][2] = 'T';
            (*this).currIndBlocksOnTetro[0][0] = 2; (*this).currIndBlocksOnTetro[0][1] = 1;
            (*this).currIndBlocksOnTetro[1][0] = 3; (*this).currIndBlocksOnTetro[1][1] = 0;
            (*this).currIndBlocksOnTetro[2][0] = 3; (*this).currIndBlocksOnTetro[2][1] = 1;
            (*this).currIndBlocksOnTetro[3][0] = 3; (*this).currIndBlocksOnTetro[3][1] = 2;
            current_position = UP_POS;
        }

        else {
            if(precise_rotate_count == 1) {
                if(rotation_direction == RIGHT) {
                    my_tetromino[1][1] = 'T';
                    my_tetromino[2][0] = 'T';
                    my_tetromino[2][1] = 'T';
                    my_tetromino[3][1] = 'T';
                    (*this).currIndBlocksOnTetro[0][0] = 1; (*this).currIndBlocksOnTetro[0][1] = 1;
                    (*this).currIndBlocksOnTetro[1][0] = 2; (*this).currIndBlocksOnTetro[1][1] = 0;
                    (*this).currIndBlocksOnTetro[2][0] = 2; (*this).currIndBlocksOnTetro[2][1] = 1;
                    (*this).currIndBlocksOnTetro[3][0] = 3; (*this).currIndBlocksOnTetro[3][1] = 1;
                    current_position = RIGHT_POS;
                }

                else if(rotation_direction == LEFT) {
                    my_tetromino[1][0] = 'T';
                    my_tetromino[2][0] = 'T';
                    my_tetromino[2][1] = 'T';
                    my_tetromino[3][0] = 'T';
                    (*this).currIndBlocksOnTetro[0][0] = 1; (*this).currIndBlocksOnTetro[0][1] = 0;
                    (*this).currIndBlocksOnTetro[1][0] = 2; (*this).currIndBlocksOnTetro[1][1] = 0;
                    (*this).currIndBlocksOnTetro[2][0] = 2; (*this).currIndBlocksOnTetro[2][1] = 1;
                    (*this).currIndBlocksOnTetro[3][0] = 3; (*this).currIndBlocksOnTetro[3][1] = 0;
                    current_position = LEFT_POS;
                }
            }

            else if(precise_rotate_count == 3) {
                if(rotation_direction == RIGHT) {
                    my_tetromino[1][0] = 'T';
                    my_tetromino[2][0] = 'T';
                    my_tetromino[2][1] = 'T';
                    my_tetromino[3][0] = 'T';
                    (*this).currIndBlocksOnTetro[0][0] = 1; (*this).currIndBlocksOnTetro[0][1] = 0;
                    (*this).currIndBlocksOnTetro[1][0] = 2; (*this).currIndBlocksOnTetro[1][1] = 0;
                    (*this).currIndBlocksOnTetro[2][0] = 2; (*this).currIndBlocksOnTetro[2][1] = 1;
                    (*this).currIndBlocksOnTetro[3][0] = 3; (*this).currIndBlocksOnTetro[3][1] = 0;
                    current_position = LEFT_POS;
                }

                else if(rotation_direction == LEFT) {
                    my_tetromino[1][1] = 'T';
                    my_tetromino[2][0] = 'T';
                    my_tetromino[2][1] = 'T';
                    my_tetromino[3][1] = 'T';
                    (*this).currIndBlocksOnTetro[0][0] = 1; (*this).currIndBlocksOnTetro[0][1] = 1;
                    (*this).currIndBlocksOnTetro[1][0] = 2; (*this).currIndBlocksOnTetro[1][1] = 0;
                    (*this).currIndBlocksOnTetro[2][0] = 2; (*this).currIndBlocksOnTetro[2][1] = 1;
                    (*this).currIndBlocksOnTetro[3][0] = 3; (*this).currIndBlocksOnTetro[3][1] = 1;
                    current_position = RIGHT_POS;  
                }
            }
        }  
    }


    else if(current_tetromino == Tetrominos::J){

        if(precise_rotate_count == 2) {
            my_tetromino[1][0] = 'J';
            my_tetromino[1][1] = 'J';
            my_tetromino[2][0] = 'J';
            my_tetromino[3][0] = 'J';
            (*this).currIndBlocksOnTetro[0][0] = 1; (*this).currIndBlocksOnTetro[0][1] = 0;
            (*this).currIndBlocksOnTetro[1][0] = 1; (*this).currIndBlocksOnTetro[1][1] = 1;
            (*this).currIndBlocksOnTetro[2][0] = 2; (*this).currIndBlocksOnTetro[2][1] = 0;
            (*this).currIndBlocksOnTetro[3][0] = 3; (*this).currIndBlocksOnTetro[3][1] = 0;
            current_position = UP_POS;
        }

        else {
            if(precise_rotate_count == 1) {
                if(rotation_direction == RIGHT) {
                    my_tetromino[2][0] = 'J';
                    my_tetromino[3][0] = 'J';
                    my_tetromino[3][1] = 'J';
                    my_tetromino[3][2] = 'J';
                    (*this).currIndBlocksOnTetro[0][0] = 2; (*this).currIndBlocksOnTetro[0][1] = 0;
                    (*this).currIndBlocksOnTetro[1][0] = 3; (*this).currIndBlocksOnTetro[1][1] = 0;
                    (*this).currIndBlocksOnTetro[2][0] = 3; (*this).currIndBlocksOnTetro[2][1] = 1;
                    (*this).currIndBlocksOnTetro[3][0] = 3; (*this).currIndBlocksOnTetro[3][1] = 2;
                    current_position = RIGHT_POS;
                }

                else if(rotation_direction == LEFT) {
                    my_tetromino[2][0] = 'J';
                    my_tetromino[2][1] = 'J';
                    my_tetromino[2][2] = 'J';
                    my_tetromino[3][2] = 'J';
                    (*this).currIndBlocksOnTetro[0][0] = 2; (*this).currIndBlocksOnTetro[0][1] = 0;
                    (*this).currIndBlocksOnTetro[1][0] = 2; (*this).currIndBlocksOnTetro[1][1] = 1;
                    (*this).currIndBlocksOnTetro[2][0] = 2; (*this).currIndBlocksOnTetro[2][1] = 2;
                    (*this).currIndBlocksOnTetro[3][0] = 3; (*this).currIndBlocksOnTetro[3][1] = 2;
                    current_position = LEFT_POS;  
                }
            }

            else if(precise_rotate_count == 3) {
                if(rotation_direction == RIGHT) {
                    my_tetromino[2][0] = 'J';
                    my_tetromino[2][1] = 'J';
                    my_tetromino[2][2] = 'J';
                    my_tetromino[3][2] = 'J';
                    (*this).currIndBlocksOnTetro[0][0] = 2; (*this).currIndBlocksOnTetro[0][1] = 0;
                    (*this).currIndBlocksOnTetro[1][0] = 2; (*this).currIndBlocksOnTetro[1][1] = 1;
                    (*this).currIndBlocksOnTetro[2][0] = 2; (*this).currIndBlocksOnTetro[2][1] = 2;
                    (*this).currIndBlocksOnTetro[3][0] = 3; (*this).currIndBlocksOnTetro[3][1] = 2;
                    current_position = LEFT_POS;
                }

                else if(rotation_direction == LEFT) {
                    my_tetromino[2][0] = 'J';
                    my_tetromino[3][0] = 'J';
                    my_tetromino[3][1] = 'J';
                    my_tetromino[3][2] = 'J';
                    (*this).currIndBlocksOnTetro[0][0] = 2; (*this).currIndBlocksOnTetro[0][1] = 0;
                    (*this).currIndBlocksOnTetro[1][0] = 3; (*this).currIndBlocksOnTetro[1][1] = 0;
                    (*this).currIndBlocksOnTetro[2][0] = 3; (*this).currIndBlocksOnTetro[2][1] = 1;
                    (*this).currIndBlocksOnTetro[3][0] = 3; (*this).currIndBlocksOnTetro[3][1] = 2;
                    current_position = RIGHT_POS;
                }
            }
        }
         
    }

    else if(current_tetromino == Tetrominos::L){

        if(precise_rotate_count == 2) {
            my_tetromino[1][0] = 'L';
            my_tetromino[1][1] = 'L';
            my_tetromino[2][1] = 'L';
            my_tetromino[3][1] = 'L';
            (*this).currIndBlocksOnTetro[0][0] = 1; (*this).currIndBlocksOnTetro[0][1] = 0;
            (*this).currIndBlocksOnTetro[1][0] = 1; (*this).currIndBlocksOnTetro[1][1] = 1;
            (*this).currIndBlocksOnTetro[2][0] = 2; (*this).currIndBlocksOnTetro[2][1] = 1;
            (*this).currIndBlocksOnTetro[3][0] = 3; (*this).currIndBlocksOnTetro[3][1] = 1;
            current_position = UP_POS;
        }

        else {
            if(precise_rotate_count == 1) {
                if(rotation_direction == RIGHT) {
                    my_tetromino[2][0] = 'L';
                    my_tetromino[2][1] = 'L';
                    my_tetromino[2][2] = 'L';
                    my_tetromino[3][0] = 'L';
                    (*this).currIndBlocksOnTetro[0][0] = 2; (*this).currIndBlocksOnTetro[0][1] = 0;
                    (*this).currIndBlocksOnTetro[1][0] = 2; (*this).currIndBlocksOnTetro[1][1] = 1;
                    (*this).currIndBlocksOnTetro[2][0] = 2; (*this).currIndBlocksOnTetro[2][1] = 2;
                    (*this).currIndBlocksOnTetro[3][0] = 3; (*this).currIndBlocksOnTetro[3][1] = 0;
                    current_position = RIGHT_POS;
                }

                else if(rotation_direction == LEFT) {
                    my_tetromino[2][2] = 'L';
                    my_tetromino[3][0] = 'L';
                    my_tetromino[3][1] = 'L';
                    my_tetromino[3][2] = 'L';
                    (*this).currIndBlocksOnTetro[0][0] = 2; (*this).currIndBlocksOnTetro[0][1] = 2;
                    (*this).currIndBlocksOnTetro[1][0] = 3; (*this).currIndBlocksOnTetro[1][1] = 0;
                    (*this).currIndBlocksOnTetro[2][0] = 3; (*this).currIndBlocksOnTetro[2][1] = 1;
                    (*this).currIndBlocksOnTetro[3][0] = 3; (*this).currIndBlocksOnTetro[3][1] = 2;
                    current_position = LEFT_POS;
                }
            }

            else if(precise_rotate_count == 3) {
                if(rotation_direction == RIGHT) {
                    my_tetromino[2][2] = 'L';
                    my_tetromino[3][0] = 'L';
                    my_tetromino[3][1] = 'L';
                    my_tetromino[3][2] = 'L';
                    (*this).currIndBlocksOnTetro[0][0] = 2; (*this).currIndBlocksOnTetro[0][1] = 2;
                    (*this).currIndBlocksOnTetro[1][0] = 3; (*this).currIndBlocksOnTetro[1][1] = 0;
                    (*this).currIndBlocksOnTetro[2][0] = 3; (*this).currIndBlocksOnTetro[2][1] = 1;
                    (*this).currIndBlocksOnTetro[3][0] = 3; (*this).currIndBlocksOnTetro[3][1] = 2;
                    current_position = LEFT_POS;
                }

                else if(rotation_direction == LEFT) {
                    my_tetromino[2][0] = 'L';
                    my_tetromino[2][1] = 'L';
                    my_tetromino[2][2] = 'L';
                    my_tetromino[3][0] = 'L';  
                    (*this).currIndBlocksOnTetro[0][0] = 2; (*this).currIndBlocksOnTetro[0][1] = 0;
                    (*this).currIndBlocksOnTetro[1][0] = 2; (*this).currIndBlocksOnTetro[1][1] = 1;
                    (*this).currIndBlocksOnTetro[2][0] = 2; (*this).currIndBlocksOnTetro[2][1] = 2;
                    (*this).currIndBlocksOnTetro[3][0] = 3; (*this).currIndBlocksOnTetro[3][1] = 0;
                    current_position = RIGHT_POS;
                }
            }
        }
         
    }
     

    else if(current_tetromino == Tetrominos::S){

        if(precise_rotate_count == 2) {
            my_tetromino[2][1] = 'S';
            my_tetromino[2][2] = 'S';
            my_tetromino[3][0] = 'S';
            my_tetromino[3][1] = 'S';
            (*this).currIndBlocksOnTetro[0][0] = 2; (*this).currIndBlocksOnTetro[0][1] = 1;
            (*this).currIndBlocksOnTetro[1][0] = 2; (*this).currIndBlocksOnTetro[1][1] = 2;
            (*this).currIndBlocksOnTetro[2][0] = 3; (*this).currIndBlocksOnTetro[2][1] = 0;
            (*this).currIndBlocksOnTetro[3][0] = 3; (*this).currIndBlocksOnTetro[3][1] = 1;  
            current_position = BOTTOM_POS;
        }

        else {
            my_tetromino[1][0] = 'S';
            my_tetromino[2][0] = 'S';
            my_tetromino[2][1] = 'S';
            my_tetromino[3][1] = 'S';  
            (*this).currIndBlocksOnTetro[0][0] = 1; (*this).currIndBlocksOnTetro[0][1] = 0;
            (*this).currIndBlocksOnTetro[1][0] = 2; (*this).currIndBlocksOnTetro[1][1] = 0;
            (*this).currIndBlocksOnTetro[2][0] = 2; (*this).currIndBlocksOnTetro[2][1] = 1;
            (*this).currIndBlocksOnTetro[3][0] = 3; (*this).currIndBlocksOnTetro[3][1] = 1;
            current_position = RIGHT_POS;  
        }
         
    }

 

    else if(current_tetromino == Tetrominos::Z){

        if(precise_rotate_count == 2) {
            my_tetromino[2][0] = 'Z';
            my_tetromino[2][1] = 'Z';
            my_tetromino[3][1] = 'Z';
            my_tetromino[3][2] = 'Z';
            (*this).currIndBlocksOnTetro[0][0] = 2; (*this).currIndBlocksOnTetro[0][1] = 0;
            (*this).currIndBlocksOnTetro[1][0] = 2; (*this).currIndBlocksOnTetro[1][1] = 1;
            (*this).currIndBlocksOnTetro[2][0] = 3; (*this).currIndBlocksOnTetro[2][1] = 1;
            (*this).currIndBlocksOnTetro[3][0] = 3; (*this).currIndBlocksOnTetro[3][1] = 2;  
            current_position = BOTTOM_POS;
        }

        else {
            my_tetromino[1][1] = 'Z';
            my_tetromino[2][0] = 'Z';
            my_tetromino[2][1] = 'Z';
            my_tetromino[3][0] = 'Z';  
            (*this).currIndBlocksOnTetro[0][0] = 1; (*this).currIndBlocksOnTetro[0][1] = 1;
            (*this).currIndBlocksOnTetro[1][0] = 2; (*this).currIndBlocksOnTetro[1][1] = 0;
            (*this).currIndBlocksOnTetro[2][0] = 2; (*this).currIndBlocksOnTetro[2][1] = 1;
            (*this).currIndBlocksOnTetro[3][0] = 3; (*this).currIndBlocksOnTetro[3][1] = 0;  
             
            current_position = RIGHT_POS;
        }
         
    }

}

/* Tetromino class constructor to initially assign tetromino type and its position */
Tetromino:: Tetromino() {
    current_tetromino = Tetrominos::I;
    current_position = BOTTOM_POS;
    for(auto i=0; i<4; i++) {
        currIndBlocksOnTetro[i][0] = 0;
        currIndBlocksOnTetro[i][1] = 0;

    }
}


/* Tetromino class constructor to initially assign desired tetromino type and desired its position */
Tetromino:: Tetromino(const Tetrominos current_tetro, const Positions current_pos) {
    current_tetromino = current_tetro;
    current_position = current_pos;
    for(auto i=0; i<4; i++) {
        currIndBlocksOnTetro[i][0] = 0;
        currIndBlocksOnTetro[i][1] = 0;

    }

}






