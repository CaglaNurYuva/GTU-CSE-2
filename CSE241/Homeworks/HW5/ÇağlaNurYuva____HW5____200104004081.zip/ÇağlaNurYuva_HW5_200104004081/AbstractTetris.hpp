#ifndef ABSTRACT_TETRIS_HPP
#define ABSTRACT_TETRIS_HPP

#include "tetromino.hpp"

namespace MyGame2 {
	

    /* AbstractTetris class */
    class AbstractTetris {
        public:

            enum MoveTypes {ADDED,MOVED,ROTATED,DROPPED}; /* Keeping move type */

            /* Keeping move information */
            struct MoveInfo{
                Tetrominos TetroType = Tetrominos::I;
                MoveTypes move_type = ADDED;
                Directions direction_type = NONE;
                int currIndBlocksOnBoard[4][2];
                int howManyTimes = 0;
            }; 

            vector<MoveInfo> AllMoves;  /* Keeps all move information in game using vector*/
            int MoveInd = 0; /* Keeps index of AllMoves vector*/
            char change = 'Y'; /* Indicates whether adding tetromino to the tetris board make change on tetris board or not */
            bool adding_success = true; /* Keeping adding success */
            string QuitWay = "choice"; /* Keeps the way game ends */

 
            AbstractTetris(const int row_,const int col_) : boardRow(row_), boardCol(col_) { /* AbstratTetris class constructor */
                MoveInd = 0;
                QuitWay = "choice";
                AllMoves.resize(10);
                for(auto a=0; a<10; a++){
                    for(auto b=0; b<4; b++){
                        AllMoves[a].currIndBlocksOnBoard[b][0] = 0;
                        AllMoves[a].currIndBlocksOnBoard[b][1] = 0;
                    }
                
                }
            }  

            virtual void draw() const = 0;  /* Drawing tetris board */
            void readFromFile(const string& FileName) const; /* Reading the game from the file */
     
            AbstractTetris* operator+=( Tetromino &TetroObj); /* Adding a tetromino to tetris board */
            bool animate(const Tetromino &tetromino_obj,const int rotating_times, int temp1[][2], const char c); /* Animating a dropping tetromino */
            MoveInfo lastMove() ; /* Returning the last move */
            int numberOfMoves()const; /* Returning the number of steps (moves) this board made */
            bool MoveTetromino(const char c, int temp1[][2], const int rotating_times, Tetromino &obj) ; /* Rotating tetromino as desired and moving it to the desired location */
            void InteractWithUser(); /* Interacting with player by getting input from user and showing results to her */
            virtual bool isBoardAvailable(const int row, const int col, const char value) const = 0; /* Checking whether the particular location is available */
            virtual void ReflectAddChangeOnBoard(const Tetromino &obj) = 0; /* Reflecting change made by operator+= function on tetris board */
            bool Validate_input(int& input); /* Validating input */
            virtual void ReflectMoveChangeOnBoard(const char c, const int temp1[][2]) = 0 ; /* Reflecting change made by MoveTetromino function on tetris board */
            virtual void ReflectAnimateChangeOnBoard(const char c) = 0; /* Reflecting change made by animate function on tetris board */

            void writeToFile(const string& FileName) const;  /* Writing the game to the file */
            virtual ~AbstractTetris(){ MyVector.clear();} /* AbstractTetris class's destructor */


        protected:
            vector<AbstractTetris*> MyVector; /* Keeps object pointers */
            const int boardRow = 5, boardCol = 5; /* Keeping tetris board row and column */
       
    };

}

using namespace MyGame2;


#endif




