#include "AbstractTetris.hpp"
#include "TetrisArray1D.hpp"
#include "TetrisVector.hpp"
#include "TetrisAdaptor.hpp"
#include "tetromino.hpp"
#include "TetrisAdaptor.cpp"

template <typename T, typename U> void PlayGame(T MyTetrisBoard, U& GameObj);




int main() {

    srand(time(NULL));
    Tetromino array[10];
    char c[10];

    /* Testing Tetromino(const Tetrominos current_tetro, const Positions current_pos) constructor */
    cout << "Testing Tetromino(const Tetrominos current_tetro, const Positions current_pos) constructor..." << endl;
    Tetromino obj1(Tetrominos::Z,Positions::LEFT_POS);
    Tetromino obj2(Tetrominos::J,Positions::RIGHT_POS);
    
    array[0] = obj1;
    array[1] = obj2;

    cout << "Printing information about tetrominos..." << endl << endl;
    for(auto k=0; k<2; k++) {
        if(array[k].current_tetromino == Tetrominos::I) c[k] = 'I';
        else if(array[k].current_tetromino == Tetrominos::O) c[k] = 'O';
        else if(array[k].current_tetromino == Tetrominos::T) c[k] = 'T';
        else if(array[k].current_tetromino == Tetrominos::J) c[k] = 'J';
        else if(array[k].current_tetromino == Tetrominos::L) c[k] = 'L';
        else if(array[k].current_tetromino == Tetrominos::S) c[k] = 'S';
        else if(array[k].current_tetromino == Tetrominos::Z) c[k] = 'Z';
        cout << "Tetromino " << c[k] << " " ;

        if(array[k].current_position == BOTTOM_POS) cout << "BOTTOM POS" << endl;
        else if(array[k].current_position == UP_POS) cout << "UP POS" << endl;
        else if(array[k].current_position == LEFT_POS) cout << "LEFT POS" << endl;
        else if(array[k].current_position == RIGHT_POS) cout << "RIGHT POS" << endl;

    }
    cout << endl << "---------------------------------------------------------" << endl; 


    /* Testing Tetromino() constructor */
    cout << "Testing Tetromino() constructor..." << endl;
    Tetromino obj3, obj4;
    array[2] = obj3;
    array[3] = obj4;

    cout << "Printing information about created tetrominos..." << endl << endl;
    for(auto k=2; k<4; k++) {
        
        if(array[k].current_tetromino == Tetrominos::I) c[k] = 'I';
        else if(array[k].current_tetromino == Tetrominos::O) c[k] = 'O';
        else if(array[k].current_tetromino == Tetrominos::T) c[k] = 'T';
        else if(array[k].current_tetromino == Tetrominos::J) c[k] = 'J';
        else if(array[k].current_tetromino == Tetrominos::L) c[k] = 'L';
        else if(array[k].current_tetromino == Tetrominos::S) c[k] = 'S';
        else if(array[k].current_tetromino == Tetrominos::Z) c[k] = 'Z';
        cout << "Tetromino " << c[k] << " " ;

        if(array[k].current_position == BOTTOM_POS) cout << "BOTTOM POS" << endl;
        else if(array[k].current_position == UP_POS) cout << "UP POS" << endl;
        else if(array[k].current_position == LEFT_POS) cout << "LEFT POS" << endl;
        else if(array[k].current_position == RIGHT_POS) cout << "RIGHT POS" << endl;
        
    }
    cout << endl << "---------------------------------------------------" << endl;


    Tetromino obj5(Tetrominos::J,Positions::BOTTOM_POS);
    array[4] = obj5;
    c[4] = 'J';

    /* Testing initially_construct_tetromino() function */
    cout << "Testing initially_construct_tetromino() function 2 times..." << endl;

    cout << "Printing initially having constructed tetrominos: " << endl;
    for(auto k=3; k<5; k++) {
        array[k].initially_construct_tetromino();
        cout << endl << "Tetromino " << c[k] << endl; 
        for(auto i=0; i<4; i++) {
            for(auto j=0; j<4; j++) {
                cout << array[k].my_tetromino[i][j];
            }
            cout << endl;
        }
    } 
    cout << endl << "---------------------------------------------------" << endl;

    /* Testing rotate(Directions const rotation_direction, int rotation_count) function */
    cout << "Testing rotate(Directions const rotation_direction, int rotation_count) function 2 times..." << endl;
    cout << "Tetrominos before rotating: " << endl;
    for(auto k=3; k<5; k++) {
        if(k == 3) cout << endl << "1. Tetromino before calling the function: " << endl;
        else if(k == 4) cout << endl << "2. Tetromino before calling the function: " << endl;
        for(auto i=0; i<4; i++) {
            for(auto j=0; j<4; j++) {
                cout << array[k].my_tetromino[i][j];
            }
            cout << endl;
        }
    }
    array[3].rotate(Directions::RIGHT,2);
    array[4].rotate(Directions::LEFT,1);

    
    for(auto k=3; k<5; k++) {
        if(k == 3) cout << endl << "1. Tetromino after rotating to the right 2 times: " << endl;
        else if(k == 4) cout << endl << "2. Tetromino after rotating to the left 1 times: " << endl;
        for(auto i=0; i<4; i++) {
            for(auto j=0; j<4; j++) {
                cout << array[k].my_tetromino[i][j];
            }
            cout << endl;
        }
    }
    cout << endl << "---------------------------------------------------" << endl; 


    /* Testing TetrisVector(const int row_, const int col_) constructor */
    cout << "Testing TetrisVector(const int row_, const int col_) constructor 2 times..." << endl; 
    TetrisVector vect(5,7);
    vector<vector<char>> TetrisBoardVector(7, vector<char>(9));
    vect.CreateTetrisBoard(&TetrisBoardVector);
    
    cout << "Drawing tetris board whose sizes got from the constructor... " << endl;
    cout << "Showing 5 row 7 column (5x7) tetris board..." << endl;
    vect.draw();

    TetrisVector vect1(15,15);
    vector<vector<char>> TetrisBoardVector1(17, vector<char>(17));
    vect1.CreateTetrisBoard(&TetrisBoardVector1);
    cout << "Drawing tetris board whose sizes got from the constructor... " << endl;
    cout << "Showing 15 row 15 column (15x15) tetris board..." << endl;
    vect1.draw();
    cout << endl << "---------------------------------------------------" << endl; 


    /* Testing CreateTetrisBoard(const vector<vector<char>>* MyTetrisBoard) function */
    cout << "Testing CreateTetrisBoard(const vector<vector<char>>* MyTetrisBoard) function 2 times (It belongs to TetrisVector class)..." << endl;
    TetrisVector vect2(6,6);
    vector<vector<char>> TetrisBoardVector2(8, vector<char>(8));
    vect2.CreateTetrisBoard(&TetrisBoardVector2);
    cout << "Drawing tetris board to show 6 row 6 column (6x6) tetris board..." << endl;
    vect2.draw();

    TetrisVector vect3(7,12);
    vector<vector<char>> TetrisBoardVector3(9, vector<char>(14));
    vect3.CreateTetrisBoard(&TetrisBoardVector3);
    cout << "Drawing tetris board to show 7 row 12 column (7x12) tetris board..." << endl;
    vect3.draw();

    cout << endl << "---------------------------------------------------- " << endl;

    /* Testing AbstractTetris* operator+=(Tetromino &TetroObj) function */
    cout << "Testing AbstractTetris* operator+=(Tetromino &TetroObj) function..." << endl;

    TetrisVector vect4(6,6);
    vector<vector<char>> TetrisBoardVector4(8, vector<char>(8));
    vect4.CreateTetrisBoard(&TetrisBoardVector4);
    cout << "Drawing tetris board to show 6 row 6 column (6x6) tetris board before calling the function..." << endl;
    vect4.draw();
    
    obj5.initially_construct_tetromino();
    cout << "Printing the tetromino which is going to be added..." << endl;
    for(auto i=0; i<4; i++) {
        for(auto j=0; j<4; j++) {
            cout << obj5.my_tetromino[i][j];
        }
        cout << endl;
    }
    cout  << endl;

    vector<AbstractTetris*> MyVector;
    MyVector.push_back(&vect4);
    *(MyVector[0]) += obj5;
    vect4.ReflectAddChangeOnBoard(obj5);
    cout << "Printing tetris board after calling the function..." << endl;
    vect4.draw();



    TetrisVector vect5(12,12);
    vector<vector<char>> TetrisBoardVector5(14, vector<char>(14));
    vect5.CreateTetrisBoard(&TetrisBoardVector5);
    cout << "Drawing tetris board to show 12 row 12 column (12x12) tetris board before calling the function..." << endl;
    vect5.draw();
    

    cout << "Printing the tetromino which is going to be added..." << endl;
    obj4.initially_construct_tetromino();
    for(auto i=0; i<4; i++) {
        for(auto j=0; j<4; j++) {
            cout << obj4.my_tetromino[i][j];
        }
        cout << endl;
    }
    cout  << endl;

    /* Handling exception by throwing error message */
    try {
       if((MyVector.size()) != 0) throw ("VECTOR CARRYING OBJECT POINTERS IS KEEPING ANOTHER OBJECT POINTER");
    }

    
    catch(const char* message) {
        std::cerr << "Throwing Error: "<< message <<  endl;  
        MyVector.clear();
    }  

    
    MyVector.push_back(&vect5);
    *(MyVector[0]) += obj4;

    /* Testing ReflectAddChangeOnBoard(const Tetromino &obj) function  */
    cout << endl << "Testing ReflectAddChangeOnBoard(const Tetromino &obj) function (It belongs to TetrisVector class)..." << endl;
    vect5.ReflectAddChangeOnBoard(obj4);
    cout << "Printing tetris board after calling the function..." << endl;
    vect5.draw();
    cout << endl << "---------------------------------------------------- " << endl;

    int input;
    bool valid;

    /* Testing bool Validate_input(int& input) function */
    cout << "Testing bool Validate_input(int& input) function 2 times..." << endl;

    cout << endl << "Enter an integer value: " ;
    valid = vect5.Validate_input(input);
    if(valid == true) cout << "It is a valid integer input" << endl;
    else if(valid == false) cout << "It is not a valid integer input" << endl;
    cout << endl << "Enter an integer value: " ;
    valid = vect5.Validate_input(input);
    if(valid == true) cout << "It is a valid integer input" << endl;
    else if(valid == false) cout << "It is not a valid integer input" << endl;

    cout << endl << "---------------------------------------------------- " << endl;

    /* Testing isBoardAvailable(const int row, const int col, const char value) function */
    cout << "Testing isBoardAvailable(const int row, const int col, const char value) function 2 times..." << endl;
    cout << "Printing tetris board:" << endl;
    vect4.draw();
    valid = vect4.isBoardAvailable(2,2,' ');
    if(valid == true) cout << "The board is available on location (2,2)";
    else if(valid == false) cout << "The board is not available on location (2,2)";
    valid = vect4.isBoardAvailable(3,3,' ');
    if(valid == true) cout << "The board is available on location (3,3)";
    else if(valid == false) cout << endl << "The board is not available on location (3,3)";

    cout << endl << "---------------------------------------------------- " << endl;

    /* Testing draw() function */
    cout << "Testing draw() function 2 times (It belongs to TetrisVector class)..." << endl;
    vect2.draw();
    vect3.draw();

    cout << endl << "---------------------------------------------------- " << endl;

    /* Testing AbstractTetris(const int row_,const int col_) constructor */
    cout << "Testing AbstractTetris(const int row_,const int col_) constructor 2 times..." << endl;
    cout << "Printing tetris boards whose bound values got from the constructor..." << endl;

    TetrisVector vect8(4,4);
    vector<vector<char>> TetrisBoardVector8(6, vector<char>(6));
    vect8.CreateTetrisBoard(&TetrisBoardVector8);
    cout << "Drawing tetris board to show 4 row 4 column (4x4) tetris board before calling the function..." << endl;
    vect8.draw();

    TetrisVector vect9(7,14);
    vector<vector<char>> TetrisBoardVector9(9, vector<char>(16));
    vect9.CreateTetrisBoard(&TetrisBoardVector9);
    cout << "Drawing tetris board to show 7 row 14 column (7x14) tetris board before calling the function..." << endl;
    vect9.draw();

    cout << endl << "---------------------------------------------------- " << endl;

    /* Testing InteractWithUser() function */
    TetrisVector GameObj(12,12);
    vector<vector<char>> TetrisBoardVector10(14, vector<char>(14));
    cout << "Testing InteractWithUser() function..." << endl;
    GameObj.CreateTetrisBoard(&TetrisBoardVector10);
    GameObj.InteractWithUser();
    cout << endl << "---------------------------------------------------- " << endl;

    /* Testing numberOfMoves()const function */
    cout << endl << "---------------------------------------------------- " << endl;
    int num;
    cout << "Testing numberOfMoves()const function..." << endl;
    num = GameObj.numberOfMoves();
    cout << endl << "Number of moves made during the game = " << num << endl;
    cout << endl << "---------------------------------------------------- " << endl;


    /* Testing writeToFile(const string& FileName) function */
    cout << "Testing writeToFile(const string& FileName) function..." << endl;
    GameObj.writeToFile("test");
    if(num == 0) cout << "There is nothing to write to file since there is no successful move made on board..." << endl;
    else cout << "Look at the created file..." << endl;
    cout << endl << "---------------------------------------------------- " << endl;

    /* Testing readFromFile(const string& FileName) function */
    cout << "Testing readFromFile(const string& FileName) function..." << endl;
    GameObj.readFromFile("test");
    if(num == 0) cout << "There is nothing to read from file since there is no succesful move made on board..." << endl;
    else cout << "File has been read..." << endl;

    cout << "File operations completed with the text file named test "<< endl;
    cout << endl << "---------------------------------------------------- " << endl;
    /* Testing lastMove() function */
    cout << "Testing lastMove() function..." << endl;

    char a;
    AbstractTetris::MoveInfo keep;
    keep = GameObj.lastMove();

    if(keep.direction_type != NONE) {

        if(keep.TetroType == Tetrominos::I) a = 'I';
        else if(keep.TetroType == Tetrominos::O) a = 'O';
        else if(keep.TetroType == Tetrominos::T) a = 'T' ;
        else if(keep.TetroType == Tetrominos::J) a = 'J' ;
        else if(keep.TetroType == Tetrominos::L) a = 'L' ;
        else if(keep.TetroType == Tetrominos::S) a = 'S' ;
        else if(keep.TetroType == Tetrominos::Z) a = 'Z' ;

        cout << "Tetromino " << a  << " ";


    
        if(keep.move_type == AbstractTetris::ADDED) cout << "ADDED ";
        else if(keep.move_type == AbstractTetris::ROTATED) cout << "ROTATED ";
        else if(keep.move_type == AbstractTetris::MOVED) cout << "MOVED ";
        else if(keep.move_type == AbstractTetris::DROPPED) cout << "DROPPED "; 


       
        if(keep.direction_type == DOWN) cout << "TO THE DOWN ";
        else if(keep.direction_type == LEFT) cout << "TO THE LEFT ";
        else if(keep.direction_type == UP) cout << "TO THE UP ";
        else if(keep.direction_type == RIGHT) cout << "TO THE RIGHT ";

        cout << keep.howManyTimes << " TIMES ";


        cout << endl << "Current coordinates on Tetris Board: {" ;
        for(auto j=0; j<4; j++) {
            cout << "(" << keep.currIndBlocksOnBoard[j][0] << "," << keep.currIndBlocksOnBoard[j][1] << ")";
            if(j != 3) cout << ",";
        }
        cout << "}" << endl;
        cout << endl;
    }

    else cout << "NONE" << endl;

  
    cout << endl << "---------------------------------------------------- " << endl;

    /* Testing MoveTetromino(const char c, int temp1[][2], const int rotating_times, Tetromino &obj) function */
    cout << "Testing MoveTetromino(const char c, int temp1[][2], const int rotating_times, Tetromino &obj) function..." << endl;


    TetrisVector vect7(10,10);
    vector<vector<char>> TetrisBoardVector7(12, vector<char>(12));
    vect7.CreateTetrisBoard(&TetrisBoardVector7); /* Creating tetris board */
    int rotating_times;
    int temp1[4][2];

    Tetromino TetrObj;
    TetrObj.initially_construct_tetromino(); /* Initially construct tetromino */
    vect7.AllMoves[vect7.MoveInd].TetroType = TetrObj.current_tetromino;
    vect7.change = 'Y';
    TetrObj.current_position = Positions::BOTTOM_POS;
    rotating_times = 0;

    vect7.AllMoves.resize(10); /* Resizing vector */

  
    for(auto b=0; b<4; b++){
        vect7.AllMoves[vect7.MoveInd].currIndBlocksOnBoard[b][0] = 0;
        vect7.AllMoves[vect7.MoveInd].currIndBlocksOnBoard[b][1] = 0;
    }
        
    /* Adding a move */
    vect7.AllMoves[vect7.MoveInd].move_type = AbstractTetris::ADDED;
    vect7.AllMoves[vect7.MoveInd].direction_type = NONE;
    vect7.AllMoves[vect7.MoveInd].howManyTimes = 0;
     


    do{
        (*MyVector[0]) += TetrObj;

        if(vect7.adding_success == true) {
            MyVector[0]->ReflectAddChangeOnBoard(TetrObj); /* Reflecting add change made by operator+= function */
            cout << "Added tetromino:" << endl;
            MyVector[0]->draw();

            vect7.AllMoves[vect7.MoveInd].move_type = AbstractTetris::ADDED;
            vect7.AllMoves[vect7.MoveInd].direction_type = NONE;
            vect7.AllMoves[vect7.MoveInd].howManyTimes = 1;
            vect7.AllMoves[vect7.MoveInd].TetroType = TetrObj.current_tetromino;
            vect7.MoveInd++;
            break;
        }

           
        /* Handling the case in which adding is not successful */
        else if(vect7.adding_success == false) {

            rotating_times++;
            TetrObj.rotate(RIGHT,rotating_times);

            if(rotating_times == 1) TetrObj.current_position = Positions::RIGHT_POS;
            else if(rotating_times == 2) TetrObj.current_position = Positions::UP_POS;
            else if(rotating_times == 3) TetrObj.current_position = Positions::LEFT_POS;
            else if(rotating_times == 4) TetrObj.current_position = Positions::BOTTOM_POS;

            vect7.AllMoves[vect7.MoveInd].move_type = AbstractTetris::ROTATED;
            vect7.AllMoves[vect7.MoveInd].direction_type = RIGHT;
            vect7.AllMoves[vect7.MoveInd].howManyTimes = 1;
            for(auto z=0; z<4; z++){
                vect7.AllMoves[vect7.MoveInd].currIndBlocksOnBoard[z][0] = 0;
                vect7.AllMoves[vect7.MoveInd].currIndBlocksOnBoard[z][1] = 0;
            }
        
            vect7.AllMoves[vect7.MoveInd].TetroType = TetrObj.current_tetromino;
            vect7.MoveInd++;

        }
           
    }while(rotating_times < 4 && vect7.adding_success == false); /* Trying to add the tetromino in different positions */

    if(vect7.adding_success == true) {
           
            
        bool flag = vect7.MoveTetromino('I',temp1,rotating_times,TetrObj);
        temp1[0][0] = 1; temp1[0][1] = 6;
        temp1[1][0] = 2; temp1[1][1] = 6;
        temp1[2][0] = 3; temp1[2][1] = 6;
        temp1[3][0] = 4; temp1[3][1] = 6;

        /* Testing ReflectMoveChangeOnBoard(const char c, const int temp1[][2]) function */
        cout << "Testing ReflectMoveChangeOnBoard(const char c, const int temp1[][2]) function (It belongs to TetrisVector class)..." << endl;
        vect7.ReflectMoveChangeOnBoard('I', temp1);
        vect7.draw(); 
        cout << "----------------------------------------------" << endl;

        if(flag == false) {
            cout << "Moving the tetromino is not successful" << endl;
            if(vect7.QuitWay != "RotateFail") vect7.QuitWay = "MoveFail";
            else vect7.QuitWay = "RotateFail";
              
        }

        /* Testing animate(const Tetromino &tetromino_obj,const int rotating_times, int temp1[][2], const char c) function */
        cout << "Testing animate(const Tetromino &tetromino_obj,const int rotating_times, int temp1[][2], const char c) function ..." << endl;
        flag = vect7.animate(TetrObj,rotating_times,temp1,'I');

        /* Testing ReflectAnimateChangeOnBoard(const char c) function */
        cout << "Testing ReflectAnimateChangeOnBoard(const char c) function (It belongs to TetrisVector class)..." << endl;
        vect7.ReflectAnimateChangeOnBoard('I');
        vect7.draw();

        /* Handling the case in which animating is not successful */
        if(flag == false) {
            cout << "Animation of the tetromino is not successful" << endl;
            vect7.QuitWay = "AnimateFail";
               
        }
    }

    else {
        cout << "There is not enough space to add a new tetromino..." << endl;
        vect7.QuitWay = "AddFail";
          
    }


    /* Testing template <typename T, typename U> void PlayGame(T MyTetrisBoard, U& GameObj) global function */
    cout << endl<< "--------------------------------------------------------" << endl;

    cout << "Testing template <typename T, typename U> void PlayGame(T MyTetrisBoard, U& GameObj) global function with TetrisVector class.." << endl;
    vector<vector<char>> TetrisBoardA(10, vector<char>(10));
    vector<vector<char>> *BoardPtrA = &TetrisBoardA;
    TetrisVector GameObjA(8,8);
    PlayGame<vector<vector<char>>*, TetrisVector>(BoardPtrA, GameObjA); 


    /* Testing template <typename T, typename U> void PlayGame(T MyTetrisBoard, U& GameObj) global function */
    cout << "Testing template <typename T, typename U> void PlayGame(T MyTetrisBoard, U& GameObj) global function with TetrisVector class.." << endl;
    vector<vector<char>> TetrisBoardB(12, vector<char>(12));
    vector<vector<char>> *BoardPtrB = &TetrisBoardB;
    TetrisVector GameObjB(10,10);
    PlayGame<vector<vector<char>>*, TetrisVector>(BoardPtrB, GameObjB);  


    /* Testing template <typename T, typename U> void PlayGame(T MyTetrisBoard, U& GameObj) global function */
    cout << "Testing template <typename T, typename U> void PlayGame(T MyTetrisBoard, U& GameObj) global function with TetrisArray1D class.." << endl;
    char* TetrisBoardC = new char[(8)*(8)];
    char* BoardPtrC = TetrisBoardC;
    TetrisArray1D GameObjC(6,6);
    PlayGame<char*, TetrisArray1D>(BoardPtrC,GameObjC);
    delete[] TetrisBoardC;


    /* Testing numberOfMoves()const function */
    cout << endl << "---------------------------------------------------- " << endl;
    int num4;
    cout << "Testing numberOfMoves()const function..." << endl;
    num4 = GameObjC.numberOfMoves();
    cout << endl << "Number of moves made during the game = " << num4 << endl;
    cout << endl << "---------------------------------------------------- " << endl;


    /* Testing lastMove() function */
    cout << "Testing lastMove() function..." << endl;
    AbstractTetris::MoveInfo keep4;
    keep4 = GameObjC.lastMove();
    if(num4 != 0) {
        
        char a4;
        

        cout << endl << "Last Move: ";
        if(keep4.TetroType == Tetrominos::I) a4 = 'I';
        else if(keep4.TetroType == Tetrominos::O) a4 = 'O';
        else if(keep4.TetroType == Tetrominos::T) a4 = 'T' ;
        else if(keep4.TetroType == Tetrominos::J) a4 = 'J' ;
        else if(keep4.TetroType == Tetrominos::L) a4 = 'L' ;
        else if(keep4.TetroType == Tetrominos::S) a4 = 'S' ;
        else if(keep4.TetroType == Tetrominos::Z) a4 = 'Z' ;

        cout << "Tetromino " << a4  << " ";


    
        if(keep4.move_type == AbstractTetris::ADDED) cout << "ADDED ";
        else if(keep4.move_type == AbstractTetris::ROTATED) cout << "ROTATED ";
        else if(keep4.move_type == AbstractTetris::MOVED) cout << "MOVED ";
        else if(keep4.move_type == AbstractTetris::DROPPED) cout << "DROPPED "; 


       
        if(keep4.direction_type == DOWN) cout << "TO THE DOWN ";
        else if(keep4.direction_type == LEFT) cout << "TO THE LEFT ";
        else if(keep4.direction_type == UP) cout << "TO THE UP ";
        else if(keep4.direction_type == RIGHT) cout << "TO THE RIGHT ";

        cout << keep4.howManyTimes << " TIMES ";


        cout << endl << "Current coordinates on Tetris Board: {" ;
        for(auto j=0; j<4; j++) {
            cout << "(" << keep4.currIndBlocksOnBoard[j][0] << "," << keep4.currIndBlocksOnBoard[j][1] << ")";
            if(j != 3) cout << ",";
        }
        cout << "}" << endl;
        cout << endl;

    }

    else cout << "NONE" << endl;

    cout << endl << "----------------------------------------------------------" << endl;

    /* Testing template <typename T, typename U> void PlayGame(T MyTetrisBoard, U& GameObj) global function with TetrisAdapter class using vector as a Tetris board */
    cout << "Testing template <typename T, typename U> void PlayGame(T MyTetrisBoard, U& GameObj) global function with TetrisAdapter class using vector as a Tetris board.." << endl;
    vector<char> TetrisBoardD((8)*(8));
    vector<char>* BoardPtrD = &TetrisBoardD;
    TetrisAdapter<vector<char>> GameObjD(6,6);
    PlayGame<vector<char>*, TetrisAdapter<vector<char>>>(BoardPtrD,GameObjD);


    /* Testing numberOfMoves()const function */
    int num5;
    cout << "Testing numberOfMoves()const function..." << endl;
    num5 = GameObjD.numberOfMoves();
    cout << endl << "Number of moves made during the game = " << num5 << endl;
    cout << endl << "---------------------------------------------------- " << endl;


    /* Testing lastMove() function */
    cout << "Testing lastMove() function..." << endl;
    AbstractTetris::MoveInfo keep5;
    keep5 = GameObjD.lastMove();

    if(num5 != 0) {
        cout << endl << "Last Move: ";
        char a5;
        

        if(keep5.TetroType == Tetrominos::I) a5 = 'I';
        else if(keep5.TetroType == Tetrominos::O) a5 = 'O';
        else if(keep5.TetroType == Tetrominos::T) a5 = 'T' ;
        else if(keep5.TetroType == Tetrominos::J) a5 = 'J' ;
        else if(keep5.TetroType == Tetrominos::L) a5 = 'L' ;
        else if(keep5.TetroType == Tetrominos::S) a5 = 'S' ;
        else if(keep5.TetroType == Tetrominos::Z) a5 = 'Z' ;

        cout << "Tetromino " << a5  << " ";


    
        if(keep5.move_type == AbstractTetris::ADDED) cout << "ADDED ";
        else if(keep5.move_type == AbstractTetris::ROTATED) cout << "ROTATED ";
        else if(keep5.move_type == AbstractTetris::MOVED) cout << "MOVED ";
        else if(keep5.move_type == AbstractTetris::DROPPED) cout << "DROPPED "; 


       
        if(keep5.direction_type == DOWN) cout << "TO THE DOWN ";
        else if(keep5.direction_type == LEFT) cout << "TO THE LEFT ";
        else if(keep5.direction_type == UP) cout << "TO THE UP ";
        else if(keep5.direction_type == RIGHT) cout << "TO THE RIGHT ";

        cout << keep5.howManyTimes << " TIMES ";


        cout << endl << "Current coordinates on Tetris Board: {" ;
        for(auto j=0; j<4; j++) {
            cout << "(" << keep5.currIndBlocksOnBoard[j][0] << "," << keep5.currIndBlocksOnBoard[j][1] << ")";
            if(j != 3) cout << ",";
        }
        cout << "}" << endl;
        cout << endl;

    }

    else cout << "NONE" << endl;

    cout << endl << "---------------------------------------------------- " << endl;
    /* Testing template <typename T, typename U> void PlayGame(T MyTetrisBoard, U& GameObj) global function  */
    cout << "Testing template <typename T, typename U> void PlayGame(T MyTetrisBoard, U& GameObj) global function with TetrisAdapter class using deque as a Tetris board.." << endl;
    deque<char> TetrisBoardE((6)*(8));
    deque<char>* BoardPtrE = &TetrisBoardE;
    TetrisAdapter<deque<char>> GameObjE(4,6);
    PlayGame<deque<char>*, TetrisAdapter<deque<char>>>(BoardPtrE,GameObjE); 


    /* Testing numberOfMoves()const function */
    cout << endl << "---------------------------------------------------- " << endl;
    int num8;
    cout << "Testing numberOfMoves()const function..." << endl;
    num8 = GameObjE.numberOfMoves();
    cout << endl << "Number of moves made during the game = " << num8 << endl;
    cout << endl << "---------------------------------------------------- " << endl;


    /* Testing writeToFile(const string& FileName) function */
    cout << "Testing writeToFile(const string& FileName) function..." << endl;
    string file_name;
    cout << "Enter file name to write game to that file: ";
    getline(cin,file_name);
    
    GameObjE.writeToFile(file_name);
    if(num8 == 0) cout << "There is nothing to write to file since there is no successful move made on board..." << endl;
    else cout << "Look at the created file..." << endl;
    cout << endl << "---------------------------------------------------- " << endl;

    /* Testing readFromFile(const string& FileName) function */
    cout << "Testing readFromFile(const string& FileName) function..." << endl;
    GameObjE.readFromFile(file_name);
    if(num8 == 0) cout << "There is nothing to read from file since there is no succesful move made on board..." << endl;
    else cout << "File has been read..." << endl;


    cout << endl<< "--------------------------------------------------------" << endl;


    /* Testing TetrisArray1D(const int row_, const int col_) constructor */
    cout << "Testing TetrisArray1D(const int row_, const int col_) constructor 2 times..." << endl; 

    TetrisArray1D vect10(8,14);
    char* TetrisBoard11 = new char[10*16];
    char* BoardPtr11 = TetrisBoard11;
    vect10.CreateTetrisBoard(BoardPtr11);
    cout << "Drawing tetris board whose sizes got from the constructor... " << endl;
    cout << "Showing 8 row 14 column (8x14) tetris board..." << endl;
    vect10.draw();


    TetrisArray1D vect11(12,20);
    char* TetrisBoard12 = new char[14*22];
    char* BoardPtr12 = TetrisBoard12;
    vect11.CreateTetrisBoard(BoardPtr12);
    cout << "Drawing tetris board whose sizes got from the constructor... " << endl;
    cout << "Showing 12 row 20 column (12x20) tetris board..." << endl;
    vect11.draw();
    cout << endl << "---------------------------------------------------" << endl; 


    /* Testing CreateTetrisBoard(char* MyTetrisBoard) function */
    cout << "Testing CreateTetrisBoard(char* MyTetrisBoard) function 2 times (It belongs to TetrisArray1D class)..." << endl;
    TetrisArray1D vect12(9,7);
    char* TetrisBoard13 = new char[11*9];
    char* BoardPtr13 = TetrisBoard13;
    vect12.CreateTetrisBoard(BoardPtr13);
    cout << "Drawing tetris board whose sizes got from the constructor... " << endl;
    cout << "Showing 9 row 7 column (9x7) tetris board..." << endl;
    vect12.draw();

    TetrisArray1D vect13(6,6);
    char* TetrisBoard14 = new char[8*8];
    char* BoardPtr14 = TetrisBoard14;
    vect13.CreateTetrisBoard(BoardPtr14);
    cout << "Drawing tetris board whose sizes got from the constructor... " << endl;
    cout << "Showing 6 row 6 column (6x6) tetris board..." << endl;
    vect13.draw();

    cout << endl << "-------------------------------------------------------" << endl;

    /* Testing draw() function */
    cout << "Testing draw() function 2 times (It belongs to TetrisArray1D class)..." << endl;
    vect12.draw();
    vect13.draw();

    cout << endl << "---------------------------------------------------- " << endl;

    /* ReflectAddChangeOnBoard(const Tetromino &obj) function (It belongs to TetrisArray1D class) */
    cout << "Testing ReflectAddChangeOnBoard(const Tetromino &obj) function (It belongs to TetrisArray1D class)..."<< endl;
    cout << "Drawing tetris board to show 8 row 14 column (8x14) tetris board before calling the function..." << endl;
    vect10.draw();
    
    obj4.initially_construct_tetromino();
    cout << "Printing the tetromino which is going to be added..." << endl;
    for(auto i=0; i<4; i++) {
        for(auto j=0; j<4; j++) {
            cout << obj4.my_tetromino[i][j];
        }
        cout << endl;
    }
    cout  << endl;


    /* Handling exception by throwing error message */
    try {
       if((MyVector.size()) != 0) throw ("VECTOR CARRYING OBJECT POINTERS IS KEEPING ANOTHER OBJECT POINTER");
    }

    
    catch(const char* message) {
        std::cerr << "Throwing Error: "<< message <<  endl;  
        MyVector.clear();
    }  


    MyVector.push_back(&vect10);
    *(MyVector[0]) += obj4;
    vect10.ReflectAddChangeOnBoard(obj4);
    cout << "Printing tetris board after calling the function..." << endl;
    vect10.draw(); 
    cout << endl << "---------------------------------------------------- " << endl;

    /* Testing isBoardAvailable(const int row, const int col, const char value) function  */
    cout << "Testing isBoardAvailable(const int row, const int col, const char value) function (It belongs to TetrisArray1D class)..." << endl;

    cout << "Printing tetris board:" << endl;
    vect10.draw();
    valid = vect10.isBoardAvailable(1,7,' ');
    if(valid == true) cout << endl << "The board is available on location (1,7)";
    else if(valid == false) cout << endl << "The board is not available on location (1,7)";
    valid = vect10.isBoardAvailable(1,10,' ');
    if(valid == true) cout << endl << "The board is available on location (1,10)";
    else if(valid == false) cout << endl << "The board is not available on location (1,10)";

    cout << endl << "-------------------------------------------------------- " << endl;


    TetrisArray1D vect14(10,10);

    /* Handling exception by throwing error message */
    try {
       if((MyVector.size()) != 0) throw ("VECTOR CARRYING OBJECT POINTERS IS KEEPING ANOTHER OBJECT POINTER");
    }

    
    catch(const char* message) {
        std::cerr << "Throwing Error: "<< message <<  endl;  
        MyVector.clear();
    }  


    MyVector.push_back(&vect14);
    char* TetrisBoard15 = new char[12*12];
    char* BoardPtr15 = TetrisBoard15;
    vect14.CreateTetrisBoard(BoardPtr15);
    int rotating_timesA;
    int temp3[4][2];

    Tetromino TetrObjA;
    TetrObjA.initially_construct_tetromino();
    vect14.AllMoves[vect14.MoveInd].TetroType = TetrObjA.current_tetromino;
    vect14.change = 'Y';
    TetrObjA.current_position = Positions::BOTTOM_POS;
    rotating_timesA = 0;

    vect14.AllMoves.resize(10);

  
    for(auto b=0; b<4; b++){
        vect14.AllMoves[vect14.MoveInd].currIndBlocksOnBoard[b][0] = 0;
        vect14.AllMoves[vect14.MoveInd].currIndBlocksOnBoard[b][1] = 0;
    }
        

    vect14.AllMoves[vect14.MoveInd].move_type = AbstractTetris::ADDED;
    vect14.AllMoves[vect14.MoveInd].direction_type = NONE;
    vect14.AllMoves[vect14.MoveInd].howManyTimes = 0;
     


    do{
        (*MyVector[0]) += TetrObjA;

        if(vect14.adding_success == true) {
            
            /* Testing ReflectAddChangeOnBoard(const Tetromino &obj) function */
            cout << "Testing ReflectAddChangeOnBoard(const Tetromino &obj) function (It belongs to TetrisArray1D class)..."<< endl;
            MyVector[0]->ReflectAddChangeOnBoard(TetrObjA);
            cout << "Added tetromino:" << endl;

            MyVector[0]->draw();

            vect14.AllMoves[vect14.MoveInd].move_type = AbstractTetris::ADDED;
            vect14.AllMoves[vect14.MoveInd].direction_type = NONE;
            vect14.AllMoves[vect14.MoveInd].howManyTimes = 1;
            vect14.AllMoves[vect14.MoveInd].TetroType = TetrObj.current_tetromino;
            vect14.MoveInd++;
            break;
        }

           
        /* Handling the case in which adding is not successful */
        else if(vect14.adding_success == false) {

            rotating_timesA++;

            TetrObjA.rotate(RIGHT,rotating_timesA);

            if(rotating_timesA == 1) TetrObjA.current_position = Positions::RIGHT_POS;
            else if(rotating_timesA == 2) TetrObjA.current_position = Positions::UP_POS;
            else if(rotating_timesA == 3) TetrObjA.current_position = Positions::LEFT_POS;
            else if(rotating_timesA == 4) TetrObjA.current_position = Positions::BOTTOM_POS;

            vect14.AllMoves[vect14.MoveInd].move_type = AbstractTetris::ROTATED;
            vect14.AllMoves[vect14.MoveInd].direction_type = RIGHT;
            vect14.AllMoves[vect14.MoveInd].howManyTimes = 1;
            for(auto z=0; z<4; z++){
                vect14.AllMoves[vect14.MoveInd].currIndBlocksOnBoard[z][0] = 0;
                vect14.AllMoves[vect14.MoveInd].currIndBlocksOnBoard[z][1] = 0;
            }
        
            vect14.AllMoves[vect14.MoveInd].TetroType = TetrObjA.current_tetromino;
            vect14.MoveInd++;

        }
           
    }while(rotating_timesA < 4 && vect14.adding_success == false); /* Trying to add the tetromino in different positions */

    if(vect14.adding_success == true) {
           
            
        bool flag = vect14.MoveTetromino('I',temp3,rotating_timesA,TetrObjA);
        temp3[0][0] = 1; temp3[0][1] = 6;
        temp3[1][0] = 2; temp3[1][1] = 6;
        temp3[2][0] = 3; temp3[2][1] = 6;
        temp3[3][0] = 4; temp3[3][1] = 6;

        /* Testing ReflectMoveChangeOnBoard(const char c, const int temp1[][2]) function */
        cout << "Testing ReflectMoveChangeOnBoard(const char c, const int temp1[][2]) function (It belongs to TetrisArray1D class)..." << endl;
        vect14.ReflectMoveChangeOnBoard('I', temp3);
        vect14.draw(); 
        cout << "----------------------------------------------" << endl;

        if(flag == false) {
            cout << "Moving the tetromino is not successful" << endl;
            if(vect14.QuitWay != "RotateFail") vect14.QuitWay = "MoveFail";
            else vect14.QuitWay = "RotateFail";
              
        }

        /* Testing animate(const Tetromino &tetromino_obj,const int rotating_times, int temp1[][2], const char c) function */
        cout << "Testing animate(const Tetromino &tetromino_obj,const int rotating_times, int temp1[][2], const char c) function ..." << endl;
        flag = vect14.animate(TetrObjA,rotating_timesA,temp1,'I');

        /* Testing ReflectAnimateChangeOnBoard(const char c) function */
        cout << "Testing ReflectAnimateChangeOnBoard(const char c) function (It belongs to TetrisArray1D class)..." << endl;
        vect14.ReflectAnimateChangeOnBoard('I');
        vect14.draw();

        /* Handling the case in which animating is not successful */
        if(flag == false) {
            cout << "Animation of the tetromino is not successful" << endl;
            vect14.QuitWay = "AnimateFail";
               
        }
    }

    else {
        cout << "There is not enough space to add a new tetromino..." << endl;
        vect14.QuitWay = "AddFail";
          
    }


    cout << endl << "---------------------------------------------------- " << endl;
    int num2;
    
    /* Testing numberOfMoves()const function */
    cout << "Testing numberOfMoves()const function..." << endl;
    num2 = vect14.numberOfMoves();
    cout << endl << "Number of moves made during the game = " << num2 << endl;
    cout << endl << "---------------------------------------------------- " << endl;


    /* Testing lastMove() function */
    cout << "Testing lastMove() function..." << endl;
    AbstractTetris::MoveInfo keep2;
    keep2 = vect14.lastMove();


    if(num2 != 0) {
        char a2;
        

        if(keep2.TetroType == Tetrominos::I) a2 = 'I';
        else if(keep2.TetroType == Tetrominos::O) a2 = 'O';
        else if(keep2.TetroType == Tetrominos::T) a2 = 'T' ;
        else if(keep2.TetroType == Tetrominos::J) a2 = 'J' ;
        else if(keep2.TetroType == Tetrominos::L) a2 = 'L' ;
        else if(keep2.TetroType == Tetrominos::S) a2 = 'S' ;
        else if(keep2.TetroType == Tetrominos::Z) a2 = 'Z' ;

        cout << "Tetromino " << a2  << " ";


    
        if(keep2.move_type == AbstractTetris::ADDED) cout << "ADDED ";
        else if(keep2.move_type == AbstractTetris::ROTATED) cout << "ROTATED ";
        else if(keep2.move_type == AbstractTetris::MOVED) cout << "MOVED ";
        else if(keep2.move_type == AbstractTetris::DROPPED) cout << "DROPPED "; 


       
        if(keep2.direction_type == DOWN) cout << "TO THE DOWN ";
        else if(keep2.direction_type == LEFT) cout << "TO THE LEFT ";
        else if(keep2.direction_type == UP) cout << "TO THE UP ";
        else if(keep2.direction_type == RIGHT) cout << "TO THE RIGHT ";

        cout << keep2.howManyTimes << " TIMES ";


        cout << endl << "Current coordinates on Tetris Board: {" ;
        for(auto j=0; j<4; j++) {
            cout << "(" << keep2.currIndBlocksOnBoard[j][0] << "," << keep2.currIndBlocksOnBoard[j][1] << ")";
            if(j != 3) cout << ",";
        }
        cout << "}" << endl;
        cout << endl;

    }

    else cout << "NONE" << endl;


    delete [] TetrisBoard11;
    delete [] TetrisBoard12;
    delete [] TetrisBoard13;
    delete [] TetrisBoard14;
    delete [] TetrisBoard15; 

    cout << "----------------------------------------------" << endl;
    
    /* Testing Testing TetrisAdapter(const int row_, const int col_) constructor */
    cout << "Testing TetrisAdapter(const int row_, const int col_) constructor using vector..." << endl; 
    TetrisAdapter<vector<char>> vect16(11,11);
    vector<char> TetrisBoard17((13)*(13));
    vector<char>* BoardPtr17 = &TetrisBoard17;
    vect16.CreateTetrisBoard(BoardPtr17);
    cout << "Drawing tetris board whose sizes got from the constructor... " << endl;
    cout << "Showing 11 row 11 column (11x11) tetris board..." << endl;
    vect16.draw();


    /* Testing TetrisAdapter(const int row_, const int col_) constructor  */
    cout << "Testing TetrisAdapter(const int row_, const int col_) constructor using deque..." << endl; 
    TetrisAdapter<deque<char>> vect17(13,6);
    deque<char> TetrisBoard18((15)*(8));
    deque<char>* BoardPtr18 = &TetrisBoard18;
    vect17.CreateTetrisBoard(BoardPtr18);
    cout << "Drawing tetris board whose sizes got from the constructor... " << endl;
    cout << "Showing 13 row 6 column (13x6) tetris board..." << endl;
    vect17.draw();
    cout << endl << "---------------------------------------------------" << endl; 

    /* Testing CreateTetrisBoard(const T* MyTetrisBoard) function */
    cout << "Testing CreateTetrisBoard(const T* MyTetrisBoard) function using vector (Function belongs to TetrisAdapter class)..." << endl; 
    TetrisAdapter<vector<char>> vect18(11,11);
    vector<char> TetrisBoard19((13)*(13));
    vector<char>* BoardPtr19 = &TetrisBoard19;
    vect18.CreateTetrisBoard(BoardPtr19);
    cout << "Drawing created (11x11) tetris board... " << endl;
    vect18.draw();


    /* Testing CreateTetrisBoard(const T* MyTetrisBoard) function */
    cout << "Testing CreateTetrisBoard(const T* MyTetrisBoard) function using deque (Function belongs to TetrisAdapter class)..." << endl; 
    TetrisAdapter<deque<char>> vect19(13,6);
    deque<char> TetrisBoard20((15)*(8));
    deque<char>* BoardPtr20 = &TetrisBoard20;
    vect19.CreateTetrisBoard(BoardPtr20);
    cout << "Drawing created (13x6) tetris board... " << endl;
    vect19.draw();
    cout << endl << "---------------------------------------------------" << endl; 

    /* Testing draw() function */
    cout << "Testing draw() function using vector (Function belongs to TetrisAdapter class)..." << endl;
    vect18.draw();
    cout << endl << "Testing draw() function using deque (Function belongs to TetrisAdapter class)..." << endl;
    vect19.draw();

    cout << endl << "---------------------------------------------------" << endl; 

    /* Testing ReflectAddChangeOnBoard(const Tetromino &obj) function */
    cout << "Testing ReflectAddChangeOnBoard(const Tetromino &obj) function (It belongs to TetrisAdapter class)..."<< endl;
    cout << "Drawing tetris board to show 11 row 11 column (11x11) tetris board before calling the function..." << endl;
    vect16.draw();
    
    obj4.initially_construct_tetromino();
    cout << "Printing the tetromino which is going to be added..." << endl;
    for(auto i=0; i<4; i++) {
        for(auto j=0; j<4; j++) {
            cout << obj4.my_tetromino[i][j];
        }
        cout << endl;
    }
    cout  << endl;

    /* Handling exception by throwing error message */
    try {
       if((MyVector.size()) != 0) throw ("VECTOR CARRYING OBJECT POINTERS IS KEEPING ANOTHER OBJECT POINTER");
    }

    
    catch(const char* message) {
        std::cerr << "Throwing Error: "<< message <<  endl;  
        MyVector.clear();
    }  

    MyVector.push_back(&vect16);
    *(MyVector[0]) += obj4;
    vect16.ReflectAddChangeOnBoard(obj4);
    cout << "Printing tetris board after calling the function..." << endl;
    vect16.draw(); 
    cout << endl << "---------------------------------------------------- " << endl;

    /* Testing isBoardAvailable(const int row, const int col, const char value) function */
    cout << "Testing isBoardAvailable(const int row, const int col, const char value) function (It belongs to TetrisAdapter class)..." << endl;

    cout << "Printing tetris board:" << endl;
    vect16.draw();
    valid = vect16.isBoardAvailable(1,4,' ');
    if(valid == true) cout << endl << "The board is available on location (1,4)";
    else if(valid == false) cout << endl << "The board is not available on location (1,4)";
    valid = vect16.isBoardAvailable(1,8,' ');
    if(valid == true) cout << endl << "The board is available on location (1,8)";
    else if(valid == false) cout << endl << "The board is not available on location (1,8)";

    cout << endl << "-------------------------------------------------------- " << endl; 


    TetrisAdapter<deque<char>> vect20(13,6);
    deque<char> TetrisBoard21((15)*(8));
    deque<char>* BoardPtr21 = &TetrisBoard21;
    vect20.CreateTetrisBoard(BoardPtr21);
    MyVector.clear();
    MyVector.push_back(&vect20);
    int rotating_timesB;
    int temp4[4][2];

    Tetromino TetrObjE;
    TetrObjE.initially_construct_tetromino();
    vect20.AllMoves[vect20.MoveInd].TetroType = TetrObjE.current_tetromino;
    vect20.change = 'Y';
    TetrObjE.current_position = Positions::BOTTOM_POS;
    rotating_timesB = 0;

    vect20.AllMoves.resize(10);  /* Resizing vector */

  
    for(auto b=0; b<4; b++){
        vect20.AllMoves[vect20.MoveInd].currIndBlocksOnBoard[b][0] = 0;
        vect20.AllMoves[vect20.MoveInd].currIndBlocksOnBoard[b][1] = 0;
    }
        

    vect20.AllMoves[vect20.MoveInd].move_type = AbstractTetris::ADDED;
    vect20.AllMoves[vect20.MoveInd].direction_type = NONE;
    vect20.AllMoves[vect20.MoveInd].howManyTimes = 0;
     


    do{
        (*MyVector[0]) += TetrObjE;

        if(vect20.adding_success == true) {
            MyVector[0]->ReflectAddChangeOnBoard(TetrObjE);
            cout << "Added tetromino:" << endl;
            MyVector[0]->draw();

            vect20.AllMoves[vect20.MoveInd].move_type = AbstractTetris::ADDED;
            vect20.AllMoves[vect20.MoveInd].direction_type = NONE;
            vect20.AllMoves[vect20.MoveInd].howManyTimes = 1;
            vect20.AllMoves[vect20.MoveInd].TetroType = TetrObjE.current_tetromino;
            vect20.MoveInd++;
            break;
        }

           
        /* Handling the case in which adding is not successful */
        else if(vect20.adding_success == false) {

            rotating_timesB++;
            TetrObjE.rotate(RIGHT,rotating_timesB);

            if(rotating_timesB == 1) TetrObjE.current_position = Positions::RIGHT_POS;
            else if(rotating_timesB == 2) TetrObjE.current_position = Positions::UP_POS;
            else if(rotating_timesB == 3) TetrObjE.current_position = Positions::LEFT_POS;
            else if(rotating_timesB == 4) TetrObjE.current_position = Positions::BOTTOM_POS;

            vect20.AllMoves[vect20.MoveInd].move_type = AbstractTetris::ROTATED;
            vect20.AllMoves[vect20.MoveInd].direction_type = RIGHT;
            vect20.AllMoves[vect20.MoveInd].howManyTimes = 1;
            for(auto z=0; z<4; z++){
                vect20.AllMoves[vect20.MoveInd].currIndBlocksOnBoard[z][0] = 0;
                vect20.AllMoves[vect20.MoveInd].currIndBlocksOnBoard[z][1] = 0;
            }
        
            vect20.AllMoves[vect20.MoveInd].TetroType = TetrObjE.current_tetromino;
            vect20.MoveInd++;

        }
           
    }while(rotating_timesB < 4 && vect20.adding_success == false); /* Trying to add the tetromino in different positions */

    if(vect20.adding_success == true) {
           
            
        bool flag = vect20.MoveTetromino('I',temp4,rotating_timesB,TetrObjE);
        temp4[0][0] = 1; temp4[0][1] = 6;
        temp4[1][0] = 2; temp4[1][1] = 6;
        temp4[2][0] = 3; temp4[2][1] = 6;
        temp4[3][0] = 4; temp4[3][1] = 6;

        /* Testing ReflectMoveChangeOnBoard(const char c, const int temp1[][2]) function */
        cout << "Testing ReflectMoveChangeOnBoard(const char c, const int temp1[][2]) function (It belongs to TetrisAdapter class)..." << endl;
        vect20.ReflectMoveChangeOnBoard('I', temp4);
        vect20.draw(); 
        cout << "----------------------------------------------" << endl;

        if(flag == false) {
            cout << "Moving the tetromino is not successful" << endl;
            if(vect20.QuitWay != "RotateFail") vect20.QuitWay = "MoveFail";
            else vect20.QuitWay = "RotateFail";
              
        }

        /* Testing animate(const Tetromino &tetromino_obj,const int rotating_times, int temp1[][2], const char c) function */
        cout << "Testing animate(const Tetromino &tetromino_obj,const int rotating_times, int temp1[][2], const char c) function ..." << endl;
        flag = vect20.animate(TetrObjE,rotating_timesB,temp4,'I');

        /* Testing ReflectAnimateChangeOnBoard(const char c) function */
        cout << "Testing ReflectAnimateChangeOnBoard(const char c) function (It belongs to TetrisAdapter class)..." << endl;
        vect20.ReflectAnimateChangeOnBoard('I');
        vect20.draw();

        /* Handling the case in which animating is not successful */
        if(flag == false) {
            cout << "Animation of the tetromino is not successful" << endl;
            vect20.QuitWay = "AnimateFail";
               
        }
    }

    else {
        cout << "There is not enough space to add a new tetromino..." << endl;
        vect20.QuitWay = "AddFail";
          
    }



    return 0; 
}









