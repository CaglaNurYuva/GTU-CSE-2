#ifndef TETROMINO_HPP
#define TETROMINO_HPP


#include <iostream>
#include <vector>
#include <array>
#include <deque>
#include <chrono>
#include <thread>
#include <stdlib.h>
#include <ctime>
#include <stdexcept>
#include <fstream>
#include <string>


using std::string;
using std::vector;
using std::array;
using std::cin;
using std::cout;
using std::endl;
using std::deque;

const int MaxIntVal = 2147483647;

template <typename T, typename U> void PlayGame(T MyTetrisBoard, U& GameObj);
enum Directions{DOWN,LEFT,UP,RIGHT,NONE};
enum Positions{BOTTOM_POS,LEFT_POS,UP_POS,RIGHT_POS};
enum class Tetrominos {I,O,T,J,L,S,Z};

namespace MyGame1 {


    /* Tetromino class */
    class Tetromino {
        public:
            Tetromino(); /* Tetromino class constructor to initially assign tetromino type and its position */
            Tetromino(const Tetrominos current_tetro, const Positions current_pos); /* Tetromino class constructor to initially assign desired tetromino type and desired its position */
            void rotate(Directions const rotation_direction, const int rotation_count); /* Rotating tetromino */
            void initially_construct_tetromino(); /* Constructing a tetromino initially which is in bottom position */
            ~Tetromino() {/**/}  /* Tetromino class destructor */

           
            vector<vector<char>> my_tetromino {{' ',' ',' ',' '},{' ',' ',' ',' '},  /* Keeps tetromino */
                                                {' ',' ',' ',' '},{' ',' ',' ',' '}};
            Positions current_position;  /* Keeps current position of tetromino */
            Tetrominos current_tetromino;   /* Keeps current type of tetromino */
            int currIndBlocksOnTetro[4][2];  /* Keeps current indexes of blocks of tetromino */                      

    };

}


using namespace MyGame1;
#endif


