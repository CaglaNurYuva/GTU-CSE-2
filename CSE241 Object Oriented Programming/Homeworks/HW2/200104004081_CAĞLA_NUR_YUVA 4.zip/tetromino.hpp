#ifndef TETROMINO_H
#define TETROMINO_H

// #include "tetris.hpp"
using namespace std;

enum Directions {LEFT, RIGHT}; /* It represents in which direction tetromino will be rotated */
enum CurrentPosition{BOTTOM_POS,LEFT_POS,UP_POS,RIGHT_POS}; /* It represents current position of a tetromino */
enum class Tetrominos {I,O,T,J,L,S,Z}; /* It represents the types of tetrominos */

class Tetromino {

    public:
     
        Tetromino(Tetrominos my_current_tetromino); /* Initializing current tetromino type, position and next tetromino in the constructor */ 
        Tetromino(); /* Initializing current tetromino position in the constructor */

        vector <Tetrominos> all_tetrominos; /* This vector keeps representatives of all tetrominos that the user entered */

        vector<vector<char>> my_tetromino { /* Representing blocks of a tetromino */
            {' ',' ',' ',' '},
            {' ',' ',' ',' '},
            {' ',' ',' ',' '},
            {' ',' ',' ',' '}
        };


        void start_program(); /* Finding and printing best fit for all tetrominos */
        void get_input();     /* Getting the type of tetrominos and the number of tetrominos from the user */
        void print(Tetromino const &proper_tetromino); /* Printing a certain tetromino */ 

        
        void rotate(Directions const rotating_direction, Tetromino &obj); /* Rotating a certain tetromino to the desired direction */
        void printing_best_fit(string horizontal1, string horizontal2, string horizontal3,string horizontal4)const; /* Printing the best fit for all tetrominos */ 
        void initially_construct_tetromino(Tetromino &proper_tetromino); /* Filling 2D char vector to represent blocks of a tetromino which is in bottom position by default */
        string converting_to_horizontal(Tetrominos const type, CurrentPosition const position) const; /* Returning the last row of a certain tetromino as string while taking type and position of the tetromino into account */ 
        string converting_to_string(Tetromino const obj, int const row)const; /* Converting 1D char vector to 1D string */
        bool canFit(Tetromino proper_tetromino, CurrentPosition relative_position); /* Checking whether two tetrominos can make best fit or not */
       
        friend class Tetris;

    private:

        Tetrominos current_tetromino;
        Tetrominos next_tetromino;    
        CurrentPosition current_position;

};



#endif
