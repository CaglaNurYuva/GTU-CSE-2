
#include "tetris.hpp"


using namespace std;


int main() {
    
    Tetromino obj1(Tetrominos::I);
    string row;
    
    /* Running all functions in two classes one by one */
    cout << "Running get_input() function..." << endl;
    obj1.get_input();
    
    int size = obj1.all_tetrominos.size();
    cout << endl << "size = " << size << endl;
    cout << endl << "Showing tetromino types created by get_input() function as a result:" << endl;
    
    for(auto i=0; i<size; i++){
        if(obj1.all_tetrominos[i] == Tetrominos::I) cout << 'I' << " " ;
        else if(obj1.all_tetrominos[i] == Tetrominos::O) cout << 'O' << " " ;
        else if(obj1.all_tetrominos[i] == Tetrominos::T) cout << 'T' << " " ;
        else if(obj1.all_tetrominos[i] == Tetrominos::J) cout << 'J' << " " ;
        else if(obj1.all_tetrominos[i] == Tetrominos::L) cout << 'L' << " " ;
        else if(obj1.all_tetrominos[i] == Tetrominos::Z) cout << 'Z' << " " ;
        else if(obj1.all_tetrominos[i] == Tetrominos::S) cout << 'S' << " " ;
        
    }
    

    cout << endl << "Running initially_construct_tetromino(Tetromino &proper_tetromino) function..." << endl;
    obj1.initially_construct_tetromino(obj1);
    cout << "Printing having constructed tetromino as a result:" << endl << endl;
    obj1.print(obj1);
    
    cout << endl << "Running print(Tetromino const &proper_tetromino) function..." << endl;
    cout << "Printing tetromino:" << endl;
    obj1.print(obj1);
    
    cout << endl << "Running rotate(Directions const rotating_direction, Tetromino &obj) function..." << endl;
    obj1.rotate(RIGHT,obj1);
    cout << "Printing having rotated to the right tetromino as a result:" << endl << endl;
    obj1.print(obj1);
    
    cout << endl << "Running converting_to_horizontal(Tetrominos const type, CurrentPosition const position) const function..." << endl;
    row = obj1.converting_to_horizontal(Tetrominos::Z, BOTTOM_POS);
    cout << "Printing the last row of a certain tetromino as a result whose current position and type is known: " << endl << endl;
    cout << row << endl;
    
    cout << endl << "Running converting_to_string(Tetromino const obj, int const row) const function..." << endl;
    row = obj1.converting_to_string(obj1,1);
    cout << "1. row of the tetromino has been converted to string. Printing the resultant string: " << row << endl;
    
    cout <<  endl<< "Running printing_best_fit(string horizontal1, string horizontal2, string horizontal3,string horizontal4) const function..." << endl;
    obj1.printing_best_fit("                           ","              L          T ","ZZ  SST OO    L  SSOO    TT"," ZZSSTTTOOIIIILLSS OOIIIIT ");
    cout << endl;
    
    bool result;
    cout << endl << "Running canFit(Tetromino proper_tetromino, CurrentPosition relative_position) function..." << endl;
    result = obj1.canFit(obj1, BOTTOM_POS);
    cout << "Printing 1 or 0 showing whether the two tetrominos can make best fit or not:" << endl;
    cout << result << endl;
    
   
    cout << endl << "Running start_program() function..." << endl;
    obj1.start_program();
    
    
    
    Tetris obj3;
    Tetromino obj2(Tetrominos::I);
   
    cout << "Running Add(Tetromino &new_tetromino, const CurrentPosition expected_pos, const char change) function..." << endl;
    obj3.Add(obj2, BOTTOM_POS,'Y'); 
    cout << "Printing tetris board to show the results of Add function:" << endl;
    obj3.Draw_Tetris_Board();
    
    cout << endl<<"Running Draw_Tetris_Board() const function..." << endl;
    obj3.Draw_Tetris_Board();
   
    cout << "Running Animate(Tetromino &tetromino_obj) function... " << endl;
    obj3.Animate(obj2);
    
    vector<vector<int> > current;
    vector<vector<int> > target;
    vector<vector<int> > temp;
   
    
    
    cout << "Running Check_Vertical_Way(const char c) function... " << endl;
    bool value = obj3.Check_Vertical_Way('I');
    cout << "Printing 1 or 0 returned from Check_Vertical_Way(const char c) function: " << value << endl;
    cout << "When the result is 1, dropping tetromino can be animated as seen above." << endl << endl;
    
    
    cout << "Running Fit(Tetromino &tetromino_obj, const char c) function... " << endl;
    obj3.Add(obj2,BOTTOM_POS,'Y'); 
    obj3.getter_indexes(current,temp);
    
    cout << "Printing tetris board to show the last added tetromino:" << endl;
    obj3.Draw_Tetris_Board();
 
    
    
    
    obj3.Fit(obj2,'I'); 
    obj3.getter_indexes(temp,target);
    
    
    cout << "Printing the current indexes of tetromino and the last reached target indexes of tetromino(best fit indexes): " << endl;
 
    cout << "current" << endl;
    for(auto i=0; i<4; i++){
        for(auto j=0; j<2; j++) {
            cout << current[i][j] << " ";
        }
        cout << endl;
    }
    
    cout << "target" << endl;
    for(auto i=0; i<4; i++){
        for(auto j=0; j<2; j++) {
            cout << target[i][j] << " ";
        }
        cout << endl;
    }
    
    obj3.Animate(obj2) ; 
    
    cout << "Running Decide_posture_precedence(const int ideal_pos_precedence, const Tetrominos &current_tetromino) const function..." << endl;
    CurrentPosition decided = obj3.Decide_posture_precedence(2,Tetrominos::T) ;
    cout << "Decided best fitting position in 2.precedence for tetromino T = " ;
    if(decided == 0) cout << "BOTTOM_POS";
    if(decided == 1) cout << "LEFT_POS";
    if(decided == 2) cout << "UP_POS";
    if(decided == 3) cout << "RIGHT_POS";
    
    
    cout << endl << endl<<"Running Arranging_target_position(const int empty_x,const int empty_y,const int blocks) function... " << endl;
    cout << "Found target position according to arranged empty place (3,2):"<< endl;
    obj3.Arranging_target_position(3,2, 2);
    obj3.getter_indexes(temp,target);
   
    for(auto i=0; i<4; i++){
        for(auto j=0; j<2; j++) {
            cout << target[i][j] << " ";
        }
        cout << endl;
    }
    
    cout << endl <<"Running getter_indexes(vector<vector<int> > &current_indexes,vector<vector<int> > &target_indexes) const function..." << endl;
    cout << "just before running..." << endl;
    cout << "current indexes" << endl;
    for(auto i=0; i<4; i++){
        for(auto j=0; j<2; j++) {
            cout << current[i][j] << " ";
        }
        cout << endl;
    }
    
    cout << "target indexes" << endl;
    for(auto i=0; i<4; i++){
        for(auto j=0; j<2; j++) {
            cout << target[i][j] << " ";
        }
        cout << endl;
    }
    
    obj3.getter_indexes(current,target);
    cout << "just after running..." << endl;
    cout << "current indexes" << endl;
    for(auto i=0; i<4; i++){
        for(auto j=0; j<2; j++) {
            cout << current[i][j] << " ";
        }
        cout << endl;
    }
    
    cout << "target indexes" << endl;
    for(auto i=0; i<4; i++){
        for(auto j=0; j<2; j++) {
            cout << target[i][j] << " ";
        }
        cout << endl;
    }

    
    cout << endl <<"Running Tetris_Game() function..." << endl;
    Tetris obj4;
    obj4.Tetris_Game(); 
    
   return 0; 
    
}
    
  

    
