#include "tetris.hpp"



using namespace std;

int main() {
   
    Tetris obj;
    srand(time(NULL));
    obj.Tetris_Game();  /* Starting tetris game */
}
    

