#ifndef TETRS_H
#define TETRIS_H

#include <iostream>

#include <vector>

#include <chrono>

#include <thread>

#include <stdlib.h>


#include <ctime>

#include "tetromino.hpp"


using namespace std;


class Tetris {
    public:
        Tetris(); /* Asking user inputs */
        void Tetris_Game(); /* Starting the game */
        void Draw_Tetris_Board() const; /* Drawing the tetris board */
        bool Add(Tetromino &new_tetromino, const CurrentPosition expected_pos, const char change); /* Adding a new tetromino to the tetris board */
        bool Fit(Tetromino &tetromino_obj, const char c); /* Finding the best fit place for a new tetromino */
        bool Animate(Tetromino &tetromino_obj); /* Animating dropping tetromino */
        bool Check_Vertical_Way(const char c);  /* Checking whether the tetris board is available for dropping animation or not */
        void Arranging_target_position(const int empty_x,const int empty_y,const int blocks); /* Arranging target position of a tetromino relative to any blocks of the tetromino*/
        CurrentPosition Decide_posture_precedence(const int ideal_pos_precedence, const Tetrominos &current_tetromino) const; /* Arranging tetromino position for the best fit */
        void getter_indexes( vector<vector<int> > &current_indexes,  vector<vector<int> > &target_indexes ) const; /* Enables users to reach 2 vectors from Tetris class */


        vector<vector<char> > tetris_board;
        vector<vector<int> > current_indexes_of_blocks;
        vector<vector<int> > target_indexes_of_blocks;
   

    private:
        int board_row;  /* Tetris board's row  */
        int board_col;  /* Tetris board's column */
     
};



#endif
