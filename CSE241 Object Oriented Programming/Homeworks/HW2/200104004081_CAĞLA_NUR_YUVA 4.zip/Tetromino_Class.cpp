#include "tetris.hpp"




/* Printing the best fit for all tetrominos */ 
void Tetromino:: printing_best_fit(string horizontal1, string horizontal2, string horizontal3,string horizontal4) const { 

    bool flag0=false, flag1=false, flag2=false, block=false; 
    int k, i, ilk0, ilk1, ilk2; 


    for(k=0; k<horizontal4.size(); k++){
    
        /* Checking whether the first block of the tetromino has found or not */ 
        if(horizontal4[k] != ' ' && block == false) { 
            block = true; 
        } 
    

        /* Empty places before the first block is ignored */
        if (block == false) continue; 

        /* Adding some special conditions for O and Z tetrominos */
        if(horizontal4[k-1] != 'I'){ 

            if(horizontal4[k+1] == 'O' && horizontal4[k] == ' ') continue;  
            if(horizontal4[k+1] == ' ' && horizontal4[k] == ' ' && horizontal4[k] == 'O') continue;  
            if(horizontal4[k+1] == 'Z' && horizontal4[k] == ' ' && horizontal4[k-1]!='Z'&& horizontal3[k-1]!= ' ') continue; 
            if(horizontal4[k+1] == ' ' && horizontal4[k] == ' ' && horizontal4[k+2] == 'Z') continue; 

        } 

        
        /* Handling the condition in which empty area has been found */
        if(horizontal4[k] == ' ') { 

            int a, b, m; 

            flag0 = false; 
            flag1 = false; 
            flag2 = false; 

            /* Looking for the first empty place after having already found one empty place */
            for(m=k; m<horizontal4.size(); m++){ 
                if(horizontal3[m] == ' ' && flag2 == false) { 
                    flag2 = true; 
                    ilk2 = m; /* Getting desired index that indicates an empty place has been found */
                    break; 
                } 
            } 


            /* Looking for the first empty place after having already found two empty places after shrinking the area on which an empty place is looked for */
            for(a=ilk2; a<horizontal4.size(); a++){ 
                if(horizontal2[a] == ' ' && flag1 == false) { 
                    flag1 = true; 
                    ilk1 = a; /* Getting desired index that indicates an empty place has been found */
                    break; 
                }  
            } 


            /* Looking for the first empty place after having already found two empty places after shrinking the area on which an empty place is looked for */
            for(b=ilk1; b<horizontal4.size(); b++){ 
                if(horizontal1[b] == ' ' && flag0 == false) { 
                    flag0 = true; 
                    ilk0 = b; /* Getting desired index that indicates an empty place has been found */
                    break; 
                }  
            } 

                
            /* Specializing moving one tetromino to the left condition for Z Tetromino as an exception */
            if(horizontal4[k+1] == 'Z' && horizontal4[k+2] == 'Z') { 
                horizontal3.erase(k-1,1); 
                horizontal4.erase(k,1); 
                horizontal2.erase(k-1,1); 
            } 

            /* Moving one tetromino to the left since there is enough space between tetrominos */
            else if((flag0 && flag1 && flag2) == true) { 
                horizontal1.erase(ilk0,1); 
                horizontal2.erase(ilk1,1); 
                horizontal3.erase(ilk2,1); 
                horizontal4.erase(k,1); 
            } 
        } 
    } 


    /* Printing the final best fit */
    for(i=0; i<horizontal1.length(); i++) cout << horizontal1[i]; 
    cout << endl; 

    for(i=0; i<horizontal2.length(); i++) cout << horizontal2[i]; 
    cout << endl; 

    for(i=0; i<horizontal3.length(); i++) cout << horizontal3[i]; 
    cout<< endl; 

    for(i=0; i<horizontal4.length(); i++) cout << horizontal4[i]; 
    cout<< endl; 

} 


/* Converting 1D char vector to 1D string */
string Tetromino:: converting_to_string(Tetromino const obj, int const row) const{ 

    string turning1(obj.my_tetromino[row].begin(),obj.my_tetromino[row].end()); /* Converting 1D char vector to 1D string */
    return turning1; /* Returning string */

} 


/* Checking whether two tetrominos can make best fit or not */
bool Tetromino:: canFit(Tetromino proper_tetromino, CurrentPosition relative_position) { 

    Tetromino second_tetromino; 
    string hor0, hor1, hor2, hor3; 
    CurrentPosition pos = BOTTOM_POS; 

    /* Handling O tetromino as an exception since it is a square */
    if(proper_tetromino.next_tetromino == Tetrominos::O) return true; 

    /* Constructing second tetromino */
    second_tetromino.current_tetromino = proper_tetromino.next_tetromino; 
    second_tetromino.current_position = relative_position; 
    initially_construct_tetromino(second_tetromino); 

    while(pos != relative_position) { 
        rotate(RIGHT,second_tetromino); 

        if(pos == BOTTOM_POS) pos = RIGHT_POS; 
        else if(pos == RIGHT_POS) pos = UP_POS; 
        else if(pos == UP_POS) pos = LEFT_POS; 
        else if(pos == LEFT_POS) pos = BOTTOM_POS; 
    } 


    /* Two tetrominos' blocks have been joined */
    hor0.append(converting_to_string(proper_tetromino,0)); 
    hor0.append(converting_to_string(second_tetromino,0)); 
    hor1.append(converting_to_string(proper_tetromino,1)); 
    hor1.append(converting_to_string(second_tetromino,1)); 
    hor2.append(converting_to_string(proper_tetromino,2)); 
    hor2.append(converting_to_string(second_tetromino,2)); 
    hor3.append(converting_to_string(proper_tetromino,3)); 
    hor3.append(converting_to_string(second_tetromino,3)); 

    int i, j, k, m; 
    bool full = true; /* If a row full of blocks, it is true */
    bool flag0=false, flag1=false, flag2 = false;


    for(i=0; i<hor3.length(); i++){ 
        if(hor3[i] == ' ') full = false; /* Last row is not full of blocks, empty place exists */
    } 

 
    /* If last row is full of blocks, best fit has been found, return true */
    if(full == true) return true; 

    else if(full == false) { 

        /* Ignoring the empty places until a block is seen from the right */
        for(i=hor3.length()-1; i>=0; i--){ 
            if(hor3[i] != ' '){  
                break; 
            }  
        } 


        /* Ignoring the empty places until a block is seen from the left */
        for(j=0; j<hor3.length(); j++){ 
            if(hor3[j] != ' ') { 
                break; 
            } 
        } 

        
        for(k=j; k<=i; k++){ 

            /* If an empty place has been found in third row on this limited area, look for empty places in other rows,too */
            if(hor3[k] == ' ') { 

                flag0 = false; 
                flag1 = false; 
                flag2 = false; 

                for(m=k; m<=i; m++){ 

                    /* Looking for empty places in other rows */
                    if(hor0[m] == ' ' && flag0 == false) { 
                        
                        flag0 = true; 
                    } 

                    if(hor1[m] == ' ' && flag1 == false) { 
                        
                        flag1 = true; 
                    }  

                    if(hor2[m] == ' ' && flag2 == false) { 
                        
                        flag2 = true; 
                    } 
                } 

                /* If all rows has empty places between certain column indexes, best fit has been found since blocks can be moved to the right as a whole */
                return (flag0 && flag1 && flag2); 
            } 
        } 

        /* best fit has been found since all rows don't have empty places, there is no way that a tetromino can be moved to the right as a whole */
        return true; 
    } 

    return true;
} 

  

/* Finding and printing best fit for all tetrominos */ 
void Tetromino:: start_program() { 

    int ind1=0, ind2=1, the_num_of_tetrominos=0,count=0; 
    bool fitting_control = false; 

    the_num_of_tetrominos = all_tetrominos.size(); /* Finding the number of tetrominos */
    cout << "Your tetrominos" << endl; 

    /* Printing all tetrominos one by one */ 
    while(ind1<the_num_of_tetrominos && fitting_control==false){ 

        Tetromino obj3(all_tetrominos[ind1]); 
        initially_construct_tetromino(obj3); 


        /* Handling the condition in which best fit has already been reached */ 
        if(the_num_of_tetrominos == 1) { 

            fitting_control = true; 

            /* Improving best fit for T, J and L tetrominos */ 
            if(all_tetrominos[ind1] == Tetrominos::T) {  

                rotate(RIGHT,obj3); 
                rotate(RIGHT,obj3); 
            } 

            else if(all_tetrominos[ind1] == Tetrominos::J)rotate(RIGHT,obj3); 
            else if(all_tetrominos[ind1] == Tetrominos::L)rotate(LEFT,obj3); 
        } 

        /* Printing a tetromino */ 
        print(obj3); 

        ind1++; /* Increasing index by one */
    } 

    ind1 = 0; 
    cout << "Horizontally best-fit tetrominos" << endl; 


    /* Handling the condition in which best fit has not been reached yet */ 
    if(fitting_control == false) { 

        Tetromino obj1(all_tetrominos[ind1]), obj2(all_tetrominos[ind2]); 
        string horizontal1, horizontal2, horizontal3, horizontal4; 

 
        initially_construct_tetromino(obj1); 

       /* Converting tetromino's rows carried by obj1 into string */       
       horizontal1.append(converting_to_string(obj1,0)); 
       horizontal2.append(converting_to_string(obj1,1)); 
       horizontal3.append(converting_to_string(obj1,2)); 
       horizontal4.append(converting_to_string(obj1,3)); 

 
        do{ 

            count=0; 

            obj1.current_tetromino = all_tetrominos[ind1]; 
            obj2.current_tetromino = all_tetrominos[ind2]; 
            obj1.next_tetromino = obj2.current_tetromino; 

            initially_construct_tetromino(obj1); 
            initially_construct_tetromino(obj2); 

            count++; 

            /* Checking whether two tetrominos make best fit or not */ 
            fitting_control = canFit(obj1,BOTTOM_POS);  

            /* Handling the condition in which two certain tetrominos don't make best fit */ 
            if(fitting_control == false) { 

                /* Trying to fit two tetrominos in a best way by rotating the one which is going to be added to the right of the other tetromino */ 
                while(fitting_control == false) { 

                    if(all_tetrominos[ind2] == (Tetrominos::I)) rotate(LEFT,obj2);
                    else if(all_tetrominos[ind2] == (Tetrominos::T)) rotate(LEFT,obj2); 
                    else if(all_tetrominos[ind2] == (Tetrominos::J))  rotate(RIGHT,obj2);
                    else if(all_tetrominos[ind2] == (Tetrominos::L)) rotate(LEFT,obj2); 
                    else if(all_tetrominos[ind2] == (Tetrominos::S)) rotate(LEFT,obj2); 
                    else if(all_tetrominos[ind2] == (Tetrominos::Z)) rotate(RIGHT,obj2);  

                    count++;  

                    /* Handling the condition in which there is no perfect and best fit by choosing one of the positions which are possible for the tetromino who is going to be added to the right of the other tetromino */ 
                    if(count < 5) fitting_control = canFit(obj1,obj2.current_position); 

                    /*Stopping looking for nonexist best fit for two certain tetromino */   
                    else { 
                        fitting_control = true; 
                        break;
                    } 
                } 
            } 

            /* Adding the other tetromino's rows to four strings in which having been already added rows exist when best fit is reached for two certain tetrominos */ 
            if(fitting_control == true) { 

                horizontal1.append(converting_to_string(obj2,0)); 
                horizontal2.append(converting_to_string(obj2,1)); 
                horizontal3.append(converting_to_string(obj2,2)); 
                horizontal4.append(converting_to_string(obj2,3)); 

                /* keep checking the other two tetrominos */ 
                ind1 = ind2; 
                ++ind2; 
            } 

        } while(ind2 < the_num_of_tetrominos); /* Keep looking for best fit for other tetrominos until the number of tetrominos is reached */ 

 
        /* Printing best fit by printing four rows */
        printing_best_fit(horizontal1,horizontal2,horizontal3,horizontal4); 

    }  
} 


/* Filling 2D char vector to represent blocks of a tetromino which is in bottom position by default */  
void Tetromino:: initially_construct_tetromino(Tetromino &proper_tetromino) { 

    proper_tetromino.current_position = BOTTOM_POS; 

    /* Filling 2D char vector to represent blocks of a tetromino which is in bottom position by default */ 
    if(proper_tetromino.current_tetromino == Tetrominos::I){ 

        proper_tetromino.my_tetromino[0] = {' ', ' ', ' ', ' '}; 
        proper_tetromino.my_tetromino[1] = {' ', ' ', ' ', ' '}; 
        proper_tetromino.my_tetromino[2] = {' ', ' ', ' ', ' '}; 
        proper_tetromino.my_tetromino[3] = {'I', 'I', 'I', 'I'}; 
    } 


    else if(proper_tetromino.current_tetromino == Tetrominos::O){ 

        proper_tetromino.my_tetromino[0] = {' ', ' '}; 
        proper_tetromino.my_tetromino[1] = {' ', ' '}; 
        proper_tetromino.my_tetromino[2] = {'O', 'O'}; 
        proper_tetromino.my_tetromino[3] = {'O', 'O'}; 
    } 

 
    else if(proper_tetromino.current_tetromino == Tetrominos::T){ 

        proper_tetromino.my_tetromino[0] = {' ', ' ', ' '}; 
        proper_tetromino.my_tetromino[1] = {' ', ' ', ' '}; 
        proper_tetromino.my_tetromino[2] = {'T', 'T', 'T'}; 
        proper_tetromino.my_tetromino[3] = {' ', 'T', ' '}; 
    } 


    else if(proper_tetromino.current_tetromino == Tetrominos::J){ 

        proper_tetromino.my_tetromino[0] = {' ', ' '}; 
        proper_tetromino.my_tetromino[1] = {' ', 'J'}; 
        proper_tetromino.my_tetromino[2] = {' ', 'J'}; 
        proper_tetromino.my_tetromino[3] = {'J', 'J'}; 
    } 


    else if(proper_tetromino.current_tetromino == Tetrominos::L){ 

        proper_tetromino.my_tetromino[0] = {' ', ' '}; 
        proper_tetromino.my_tetromino[1] = {'L', ' '}; 
        proper_tetromino.my_tetromino[2] = {'L', ' '}; 
        proper_tetromino.my_tetromino[3] = {'L', 'L'}; 
    } 


    else if(proper_tetromino.current_tetromino == Tetrominos::S){ 

        proper_tetromino.my_tetromino[0] = {' ', ' ', ' '}; 
        proper_tetromino.my_tetromino[1] = {' ', ' ', ' '}; 
        proper_tetromino.my_tetromino[2] = {' ', 'S', 'S'}; 
        proper_tetromino.my_tetromino[3] = {'S', 'S', ' '}; 
    } 

 
    else if(proper_tetromino.current_tetromino == Tetrominos::Z){ 

        proper_tetromino.my_tetromino[0] = {' ', ' ', ' '}; 
        proper_tetromino.my_tetromino[1] = {' ', ' ', ' '}; 
        proper_tetromino.my_tetromino[2] = {'Z', 'Z', ' '}; 
        proper_tetromino.my_tetromino[3] = {' ', 'Z', 'Z'}; 
    } 
} 


/* Initializing current tetromino type, position and next tetromino in the constructor */ 
Tetromino:: Tetromino(Tetrominos my_current_tetromino) { 

    current_tetromino = my_current_tetromino; 
    current_position = BOTTOM_POS; 
    next_tetromino = current_tetromino; 

} 


/* Initializing current tetromino position in the constructor */ 
Tetromino:: Tetromino() { 

    current_position = BOTTOM_POS; 
} 


/* Returning the last row of a certain tetromino as string while taking type and position of the tetromino into account */ 
string Tetromino:: converting_to_horizontal(Tetrominos const type, CurrentPosition const position) const { 

    string horizontal; 

    /* Assigning last row of tetromino to horizontal string */ 
    if(type == Tetrominos::I) { 

        if(position == BOTTOM_POS || position == UP_POS) horizontal = "IIII"; 
        else if(position == RIGHT_POS || position == LEFT_POS) horizontal = "I";   
    } 

 
    else if(type == Tetrominos::O) horizontal = "OO"; 
    
    else if(type == Tetrominos::T) { 

        if(position == BOTTOM_POS)  horizontal = " T "; 
        else if(position == RIGHT_POS)  horizontal = " T"; 
        else if(position == LEFT_POS) horizontal = "T "; 
        else if(position == UP_POS) horizontal = "TTT"; 
    } 

    else if(type == Tetrominos::J) { 

        if(position == BOTTOM_POS)  horizontal = "JJ"; 
        else if(position == RIGHT_POS)  horizontal = "JJJ"; 
        else if(position == LEFT_POS) horizontal = "  J"; 
        else if(position == UP_POS)horizontal = "J "; 
    } 

    else if(type == Tetrominos::L) { 

        if(position == BOTTOM_POS)  horizontal = "LL"; 
        else if(position == RIGHT_POS)  horizontal = "L  "; 
        else if(position == LEFT_POS) horizontal = "LLL"; 
        else if(position == UP_POS) horizontal = " L"; 
    } 

 
    else if(type == Tetrominos::S) { 

        if(position == BOTTOM_POS || position == UP_POS) horizontal = "SS "; 
        else if(position == RIGHT_POS || position == LEFT_POS) horizontal = " S"; 
    } 

 
    else if(type == Tetrominos::Z) { 

        if(position == BOTTOM_POS || position == UP_POS) horizontal = " ZZ"; 
        else if(position == RIGHT_POS || position == LEFT_POS) horizontal = "Z "; 
    } 

    return horizontal; /* Returning the last row of the tetromino */ 
} 

 

/* Rotating a certain tetromino to the desired direction */ 
void Tetromino:: rotate(Directions const rotating_direction, Tetromino &obj) { 

    /* Rotating a certain tetromino to the desired direction while taking the tetromino's current position into account */ 
    if(obj.current_tetromino == Tetrominos::I){ 
        if((rotating_direction == RIGHT) || (rotating_direction == LEFT)) {   
            if(obj.current_position == BOTTOM_POS || obj.current_position == UP_POS) { 

                obj.my_tetromino[0] = {'I'}; 
                obj.my_tetromino[1] = {'I'}; 
                obj.my_tetromino[2] = {'I'}; 
                obj.my_tetromino[3] = {'I'}; 
            }      

            else if(obj.current_position == RIGHT_POS || obj.current_position == LEFT_POS) { 
                obj.my_tetromino[0] = {' ', ' ', ' ', ' '}; 
                obj.my_tetromino[1] = {' ', ' ', ' ', ' '}; 
                obj.my_tetromino[2] = {' ', ' ', ' ', ' '}; 
                obj.my_tetromino[3] = {'I', 'I', 'I', 'I'}; 
            } 
        } 
    } 

 
    else if(obj.current_tetromino == Tetrominos::O){ 

        obj.my_tetromino[0] = {' ', ' '}; 
        obj.my_tetromino[1] = {' ', ' '}; 
        obj.my_tetromino[2] = {'O', 'O'}; 
        obj.my_tetromino[3] = {'O', 'O'}; 
    } 

 
    else if(obj.current_tetromino == Tetrominos::T){ 

        if(obj.current_position == BOTTOM_POS) { 
            if(rotating_direction == RIGHT){ 

                obj.my_tetromino[0] = {' ', ' '}; 
                obj.my_tetromino[1] = {' ', 'T'}; 
                obj.my_tetromino[2] = {'T', 'T'}; 
                obj.my_tetromino[3] = {' ', 'T'}; 
            } 


            else if(rotating_direction == LEFT){ 

                obj.my_tetromino[0] = {' ', ' '}; 
                obj.my_tetromino[1] = {'T', ' '}; 
                obj.my_tetromino[2] = {'T', 'T'}; 
                obj.my_tetromino[3] = {'T', ' '}; 
            } 
        } 

 
        else if(obj.current_position == LEFT_POS){ 

            if(rotating_direction == RIGHT){ 

                obj.my_tetromino[0] = {' ', ' ', ' '}; 
                obj.my_tetromino[1] = {' ', ' ', ' '}; 
                obj.my_tetromino[2] = {'T', 'T', 'T'}; 
                obj.my_tetromino[3] = {' ', 'T', ' '}; 
            } 

 
            else if(rotating_direction == LEFT){ 

                obj.my_tetromino[0] = {' ', ' ', ' '}; 
                obj.my_tetromino[1] = {' ', ' ', ' '}; 
                obj.my_tetromino[2] = {' ', 'T', ' '}; 
                obj.my_tetromino[3] = {'T', 'T', 'T'}; 
            } 
        } 


        else if(obj.current_position == UP_POS){ 

            if(rotating_direction == RIGHT){ 

                obj.my_tetromino[0] = {' ', ' '}; 
                obj.my_tetromino[1] = {'T', ' '}; 
                obj.my_tetromino[2] = {'T', 'T'}; 
                obj.my_tetromino[3] = {'T', ' '}; 
            } 

 
            else if(rotating_direction == LEFT){ 

                obj.my_tetromino[0] = {' ', ' '}; 
                obj.my_tetromino[1] = {' ', 'T'}; 
                obj.my_tetromino[2] = {'T', 'T'}; 
                obj.my_tetromino[3] = {' ', 'T'}; 
            } 
        } 

 
        else if(obj.current_position == RIGHT_POS){ 

            if(rotating_direction == RIGHT){ 
                obj.my_tetromino[0] = {' ', ' ', ' '}; 
                obj.my_tetromino[1] = {' ', ' ', ' '}; 
                obj.my_tetromino[2] = {' ', 'T', ' '}; 
                obj.my_tetromino[3] = {'T', 'T', 'T'}; 
            } 

 
            else if(rotating_direction == LEFT){ 

                obj.my_tetromino[0] = {' ', ' ', ' '}; 
                obj.my_tetromino[1] = {' ', ' ', ' '}; 
                obj.my_tetromino[2] = {'T', 'T', 'T'}; 
                obj.my_tetromino[3] = {' ', 'T', ' '}; 
            } 
        } 
    } 


    else if(obj.current_tetromino == Tetrominos::J){ 

        if(obj.current_position == BOTTOM_POS) { 
            if(rotating_direction == RIGHT){ 

                obj.my_tetromino[0] = {' ', ' ', ' '}; 
                obj.my_tetromino[1] = {' ', ' ', ' '}; 
                obj.my_tetromino[2] = {'J', ' ', ' '}; 
                obj.my_tetromino[3] = {'J', 'J', 'J'}; 
            } 

            else if(rotating_direction == LEFT){ 

                obj.my_tetromino[0] = {' ', ' ', ' '}; 
                obj.my_tetromino[1] = {' ', ' ', ' '}; 
                obj.my_tetromino[2] = {'J', 'J', 'J'}; 
                obj.my_tetromino[3] = {' ', ' ', 'J'}; 
            } 
        } 

 
        else if(obj.current_position == LEFT_POS){ 

            if(rotating_direction == RIGHT){ 

                obj.my_tetromino[0] = {' ', ' '}; 
                obj.my_tetromino[1] = {' ', 'J'}; 
                obj.my_tetromino[2] = {' ', 'J'}; 
                obj.my_tetromino[3] = {'J', 'J'}; 
            } 

 
            else if(rotating_direction == LEFT){ 

                obj.my_tetromino[0] = {' ', ' '}; 
                obj.my_tetromino[1] = {'J', 'J'}; 
                obj.my_tetromino[2] = {'J', ' '}; 
                obj.my_tetromino[3] = {'J', ' '}; 
            } 
        } 

 
        else if(obj.current_position == UP_POS){ 

            if(rotating_direction == RIGHT){ 

                obj.my_tetromino[0] = {' ', ' ', ' '}; 
                obj.my_tetromino[1] = {' ', ' ', ' '}; 
                obj.my_tetromino[2] = {'J', 'J', 'J'}; 
                obj.my_tetromino[3] = {' ', ' ', 'J'}; 
            } 


            else if(rotating_direction == LEFT){ 

                obj.my_tetromino[0] = {' ', ' ', ' '}; 
                obj.my_tetromino[1] = {' ', ' ', ' '}; 
                obj.my_tetromino[2] = {'J', ' ', ' '}; 
                obj.my_tetromino[3] = {'J', 'J', 'J'}; 
            } 
        } 

 
        else if(obj.current_position == RIGHT_POS){ 

            if(rotating_direction == RIGHT){ 

                obj.my_tetromino[0] = {' ', ' '}; 
                obj.my_tetromino[1] = {'J', 'J'}; 
                obj.my_tetromino[2] = {'J', ' '}; 
                obj.my_tetromino[3] = {'J', ' '}; 
            } 


            else if(rotating_direction == LEFT){ 

                obj.my_tetromino[0] = {' ', ' '}; 
                obj.my_tetromino[1] = {' ', 'J'}; 
                obj.my_tetromino[2] = {' ', 'J'}; 
                obj.my_tetromino[3] = {'J', 'J'}; 
            } 
        } 
    } 

 
    else if(obj.current_tetromino == Tetrominos::L){ 

        if(obj.current_position == BOTTOM_POS) { 
            if(rotating_direction == RIGHT){ 

                obj.my_tetromino[0] = {' ', ' ', ' '}; 
                obj.my_tetromino[1] = {' ', ' ', ' '}; 
                obj.my_tetromino[2] = {'L', 'L', 'L'}; 
                obj.my_tetromino[3] = {'L', ' ', ' '}; 
            } 


            else if(rotating_direction == LEFT){ 

                obj.my_tetromino[0] = {' ', ' ', ' '}; 
                obj.my_tetromino[1] = {' ', ' ', ' '}; 
                obj.my_tetromino[2] = {' ', ' ', 'L'}; 
                obj.my_tetromino[3] = {'L', 'L', 'L'}; 
            } 
        } 


        else if(obj.current_position == LEFT_POS){ 

            if(rotating_direction == RIGHT){ 

                obj.my_tetromino[0] = {' ', ' '}; 
                obj.my_tetromino[1] = {'L', ' '}; 
                obj.my_tetromino[2] = {'L', ' '}; 
                obj.my_tetromino[3] = {'L', 'L'}; 
            } 

 
            else if(rotating_direction == LEFT){ 

                obj.my_tetromino[0] = {' ', ' '}; 
                obj.my_tetromino[1] = {'L', 'L'}; 
                obj.my_tetromino[2] = {' ', 'L'}; 
                obj.my_tetromino[3] = {' ', 'L'}; 
            } 
        } 

 
        else if(obj.current_position == UP_POS){ 

            if(rotating_direction == RIGHT){ 

                obj.my_tetromino[0] = {' ', ' ', ' '}; 
                obj.my_tetromino[1] = {' ', ' ', ' '}; 
                obj.my_tetromino[2] = {' ', ' ', 'L'}; 
                obj.my_tetromino[3] = {'L', 'L', 'L'}; 
            } 

 
            else if(rotating_direction == LEFT){ 

                obj.my_tetromino[0] = {' ', ' ', ' '}; 
                obj.my_tetromino[1] = {' ', ' ', ' '}; 
                obj.my_tetromino[2] = {'L', 'L', 'L'}; 
                obj.my_tetromino[3] = {'L', ' ', ' '}; 
            } 
        } 

 
        else if(obj.current_position == RIGHT_POS){ 

            if(rotating_direction == RIGHT){ 

                obj.my_tetromino[0] = {' ', ' '}; 
                obj.my_tetromino[1] = {'L', 'L'}; 
                obj.my_tetromino[2] = {' ', 'L'}; 
                obj.my_tetromino[3] = {' ', 'L'}; 
            } 

 
            else if(rotating_direction == LEFT){ 

                obj.my_tetromino[0] = {' ', ' '}; 
                obj.my_tetromino[1] = {'L', ' '}; 
                obj.my_tetromino[2] = {'L', ' '}; 
                obj.my_tetromino[3] = {'L', 'L'}; 
            } 
        } 
    } 

 

    else if(obj.current_tetromino == Tetrominos::S){ 

        if(obj.current_position == BOTTOM_POS) { 
            if(rotating_direction == RIGHT){ 

                obj.my_tetromino[0] = {' ', ' '}; 
                obj.my_tetromino[1] = {'S', ' '}; 
                obj.my_tetromino[2] = {'S', 'S'}; 
                obj.my_tetromino[3] = {' ', 'S'}; 
            } 


            else if(rotating_direction == LEFT){ 

                obj.my_tetromino[0] = {' ', ' '}; 
                obj.my_tetromino[1] = {'S', ' '}; 
                obj.my_tetromino[2] = {'S', 'S'}; 
                obj.my_tetromino[3] = {' ', 'S'}; 
            } 
        } 

 
        else if(obj.current_position == LEFT_POS){ 

            if(rotating_direction == RIGHT){ 

                obj.my_tetromino[0] = {' ', ' ', ' '}; 
                obj.my_tetromino[1] = {' ', ' ', ' '}; 
                obj.my_tetromino[2] = {' ', 'S', 'S'}; 
                obj.my_tetromino[3] = {'S', 'S', ' '}; 
            } 

 
            else if(rotating_direction == LEFT){ 

                obj.my_tetromino[0] = {' ', ' ', ' '}; 
                obj.my_tetromino[1] = {' ', ' ', ' '}; 
                obj.my_tetromino[2] = {' ', 'S', 'S'}; 
                obj.my_tetromino[3] = {'S', 'S', ' '}; 
            } 
        } 

 
        else if(obj.current_position == UP_POS){ 

            if(rotating_direction == RIGHT){ 

                obj.my_tetromino[0] = {' ', ' '}; 
                obj.my_tetromino[1] = {'S', ' '}; 
                obj.my_tetromino[2] = {'S', 'S'}; 
                obj.my_tetromino[3] = {' ', 'S'}; 
            } 

 
            else if(rotating_direction == LEFT){ 

                obj.my_tetromino[0] = {' ', ' '}; 
                obj.my_tetromino[1] = {'S', ' '}; 
                obj.my_tetromino[2] = {'S', 'S'}; 
                obj.my_tetromino[3] = {' ', 'S'}; 
            } 
        } 

 
        else if(obj.current_position == RIGHT_POS){ 

            if(rotating_direction == RIGHT){ 

                obj.my_tetromino[0] = {' ', ' ', ' '}; 
                obj.my_tetromino[1] = {' ', ' ', ' '}; 
                obj.my_tetromino[2] = {' ', 'S', 'S'}; 
                obj.my_tetromino[3] = {'S', 'S', ' '}; 
            } 


            else if(rotating_direction == LEFT){ 

                obj.my_tetromino[0] = {' ', ' ', ' '}; 
                obj.my_tetromino[1] = {' ', ' ', ' '}; 
                obj.my_tetromino[2] = {' ', 'S', 'S'}; 
                obj.my_tetromino[3] = {'S', 'S', ' '}; 
            } 
        } 
    } 


    else if(obj.current_tetromino == Tetrominos::Z){ 
        if(obj.current_position == BOTTOM_POS) { 
            if(rotating_direction == RIGHT){ 

                obj.my_tetromino[0] = {' ', ' '}; 
                obj.my_tetromino[1] = {' ', 'Z'}; 
                obj.my_tetromino[2] = {'Z', 'Z'}; 
                obj.my_tetromino[3] = {'Z', ' '}; 
            } 

 
            else if(rotating_direction == LEFT){ 

                obj.my_tetromino[0] = {' ', ' '}; 
                obj.my_tetromino[1] = {' ', 'Z'}; 
                obj.my_tetromino[2] = {'Z', 'Z'}; 
                obj.my_tetromino[3] = {'Z', ' '}; 
            } 
        } 

 
        else if(obj.current_position == LEFT_POS){ 

            if(rotating_direction == RIGHT){ 
                obj.my_tetromino[0] = {' ', ' ', ' '}; 
                obj.my_tetromino[1] = {' ', ' ', ' '}; 
                obj.my_tetromino[2] = {'Z', 'Z', ' '}; 
                obj.my_tetromino[3] = {' ', 'Z', 'Z'}; 
            } 

 
            else if(rotating_direction == LEFT){ 

                obj.my_tetromino[0] = {' ', ' ', ' '}; 
                obj.my_tetromino[1] = {' ', ' ', ' '}; 
                obj.my_tetromino[2] = {'Z', 'Z', ' '}; 
                obj.my_tetromino[3] = {' ', 'Z', 'Z'}; 
            } 
        } 

 
        else if(obj.current_position == UP_POS){ 

            if(rotating_direction == RIGHT){ 

                obj.my_tetromino[0] = {' ', ' '}; 
                obj.my_tetromino[1] = {' ', 'Z'}; 
                obj.my_tetromino[2] = {'Z', 'Z'}; 
                obj.my_tetromino[3] = {'Z', ' '}; 
            } 

            else if(rotating_direction == LEFT){ 

                obj.my_tetromino[0] = {' ', ' '}; 
                obj.my_tetromino[1] = {' ', 'Z'}; 
                obj.my_tetromino[2] = {'Z', 'Z'}; 
                obj.my_tetromino[3] = {'Z', ' '}; 
            } 
        } 

 
        else if(obj.current_position == RIGHT_POS){ 

            if(rotating_direction == RIGHT){ 

                obj.my_tetromino[0] = {' ', ' ', ' '}; 
                obj.my_tetromino[1] = {' ', ' ', ' '}; 
                obj.my_tetromino[2] = {'Z', 'Z', ' '}; 
                obj.my_tetromino[3] = {' ', 'Z', 'Z'}; 
            } 


            else if(rotating_direction == LEFT){ 

                obj.my_tetromino[0] = {' ', ' ', ' '}; 
                obj.my_tetromino[1] = {' ', ' ', ' '}; 
                obj.my_tetromino[2] = {'Z', 'Z', ' '}; 
                obj.my_tetromino[3] = {' ', 'Z', 'Z'}; 
            } 
        } 
    } 

 
    /* Changing the tetromino's current position after rotating while taking the tetromino's rotating direction into account */ 
    if(obj.current_position == BOTTOM_POS) { 

        if(rotating_direction == RIGHT) obj.current_position = RIGHT_POS; 
        else if(rotating_direction == LEFT) obj.current_position = LEFT_POS;   
    } 

    else if(obj.current_position == RIGHT_POS){ 

        if(rotating_direction == RIGHT) obj.current_position = UP_POS; 
        else if(rotating_direction == LEFT) obj.current_position = BOTTOM_POS;  
    } 

 
    else if(obj.current_position == LEFT_POS){ 

        if(rotating_direction == RIGHT) obj.current_position = BOTTOM_POS; 
        else if(rotating_direction == LEFT) obj.current_position = UP_POS;  
    } 

 
    else if(obj.current_position == UP_POS){ 

        if(rotating_direction == RIGHT) obj.current_position = LEFT_POS; 
        else if(rotating_direction == LEFT) obj.current_position = RIGHT_POS; 
    } 
} 

 

/* Printing a certain tetromino */ 
void Tetromino:: print(Tetromino const &proper_tetromino) { 

    for(auto row : proper_tetromino.my_tetromino) { 
        for(auto letter : row) { 
            cout << letter; 
        } 

        cout << endl; 
    } 
} 
 

/* Getting the type of tetrominos and the number of tetrominos from the user */ 
void Tetromino:: get_input(){  
    int the_num_of_tetrominos; 
    char x; 
   
    /* Getting the number of tetrominos from the user as input */
    cout << "How many tetrominos?" << endl;

    do{ 
        cin >> the_num_of_tetrominos; 

        if(the_num_of_tetrominos <= 0) cout << "Unvalid number of tetrominos, enter again" << endl;

    } while(the_num_of_tetrominos<=0);
    

    /* Getting types of tetrominos from the user as input */ 
    cout << "What are the types?" << endl; 
    while(the_num_of_tetrominos>0) { 

        cin >> x; 

        /* Filling all_tetrominos vector with types of tetrominos */ 
        if(x == 'I') all_tetrominos.push_back(Tetrominos::I); 
        else if(x == 'O') all_tetrominos.push_back(Tetrominos::O); 
        else if(x == 'T') all_tetrominos.push_back(Tetrominos::T); 
        else if(x == 'J') all_tetrominos.push_back(Tetrominos::J); 
        else if(x == 'L') all_tetrominos.push_back(Tetrominos::L); 
        else if(x == 'S') all_tetrominos.push_back(Tetrominos::S); 
        else if(x == 'Z') all_tetrominos.push_back(Tetrominos::Z); 
         

        /* Checking the validity of input */ 
        else {
            cout << "Unvalid input, enter again" << endl; 
            continue; 
        } 

        the_num_of_tetrominos--; 
    } 
}
