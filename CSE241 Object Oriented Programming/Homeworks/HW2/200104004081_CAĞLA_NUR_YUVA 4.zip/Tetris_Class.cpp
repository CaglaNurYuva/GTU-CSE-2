#include "tetris.hpp"



/* Animating dropping tetromino */
bool Tetris:: Animate(Tetromino &tetromino_obj) {
    char c = 'I';
    bool hitting_bottom = false;
   
    
    /* Assigning a char to the c value according to current tetromino type */
    if(tetromino_obj.current_tetromino == Tetrominos::I) c = 'I';
    else if(tetromino_obj.current_tetromino == Tetrominos::O) c = 'O';
    else if(tetromino_obj.current_tetromino == Tetrominos::T) c = 'T';
    else if(tetromino_obj.current_tetromino == Tetrominos::J) c = 'J';
    else if(tetromino_obj.current_tetromino == Tetrominos::L) c = 'L';
    else if(tetromino_obj.current_tetromino == Tetrominos::S) c = 'S';
    else if(tetromino_obj.current_tetromino == Tetrominos::Z) c = 'Z';
	
    /* Drawing tetris board */
    Draw_Tetris_Board(); 

    /* Calling Fit function */
    if(Fit(tetromino_obj, c) == false) {
      
        return true;
    }
    

    /* Drawing tetris board */
    Draw_Tetris_Board(); 
    
    do{
        
        /* Sleeping for 50 seconds */
        this_thread::sleep_for(chrono::milliseconds(50));
        
        /* Checking whether bottom has been reached or not */
        if((current_indexes_of_blocks[0][0] + 1) <= target_indexes_of_blocks[0][0] && (current_indexes_of_blocks[1][0] + 1) <= target_indexes_of_blocks[1][0] && (current_indexes_of_blocks[2][0]+1) <= target_indexes_of_blocks[2][0] && (current_indexes_of_blocks[3][0]+1) <= target_indexes_of_blocks[3][0]) {
       
            tetris_board[current_indexes_of_blocks[0][0]][current_indexes_of_blocks[0][1]] = ' ';
            tetris_board[current_indexes_of_blocks[1][0]][current_indexes_of_blocks[1][1]] = ' ';
            tetris_board[current_indexes_of_blocks[2][0]][current_indexes_of_blocks[2][1]] = ' ';
            tetris_board[current_indexes_of_blocks[3][0]][current_indexes_of_blocks[3][1]] = ' ';
            
            current_indexes_of_blocks[0][0] = current_indexes_of_blocks[0][0] + 1;
            current_indexes_of_blocks[1][0] = current_indexes_of_blocks[1][0] + 1;
            current_indexes_of_blocks[2][0] = current_indexes_of_blocks[2][0] + 1;
            current_indexes_of_blocks[3][0] = current_indexes_of_blocks[3][0] + 1;
            
      
            
            tetris_board[current_indexes_of_blocks[0][0]][current_indexes_of_blocks[0][1]] = c;
            tetris_board[current_indexes_of_blocks[1][0]][current_indexes_of_blocks[1][1]] = c;
            tetris_board[current_indexes_of_blocks[2][0]][current_indexes_of_blocks[2][1]] = c;
            tetris_board[current_indexes_of_blocks[3][0]][current_indexes_of_blocks[3][1]] = c;
            
            /* Drawing tetris board */
            Draw_Tetris_Board();
            
         
        }
        
        /* when the bottom has been reached, animation ends */
        else {
            hitting_bottom = true;
            break;
        }
       
       
       

    }while(hitting_bottom == false); /* Keep animating until the block hits the bottom of the tetris board */
   
    return true;
   
}

/* Adding a new tetromino to the tetris board */
bool Tetris:: Add(Tetromino &new_tetromino, const CurrentPosition expected_pos, const char change){
   
    bool adding_success = true;

    CurrentPosition pos = BOTTOM_POS;

    /* Constructing a new tetromino */
    new_tetromino.initially_construct_tetromino(new_tetromino);
    
    /* Making the new tetromino the same position as expected_pos variable */
    while(pos != expected_pos){
        new_tetromino.rotate(RIGHT,new_tetromino);
        if(pos == BOTTOM_POS) {
            pos = RIGHT_POS;
            new_tetromino.current_position = RIGHT_POS;
        }

        else if (pos == RIGHT_POS){
            pos = UP_POS;
            new_tetromino.current_position = UP_POS;
        }

        else if (pos ==  UP_POS){
            pos = LEFT_POS;
            new_tetromino.current_position = LEFT_POS;
        }

        else if(pos == LEFT_POS) {
            pos = BOTTOM_POS;
            new_tetromino.current_position = BOTTOM_POS;
        }

    }
   
   
    int width_of_tetromino = new_tetromino.my_tetromino[0].size();
    bool first_block_found = false;
    int i,j,m, board_x, board_y;
    int keep_indexes_x=0;
    int biggest_b=0, least_b=0;
    int a,b;
    
    
    /* Looking for the first block starting from the top */
    for(i=0; i<4 && first_block_found == false ; i++){
        for(j=0; j<width_of_tetromino && first_block_found == false; j++){
            if(new_tetromino.my_tetromino[i][j] != ' ') {
                first_block_found = true;
                break;
            }
        }
        
        if(first_block_found == true) break;
    }
    
   first_block_found = false;
    

    /* Finding the most left and the most right blocks of a tetromino */
    for(a=0; a<4 ; a++){
        for(b=0; b<width_of_tetromino ; b++){
            if(new_tetromino.my_tetromino[a][b] != ' ') {
                if(first_block_found==false) {
                     first_block_found = true;
                    least_b = b;
                    biggest_b = b;
                }  
                
                else {
                    if(b < least_b) {
                        least_b = b;
                    }
                    
                    if(b > biggest_b) {
                        biggest_b = b;
                    }
                }
              
            }
        } 
    }
    

    /* Checking whether adding is going to be successful or not */
    adding_success = true;
    width_of_tetromino = biggest_b - least_b + 1;
   
    board_x = 1;
    board_y = (board_col - width_of_tetromino)/2 + 1;
  
    for(m=i; m<4 && adding_success == true; m++){
        
        board_y = (board_col - width_of_tetromino)/2 + 1;
        for(j=0; j<width_of_tetromino && adding_success == true; j++) {
            if(new_tetromino.my_tetromino[m][j] !=' ') {

                /* If there is no available place, adding is not successful */
                if(tetris_board[board_x][board_y] != ' ' ) {
                    adding_success = false;
                    break;
                }
                
                /* If places don't fit in the tetris board, adding is not successful  */
                if(board_x<=0 || board_x>board_row ) {
                    adding_success = false;
                    break;
                }
                           
                if(board_y<=0 || board_y>board_col ) {
                    adding_success = false;
                    break;
                               
                }
            }
            board_y++; /* Incrementing the tetris board's column value */
        }
        board_x++; /* Incrementing the tetris board's row value */
    }
    
   
    board_x = 1;
    
    /* Finding the indexes of blocks of a tetromino */
    for(m=i; m<4; m++){
        
        board_y = (board_col - width_of_tetromino)/2 + 1;
     
        for(j=0; j<width_of_tetromino; j++){
           
            
            if(new_tetromino.my_tetromino[m][j] !=' '){

                /* The char 'Y' indicates that indexes of the tetromino is going to be found and write on the tetris board */
                if(change == 'Y' && adding_success == true) {
                  
                    tetris_board[board_x][board_y] = new_tetromino.my_tetromino[m][j]; 
                }
           
                
                current_indexes_of_blocks[keep_indexes_x][0] = board_x;
                current_indexes_of_blocks[keep_indexes_x][1] = board_y;
                                    
                keep_indexes_x++;
                
            }
          
            board_y++; /* Incrementing the tetris board's column value */
        }
        board_x++; /* Incrementing the tetris board's row value */
    }
      

   return adding_success; /* Returning whether adding has been successful or not */
}

/* Enables users to reach 2 vectors from Tetris class */
void Tetris:: getter_indexes( vector<vector<int> > &current_indexes,  vector<vector<int> > &target_indexes) const {

    /* Assigning vectors keeping current and target indexes of blocks to another vectors */
    current_indexes =  current_indexes_of_blocks;
    target_indexes = target_indexes_of_blocks;
}

/* Drawing the tetris board */
void Tetris:: Draw_Tetris_Board() const {

    /* Drawing the tetris board */
    for(auto i=0; i<board_row+2; i++){
        for(auto j=0; j<board_col+2; j++){
           
            cout << tetris_board[i][j];
        }
        cout << endl;
    }
}


/* Asking user inputs */
Tetris:: Tetris() {

    /* Checking the validity of the row and column values of the tetris board */
    do{
       cout << "Enter row and column of tetris board respectively\n";
       cin >> board_row >> board_col;
       if(board_row<=0 || board_col <=0) {
           cout << "Unvalid input" << endl;
        }
       
    }while(board_row<=0 || board_col <=0);

    vector<vector<char> > my_tetris_board(board_row+2,vector<char>(board_col+2,' '));
    vector<vector<int> > v(4, vector<int> (2, 0)) ;

    /* Filling tetris board's sides with the char '#' */
    for(auto i=0; i<board_row+2; i++){
        for(auto j=0; j<board_col+2; j++){
            if(i == 0 || i == (board_row+1)){
                my_tetris_board[i][j] = '#';
            }

            else if(j == 0 || j == (board_col+1)){
                my_tetris_board[i][j] = '#';
            }
        }
    }
    
    /* Creating size for 2D char and int vectors by using temp vectors */
    tetris_board = my_tetris_board;
    current_indexes_of_blocks = v;
    target_indexes_of_blocks = v;
}



/* Starting the game */
void Tetris:: Tetris_Game() {
    char x;
    int y = -1;
    Tetromino obj;
    bool is_first_row_available = false;
    bool adding_success = false;
    vector <CurrentPosition> AllPositions = {BOTTOM_POS,RIGHT_POS,UP_POS,LEFT_POS};
    
   
    do{
        
        adding_success = false;
        cout << "\x1B[2J";   /* Cleaning terminal */
        Draw_Tetris_Board(); /* Drawing tetris board */
        
        is_first_row_available = false;

        /* Checking whether the first row of the tetris board is available or not */
        for(auto i=1; i<=board_col && is_first_row_available == false ;i++){ 
            if(tetris_board[1][i] == ' ') is_first_row_available = true;    
        }
        
        if(is_first_row_available == false) {
            cout << endl << "Top row of the tetris board is full.." << endl;
            break;
        }

        /* Asking tetromino type */
        cout << "What is the tetromino type?" << endl;
        cin >> x;
        
        y= -1;
        if(x == 'R') {
            y = 1 + rand()%7;
        }
        
       
        if(x == 'Q') {
            break;
        }

        
        /* Assigning current tetromino type according to char value */
        if(x == 'I' || y == 1) obj.current_tetromino = Tetrominos::I;
        else if(x == 'O' || y==2) obj.current_tetromino = Tetrominos::O;
        else if(x == 'T' || y==3) obj.current_tetromino = Tetrominos::T;
        else if(x == 'J' || y==4) obj.current_tetromino= Tetrominos::J;
        else if(x == 'L' || y==5) obj.current_tetromino = Tetrominos::L;
        else if(x == 'S' || y==6) obj.current_tetromino= Tetrominos::S;
        else if(x == 'Z' || y==7) obj.current_tetromino = Tetrominos::Z;
        

        else {
            cout << "Unvalid input" << endl;
            continue;
        }

        
        obj.current_position = BOTTOM_POS;
        
        /* Trying to add a new tetromino in any position to the tetris board */
        for(auto j=0; j<4 && adding_success == false; j++) {
            
            obj.current_position = AllPositions[j];
            obj.all_tetrominos.push_back(obj.current_tetromino);
            obj.initially_construct_tetromino(obj);
            
            if((Add(obj,AllPositions[j],'Y')) == false) {
                if(j==0) {
                    cout << endl << "There is no place in the middle of top row enough to add " << x  << " " ;
                    if(y != -1) cout << "(RANDOM) " ;
                    cout << "tetromino in BOTTOM POSITION.." << endl;
                    cout << "Other positions are going to be tried.." << endl;
                    obj.all_tetrominos.pop_back();
                }  
            }
                
            else {
                adding_success = true;
                break;
            }
       
        }
        
        /* If adding is not successful, game is over */
        if(adding_success == false) {
           cout << endl << "There is no place in the middle of top row enough to add " << x  << " " ;
                    if(y != -1) cout << "(RANDOM) " ;
                    cout << "tetromino in any position.." << endl;
            break;
        }
        
        
        /* Animating dropping of the new tetromino */
        if((Animate(obj))==false) {
            break;
        }
       
    }while(x != 'Q');
    cout << endl << "Quitting..." << endl;
}


/* Finding the best fit place for a new tetromino */
bool Tetris:: Fit(Tetromino &tetromino_obj, const char c) { 
    int i,j;
    int the_num_of_total_trying = 0;
    bool fitting = true;
    bool adding_success = true;
    CurrentPosition ideal_posture;
    vector <int> yedek1(4,0);
    vector <int>yedek2(4,0);

    /* Keeping where the tetromino has been added on the tetris board */
    yedek1[0] = (current_indexes_of_blocks[0][0]);
    yedek1[1] = (current_indexes_of_blocks[1][0]);
    yedek1[2] = (current_indexes_of_blocks[2][0]);
    yedek1[3] = (current_indexes_of_blocks[3][0]);
                                                             
    yedek2[0] = (current_indexes_of_blocks[0][1]);         
    yedek2[1] = (current_indexes_of_blocks[1][1]);           
    yedek2[2] = (current_indexes_of_blocks[2][1]);          
    yedek2[3]= (current_indexes_of_blocks[3][1]); 

    /* Deleting the places where the tetromino has been added on the tetris board  */
    tetris_board[(yedek1[0])][yedek2[0]] = ' ';
    tetris_board[(yedek1[1])][(yedek2[1])] = ' ';
    tetris_board[yedek1[2]][yedek2[2]] = ' ';
    tetris_board[yedek1[3]][yedek2[3]] = ' ';  
                     

    /* Going through the tetris board */
    for(i=board_row; i>=1; i--){                            
        for(j=1; j<board_col+1;j++){                         
                                                                                                
            fitting = true; 

            /* If the first added places has been reached, they are the best fitting places */
            if((i == yedek1[3] && j == yedek2[3]) || (i == yedek1[2] && j == yedek2[2]) || (i == yedek1[1] && j == yedek2[1]) || (i == yedek1[0] && j == yedek2[0])) {

                /* Adding the tetris board the letters that symbolized the tetromino again */
                tetris_board[yedek1[0]][yedek2[0]] = c;
                tetris_board[yedek1[1]][yedek2[1]] = c;
                tetris_board[yedek1[2]][yedek2[2]] = c;
                tetris_board[yedek1[3]][yedek2[3]] = c; 

                /* Current indexes and target indexes are going to be the same */
                current_indexes_of_blocks[0][0] =  yedek1[0];
                current_indexes_of_blocks[1][0] =  yedek1[1];
                current_indexes_of_blocks[2][0] =  yedek1[2];
                current_indexes_of_blocks[3][0] =  yedek1[3];
                current_indexes_of_blocks[0][1] =  yedek2[0];
                current_indexes_of_blocks[1][1] =  yedek2[1];
                current_indexes_of_blocks[2][1] =  yedek2[2];
                current_indexes_of_blocks[3][1] =  yedek2[3];
                
                target_indexes_of_blocks[0][0] =  yedek1[0];
                target_indexes_of_blocks[1][0] =  yedek1[1];
                target_indexes_of_blocks[2][0] =  yedek1[2];
                target_indexes_of_blocks[3][0] =  yedek1[3];
                target_indexes_of_blocks[0][1] =  yedek2[0];
                target_indexes_of_blocks[1][1] =  yedek2[1];
                target_indexes_of_blocks[2][1] =  yedek2[2];
                target_indexes_of_blocks[3][1] =  yedek2[3];
                
                

                /* Fitting is done */
                return true;
            }


            if(tetris_board[i][j] == ' ') {

                /* Assigning a number of total trying according to types of the tetrominos */
                if(tetromino_obj.current_tetromino == Tetrominos::I) the_num_of_total_trying = 2;
                else if(tetromino_obj.current_tetromino == Tetrominos::O) the_num_of_total_trying = 1;
                else if(tetromino_obj.current_tetromino == Tetrominos::T) the_num_of_total_trying = 4;
                else if(tetromino_obj.current_tetromino == Tetrominos::J) the_num_of_total_trying = 4;
                else if(tetromino_obj.current_tetromino == Tetrominos::L) the_num_of_total_trying = 4;
                else if(tetromino_obj.current_tetromino == Tetrominos::S) the_num_of_total_trying = 2;
                else if(tetromino_obj.current_tetromino == Tetrominos::Z) the_num_of_total_trying = 2;
                
                int ideal_pos_precedence = 1;
                int blocks = 3;


                /* Going through all positions of the tetromino */
                while(ideal_pos_precedence<=the_num_of_total_trying){
                    blocks = 3;
                    fitting = true;

                    /* Deciding posture precedence */
                    ideal_posture = Decide_posture_precedence(ideal_pos_precedence,tetromino_obj.current_tetromino);

                    adding_success = true;

                    /* Adding a magical tetromino to the board, therefore the tetromino is not going to be added to the board and sent with 'N'character */
                    adding_success = Add(tetromino_obj,ideal_posture,'N');


                    /* Going through relative positions according to 4 blocks of a tetromino */
                    do{

                        fitting = true;    
                        Arranging_target_position(i,j,blocks); /* Arranging target position */

                        /* Checking the validity of target positions */
                        for(auto x=0; x<4; x++){
                            
                            /* If target indexes doesn't fit in the tetris board, they are not appropriate */
                            if((target_indexes_of_blocks[x][0])<=0 || (target_indexes_of_blocks[x][0])>board_row) {
                                fitting = false;
                                break;
                            }
                           
                            /* If target indexes doesn't fit in the tetris board, they are not appropriate */
                            if((target_indexes_of_blocks[x][1])<=0 || (target_indexes_of_blocks[x][1])>board_col) {
                                fitting = false;
                                break;
                            }
                            
                            /* If target indexes have already filled with another letters symbolizing another tetrominos, the place might not be appropriate */
                            if(tetris_board[(target_indexes_of_blocks[x][0])][(target_indexes_of_blocks[x][1])] != ' '){
                               
                                fitting=false;

                                /* If target indexes happen to be the same as current indexes, target indexes are still appropriate */
                                for(auto v=0; v<4; v++){
                                    if((current_indexes_of_blocks[v][0] == target_indexes_of_blocks[x][0]) && (current_indexes_of_blocks[v][1] == target_indexes_of_blocks[x][1])) {
                                        fitting = true;
                                        break;
                                    }
                                }
                               
                               
                                if(fitting == false) break;
                            }
                        }

                        if(fitting == true) break; /* If fitting position has been found, quit the loop */
                        else blocks--;
                       

                    }while(blocks>=0 && fitting == false);

                    
                    if(fitting == true){

                        /*Checking whether adding is really unsuccessful or not */
                        if(adding_success == false) {
                            vector <int> columns;
                            bool control = true;

                            for(auto h=0; h<4; h++){
                                
                                /* Keeping column values of current indexes */
                                columns.push_back(current_indexes_of_blocks[h][1]);
                                current_indexes_of_blocks[h][1] = target_indexes_of_blocks[h][1]; /* Assigning column values of target indexes to current indexes */
                                
                                /* If current indexes doesn't fit in the tetris board, they are not appropriate */
                                if((current_indexes_of_blocks[h][0])<=0 || (current_indexes_of_blocks[h][0])>board_row) {
                                    control = false;  
                                }
                                
                                /* If current indexes doesn't fit in the tetris board, they are not appropriate */
                                if((current_indexes_of_blocks[h][1])<=0 || (current_indexes_of_blocks[h][1])>board_col) {
                                    control = false;
                                }
                                
                                /* If tetris board is not available for current indexes, they are not appropriate */
                                if(tetris_board[current_indexes_of_blocks[h][0]][current_indexes_of_blocks[h][1]] != ' ') {
                                    control = false;
                                }
                            }
                            
                            /* If control is true, adding is successful */
                            if(control == true) {
                                adding_success = true; 
                            }

                            /* Adding is not successful case  */
                            else{
                             
                                adding_success = false;

                                /* Assigning old values of columns to current indexes' columns */
                                current_indexes_of_blocks[0][1] = columns[0];
                                current_indexes_of_blocks[1][1] = columns[1];
                                current_indexes_of_blocks[2][1]= columns[2];
                                current_indexes_of_blocks[3][1] = columns[3];
                                   
                    
                            }
                           
                        }

                        /* If adding success is true, check the way is available that is going to be used in animate function */
                        if(adding_success == true) {
                            if(Check_Vertical_Way(c) == true) { 
                           
                                return true;
                            }
                        }

                        
                    }



                    ideal_pos_precedence++;
                }
            }                              
                                                                                                      
             
           
         
        }
    }

    return false;

}


/* Checking whether the tetris board is available for dropping animation or not */
bool Tetris:: Check_Vertical_Way(const char c) {
    int block1, block2, block3, block4;
    int a,b;
    bool found=false;

    /* Keeping column values of current indexes */
    block1 = current_indexes_of_blocks[0][1];
    block2 = current_indexes_of_blocks[1][1];
    block3 = current_indexes_of_blocks[2][1];
    block4 = current_indexes_of_blocks[3][1];
    
    /* Assigning target indexes' column values to current indexes' column values */
    current_indexes_of_blocks[0][1] = target_indexes_of_blocks[0][1];
    current_indexes_of_blocks[1][1] = target_indexes_of_blocks[1][1];
    current_indexes_of_blocks[2][1] = target_indexes_of_blocks[2][1];
    current_indexes_of_blocks[3][1] = target_indexes_of_blocks[3][1];
    
    /* Checking whether the way is available that is going to be used by animate function */
    for(auto x=0; x<4; x++){
        a = target_indexes_of_blocks[x][0];
        b = target_indexes_of_blocks[x][1];
       
        found = false;
        while(a > 0){

            /* If there is a place on tetris board that is not available on the way, checking might be false */
            if(tetris_board[a][b] != ' '){
                
                found = false;

                /* If seen block does not belong to the current tetromino, checking is false */
                for(auto m=0; m<4; m++){
                    if(current_indexes_of_blocks[m][0] == a && current_indexes_of_blocks[m][1] == b){
                        found = true;
                        break;
                    }
                }
               
                if(found == false) {

                    /* Assigning old values of columns to current indexes' columns */
                    current_indexes_of_blocks[0][1] = block1;
                    current_indexes_of_blocks[1][1] = block2;
                    current_indexes_of_blocks[2][1] = block3;
                    current_indexes_of_blocks[3][1] = block4;
                   return false;
                  
                }
            }
           
            a--;
        }
        
        
    }
    
    /* The way is available that is going to be used by animate function therefore assigning letters symbolizing the tetromino to the tetris board*/
    tetris_board[(current_indexes_of_blocks[0][0])][(current_indexes_of_blocks[0][1])] = c;
    tetris_board[(current_indexes_of_blocks[1][0])][(current_indexes_of_blocks[1][1])] = c;
    tetris_board[(current_indexes_of_blocks[2][0])][(current_indexes_of_blocks[2][1])] = c;
    tetris_board[(current_indexes_of_blocks[3][0])][(current_indexes_of_blocks[3][1])] = c;
    return true;
}


/* Arranging target position of a tetromino relative to any blocks of the tetromino */
void Tetris:: Arranging_target_position(const int empty_x,const int empty_y,const int blocks){
    
    /* Arranging gap created to move a specific block to a specific place */
    int gap_x = empty_x -  current_indexes_of_blocks[blocks][0];
    int gap_y = empty_y -  current_indexes_of_blocks[blocks][1];
    int i;
    
    for(i=0; i<4; i++){
        if(i != blocks) {

            /* Moving all blocks gap amount */
            target_indexes_of_blocks[i][0] = gap_x + current_indexes_of_blocks[i][0];
            target_indexes_of_blocks[i][1] = gap_y + current_indexes_of_blocks[i][1];
        }   
    } 
    
    /* Moving the block that has been referenced */
    target_indexes_of_blocks[blocks][0] = empty_x  ;
    target_indexes_of_blocks[blocks][1] = empty_y  ;
     
  
}


/* Arranging tetromino position for the best fit */
CurrentPosition Tetris:: Decide_posture_precedence(const int ideal_pos_precedence, const Tetrominos &current_tetromino) const {
    CurrentPosition ideal_pos = BOTTOM_POS;

    if(ideal_pos_precedence == 1) {
        if(current_tetromino == Tetrominos::I) {
            ideal_pos = BOTTOM_POS;
        }

        else if(current_tetromino == Tetrominos::O){
            ideal_pos = BOTTOM_POS;
        }

        else if(current_tetromino == Tetrominos::T){
            ideal_pos = UP_POS;
        }

        else if(current_tetromino == Tetrominos::J){
            ideal_pos = RIGHT_POS;
        }

        else if(current_tetromino == Tetrominos::L){
            ideal_pos = LEFT_POS;
        }

        else if(current_tetromino == Tetrominos::S){
            ideal_pos = RIGHT_POS;
        }

        else if(current_tetromino == Tetrominos::Z){
            ideal_pos = RIGHT_POS;
        }

    }

    else if(ideal_pos_precedence == 2){

        if(current_tetromino == Tetrominos::I) {
            ideal_pos = RIGHT_POS;
        }

        else if(current_tetromino == Tetrominos::T){
            ideal_pos = LEFT_POS;
        }

        else if(current_tetromino == Tetrominos::J){
            ideal_pos = BOTTOM_POS;
        }

        else if(current_tetromino == Tetrominos::L){
            ideal_pos = BOTTOM_POS;
        }

        else if(current_tetromino == Tetrominos::S){
            ideal_pos = UP_POS;
        }

        else if(current_tetromino == Tetrominos::Z){
            ideal_pos = UP_POS;
        }
    }


    else if(ideal_pos_precedence == 3){

        if(current_tetromino == Tetrominos::T){
            ideal_pos = RIGHT_POS;
        }

        else if(current_tetromino == Tetrominos::J){
            ideal_pos = LEFT_POS;
        }

        else if(current_tetromino == Tetrominos::L){
            ideal_pos = RIGHT_POS;
        }

    }


    else if(ideal_pos_precedence == 4){

        if(current_tetromino == Tetrominos::T){
            ideal_pos = BOTTOM_POS;
        }

        else if(current_tetromino == Tetrominos::J){
            ideal_pos = UP_POS;
        }

        else if(current_tetromino == Tetrominos::L){
            ideal_pos = UP_POS;
        }

    }

return ideal_pos;

}

