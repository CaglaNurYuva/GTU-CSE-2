#include "source.h"

int main() {

    Tetromino obj1;
    
    /* Getting the number of tetrominos and the type of tetrominos from the user */
    obj1.get_input();

    /* Printing tetrominos one by one and their best fit position */
    obj1.start_program();

    return(0);
} /* end of main function */
