
#include "DayofYearSet.h"

using namespace SetOperation;
int DayofYearSet:: DayOfYear:: max_int_val = 2147483647; /* Initializing static integer variable */

int main() {

    /* Deciding whether output of the program will be written to the text file or not */
    bool write_text = DayofYearSet::DayOfYear:: WriteTextFile(); 
    
    /* Deleting contents of the file */
    if(write_text == true) {
        std::ofstream write_file;

        write_file.open("results.txt"); /* Opening text file */
        
        /* Handling the case in which the file is not opened */
        if(!write_file) {
            cout << endl << "File could not be opened..." << endl;
            cout << "Terminating the program..." << endl;
            exit(0); 
        }
        
        write_file.close(); /* Closing text file */
    }
    
    
    

    /* Testing DayOfYear(int day = 1, int month = 1) constructor */
    cout << endl << "------------------------------------------------------------" << endl;
    cout << "Testing DayOfYear(int day = 1, int month = 1) constructor 18 times... " << endl;
    cout << "Having created objects respectively:" << endl;
    DayofYearSet::DayOfYear elm1(4,5); elm1.printElement(); cout << endl;
    DayofYearSet::DayOfYear elm2(29,10); elm2.printElement(); cout << endl;
    DayofYearSet::DayOfYear elm3(11); elm3.printElement(); cout << endl;
    DayofYearSet::DayOfYear elm4(15); elm4.printElement(); cout << endl;
    DayofYearSet::DayOfYear elm5; elm5.printElement(); cout << endl;
    DayofYearSet::DayOfYear elm6; elm6.printElement(); cout << endl;
    DayofYearSet::DayOfYear elm7(29,2); elm7.printElement(); cout << endl;
    DayofYearSet::DayOfYear elm8(17,5); elm8.printElement(); cout << endl;
    DayofYearSet::DayOfYear elm9(22,9); elm9.printElement(); cout << endl;
    DayofYearSet::DayOfYear elm10(3,10); elm10.printElement(); cout << endl;
    DayofYearSet::DayOfYear elm11; elm11.printElement(); cout << endl;
    DayofYearSet::DayOfYear elm12(23,4); elm12.printElement(); cout << endl;
    DayofYearSet::DayOfYear elm13(30,8); elm13.printElement(); cout << endl;
    DayofYearSet::DayOfYear elm14(9,9); elm14.printElement(); cout << endl;
    DayofYearSet::DayOfYear elm15(18,3); elm15.printElement(); cout << endl;
    DayofYearSet::DayOfYear elm16(12); elm16.printElement(); cout << endl;
    DayofYearSet::DayOfYear elm17(5); elm17.printElement(); cout << endl;
    DayofYearSet::DayOfYear elm18(31,7); elm18.printElement(); cout << endl;
    cout << endl << "------------------------------------------------------------" << endl;

    /* Testing DayOfYear(const string get_input) constructor */
    cout << "Testing DayOfYear(const string get_input) constructor 5 times... " << endl;
    DayofYearSet::DayOfYear elm19("specify"); cout << "Element: "; elm19.printElement(); cout << endl; //1 March
    DayofYearSet::DayOfYear elm20("specify"); cout << "Element: "; elm20.printElement(); cout << endl; //5 August
    DayofYearSet::DayOfYear elm21("specify"); cout << "Element: "; elm21.printElement(); cout << endl; //9 July
    DayofYearSet::DayOfYear elm22("specify"); cout << "Element: "; elm22.printElement(); cout << endl; // 3 April
    DayofYearSet::DayOfYear elm23("specify"); cout << "Element: "; elm23.printElement(); cout << endl; // 6 May
    cout << endl << "------------------------------------------------------------" << endl;

    /* Testing getDayNum() function */
    cout << "Testing getDayNum() function 3 times..." << endl;
    cout << endl << "Element: "; elm8.printElement();  cout << "   Day value = " << elm8.getDayNum();
    cout << endl << "Element: "; elm9.printElement();  cout << "   Day value = " << elm9.getDayNum();
    cout << endl << "Element: "; elm10.printElement(); cout << "   Day value = " << elm10.getDayNum();
    cout << endl << "------------------------------------------------------------" << endl;  

    /* Testing getMonthNum() function */
    cout << "Testing getMonthNum() function 3 times..." << endl;
    cout << endl << "Element: "; elm12.printElement();  cout << "   Month value = " << elm12.getMonthNum();
    cout << endl << "Element: "; elm13.printElement();  cout << "   Month value = " << elm13.getMonthNum();
    cout << endl << "Element: "; elm14.printElement(); cout << "    Month value = " << elm14.getMonthNum();
    cout << endl << "------------------------------------------------------------" << endl;  

    /* Testing WriteTextFile() function */
    cout << "Testing WriteTextFile() function 3 times..." << endl;
    cout << endl << "Note: You will see the effects of your first ever choice at the end of program, which you have already done" <<
    " at the beginning of the program." << endl;
    bool write_text1 = DayofYearSet::DayOfYear:: WriteTextFile(); cout << "Return value = " << write_text1 ;
    bool write_text2 = DayofYearSet::DayOfYear:: WriteTextFile(); cout << "Return value = " << write_text2 ;
    bool write_text3 = DayofYearSet::DayOfYear:: WriteTextFile(); cout << "Return value = " << write_text3 ;
    cout << endl << "------------------------------------------------------------" << endl;  

    /* Testing ValidateDate(const int month, const int day) function */
    cout << "Testing ValidateDate(const int month, const int day) function 4 times..." << endl;
    cout << endl << "Checking 1.element..." << endl;
    DayofYearSet::DayOfYear elm24(4,6); cout << endl << "1. Valid element: "; elm24.printElement(); cout << endl << endl;

    cout << endl << "Checking 2.element..." << endl;
    DayofYearSet::DayOfYear elm25(99,99); cout << endl << "2. Valid element: "; elm25.printElement(); cout << endl << endl;

    cout << endl << "Checking 3.element..." << endl;
    DayofYearSet::DayOfYear elm26(6,31); cout << endl << "3. Valid element: "; elm26.printElement(); cout << endl<< endl;

    cout << endl << "Checking 4.element..." << endl;
    DayofYearSet::DayOfYear elm27(31,4); cout << endl << "4. Valid element: "; elm27.printElement(); cout << endl << endl;
    cout << endl << "------------------------------------------------------------" << endl; 

    /* Testing printElement() function */
    cout << "Testing printElement() function 4 times..." << endl;
    cout << endl << "Element: "; elm12.printElement();
    cout << endl << "Element: "; elm13.printElement();
    cout << endl << "Element: "; elm14.printElement();
    cout << endl << "Element: "; elm15.printElement();
    cout << endl << "------------------------------------------------------------" << endl;
    
    /* Testing DayofYearSet() constructor */
    cout << "Testing DayofYearSet() constructor 5 times..." << endl;
    DayofYearSet Set1; cout << Set1 << endl;
    DayofYearSet Set2; cout << Set2 << endl;
    DayofYearSet Set3; cout << Set3 << endl;
    DayofYearSet Set4; cout << Set4 << endl;
    DayofYearSet Set5; cout << Set5 << endl;
    cout << endl << "------------------------------------------------------------" << endl;

    /* Testing DayofYearSet(const DayofYearSet& otherDay) constructor */
    cout << "Testing DayofYearSet(const DayofYearSet& otherDay) constructor 4 times..." << endl;

    cout << "The set which will be copied to another set: " << Set1 << endl;
    DayofYearSet Set11(Set1); cout << "Newly created set: " << Set11 << endl << endl;

    cout << "The set which will be copied to another set: " << Set2 << endl;
    DayofYearSet Set12(Set2); cout << "Newly created set: " << Set12 << endl << endl;


    cout << "The set which will be copied to another set: " << Set3 << endl;
    DayofYearSet Set13(Set3); cout << "Newly created set: " << Set13 << endl << endl;


    cout << "The set which will be copied to another set: " << Set4 << endl;
    DayofYearSet Set14(Set4); cout << "Newly created set: " << Set14 << endl;
    cout << endl << "------------------------------------------------------------" << endl; 

    /* Testing DayofYearSet(const std::list<DayOfYear> &my_elements) constructor */
    cout << "Testing DayofYearSet(const std::list<DayOfYear> &my_elements) constructor 11 times..." << endl;
    DayofYearSet Set15({elm1,elm2,elm3,elm4,elm5,elm6}); cout << "Newly created set: " << Set15 << endl;
    DayofYearSet Set16({elm18,elm15,elm10,elm4,elm11,elm20,elm1,elm8,elm9}); cout << "Newly created set: " << Set16 << endl;
    DayofYearSet Set17({elm23,elm20,elm19,elm15,elm13,elm2,elm8,elm13,elm9,elm3,elm5,elm12,elm22}); cout << "Newly created set: " << Set17 << endl;
    DayofYearSet Set18({elm19,elm4,elm21,elm23,elm7,elm17,elm1,elm5,elm11,elm13,elm18,elm23,elm7,elm17,elm11,elm13}); cout << "Newly created set: " << Set18 << endl;
    DayofYearSet Set19({elm9,elm1,elm10,elm20,elm11,elm4,elm15,elm18,elm8}); cout << "Newly created set: " << Set19 << endl;
    DayofYearSet Set20({elm23,elm20,elm19,elm15,elm13,elm2,elm8,elm13,elm9,elm3,elm5,elm12,elm22}); cout << "Newly created set: " << Set20 << endl;
    DayofYearSet Set6({elm23,elm22,elm21,elm20}); cout << "Newly created set: " << Set6 << endl;
    DayofYearSet Set7({elm19,elm15,elm4,elm9,elm3,elm11,elm10,elm6}); cout << "Newly created set: " << Set7 << endl;
    DayofYearSet Set8({elm10,elm5,elm20,elm10}); cout << "Newly created set: " << Set8 << endl;
    DayofYearSet Set9({elm19, elm6, elm11}); cout << "Newly created set: " << Set9 << endl;
    DayofYearSet Set10({elm1,elm3,elm5,elm16,elm22}); cout << "Newly created set: " << Set10 << endl;
    cout << endl << "------------------------------------------------------------" << endl;
    
    /* Testing operator<<(std::ostream& os, const DayofYearSet& DaySet) function */
    cout << "Testing operator<<(std::ostream& os, const DayofYearSet& DaySet) function 4 times..." << endl;
    cout << "Printing sets..." << endl;
    cout << Set15 << endl << Set16 << endl << Set17 << endl << Set18 << endl;
    cout << endl << "------------------------------------------------------------" << endl;
    

    /* Testing operator==(const DayofYearSet& DaySet1, const DayofYearSet& DaySet2) function */
    cout << "Testing operator==(const DayofYearSet& DaySet1, const DayofYearSet& DaySet2) function 4 times..." << endl;
    cout << endl << "Comparing these two sets: " << endl;
    cout << Set15 << endl << Set16 << endl;
    if(Set15 == Set16) cout << "These two sets are equal." << endl;
    else cout << "These two sets are not equal." << endl;

    cout << endl << "Comparing these two sets: " << endl;
    cout << Set17 << endl << Set20 << endl;
    if(Set17 == Set20) cout << "These two sets are equal." << endl;
    else cout << "These two sets are not equal." << endl;


    cout << endl << "Comparing these two sets: " << endl;
    cout << Set18 << endl << Set19 << endl;
    if(Set18 == Set19) cout << "These two sets are equal." << endl;
    else cout << "These two sets are not equal." << endl;

    cout << endl << "Comparing these two sets: " << endl;
    cout << Set16 << endl << Set19 << endl;
    if(Set16 == Set19) cout << "These two sets are equal." << endl;
    else cout << "These two sets are not equal." << endl;
    cout << endl << "------------------------------------------------------------" << endl;

    /* Testing operator!=(const DayofYearSet& DaySet1, const DayofYearSet& DaySet2) function */
    cout << "Testing operator!=(const DayofYearSet& DaySet1, const DayofYearSet& DaySet2) function 4 times..." << endl;

    cout << endl << "Comparing these two sets: " << endl;
    cout << Set15 << endl << Set16 << endl;
    if(Set15 != Set16) cout << "These two sets are not equal." << endl;
    else cout << "These two sets are equal." << endl;

    cout << endl << "Comparing these two sets: " << endl;
    cout << Set17 << endl << Set20 << endl;
    if(Set17 != Set20) cout << "These two sets are not equal." << endl;
    else cout << "These two sets are equal." << endl;


    cout << endl << "Comparing these two sets: " << endl;
    cout << Set18 << endl << Set19 << endl;
    if(Set18 != Set19) cout << "These two sets are not equal." << endl;
    else cout << "These two sets are equal." << endl;

    cout << endl << "Comparing these two sets: " << endl;
    cout << Set16 << endl << Set19 << endl;
    if(Set16 != Set19) cout << "These two sets are not equal." << endl;
    else cout << "These two sets are equal." << endl;
    cout << endl << "------------------------------------------------------------" << endl;

    /* Testing operator+(const DayOfYear& other_element) function */
    cout << "Testing operator+(const DayOfYear& other_element) function 14 times..." << endl;

    cout << endl << "Printing set before adding new elements:" << endl << Set1 << endl; 
    cout << "Trying to add element: " ; elm1.printElement(); Set1 = Set1 + elm1; cout << endl;
    cout << "Trying to add element: " ; elm2.printElement(); Set1 = Set1 + elm2; cout << endl;
    cout << "Trying to add element: " ; elm3.printElement(); Set1 = Set1 + elm3; cout << endl;
    cout << "Trying to add element: " ; elm10.printElement(); Set1 = Set1 + elm10; cout << endl;
    cout << "Trying to add element: " ; elm12.printElement(); Set1 = Set1 + elm12; cout << endl;
    cout << "Trying to add element: " ; elm13.printElement(); Set1 = Set1 + elm13; cout << endl;
    cout << "Trying to add element: " ; elm14.printElement(); Set1 = Set1 + elm14; cout << endl;
    cout << endl << "Printing set after having added new elements:" << endl << Set1 << endl;

    cout << endl << "Printing set before adding new elements:" << endl << Set19 << endl; 
    cout << "Trying to add element: " ; elm10.printElement(); Set19 = Set19 + elm10; cout << endl;//
    cout << "Trying to add element: " ; elm7.printElement(); Set19 = Set19 + elm7; cout << endl;
    cout << "Trying to add element: " ; elm20.printElement(); Set19 = Set19 + elm20; cout << endl;//
    cout << "Trying to add element: " ; elm12.printElement(); Set19 = Set19 + elm12; cout << endl;
    cout << "Trying to add element: " ; elm16.printElement(); Set19 = Set19 + elm16; cout << endl;
    cout << "Trying to add element: " ; elm15.printElement(); Set19 = Set19 + elm15; cout << endl;//
    cout << "Trying to add element: " ; elm10.printElement(); Set19 = Set19 + elm10; cout << endl;
    cout << endl << "Printing set after having added new elements:" << endl << Set19 << endl;
    cout << endl << "------------------------------------------------------------" << endl;

    /* Testing operator+(const DayofYearSet& otherSet) function */
    cout << "Testing operator+(const DayofYearSet& otherSet) function 5 times..." << endl;

    cout << endl << "Sets before calling the function..." << endl << Set3 << endl << Set8 << endl;
    DayofYearSet Set21 = Set3 + Set8;
    cout << endl << "The resultant set:" << endl << Set21 << endl;

    cout << endl << "Sets before calling the function..." << endl << Set10 << endl << Set6 << endl;
    DayofYearSet Set22 = Set10 + Set6;
    cout << endl << "The resultant set:" << endl << Set22 << endl;

    cout << endl << "Sets before calling the function..." << endl << Set21 << endl << Set22 << endl;
    DayofYearSet Set23 = Set21 + Set22;
    cout << endl << "The resultant set:" << endl << Set23 << endl;

    cout << endl << "Sets before calling the function..." << endl << Set15 << endl << Set23 << endl;
    DayofYearSet Set24 = Set15 + Set23;
    cout << endl << "The resultant set:" << endl << Set24 << endl;

    cout << endl << "Sets before calling the function..." << endl << Set23 << endl << Set24 << endl;
    DayofYearSet Set25 = Set23 + Set24;
    cout << endl << "The resultant set:" << endl << Set25 << endl;
    cout << endl << "------------------------------------------------------------" << endl;

    /* Testing operator-(const DayOfYear& other_element) function */
    cout << "Testing operator-(const DayOfYear& other_element) function 10 times..." << endl; //7,16,21,22,25

    cout << endl << "Printing set before subtracting elements:" << endl << Set17 << endl; 
    cout << "Trying to subtract element: " ; elm23.printElement(); Set17 = Set17 - elm23; cout << endl;
    cout << "Trying to subtract element: " ; elm8.printElement(); Set17 = Set17 - elm8; cout << endl;
    cout << "Trying to subtract element: " ; elm1.printElement(); Set17 = Set17 - elm1; cout << endl;
    cout << "Trying to subtract element: " ; elm2.printElement(); Set17 = Set17 - elm2; cout << endl;
    cout << "Trying to subtract element: " ; elm15.printElement(); Set17 = Set17 - elm15; cout << endl;
    cout << endl << "Printing set after having subtracted elements:" << endl << Set17 << endl;

    cout << endl << "Printing set before subtracting elements:" << endl << Set23 << endl; 
    cout << "Trying to subtract element: " ; elm17.printElement(); Set23 = Set23 - elm17; cout << endl;//
    cout << "Trying to subtract element: " ; elm16.printElement(); Set23 = Set23 - elm16; cout << endl;
    cout << "Trying to subtract element: " ; elm10.printElement(); Set23 = Set23 - elm10; cout << endl;//
    cout << "Trying to subtract element: " ; elm9.printElement(); Set23 = Set23 - elm9; cout << endl;
    cout << "Trying to subtract element: " ; elm8.printElement(); Set23 = Set23 - elm8; cout << endl;
    cout << endl << "Printing set after having subtracted elements:" << endl << Set23 << endl;
    cout << endl << "------------------------------------------------------------" << endl;

    /* Testing operator-(const DayofYearSet& otherSet) function */
    cout << "Testing operator-(const DayofYearSet& otherSet) function 5 times..." << endl;

    cout << endl << "Sets before calling the function..." << endl << Set18 << endl << Set16 << endl;
    DayofYearSet Set26 = Set18 - Set16;
    cout << endl << "The resultant set:" << endl << Set26 << endl; 

    cout << endl << "Sets before calling the function..." << endl << Set21 << endl << Set22 << endl;
    DayofYearSet Set27 = Set21 - Set22;
    cout << endl << "The resultant set:" << endl << Set27 << endl; 

    cout << endl << "Sets before calling the function..." << endl << Set20 << endl << Set10 << endl;
    DayofYearSet Set28 = Set20 - Set10;
    cout << endl << "The resultant set:" << endl << Set28 << endl;

    cout << endl << "Sets before calling the function..." << endl << Set2 << endl << Set1 << endl;
    DayofYearSet Set29 = Set2 - Set1;
    cout << endl << "The resultant set:" << endl << Set29 << endl; 

    cout << endl << "Sets before calling the function..." << endl << Set23 << endl << Set17 << endl;
    DayofYearSet Set30 = Set23 - Set17;
    cout << endl << "The resultant set:" << endl << Set30 << endl;
    cout << endl << "------------------------------------------------------------" << endl;

    /* Testing operator^(const DayofYearSet& other_set) function */
    cout << "Testing operator^(const DayofYearSet& other_set) function 5 times..." << endl;

    cout << endl << "Sets before calling the function..." << endl << Set19 << endl << Set1 << endl;
    Set2 = Set19 ^ Set1;
    cout << endl << "The resultant set:" << endl << Set2 << endl; //

    cout << endl << "Sets before calling the function..." << endl << Set22 << endl << Set23 << endl;
    Set6 = Set22 ^ Set23;
    cout << endl << "The resultant set:" << endl << Set6 << endl; //

    cout << endl << "Sets before calling the function..." << endl << Set3 << endl << Set30 << endl;
    Set7 = Set3 ^ Set30;
    cout << endl << "The resultant set:" << endl << Set7 << endl; //

    cout << endl << "Sets before calling the function..." << endl << Set18 << endl << Set24 << endl;
    Set9 = Set18 ^ Set24;
    cout << endl << "The resultant set:" << endl << Set9 << endl; //

    cout << endl << "Sets before calling the function..." << endl << Set2 << endl << Set6 << endl;
    Set16 = Set2 ^ Set6;
    cout << endl << "The resultant set:" << endl << Set16 << endl;
    cout << endl << "------------------------------------------------------------" << endl;

    /* Testing operator!() function */
    cout << "Testing operator!() function 4 times..." << endl;
    
    cout << endl << "Set before calling the function..." << endl << Set7 << endl;
    Set30 = (!Set7);
    cout << endl << "The resultant set:" << endl << Set30 << endl; 

    cout << endl << "Set before calling the function..." << endl << Set28 << endl;
    Set29 = (!Set28);
    cout << endl << "The resultant set:" << endl << Set29 << endl; 

    cout << endl << "Set before calling the function..." << endl << Set9 << endl ;
    Set28 = (!Set9);
    cout << endl << "The resultant set:" << endl << Set28 << endl; 

    cout << endl << "Set before calling the function..." << endl << Set5 << endl ;
    Set27 = (!Set5);
    cout << endl << "The resultant set:" << endl << Set27 << endl; 
    cout << endl << "------------------------------------------------------------" << endl;

    /* Testing operator[](int pos) function */
    cout << "Testing operator[](int pos) function 9 times..." << endl;
    cout << "The set:" << endl << Set26 << endl;
    for(auto i=0; i<6; i++) {
        cout << endl << "Element in " << i << ". index: "; Set26[i].printElement(); cout << endl;
    }
    
    cout << endl << "Element in 55. index: "; Set26[55].printElement(); cout << endl;
    cout << endl << "Element in 65. index: "; Set26[65].printElement(); cout << endl;
    cout << endl << "Element in -7. index: "; Set26[-7].printElement(); cout << endl;
    cout << endl << "------------------------------------------------------------" << endl; 

    /* Testing remove(const DayOfYear& element) function */
    cout << "Testing remove(const DayOfYear& element) function 10 times..." << endl; 

    cout << endl << "Printing set before subtracting elements:" << endl << Set23 << endl; 
    cout << endl << "Trying to subtract element: " ; elm23.printElement(); Set23.remove(elm23); cout << endl;
    cout << "Trying to subtract element: " ; elm4.printElement(); Set23.remove(elm4); cout << endl;
    cout << "Trying to subtract element: " ; elm6.printElement(); Set23.remove(elm6); cout << endl;
    cout << "Trying to subtract element: " ; elm11.printElement(); Set23.remove(elm11); cout << endl;
    cout << "Trying to subtract element: " ; elm22.printElement(); Set23.remove(elm22); cout << endl;
    cout << endl << "Printing set after having subtracted elements:" << endl << Set23 << endl;

    cout << endl << "Printing set before subtracting elements:" << endl << Set17 << endl; 
    cout << endl << "Trying to subtract element: " ; elm15.printElement(); Set17.remove(elm15); cout << endl;
    cout << "Trying to subtract element: " ; elm13.printElement(); Set17.remove(elm13); cout << endl; 
    cout << "Trying to subtract element: " ; elm12.printElement(); Set17.remove(elm12); cout << endl;
    cout << "Trying to subtract element: " ; elm16.printElement(); Set17.remove(elm16); cout << endl; 
    cout << "Trying to subtract element: " ; elm11.printElement(); Set17.remove(elm11); cout << endl; 
    cout << endl << "Printing set after having subtracted elements:" << endl << Set17 << endl;
    cout << endl << "------------------------------------------------------------" << endl; 

    /* Testing size() function */
    cout << "Testing size() function 5 times..." << endl;
    cout << endl << "Printing sets and their sizes respectively..." << endl;
    cout << endl << "The set:" << endl << Set8 << endl << "Size = " << Set8.size() << endl;
    cout << endl << "The set:" << endl << Set22 << endl << "Size = " << Set22.size() << endl;
    cout << endl << "The set:" << endl << Set5 << endl << "Size = " << Set5.size() << endl;
    cout << endl << "The set:" << endl << Set6 << endl << "Size = " << Set6.size() << endl;
    cout << endl << "The set:" << endl << Set30 << endl << "Size = " << Set30.size() << endl; 
    cout << endl << "------------------------------------------------------------" << endl;

    /* Testing byValue(T parameter) function */
    cout << "Testing byValue(T parameter) function with the functions that take objects as an argument and with some variables 14 times..." << endl; 
  
    cout << "Calling DayofYearSet(const std::list<DayOfYear> &my_elements) constructor using CALL BY REFERENCE with" <<
    " the elements (DayOfYear objects) below:" << endl;
    elm15.printElement(); cout << endl; elm7.printElement(); cout << endl; elm3.printElement(); cout << endl;
    elm4.printElement(); cout << endl; elm12.printElement(); cout << endl; 
    DayofYearSet Set33({elm15,elm7,elm3,elm4,elm12});
    cout << "The resultant set: " << endl << Set33 << endl;
    cout << "Creating copies of the elements (DayOfYear objects) with the help of byValue() function..." << endl;
    elm27 = DayofYearSet:: byValue(elm15); elm26 = DayofYearSet:: byValue(elm7); elm25 = DayofYearSet:: byValue(elm3); 
    elm24 = DayofYearSet:: byValue(elm4); elm23 = DayofYearSet:: byValue(elm12);
    cout << "Newly created elements (DayOfYear objects) with the help of byValue() function:" << endl;
    elm27.printElement(); cout << endl; elm26.printElement(); cout << endl; elm25.printElement(); cout << endl;
    elm24.printElement(); cout << endl; elm23.printElement(); cout << endl; 
    cout << "Calling DayofYearSet(const std::list<DayOfYear> &my_elements) constructor using CALL BY VALUE with" <<
    " the newly created elements above..." << endl;
    DayofYearSet Set34({elm27,elm26,elm25,elm24,elm23});
    cout << "The resultant set: " << endl << Set34 << endl;
    cout << "In this case, there is no difference between calling DayofYearSet(const std::list<DayOfYear> &my_elements)" <<
    " constructor with CALL BY VALUE and CALL BY REFERENCE." << endl;


    cout << endl << "Calling DayofYearSet(const DayofYearSet& otherDay) constructor (it copies one object to another) " 
    << "using CALL BY REFERENCE with the set: " << endl << Set1 << endl;
    DayofYearSet Set31(Set1);
    cout << "Newly created set with the help of the constructor:" << endl << Set31 << endl;
    cout << "Creating copy of the set with the help of byValue() function..." << endl;
    Set3 = DayofYearSet:: byValue(Set1);
    cout << "Newly created set with the help of byValue() function: " << endl << Set3;
    cout << endl << "Calling DayofYearSet(const DayofYearSet& otherDay) constructor (it copies one object to another)" << 
    "using CALL BY VALUE with the newly created set..." << endl;
    DayofYearSet Set32(Set3);
    cout << "Newly created set with the help of the constructor:" << endl << Set32 << endl;
    cout << "All objects created by the constructor are the same. In this case, there is no difference between "<<
    "calling DayofYearSet(const DayofYearSet& otherDay) constructor with CALL BY VALUE and CALL BY REFERENCE. " << endl;

    cout << endl << "Calling operator<<(std::ostream& os, const DayofYearSet& DaySet) function with CALL BY REFERENCE..." << endl << Set2 << endl;
    cout << "Creating copy of the set above with the help of byValue() function..." << endl;
    Set4 = DayofYearSet:: byValue(Set2);
    cout << "Newly created set with the help of byValue() function: " << endl << Set4 << endl;
    cout << "Calling operator<<(std::ostream& os, const DayofYearSet& DaySet) function with the newly created set using CALL BY VALUE..." << endl << Set4 << endl;
    cout << "In this case, there is no difference between calling operator<<(std::ostream& os, const DayofYearSet& DaySet) function with CALL BY VALUE " <<
    "and CALL BY REFERENCE." << endl;

    cout << endl << "Calling operator==(const DayofYearSet& DaySet1, const DayofYearSet& DaySet2) function with CALL BY REFERENCE with these sets:" << endl;
    cout << Set18 << endl << Set15 << endl << "Result: ";
    if(Set18 == Set15) cout << "They are equal." << endl;
    else cout << "They are not equal." << endl;
    cout << "Creating copy of the sets above with the help of byValue() function..." << endl;
    Set5 = DayofYearSet:: byValue(Set18);
    Set11 = DayofYearSet:: byValue(Set15);
    cout << "Newly created sets with the help of byValue() function: " << endl << Set5 << endl << Set11 << endl;
    cout << "Calling operator==(const DayofYearSet& DaySet1, const DayofYearSet& DaySet2) function with the newly created sets using CALL BY VALUE..." << endl << "Result: ";
    if(Set5 == Set11) cout << "They are equal." << endl;
    else cout << "They are not equal." << endl;
    cout << "In this case, there is no difference between calling operator==(const DayofYearSet& DaySet1, const DayofYearSet& DaySet2) function with CALL BY VALUE " <<
    "and CALL BY REFERENCE." << endl;

    cout << endl << "Calling operator!=(const DayofYearSet& DaySet1, const DayofYearSet& DaySet2) function with CALL BY REFERENCE with these sets:" << endl;
    cout << Set23 << endl << Set21 << endl << "Result: ";
    if(Set23 != Set21) cout << "They are not equal." << endl;
    else cout << "They are equal." << endl;
    cout << "Creating copy of the sets above with the help of byValue() function..." << endl;
    Set12 = DayofYearSet:: byValue(Set23);
    Set13 = DayofYearSet:: byValue(Set21);
    cout << "Newly created sets with the help of byValue() function: " << endl << Set12 << endl << Set13 << endl;
    cout << "Calling operator!=(const DayofYearSet& DaySet1, const DayofYearSet& DaySet2) function with the newly created sets using CALL BY VALUE..." << endl << "Result: ";
    if(Set12 != Set13) cout << "They are not equal." << endl;
    else cout << "They are equal." << endl;
    cout << "In this case, there is no difference between calling operator!=(const DayofYearSet& DaySet1, const DayofYearSet& DaySet2) function with CALL BY VALUE and"<<
    " CALL BY REFERENCE." << endl;

    cout << endl << "Calling operator+(const DayOfYear& other_element) function with CALL BY REFERENCE using ";
    cout << "the set and these two elements below:" << endl << Set21 << endl; elm4.printElement(); cout << endl;
    elm18.printElement(); cout << endl;
    Set21 = Set21 + elm4;
    Set21 = Set21 + elm18;
    cout << "The resultant set: " << endl << Set21 << endl;
    cout << "Creating copy of the elements (DayOfYear objects) with the help of byValue() function..." << endl;
    elm27 = DayofYearSet:: byValue(elm4);
    elm26 = DayofYearSet:: byValue(elm18);
    cout << "Newly created elements (DayOfYear objects) with the help of byValue() function: " << endl;
    elm27.printElement(); cout << endl; elm26.printElement(); cout << endl;
    cout << "Calling operator+(const DayOfYear& other_element) function with the newly created elements " <<
    "(DayOfYear objects) using CALL BY VALUE..." << endl;
    Set21 = Set21 + elm27;
    Set21 = Set21 + elm26;
    cout << "The resultant set: " << endl << Set21 << endl;
    cout << "In this case, there is no difference between calling operator+(const DayOfYear& other_element) function" << 
    " with CALL BY VALUE and CALL BY REFERENCE." << endl;

    cout << endl << "Calling operator+(const DayofYearSet& otherSet) function with CALL BY REFERENCE using the sets:" << endl;
    cout << Set3 << endl << Set5 << endl;
    Set14 = Set3 + Set5;
    cout << "The resultant set: " << endl << Set14 << endl;
    cout << "Creating the copy of the sent as an argument operand with the help of byValue() function..." << endl;
    Set17 = DayofYearSet:: byValue(Set5);
    cout << "Newly created set: " << endl << Set17 << endl;
    cout << "Calling operator+(const DayofYearSet& otherSet) function with CALL BY VALUE using the newly created set...";
    Set14 = Set3  + Set17;
    cout << endl << "The resultant set: " << endl << Set14 << endl;
    cout << "In this case, there is no difference between calling operator+(const DayofYearSet& otherSet) function with "
    "CALL BY VALUE and CALL BY REFERENCE." << endl;

    cout << endl << "Calling operator-(const DayOfYear& other_element) function with CALL BY REFERENCE using ";
    cout << "the set and these two elements below:" << endl << Set6 << endl; elm1.printElement(); cout << endl;
    elm11.printElement(); cout << endl;
    Set6 = Set6 - elm1;
    Set6 = Set6 - elm11;
    cout << "The resultant set: " << endl << Set6 << endl;
    cout << "Creating copy of the elements (DayOfYear objects) with the help of byValue() function..." << endl;
    elm25 = DayofYearSet:: byValue(elm1);
    elm26 = DayofYearSet:: byValue(elm11);
    cout << "Newly created elements (DayOfYear objects) with the help of byValue() function: " << endl;
    elm25.printElement(); cout << endl; elm26.printElement(); cout << endl;
    cout << "Calling operator-(const DayOfYear& other_element) function with the newly created elements " <<
    "(DayOfYear objects) using CALL BY VALUE..." << endl;
    Set6 = Set6 - elm25;
    Set6 = Set6 - elm26;
    cout << "The resultant set: " << endl << Set6 << endl;
    cout << "In this case, there is no difference between calling operator-(const DayOfYear& other_element) function" << 
    " with CALL BY VALUE and CALL BY REFERENCE." << endl; 


    cout << endl << "Calling operator-(const DayofYearSet& otherSet) function with CALL BY REFERENCE using the sets:" << endl;
    cout << Set24 << endl << Set23 << endl;
    Set17 = Set24 - Set23;
    cout << "The resultant set: " << endl << Set17 << endl;
    cout << "Creating the copy of the sent as an argument operand with the help of byValue() function..." << endl;
    Set14 = DayofYearSet:: byValue(Set23);
    cout << "Newly created set: " << endl << Set14 << endl;
    cout << "Calling operator-(const DayofYearSet& otherSet) function with CALL BY VALUE using the newly created set...";
    Set17 = Set24  - Set14;
    cout << endl << "The resultant set: " << endl << Set17 << endl;
    cout << "In this case, there is no difference between calling operator-(const DayofYearSet& otherSet) function with "
    "CALL BY VALUE and CALL BY REFERENCE." << endl;

    cout << endl << "Calling operator^(const DayofYearSet& other_set) function with CALL BY REFERENCE using the sets:" << endl;
    cout << Set19 << endl << Set20 << endl;
    Set13 = Set19 ^ Set20;
    cout << "The resultant set: " << endl << Set13 << endl;
    cout << "Creating the copy of the sent as an argument operand with the help of byValue() function..." << endl;
    Set14 = DayofYearSet:: byValue(Set20);
    cout << "Newly created set: " << endl << Set14 << endl;
    cout << "Calling operator^(const DayofYearSet& other_set) function with CALL BY VALUE using the newly created set...";
    Set13 = Set19  ^ Set14;
    cout << endl << "The resultant set: " << endl << Set13 << endl;
    cout << "In this case, there is no difference between calling operator^(const DayofYearSet& other_set) function with "
    "CALL BY VALUE and CALL BY REFERENCE." << endl;

    cout << endl << "Calling remove(const DayOfYear& element) function with CALL BY REFERENCE using the set and the " <<
    "elements (DayOfYear objects): " << endl; 
    cout << Set18 << endl; elm19.printElement(); cout << endl; elm13.printElement(); cout << endl;
    Set18.remove(elm19);
    Set18.remove(elm13);
    cout << "The resultant set: " << endl << Set18 << endl;
    cout << "Creating copy of the elements (DayOfYear objects) with the help of byValue() function..." << endl;
    elm23 = DayofYearSet:: byValue(elm19);
    elm24 = DayofYearSet:: byValue(elm13);
    cout << "Newly created elements (DayOfYear objects) with the help of byValue() function: " << endl;
    elm23.printElement(); cout << endl; elm24.printElement(); cout << endl;
    cout << "Calling remove(const DayOfYear& element) function with the newly created elements " <<
    "(DayOfYear objects) using CALL BY VALUE..." << endl;
    Set18.remove(elm23);
    Set18.remove(elm24);
    cout << "The resultant set: " << endl << Set18 << endl;
    cout << "In this case, there is no difference between calling remove(const DayOfYear& element) function" << 
    " with CALL BY VALUE and CALL BY REFERENCE." << endl; 


    int val1 = 2, val2;
    cout << endl << "The variable before calling the function: " << val1 << endl; 
    cout << "Getting copy of the variable with the help of byValue() function...." << endl; val2 = Set1.byValue(val1);
    cout << "Assigning 5 to the copy..." << endl; val2 = 5;
    cout << "The value of copy: " << val2 << endl;
    cout << "The value of the variable itself: " << val1 << endl;
    cout << "Notice they are different." << endl;

    char val3 = 'b', val4 = 'k';
    cout << endl << "The variable before calling the function: " << val3 << endl; 
    cout << "Getting copy of the variable with the help of byValue() function...." << endl; val4 = Set1.byValue(val3);
    cout << "Assigning the char y to the copy..." << endl; val4 = 'y';
    cout << "The value of copy: " << val4 << endl;
    cout << "The value of the variable itself: " << val3 << endl;
    cout << "Notice they are different." << endl;

    string line1("araba"), line2;
    cout << endl << "The string before calling the function: " << line1 << endl; 
    cout << "Getting copy of the string with the help of byValue() function...." << endl; line2 = Set1.byValue(line1);
    cout << "Assigning the string kalem to the copy..." << endl; line2 = "kalem";
    cout << "Copy of the string: " << line2 << endl;
    cout << "The string itself: " << line1 << endl;
    cout << "Notice they are different." << endl;
    cout << endl << "------------------------------------------------------------" << endl;


    /* Testing get_set_name() function */
    cout << "Testing get_set_name() function 5 times..." << endl;
    cout << endl << "The set before calling the function:" << endl << Set1 << endl;
    cout << "Calling the function to modify set name...";
    Set1.get_set_name();
    cout << "The set: " << endl << Set1 << endl;

    cout << endl << "The set before calling the function:" << endl << Set2 << endl;
    cout << "Calling the function to modify set name...";
    Set2.get_set_name();
    cout << "The set: " << endl << Set2 << endl;

    cout << endl << "The set before calling the function:" << endl << Set3 << endl;
    cout << "Calling the function to modify set name...";
    Set3.get_set_name();
    cout << "The set: " << endl << Set3 << endl;

    cout << endl << "The set before calling the function:" << endl << Set4 << endl;
    cout << "Calling the function to modify set name...";
    Set4.get_set_name();
    cout << "The set: " << endl << Set4 << endl;

    cout << endl << "The set before calling the function:" << endl << Set5 << endl;
    cout << "Calling the function to modify set name...";
    Set5.get_set_name();
    cout << "The set: " << endl << Set5 << endl;
    cout << endl << "------------------------------------------------------------" << endl;

    /* Testing reconstruct_array(int newSize, DayOfYear* temp, string name_of_set) function */
    cout << "Testing reconstruct_array(int newSize, DayOfYear* temp, string name_of_set) function 4 times..." << endl;
    cout << "This function assumes that the array's all elements are different from each other." << endl;
    cout << "This function deletes temp array in itself." << endl;
    DayofYearSet:: DayOfYear* temp = new DayofYearSet:: DayOfYear[15];


    cout << endl << "Printing the set before calling function:" << endl << Set17 << endl;
    cout << endl << "Calling the function without adding any element to the temp array to reconstruct the set with temp array..." << endl; 
    Set17.reconstruct_array(0,temp,"New1"); 
    cout << "The newly constructed set:" << endl << Set17 << endl << endl;

    
    DayofYearSet:: DayOfYear* temp1 = new DayofYearSet:: DayOfYear[15];   
    cout << endl << "Printing the set before calling function:" << endl << Set7 << endl << endl;

    for(auto i=0; i<5; i++) {
        cout << "Assigning "; Set15[i].printElement(); cout << " to " << i << ". index of temp array" << endl; 
        temp1[i] = Set15[i];
    }

    cout << endl << "Calling the function to reconstruct the set with temp array..." << endl; 
    Set7.reconstruct_array(5,temp1,"New2"); 
    cout << "The newly constructed set:" << endl << Set7 << endl << endl; 
    

    DayofYearSet:: DayOfYear* temp2 = new DayofYearSet:: DayOfYear[15];   
    cout << endl << "Printing the set before calling function:" << endl << Set16 << endl << endl;
    cout << "Assigning "; elm5.printElement(); cout << " to 0. index of temp array" << endl;
    temp2[0] = elm5;
    cout << "Assigning "; elm18.printElement(); cout << " to 1. index of temp array" << endl;
    temp2[1] = elm18;
    cout << "Assigning "; elm4.printElement(); cout << " to 2. index of temp array" << endl;
    temp2[2] = elm4;
    cout << "Assigning "; elm17.printElement(); cout << " to 3. index of temp array" << endl;
    temp2[3] = elm17;
    cout << "Assigning "; elm2.printElement(); cout << " to 4. index of temp array" << endl;
    temp2[4] = elm2;
    

    cout << endl << "Calling the function to reconstruct the set with temp array..." << endl; 
    Set16.reconstruct_array(5,temp2,"New3"); 
    cout << "The newly constructed set:" << endl << Set16 << endl << endl;
  

    DayofYearSet:: DayOfYear* temp3 = new DayofYearSet:: DayOfYear[15];   
    cout << endl << "Printing the set before calling function:" << endl << Set2 << endl << endl;
    cout << "Assigning "; elm15.printElement(); cout << " to 0. index of temp array" << endl;
    temp3[0] = elm15;
    cout << "Assigning "; elm12.printElement(); cout << " to 1. index of temp array" << endl;
    temp3[1] = elm12;
    cout << "Assigning "; elm8.printElement(); cout << " to 2. index of temp array" << endl;
    temp3[2] = elm8;
    cout << "Assigning "; elm7.printElement(); cout << " to 3. index of temp array" << endl;
    temp3[3] = elm7;
    cout << "Assigning "; elm16.printElement(); cout << " to 4. index of temp array" << endl;
    temp3[4] = elm16;
    cout << "Assigning "; elm1.printElement(); cout << " to 5. index of temp array" << endl;
    temp3[5] = elm1;

    cout << endl << "Calling the function to reconstruct the set with temp array..." << endl; 
    Set2.reconstruct_array(6,temp3,"New4"); 
    cout << "The newly constructed set:" << endl << Set2 << endl << endl;
    cout << endl << "------------------------------------------------------------" << endl;

    /* Testing GetMonthName(const int &month) function */
    cout << "Testing GetMonthName(const int &month) function 5 times..." << endl;

    cout << endl << "Month value: " << elm27.getMonthNum() << endl;
    cout << "Month name: " << elm27.GetMonthName(elm27.getMonthNum()) << endl;

    cout << endl << "Month value: " << elm26.getMonthNum() << endl;
    cout << "Month name: " << elm26.GetMonthName(elm26.getMonthNum()) << endl;

    cout << endl << "Month value: " << elm25.getMonthNum() << endl;
    cout << "Month name: " << elm25.GetMonthName(elm25.getMonthNum()) << endl;

    cout << endl << "Month value: " << elm24.getMonthNum() << endl;
    cout << "Month name: " << elm24.GetMonthName(elm24.getMonthNum()) << endl;

    cout << endl << "Month value: " << elm23.getMonthNum() << endl;
    cout << "Month name: " << elm23.GetMonthName(elm23.getMonthNum()) << endl;

    /* Filling the array with all having created sets (DayofYearSet objects) so far. */
    DayofYearSet my_sets[34] = {Set1,Set2, Set3, Set4, Set5, Set6, Set7, Set8, Set9, Set10, Set11, Set12, Set13, Set14,
    Set15, Set16, Set17, Set18, Set19, Set20, Set21, Set22, Set23, Set24, Set25, Set26, Set27, Set28, Set29, Set30,
    Set31,Set32, Set33, Set34};


    std::ofstream write_file;
    bool file_success = true;
    
    if(write_text == true) {

        write_file.open("results.txt");  /* Opening text file */
        
        /* Handling the case in which the file is not opened */
        if(!write_file) {
            cout << endl << "File could not be opened..." << endl;
            file_success = false;
        } 
    }

    /* Writing the program output to the text file */
    if(file_success == true) {
        
        /* Filling the array with all having created set elements (DayOfYear objects) so far. */
        DayofYearSet::DayOfYear my_elements[27] = {elm1, elm2, elm3, elm4, elm5 ,elm6, elm7, elm8, elm9, elm10, elm11,
        elm12, elm13, elm14, elm15, elm16, elm17, elm18, elm19, elm20, elm21, elm22, elm23, elm24, elm25, elm26, elm27};
        
        /* Writing having created set elements (DayOfYear objects) so far to text file */
        write_file << "Having created elements (DayOfYear objects) during the program respectively:" << endl;
        for(auto i=0; i<27; i++) { 
            write_file << i+1 << ".Element: "<< my_elements[i].getDayNum() << " " << 
            DayofYearSet::DayOfYear:: GetMonthName(my_elements[i].getMonthNum()) << endl;
        }
        

        /* Writing having created sets (DayofYearSet objects) so far to text file */
        write_file << endl << "Having created and constructed sets during the program respectively:" << endl;
        for(auto i=0; i<34; i++) {
            write_file << endl << i+1 << ".Set: " << endl << my_sets[i] << endl;
        }


        write_file.close(); /* Closing text file */
    }

    cout << endl << "------------------------------------------------------------" << endl;

    /* Testing deallocate() function */
    cout << endl << "Testing deallocate() function 34 times..." << endl;
    for(auto i=0; i<34; i++) {
        my_sets[i].deallocate();
    }

    cout << "All DayOfYear* data members have been deallocated." << endl;
    cout << endl << "------------------------------------------------------------" << endl;

    return 0;
}





