#include "DayofYearSet.h"

namespace SetOperation {

    /* Returning month name according to month value */
    string DayofYearSet::DayOfYear:: GetMonthName(const int &month) {
        string month_name;

        /* Deciding the month name */
        switch(month) {
            case 1: month_name = "January"; break;
            case 2: month_name =  "February"; break;
            case 3: month_name =  "March"; break;
            case 4: month_name = "April"; break;
            case 5: month_name = "May"; break;
            case 6: month_name = "June"; break;
            case 7: month_name =  "July"; break;
            case 8: month_name = "August"; break;
            case 9: month_name =  "September"; break;
            case 10: month_name = "October"; break;
            case 11: month_name =  "November"; break;
            case 12:month_name =  "December"; break;
        }

        return month_name; /* Returning the month name */
    }


    /* Printing DayOfYear object's private day_ and month_ variable */
    void DayofYearSet::DayOfYear:: printElement() const {
        cout << day_ << " " ;
        cout << DayofYearSet::DayOfYear:: GetMonthName(month_) ;

    }


    /* Initializing the desired date which will be kept in DayOfYear object */
    DayofYearSet::DayOfYear:: DayOfYear(int day, int month) { 
    
        bool validation = false;

        while(validation == false) {
            validation = ValidateDate(month,day);  /* Checking whether the date is valid or not */

            /* Handling the case in which date is valid */
            if(validation == true) {
                month_ = month;
                day_ = day;
                break;
            }
        
            /* Handling the case in which date is not valid */
            else {
                int choice;
                bool flag = false;
                cout << "Desired date is not valid..." << endl;
            
            
                while(flag == false) {

                    /* Asking the user how they desire to handle the case in which date is unvalid */
                    cout << endl << "   1.Terminate the program due to unvalid date" << endl;
                    cout << "   2.Get another valid date from the user";
                    cout << endl << "Enter 1 or 2: ";
                    cin >> choice;

                    /* Validating input */
                    if((cin.get() != '\n') || (cin.fail() == 1)) {
                        cin.clear();
                        cin.ignore(max_int_val,'\n');
                        cout << "Unvalid input" << endl;  
                        continue;
                    }

                    else if(choice != 1 && choice != 2) {
                        cout << "Unvalid input" << endl;  
                        continue;
                    }

                    else {
                        flag = true;
                        break;
                    }
                }
            
                /* Terminating the program before allocating any memory dynamically in the program */
                if(choice == 1) exit(0);  


                /* Getting a valid date from user as an input */
                DayOfYear obj("specify");
                day_ = obj.day_;
                month_ = obj.month_;
                validation = true;
            
            }

        }

    }


    /* Initializing the date with the input which will be get from the user */
    DayofYearSet:: DayOfYear:: DayOfYear(const string get_input) { 

        cout << endl << "Please specify date and month..." << endl;
        if(get_input == "specify") {
            int choice;
            bool flag = false;

            flag = false;
            while(flag == false) {

                /* Getting day value */
                cout << "Enter day (1-31): ";
                cin >> day_;
                month_ = 1;

                /* Validating user input */
                if((cin.get() != '\n') || (cin.fail() == 1)) {
                    cin.clear();
                    cin.ignore(max_int_val,'\n');
                    cout << "Unvalid input" << endl;  
                    continue;
                }

                else {
                    flag = ValidateDate(month_, day_);  /* Checking whether the date is valid or not */

                    if(flag == true) {

                        flag = false;
                        while(flag == false) {

                            /* Getting month value */
                            cout << "Enter month (1-12): ";
                            cin >> month_;

                            /* Validating user input */
                            if((cin.get() != '\n') || (cin.fail() == 1)) {
                                cin.clear();
                                cin.ignore(max_int_val,'\n');
                                cout << "Unvalid input" << endl;  
                                continue;
                            }

                            else {
                                flag = ValidateDate(month_, day_); /* Checking whether the date is valid or not */
                            }
                        }
                    
                    }
               
                }

            }
        }
    }


    /* Checking whether the date is valid or not */
    bool DayofYearSet::DayOfYear:: ValidateDate(const int month, const int day) const { 

        /* Checking month and day variables */
        if(month < 1 || month > 12) {
            cout << "Invalid month value" << endl;
            return false;
        }

        if (day < 1 || day > 31) {
            cout << "Invalid day value" << endl;
            return false;
        }

        if(month == 2 && day>29) {
            cout << "Invalid day value" << endl;
            return false;
        } 

        if(month == 4 || month == 6 || month == 9 || month == 11) {
            if(day == 31) {
                cout << "Invalid month value" << endl;
                return false;
            }
        }

        return true;

    }


    /* Getting set name from the user */
    void DayofYearSet:: get_set_name() { 

        bool flag = false;
        bool white_space_check = false;

        while((flag && white_space_check) == false) {
            flag = true;
            cout << endl << "Enter a name for the set (Uppercase letter is highly recommended): ";

            /* Getting set name from the user */
            getline(cin, set_name);  

            /* Handling the case in which entered string is empty and not valid */
            if(set_name.length() == 0 || set_name.empty()) {
                cout << "You did not enter a valid name." << endl;
                flag = false;
                continue;
            } 

            int length = set_name.length();
            white_space_check = false;


            /* Handling the case in which entered string consists of only white space characters and is not valid */
            for(decltype(length) i=0; i<length; i++) {
                if(set_name[i] != ' ' && set_name[i] != '\n' && set_name[i] != '\t') {
                    white_space_check = true;
                    break;
                }
            }

            if(white_space_check == false) {
                cout << "Set name are not allowed to consist of only white spaces." << endl;
            }
        
        }
    }

    /* Copying a DayofYearSet object to another DayofYearSet object such that they have the same contents */
    DayofYearSet:: DayofYearSet(const DayofYearSet& otherDay) { 

        /* Copying all contents of the DayofYearSet object to another DayofYearSet object */
        num_of_elements = otherDay.num_of_elements;
        my_set_elements = new DayOfYear[num_of_elements];
        num_of_sets_in_it = otherDay.num_of_sets_in_it;  /* Indicating how many different sets in it (like (A n B))*/

        for(auto j=0; j<num_of_elements; j++) {
            my_set_elements[j] = otherDay.my_set_elements[j];
        }

        set_name = otherDay.set_name;
    }

    /* Creating a set (DayofYearSet object) whose size is 1 (being capable of carrying 1 DayOfYear object) but is empty */
    DayofYearSet:: DayofYearSet() { 

        num_of_elements = 0;
        my_set_elements = new DayOfYear[1];
        num_of_sets_in_it = 1;
        get_set_name();  /* Getting set name from the user */
    }


    /* Creating a set (DayofYearSet object) using list elements */
    DayofYearSet:: DayofYearSet(const std::list<DayOfYear> &my_elements) { 

        int index = 0;
        bool adding_success = true;

        num_of_elements = 0;
        my_set_elements = new DayOfYear[my_elements.size()];
        num_of_sets_in_it = 1;  /* Indicating how many different sets in it (like (A n B))*/
        DayOfYear* temp = new DayOfYear[my_elements.size()];

        get_set_name(); /* Getting set name from the user */

        /* Going through list elements */
        for (const auto& date1 : my_elements) {

            adding_success = true;

            /* Checking whether the list element is already in the set */
            for(decltype(index) i=0; i<num_of_elements; i++) {

                /* Comparing elements kept in the sets one by one */
                if(date1.getDayNum() == temp[i].getDayNum()) {
                    if(date1.getMonthNum() == temp[i].getMonthNum()) {
                        adding_success = false;
                        cout << endl; date1.printElement();
                        cout << " is not added to avoid duplicate elements..." << endl;
                        break;
                    
                    }
                }
            }

            /* Adding the particular list element to the set */
            if(adding_success == true) {
                num_of_elements++;
                temp[index] = date1;
                index++;
            }
        }

        /* Constructing the set kept in DayofYearSet object */
        reconstruct_array(num_of_elements,temp,set_name);
 
    }


    /* Printing DayofYearSet details */
    std::ostream& operator<<(std::ostream& os, const DayofYearSet& DaySet) { 
   
        int set_size = DaySet.size();  /* Getting size of set */

        /* Printing set name */
        os << DaySet.set_name << " = { ";  

        for(decltype(set_size) i=0; i<set_size; i++) {
            os << DaySet.my_set_elements[i].getDayNum() << " " <<  /* Printing day value */
            DayofYearSet::DayOfYear:: GetMonthName(DaySet.my_set_elements[i].getMonthNum());  /* Printing month value */

            if(i != (set_size-1)) os << ", ";
        }

        os << " } ";
        return os;
    
    }

    /* Comparing DayofYearSet objects and sets kept in them */
    bool operator==(const DayofYearSet& DaySet1, const DayofYearSet& DaySet2) { 

        int size_set1 = DaySet1.size(); /* Getting size of set */
        int size_set2 = DaySet2.size(); /* Getting size of set */
        bool flag = false;

        /* Handling the case in which the sets are not equal due to their different sizes */
        if(size_set1 != size_set2) return false; 
    
        /* Going through the two sets */
        for(decltype(size_set1) i=0; i<size_set1; i++) {
            flag = false;

            for(decltype(size_set2) j=0; j<size_set2; j++) {

                /* Comparing elements kept in the sets one by one */
                if(DaySet1.my_set_elements[i].getDayNum() == DaySet2.my_set_elements[j].getDayNum()) {
                    if(DaySet1.my_set_elements[i].getMonthNum() == DaySet2.my_set_elements[j].getMonthNum()){
                        flag = true;
                        break;
                    }
                }
            }

            if(flag == false) return false; /* When an element is absent in other set, the sets are not equal. */
        }
    
        return true;
    }


    /* Comparing DayofYearSet objects and sets kept in them */
    bool operator!=(const DayofYearSet& DaySet1, const DayofYearSet& DaySet2) { 

        int size_set1 = DaySet1.size(); /* Getting size of set */
        int size_set2 = DaySet2.size(); /* Getting size of set */
        bool found = false;

        /* Handling the case in which the sets are not equal due to their different sizes */
        if(size_set1 != size_set2) return true; 

        /* Going through the two sets */
        for(decltype(size_set1) i=0; i<size_set1; i++) {

            found = false;
            for(decltype(size_set2) j=0; j<size_set2; j++) {

                /* Comparing elements kept in the sets one by one */
                if(DaySet1.my_set_elements[i].getDayNum() == DaySet2.my_set_elements[j].getDayNum()) {
                    if(DaySet1.my_set_elements[i].getMonthNum() == DaySet2.my_set_elements[j].getMonthNum()){
                        found = true;
                        break;
                    }
                } 
            }

            if(found == false) return true; /* When an element is absent in other set, the sets are not equal. */
        }
    
        return false;
    }


    /* Constructing the set kept in DayofYearSet object */
    void DayofYearSet:: reconstruct_array(int newSize, DayOfYear* temp, string name_of_set) { 

        delete[] my_set_elements;  /* Deleting the set */
        my_set_elements = new DayOfYear[newSize]; /* Dynamicaly allocating memory to the set */
        num_of_elements = newSize; /* Assigning the size */
        set_name = name_of_set;    /* Assigning the set name */

        /* Assigning new set elements kept in temp array to the set */
        for(auto j=0; j<num_of_elements; j++) {
            my_set_elements[j] = temp[j];
        } 

        delete[]temp; /* Deleting temp array */
    }
 

    /* Adding the new element to the set */
    DayofYearSet DayofYearSet:: operator+(const DayOfYear& other_element)  { 

        bool adding_success = true;
        int size_of_set = size(); /* Getting size of set */

        /* Going through the set */
        for(auto i=0; i<size_of_set; i++) {

            /* Comparing elements one by one */
            if(my_set_elements[i].getDayNum() == other_element.getDayNum()) {
                if(my_set_elements[i].getMonthNum() == other_element.getMonthNum()){
                    adding_success = false;
                    break;
                }
            }
        } 

        /* Handling the case in which adding the element is not valid */
        if(adding_success == false) {
            cout << endl; other_element.printElement();
            cout << " is not added to avoid duplicate elements..." << endl;
        }

        /* Adding the new element to the set */
        else {
            int k=0;
            DayOfYear* temp = new DayOfYear[size_of_set+1];

            for(k=0; k<size_of_set; k++) {
                temp[k] = my_set_elements[k];
            }
            temp[k] = other_element;
            reconstruct_array(size_of_set+1,temp,set_name);  /* Constructing the set kept in DayofYearSet object */
        }

        return *this;
  
    }

    /* Returning the union set */
    DayofYearSet DayofYearSet:: operator+(const DayofYearSet& otherSet) const { 

        DayofYearSet result(*this); /* Calling copy constructor */
        int size_set = size();   /* Getting size of set */
        int other_set_size = otherSet.size(); /* Getting size of set */
        decltype(size_set) temp_index = 0;
        bool adding_success = true;
        DayOfYear* temp = new DayOfYear[size_set + other_set_size]; /* Dynamically allocating memory for temp array */

        /* Adding the elements of the first set to temp array */
        for(decltype(size_set) i=0; i<size_set; i++) {
            temp[temp_index] = my_set_elements[i];
            temp_index++;
        }

        /* Going through the two sets */
        for(decltype(size_set) j=0; j<other_set_size; j++) {

            adding_success = true;
            for(auto k=0; k<temp_index; k++) {

                /* Comparing elements kept in the sets one by one */
                if((otherSet.my_set_elements[j].getDayNum()) == temp[k].getDayNum()) {
                    if((otherSet.my_set_elements[j].getMonthNum()) == temp[k].getMonthNum()) {
                        adding_success = false;
                        break;
                    }
                }
            }

            /* Adding the particular element to temp array */
            if(adding_success == true) {
                temp[temp_index] = otherSet.my_set_elements[j];
                temp_index++;
            }
        }

        /* Indicating how many different sets in the union set (like (A n B)) */
        result.num_of_sets_in_it = otherSet.num_of_sets_in_it + num_of_sets_in_it ;
        string result_name;

        /* Deciding the name of union set according to how many sets in it */
        if(result.num_of_sets_in_it%2 == 0 || (result.num_of_sets_in_it>=3)) {
            result_name = "(" + set_name + " u " + otherSet.set_name + ")";
        }

        else result_name = set_name + " u " + otherSet.set_name ;

        /* Constructing the set kept in DayofYearSet object */
        result.reconstruct_array(temp_index,temp,result_name); 
   
        return result; /* Returning result object */
    }


    /* Subtracting the element from the set */
    DayofYearSet DayofYearSet:: operator-(const DayOfYear& other_element) const { 

        DayofYearSet result(*this); /* Calling copy constructor */
        int size_set = size(); /* Getting size of set */
        bool flag = false;
   
        /* Going through the set */ 
        for(auto j=0; j<size_set; j++) {
        
            /* Comparing elements one by one */
            if((my_set_elements[j].getDayNum()) == other_element.getDayNum()) {
                if((my_set_elements[j].getMonthNum()) == other_element.getMonthNum()) {
                    result.remove(other_element);
                    flag = true;
                    break;
                }
            }
        }

        /* Handling the case in which there is no such element in the set */
        if(flag == false) {
            cout << endl; 
            other_element.printElement();
            cout << " is not in the set..." << endl;
        }

        return result; /* Returning result object */
    }


    /* Returning the difference set */
    DayofYearSet DayofYearSet:: operator-(const DayofYearSet& otherSet) const { 
  
        DayofYearSet result(*this);
        int size_other_set = otherSet.size(); /* Getting size of set */
        int size_set = result.size(); /* Getting size of set */
        decltype(size_set) temp_index = 0;
        bool found = false;
        DayOfYear* temp = new DayOfYear[size_set]; /* Dynamically allocating memory for temp array */


        /* Going through the two sets */
        for(auto i=0; i<size_set; i++) {

            found = false;
            for(auto j=0; j<size_other_set; j++) {

                /* Comparing elements kept in the sets one by one */
                if(my_set_elements[i].getDayNum() == otherSet.my_set_elements[j].getDayNum()) {
                    if(my_set_elements[i].getMonthNum() == otherSet.my_set_elements[j].getMonthNum()){
                        found = true;
                        break;
                    
                    }
                }  
            }

            /* Adding the element to temp array since the element is absent in other set */
            if(found == false) {
                temp[temp_index] = my_set_elements[i];
                temp_index++;
            }

        }

        /* Indicating how many different sets in the union set (like (A n B)) */
        result.num_of_sets_in_it = otherSet.num_of_sets_in_it + num_of_sets_in_it ;
        string result_name;

        /* Deciding the name of union set according to how many sets in it */
        if(result.num_of_sets_in_it%2 == 0 || (result.num_of_sets_in_it>=3)) {
            result_name = "(" + set_name + " - " + otherSet.set_name + ")";
        }

        else result_name = set_name + " - " + otherSet.set_name ;


        /* Constructing the set kept in DayofYearSet object */
        result.reconstruct_array(temp_index,temp,result_name);

        return result; /* Returning result object */

    }


    /* Returning the intersection set */
    DayofYearSet DayofYearSet:: operator^(const DayofYearSet& other_set) const {

        int size_set = size(); /* Getting size of set */
        int size_set_other = other_set.size(); /* Getting size of set */
        decltype(size_set) index_temp = 0;
    
        DayOfYear *temp = new DayOfYear[size_set]; /* Dynamically allocating memory for temp array */
        DayofYearSet result(*this);  /* Calling copy constructor */

        /* Going through the two sets */
        for(auto i=0; i<size_set; i++) {
            for(auto j=0; j<size_set_other; j++) {

                /* Comparing elements kept in the sets one by one */
                if(my_set_elements[i].getDayNum() == other_set.my_set_elements[j].getDayNum()) {
                    if(my_set_elements[i].getMonthNum() == other_set.my_set_elements[j].getMonthNum()){
                        temp[index_temp] = my_set_elements[i];
                        index_temp++;
                    
                    }
                }  
            
            }
        }

        /* Indicating how many different sets in the union set (like (A n B)) */
        result.num_of_sets_in_it = other_set.num_of_sets_in_it + num_of_sets_in_it ;
        string result_name;

        /* Deciding the name of union set according to how many sets in it */
        if(result.num_of_sets_in_it%2 == 0 || (result.num_of_sets_in_it>=3)) {
            result_name = "(" + set_name + " n " + other_set.set_name + ")";
        }

        else result_name = set_name + " n " + other_set.set_name ;


        /* Constructing the set kept in DayofYearSet object */
        result.reconstruct_array(index_temp,temp,result_name);

        return result; /* Returning result object */

    }


    /* Returning the complement set */
    DayofYearSet DayofYearSet:: operator!() const{ 

        DayOfYear *temp = new DayOfYear[366]; /* Dynamically allocating memory for temp array */
        DayofYearSet result(*this); /* Calling copy constructor */
        bool flag = false;
        int i,j,k, all_days;
        decltype(i) index_temp = 0;   
        int set_size = size(); /* Getting size of set */


        /* Going through all months in a year */
        for(i=1; i<13; i++) {

            if((i == 4) || (i == 6) || (i == 9) || (i == 11)) all_days = 30;
            else if(i == 2) all_days = 29;
            else all_days = 31;
        
            /* Going through all days in a year */
            for(j=1; j<=all_days; j++) {

                flag = true;

                /* Going through the set */
                for(k=0; k<set_size; k++) {

                    /* Checking whether the particular date is in the set already or not */
                    if((my_set_elements[k].getDayNum()) == j) {
                        if((my_set_elements[k].getMonthNum()) == i) {
                            flag = false;
                            break;
                        }
                    }
                }

                /* Particular date is added to temp array since it is absent in the set */
                if(flag == true) {
                    temp[index_temp] = DayOfYear(j,i);
                    index_temp++;
                } 
            }
        }

        /* Constructing the set kept in DayofYearSet object */
        result.reconstruct_array(index_temp,temp,"!" + set_name);
    
        return result; /* Returning result object */
   
    }


    /* Returning the element at given position */
    DayofYearSet:: DayOfYear DayofYearSet:: operator[](const int pos)const {

        /* Handling the case in which the desired position is out of scope */
        if((pos >= (size())) || (pos<0)) {
            cout << endl << pos << ". index is out of scope!" << endl;
            cout << "First element of the set is being returned instead..." << endl;
            return my_set_elements[0];
        }

        /* Returning the desired element */
        return my_set_elements[pos];
    }


    /* Removing an element from the set */
    void DayofYearSet:: remove(const DayOfYear& element)  { 

        bool operation_success = false;
        int size_of_set = size(); /* Getting size of set */
        decltype(size_of_set) i;
    
        /* Going through the set */
        for(i=0; i<size_of_set; i++) {

            /* Comparing elements one by one */
            if(my_set_elements[i].getDayNum() == element.getDayNum()) {
                if(my_set_elements[i].getMonthNum() == element.getMonthNum()){
                    operation_success = true; 
                    break;
                }
            }
        } 

        /* Handling the case in which the date is absent in the set */
        if(operation_success == false) {
            cout << endl;
            element.printElement();  /* Printing the element */
            cout << " is not in the set..." << endl;
            return;
        }

   
        DayOfYear *temp = new DayOfYear[size_of_set-1];  /* Dynamically allocating memory for temp array */
        int index_temp = 0;

        /* Going through the set */
        for(auto j=0; j<size_of_set; j++) {

            /* Assigning set elements to temp array except the one which is not desired in the set (removing) */
            if(j != i){
                temp[index_temp] = my_set_elements[j];
                index_temp++;
            }
        }

        /* Constructing the set kept in DayofYearSet object */
        reconstruct_array(size_of_set-1,temp,(*this).set_name);

    }


    /* Deciding whether output of the program will be written to the text file or not */
    bool DayofYearSet:: DayOfYear:: WriteTextFile() {

        std::ifstream read_file;
        read_file.open("results.txt");  /* Opening text file */

        /* Handling the case in which the file is not opened */
        if(!read_file) {
            cout << endl << "File could not be opened..." << endl;
            cout << "Terminating the program..." << endl;
            exit(0); 
        }

    
        string line ;
        int index=0;
        bool empty = true;
        getline(read_file, line);
 
        /* Checking whether the file is empty or not */    
        while(line[index] != '\0') {
            if(line[index] != '\n' && line[index] != '\t' && line[index] != ' ') {
                empty = false;
                break;
            }
            index++;
        }

        /* Handling the case in which file is empty */
        if(empty == true) {

            int choice;
            bool flag = false;

            /* Asking the user how they want to handle the case */
            cout << "The file is empty." << endl;
            cout << "   1. Write results to the file as the execution is going on. (Do not expect a word-for-word text file output like you will see on terminal.)" << endl;
            cout << "   2. Do not do anything about text file. (It is recommended to use when the user himself uses ./a.out >> results.txt command on terminal.)" << endl;

            /* Validating the user input */
            while(flag == false) {
                cout << "Enter 1 or 2: ";
                cin >> choice;

                if((cin.get() != '\n') || (cin.fail() == 1)) {
                    cin.clear();
                    cin.ignore(max_int_val,'\n');
                    cout << "Unvalid input" << endl;  
                    continue;
                }

                else if(choice != 1 && choice != 2) {
                    cout << "Unvalid input" << endl;  
                    continue;
                }

                else flag = true;
            }

            /* Handling the case in which the first option is chosen */
            if(choice == 1) {
                read_file.close(); /* Closing text file */
                return true;
            }

            /* Handling the case in which the second option is chosen */
            else if(choice == 2) {
                read_file.close(); /* Closing text file */
                return false;
            }

        }

        /* Handling the case in which file is not empty */
        else {

            int choice;
            bool flag = false;

            /* Asking the user how they want to handle the case */
            cout << "The results were written to the text file before." << endl;
            cout << "   1. Delete the results and write again as the execution is going on. (Do not expect a word-for-word text file output like you will see on terminal.)" << endl;
            cout << "   2. Do not do anything about text file. (It is recommended to use when the user himself uses ./a.out >> results.txt command on terminal.)" << endl;

            /* Validating the user input */
            while(flag == false) {
                cout << "Enter 1 or 2: ";
                cin >> choice;

                if((cin.get() != '\n') || (cin.fail() == 1)) {
                    cin.clear();
                    cin.ignore(max_int_val,'\n');
                    cout << "Unvalid input" << endl;  
                    continue;
                }

                else if(choice != 1 && choice != 2) {
                    cout << "Unvalid input" << endl;  
                    continue;
                }

                else flag = true;
            }

            /* Handling the case in which the first option is chosen */
            if(choice == 1) {
                read_file.close(); /* Closing text file */
                return true;
            }

            /* Handling the case in which the second option is chosen */
            else if(choice == 2) {
                read_file.close(); /* Closing text file */
                return false;
            }
        }
    
  
        return false;
    
    }

}

