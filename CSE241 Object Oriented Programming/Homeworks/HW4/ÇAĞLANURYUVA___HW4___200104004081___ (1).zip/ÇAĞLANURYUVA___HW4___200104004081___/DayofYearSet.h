#ifndef DAYOFYEARSET_H
#define DAYOFYEARSET_H

#include <iostream>
#include <list>
#include <fstream>

using std::cout;
using std::cin;
using std::endl;
using std::string;

namespace SetOperation {

    class DayofYearSet {
        public:
            class DayOfYear {
                public:
                    DayOfYear(int day = 1, int month = 1); /* Initializing the desired date which will be kept in DayOfYear object */
                    DayOfYear(const string get_input); /* Initializing the date with the input which will be get from the user */
                    inline int getDayNum() const {return day_;} /* Returning day value */
                    inline int getMonthNum() const {return month_;} /* Returning month value */
                    static bool WriteTextFile(); /* Deciding whether output of the program will be written to the text file or not */
                    static string GetMonthName(const int &month); /* Returning month name according to month value */
                    bool ValidateDate(const int month, const int day) const; /* Checking whether the date is valid or not */
                    void printElement() const;  /* Printing DayOfYear object's private day_ and month_ variable */
               
                private:
                    int month_; /* Keeping month value */
                    int day_; /* Keeping day value */
                    static int max_int_val; /* Keeping max integer value */
            };

            DayofYearSet(); /* Creating a set (DayofYearSet object) whose size is 1 (being capable of carrying 1 DayOfYear object) but is empty */
            DayofYearSet(const DayofYearSet& otherDay); /* Copying a DayofYearSet object to another DayofYearSet object such that they have the same contents */
            DayofYearSet(const std::list<DayOfYear> &my_elements); /* Creating a set (DayofYearSet object) using list elements */
            inline void deallocate() {delete[] my_set_elements; my_set_elements = nullptr;} /* Deallocating my_set_elements array which is dynamically allocated */
            friend std::ostream& operator<<(std::ostream& os, const DayofYearSet& DaySet); /* Printing DayofYearSet details */
            friend bool operator==(const DayofYearSet& DaySet1, const DayofYearSet& DaySet2); /* Comparing DayofYearSet objects and sets kept in them */
            friend bool operator!=(const DayofYearSet& DaySet1, const DayofYearSet& DaySet2); /* Comparing DayofYearSet objects and sets kept in them */
            DayofYearSet operator+(const DayOfYear& other_element); /* Adding the new element to the set */
            DayofYearSet operator+(const DayofYearSet& otherSet) const; /* Returning the union set */
            DayofYearSet operator-(const DayOfYear& other_element) const; /* Subtracting the element from the set */
            DayofYearSet operator-(const DayofYearSet& otherSet) const; /* Returning the difference set */
            DayofYearSet operator^(const DayofYearSet& other_set) const; /* Returning the intersection set */
            DayofYearSet operator!()const;  /* Returning the complement set */
            DayOfYear operator[](const int pos) const; /* Returning the element at given position */
            void remove(const DayOfYear& element); /* Removing an element from the set */
            inline int size() const {return num_of_elements;} /* Returning size of set */
            template <typename T> static T byValue(T parameter) {return parameter;} /* Returning copy of parameter */
            void get_set_name();  /* Getting set name from the user */
            void reconstruct_array(int newSize, DayOfYear* temp, string name_of_set) ; /* Constructing the set kept in DayofYearSet object */
        
      

        private:
            DayOfYear* my_set_elements = nullptr; /* Keeping set elements */
            string set_name; /* Keeping set name */
            int num_of_elements; /* Keeping size of set */
            int num_of_sets_in_it; /* Indicating how many different sets in it (like (A n B))*/
            
    };

}




#endif
