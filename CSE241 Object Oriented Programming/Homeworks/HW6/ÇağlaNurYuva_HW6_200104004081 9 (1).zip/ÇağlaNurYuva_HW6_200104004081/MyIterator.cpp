#include "PFArray.hpp"



/* Moving one iterator from another using move constructor */
template <typename T>
PFArray<T>::MyIterator:: MyIterator(MyIterator&& other) noexcept {
    if(this != &other) (*this) = std::move(other);  /* Calling move assignment operator */
}


/* Copying one iterator to another using copy assignment operator */
template <typename T>
typename PFArray<T>::MyIterator& PFArray<T>::MyIterator::operator=(const MyIterator& iterator) {

    /* Copying */	
    this->root = iterator.root;
    this->currentNode = iterator.currentNode;
    return *this; /* Returning iterator */
}
       

/* Moving one iterator from another using move assignment operator */
template <typename T>
typename PFArray<T>::MyIterator& PFArray<T>::MyIterator::operator=(MyIterator&& other) noexcept {
     
    if(this != &other) {

        currentNode = nullptr;
        currentNode = std::move(other.currentNode); 
        other.currentNode.reset();  /* Deleting move source */
        this->root = std::move(other.root);
        other.root.reset();  /* Deleting move source */
    }
    return *this; /* Returning iterator */
}
       

/* Incrementing iterator by one */
template <typename T>
typename PFArray<T>::MyIterator& PFArray<T>::MyIterator::operator++() { 
    
    if (currentNode) currentNode = currentNode->next;
    return *this; /* Returning iterator */

}
       

/* Incrementing iterator by one */
template <typename T>
typename PFArray<T>::MyIterator PFArray<T>::MyIterator::operator++(int) { 
    MyIterator iterator = *this;
    currentNode = currentNode->next;
    return iterator; /* Returning iterator */

}
       

/* Decrementing iterator by one */
template <typename T>
typename PFArray<T>::MyIterator& PFArray<T>::MyIterator::operator--() {
    
    std::shared_ptr<Node> previous = nullptr;
    std::shared_ptr<Node> start = root;

    /* Finding previous element */       
    while(start != nullptr){
        if(start->next == currentNode){
            previous = start;
            currentNode = previous;
            return *this;
        }

        start = start->next;
    }


    /* Handling array boundary error by throwing error */
    try {
        if(1) throw ("DECREMENTING IS NOT POSSIBLE DUE TO ARRAY BOUNDARIES");
    }
    
    catch(const char* message) {
        std::cerr << "Throwing Error: "<< message <<  endl;  
    }         
    return *this;  /* Returning iterator */

}


/* Decrementing iterator by one */ 
template <typename T>
typename PFArray<T>::MyIterator PFArray<T>::MyIterator::operator--(int) { 

    std::shared_ptr<Node> previous = nullptr;
    std::shared_ptr<Node> start = root;
    MyIterator iterator(*this);

    /* Finding previous element */          
    while(start != nullptr){
        if(start->next == currentNode){
            previous = start;
            currentNode = previous;
            return iterator;
        }
        start = start->next;
    }


    /* Handling array boundary error by throwing error */
    try {
        if(1) throw ("DECREMENTING IS NOT POSSIBLE DUE TO ARRAY BOUNDARIES");
    }
    
    catch(const char* message) {
        std::cerr << "Throwing Error: "<< message <<  endl;  
    }        

    return iterator; /* Returning iterator */

}


/* Comparing iterators */
template <typename T>
bool PFArray<T>::MyIterator::operator>( MyIterator& other) const { 
  
    if(other == (*this)) return 0;
    MyIterator start(root);

    /* Going through array to check which operator is encountered sooner */       
    while(start.currentNode != nullptr) {
        if(start == other) return 1;
        if(start == (*this)) return 0;
        ++start;
    } 
           
    return 0;
}


/* Comparing iterators */
template <typename T>
bool PFArray<T>::MyIterator::operator<( MyIterator& other) const { 
 
    if(other == (*this)) return 0;  
    MyIterator start(root);  

    /* Going through array to check which operator is encountered sooner */ 
    while(start.currentNode != nullptr) {
        if(start == other) return 0;
        if(start == (*this)) return 1;
        ++start;
    } 
           
    return 0;
        
}


/* Subtracting iterators from each other */
template <typename T>
int PFArray<T>::MyIterator::operator-(const MyIterator& other) { 
    
    if(other == (*this)) return 0;
           
    int difference = 0;
    MyIterator smaller(root);
    MyIterator greater(root);
           

    /* Deciding which iterator is on greater location than other */   
    if(other > (*this)) {
        greater = other;
        smaller = (*this);
    }
           
    else if(other < (*this)) {
        greater = (*this);
        smaller = other;
    }
           
    while(smaller != greater) {
        ++smaller;
        ++difference;  /* Calculating result */
    }
           
    if(smaller == other) difference *= (-1);
    return difference;  /* Returning result */
           
}


/* Incrementing iterator by desired times */
template <typename T>
typename PFArray<T>::MyIterator PFArray<T>::MyIterator::operator+(const int allsteps) {
    MyIterator it = *this;
    
    /* Throwing error to handle the case in which negative step number was entered */
    try {
       	if(allsteps < 0) throw ("NEGATIVE INCREMENTATION IS NOT POSSIBLE");
    }
    
    catch(const char* message) {
        std::cerr << "Throwing Error: "<< message <<  endl; 
        return it; 
    }       

    for (int i = 0; i < allsteps; ++i) ++it; /* Incrementing iterator by one */
    return it; /* Returning iterator */
}


/* Decrementing iterator by desired times */
template <typename T>
typename PFArray<T>:: MyIterator PFArray<T>::MyIterator::operator-(const int allsteps) { 

    MyIterator it(*this);
    MyIterator temp;
    
     /* Throwing error to handle the case in which negative step number was entered */
    try {
       	if(allsteps < 0) throw ("NEGATIVE DECREMENTATION IS NOT POSSIBLE");
    }
    
    catch(const char* message) {
        std::cerr << "Throwing Error: "<< message <<  endl; 
        return it; 
    }       

    for (int i = 0; i < allsteps; ++i) {
        temp = it;
        --it; /* Decrementing iterator by one */

        /* Handling array boundary error by throwing error */
        try {
            if(temp == it) throw ("DECREMENTING ITERATOR IS NOT POSSIBLE DUE TO ARRAY BOUNDARIES");
        }
    
        catch(const char* message) {
            std::cerr << "Throwing Error: "<< message <<  endl; 
            return it; 
        }    
       
    }
    return it; /* Returning iterator */
}


/* Accessing element pointed by iterator */
template <typename T>
T& PFArray<T>::MyIterator::operator[](const int index) const {  

    MyIterator iterator(root);
    MyIterator temp;
   
     /* Throwing error to handle the case in which negative index was entered */
    try {
       	if(index < 0) throw ("NEGATIVE INDEX IS NOT POSSIBLE DUE TO ARRAY BOUNDARIES");
    }
    
    catch(const char* message) {
        std::cerr << "Throwing Error: "<< message <<  endl; 
        return ***this; 
    }       
     

    /* Incrementing iterator by desired times */
    for (auto i = 0; i < index; ++i) {
        temp = iterator;
        ++iterator;  /* Incrementing iterator by one */

        /* Handling array boundary error by throwing error */
        try {
            if(temp == iterator) throw ("ACCESSING ELEMENT IS NOT POSSIBLE DUE TO ARRAY BOUNDARIES");
        }
    
        catch(const char* message) {
            std::cerr << "Throwing Error: "<< message <<  endl; 
            return **iterator; 
        }       
        
    };

    return **iterator;  /* Returning iterator */
}


/* Incrementing iterator by desired times */
template <typename T>
typename PFArray<T>::MyIterator& PFArray<T>::MyIterator::operator+=(const int allsteps) {

    /* Throwing error to handle the case in which negative step number was entered */
    try {
       	if(allsteps < 0) throw ("NEGATIVE INCREMENTATION IS NOT POSSIBLE");
    }
    
    catch(const char* message) {
        std::cerr << "Throwing Error: "<< message <<  endl; 
        return *this; 
    }      
    
    
    
    for (auto i = 0; i < allsteps; ++i) ++(*this);
    return *this;  /* Returning iterator */
}


/* Decrementing iterator by desired times */
template <typename T>
typename PFArray<T>::MyIterator& PFArray<T>::MyIterator::operator-=(const int allsteps) {
    MyIterator temp;
    
    /* Throwing error to handle the case in which negative step number was entered */
    try {
       	if(allsteps < 0) throw ("NEGATIVE DECREMENTATION IS NOT POSSIBLE");
    }
    
    catch(const char* message) {
        std::cerr << "Throwing Error: "<< message <<  endl; 
        return *this; 
    }      

    /* Decrementing iterator by desired times */
    for (auto i = 0; i < allsteps; ++i) {
        temp = (*this);
        --(*this); /* Decrementing iterator by one */

        /* Handling array boundary error by throwing error */
        try {
            if(temp == (*this)) throw ("DECREMENTING ITERATOR IS NOT POSSIBLE DUE TO ARRAY BOUNDARIES");
        }

        catch(const char* message) {
            std::cerr << "Throwing Error: "<< message <<  endl;  
            return *this;
        }  
    }
    return *this;  /* Returning iterator */
}
        



/* Comparing results */
template <typename T>
bool PFArray<T>::MyIterator::operator>=( MyIterator& other) const {
    if(other == (*this)) return 1;
    MyIterator start(root);

    /* Going through array to check which operator is encountered sooner */       
    while(start.currentNode != nullptr) {
        if(start == other) return 1;
        if(start == (*this)) return 0;
        ++start;
    } 
           
    return 0;
}


/* Comparing results */
template <typename T>
bool PFArray<T>::MyIterator::operator<=( MyIterator& other) const {
    if(other == (*this)) return 1;  
    MyIterator start(root);  

    /* Going through array to check which operator is encountered sooner */ 
    while(start.currentNode != nullptr) {
        if(start == other) return 0;
        if(start == (*this)) return 1;
        ++start;
    } 
           
    return 0;
}






