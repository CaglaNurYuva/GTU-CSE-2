
#include "PFArray.hpp"
#include "PFArray.cpp"



int main() {

    /* Testing code */
    cout << endl << "Testing code using Testing() function..." << endl;
    cout << endl << "---------------------------------------------------------------" << endl;
    PFArray<int> test;  /* Calling Testing function to test code */
    test.Testing();
    return 0;
}





