#ifndef PFARRAY_HPP
#define PFARRAY_HPP


/* Including libraries */
#include <iostream>
#include <memory>
#include <algorithm>
#include <iterator>

using std::cin;
using std::cout;
using std::endl;
using std::shared_ptr;


namespace MyPFArray {
	
    
template <typename T>
    class PFArray {
   
        struct Node; /* Forward declaration of Node struct */
   
        public:
       
            class MyIterator;  /* Forward declaration of MyIterator class */
      
            PFArray() : size(0) ,head_(nullptr) ,tail_(nullptr)   { /* Intentionally empty */ } /* PFArray constructor */
            ~PFArray() { /* Intentionally empty */ }  /* PFArray destructor */
            PFArray(PFArray<T>& other) { (*this) = other; } /* Copying one array to another using copy constructor */
            PFArray(PFArray<T>&& other) noexcept;  /* Moving one array from another using move constructor */
            PFArray<T>& operator=(PFArray<T>&& otherArray) noexcept; /* Moving one array from another using move assignment operator */
            PFArray<T>& operator=(const PFArray<T>& otherArray);  /* Copying one array to another using copy assignment operator */
            void Testing(); /* Testing code */
            MyIterator begin() const { return MyIterator(head_); }  /* Return iterator to beginning */
            MyIterator end() const { return (MyIterator(head_) + size + 1); }  /* Return iterator to end */
            const MyIterator cbegin() const { return MyIterator(head_); }  /* Return a constant iterator to beginning */
            const MyIterator cend() const { return (MyIterator(head_) + size + 1); }  /* Return a constant iterator to end */
            bool empty() const { return (size == 0); }  /* Test whether container is empty */
            int ContainerSize() const { return size; }  /* Return container size */
            void clear();   /* Clearing all array content */
            void erase(MyIterator &it_del);  /* Erasing element pointed by the given iterator */
            void PushBack(T&& data);  /* Adding element to array from back */
            void PushFront(T&& data);  /* Adding element to array from front */
            std::shared_ptr<Node> create_node(const T& data) const {return std::make_shared<Node>(Node {std::make_shared<T>(data), nullptr});} /* Creating a shared_ptr that will be used as a node */
            static bool comparing(const shared_ptr<T>& i, const shared_ptr<T>& j) { if((*i > *j) || (*i == *j)) return 0; return 1; } /* Comparing values kept by two shared_ptr */
   
   
            class MyIterator {
       
                public:

                    /* Iterator tags */
                    using iterator_category = std::random_access_iterator_tag;
                    using difference_type = std::ptrdiff_t;
                    using value_type = shared_ptr<T>;
                    using pointer =  shared_ptr<Node>*;
                    using reference =  PFArray<T>::MyIterator&; 


                    MyIterator() noexcept { currentNode = root; } /* MyIterator constructor */
                    MyIterator(const MyIterator& other) : currentNode(other.currentNode) , root(other.root) { /* intentionally empty */ }  /* Copying one iterator to another using copy constructor */
                    MyIterator(MyIterator&& other) noexcept;  /* Moving one iterator from another using move constructor */
                    MyIterator(const std::shared_ptr<Node>& pNode) noexcept :currentNode (pNode) , root(pNode){ /* intentionally empty */  }  /* MyIterator constructor */
                    ~MyIterator() { /* intentionally empty */ }  /* MyIterator destructor */
                    MyIterator& operator=(const MyIterator& iterator) ;  /* Copying one iterator to another using copy assignment operator */
                    MyIterator& operator=(MyIterator&& other) noexcept ; /* Moving one iterator from another using move assignment operator */
                    MyIterator& operator++();   /* Incrementing iterator by one */
                    MyIterator operator++(int); /* Incrementing iterator by one */
                    bool operator!=(const MyIterator& iterator) const { return (currentNode != iterator.currentNode); } /* Comparing iterators */
                    bool operator==(const MyIterator& iterator) const { return (currentNode == iterator.currentNode); } /* Comparing iterators */ 
             
                    shared_ptr<T>& operator*() const { return currentNode->data; } /* Accessing data */
                    MyIterator& operator--();     /* Decrementing iterator by one */
                    MyIterator operator--(int) ;  /* Decrementing iterator by one */
                    T* operator->() const { return currentNode->data.get(); }  /* Accessing pointer pointing to element */
                    bool operator>( MyIterator& other) const;  /* Comparing iterators */
                    bool operator<( MyIterator& other) const;  /* Comparing iterators */
                    int operator-(const MyIterator& other);     /* Subtracting iterators from each other */
                    bool operator>=( MyIterator& other) const;  /* Comparing iterators */
                    bool operator<=( MyIterator& other) const;	/* Comparing iterators */

                    MyIterator operator+(const int allsteps) ;  /* Incrementing iterator by desired times */
                    MyIterator operator-(const int allsteps);   /* Decrementing iterator by desired times */
                    T& operator[](const int index) const;       /* Accessing element pointed by iterator */
                    MyIterator& operator+=(const int allsteps); /* Incrementing iterator by desired times */
                    MyIterator& operator-=(const int allsteps); /* Decrementing iterator by desired times */
                    shared_ptr<Node> GetHead() const {return root;} /* Returning head node */

                    std::shared_ptr<Node> currentNode; /* Keeping current node */

                private:      
                    std::shared_ptr<Node> root = nullptr;
      
            };

   
        private:
   
            int size;  /* Keeping size of array */
            struct Node {   /* Keeping a node */
                std::shared_ptr<T> data;
                std::shared_ptr<Node> next;
            };
 
            std::shared_ptr<Node> head_;  /* Keeping head node */
            std::shared_ptr<Node> tail_;  /* Keeping tail node */

    };



}


using namespace MyPFArray;


#endif



