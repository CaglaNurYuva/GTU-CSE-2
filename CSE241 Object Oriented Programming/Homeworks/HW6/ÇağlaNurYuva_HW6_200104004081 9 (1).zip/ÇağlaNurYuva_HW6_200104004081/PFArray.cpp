#include "PFArray.hpp"
#include "MyIterator.cpp"


/* Moving one array from another using move constructor */
template <typename T>
PFArray<T>::PFArray(PFArray<T>&& other) noexcept {
    if(this != &other) (*this) = std::move(other);
} 


/* Moving one array from another using move assignment operator */
template <typename T>
PFArray<T>& PFArray<T>:: operator=(PFArray<T>&& otherArray) noexcept {
           
    if(this != &otherArray) {

        /* Moving */
        size = std::move(otherArray.size);
        head_ = std::move(otherArray.head_);
        tail_ = std::move(otherArray.tail_);

        /* Deleting move source */
        otherArray.size = 0;
        otherArray.head_ = nullptr;
        otherArray.tail_ = nullptr;

    }
    return *this; /* Returnig iterator */
}


/* Copying one array to another using copy assignment operator */
template <typename T>
PFArray<T>& PFArray<T>:: operator=(const PFArray<T>& otherArray){ 

    /* Copying */
    this->size = otherArray.size  ;
    this->tail_ = otherArray.tail_;
    this->head_ = otherArray.head_;
    return *this;
}
       

/* Clearing all array content */
template <typename T>
void PFArray<T>::clear() {
    auto it1 = this->begin();
    auto it2 = this->end();

    /* Throwing error when array is empty and there is nothing to clear */
    try {
        if(size == 0) throw ("ARRAY IS EMPTY, THERE IS NOTHING TO CLEAR");
    }

    catch(const char* message) {
        std::cerr << "Throwing Error: "<< message <<  endl;  
        return;
    }  

    
    /* Clearing content */
    while (it1 != it2) {
        (**it1) = 0;
        ++it1;
    }

    tail_ = head_;
    size = 0;
}
   

/* Erasing element pointed by the given iterator */
template <typename T>
void PFArray<T>::erase(MyIterator &it_del) {
       
    MyIterator it_head = this->begin();
    MyIterator it_last = this->end();

    /* Handling the case in which head node will be erased */   
    if(it_del == it_head && it_head.currentNode != NULL) {
        ++it_del;
        std::shared_ptr<Node> temp = head_;
        std::shared_ptr<Node> prev = nullptr;
             
        head_ = temp->next;
        temp.reset();
        size--;
           
    }
       

    /* Handling the case in which erased node is not head node */   
    else {
        MyIterator iter = this->begin();
        std::shared_ptr<Node> previous = nullptr;
        bool found = false;

        /* Going through array to find desired element */
        while(iter.currentNode != nullptr) {
            if(iter == it_del) {
                found = true;
                break;
            }
            previous = iter.currentNode;
               (++iter);
        }

        /* Throwing error to handle the case in which there is no such element in array */
        try {
            if(found == false) throw ("ELEMENT POINTED BY GIVEN ITERATOR IS NOT IN ARRAY, NOTHING IS ERASED");
        }

        catch(const char* message) {
            std::cerr << "Throwing Error: "<< message <<  endl;  
            return;
        }     
       

        /* Erasing desired element */
        ++it_del;
        previous->next = iter.currentNode->next;
        iter.currentNode->data.reset();
        iter.currentNode.reset();
        size--;
        
    }        
       
}
   

/* Adding element to array from back */
template <typename T>
void PFArray<T>:: PushBack(T&& data) {

    std::shared_ptr<Node> new_node = create_node(data);

    /* Throwing error to handle the case in which shared_ptr could not be created. */
    try {
        if(!new_node) throw ("ABORTING PROGRAM SINCE SHARED_PTR COULD NOT BE CREATED...");
    }

    catch(const char* message) {
        std::cerr << "Throwing Error: "<< message <<  endl;  
        exit(0);
    }   
    
    /* Adding element to array from back */
    if (!tail_ || size == 0) {
        head_ = new_node;
        tail_ = new_node;
    }

    else {
        tail_->next = new_node;
        tail_ = new_node;
        new_node->next = nullptr;
    }

    size++;
    data = 0;
}


/* Adding element to array from front */
template <typename T>
void PFArray<T>::PushFront(T&& data) {

    std::shared_ptr<Node> new_node = create_node(data);

    /* Throwing error to handle the case in which shared_ptr could not be created. */
    try {
        if(!new_node) throw ("ABORTING PROGRAM SINCE SHARED_PTR COULD NOT BE CREATED...");
    }

    catch(const char* message) {
        std::cerr << "Throwing Error: "<< message <<  endl;  
        exit(0);
    }   
    
    
    /* Adding element to array from front */	
    if (!head_ || size == 0) {
        head_ = new_node;
        tail_ = new_node;
    }

    else {
        new_node->next = head_;
        head_ = new_node;
    }
    size++;
    data = 0;
}

   


/* Testing code */
template <typename T>
void PFArray<T>::Testing() { 

    /* Testing PFArray() constructor */
    cout << "Testing PFArray() constructor..." << endl;
    PFArray<int> array;
    cout << endl << "Results: ";
    for(auto x : array) std::cout << *x << " " ;
    cout << "array is empty" << endl;
    cout << endl << "---------------------------------------------------------------" << endl;

    /* Testing empty() const function */
    cout << endl << "Testing empty() const function 1 times..." << endl;
    cout << endl << "Results: ";
    if(array.empty()) cout << "array is empty" << endl;
    else cout << "array is not empty" << endl;
    cout << endl << "---------------------------------------------------------------" << endl;

    /* Testing PushBack(T&& data) function */
    cout << endl << "Testing PushBack(T&& data) function 5 times..." << endl;
    array.PushBack(5);
    array.PushBack(3);
    array.PushBack(280);
    array.PushBack(0);
    array.PushBack(99);
    cout << endl << "Results: ";
    for(auto x : array) std::cout << *x << " " ;
    cout << endl << "---------------------------------------------------------------" << endl;
    
    /* Testing PushFront(T&& data) function */
    cout << endl << "Testing PushFront(T&& data) function 5 times..." << endl;
    array.PushFront(21);
    array.PushFront(10);
    array.PushFront(1991);
    array.PushFront(8);
    array.PushFront(45);
    cout << endl << "Results: ";
    for(auto x : array) std::cout << *x << " " ;
    cout << endl << "---------------------------------------------------------------" << endl;

    /* Testing range based for loop function */
    cout << endl << "Testing range based for loop 1 times..." << endl;
    cout << endl << "Results: ";
    for(auto x : array) std::cout << *x << " " ;
    cout << endl << "---------------------------------------------------------------" << endl;
   

    /* Testing ContainerSize() const function */
    cout << endl << "Testing ContainerSize() const function 1 times..." << endl;
    cout << endl << "Results: " << endl;
    cout << "array = " ;
    for(auto x : array) std::cout << *x << " " ;
    cout << endl << "Its size = " << array.ContainerSize() << endl;
    cout << endl << "---------------------------------------------------------------" << endl;   

    /* Testing begin() const and end() const functions */
    cout << endl << "Testing begin() const and end() const functions 1 times..." << endl;
    auto it1 = array.begin();
    auto it2 = array.end();
    it2--;
    cout << endl << "Results: " << endl;
    cout << "array = " ;
    for(auto x : array) std::cout << *x << " " ;
    cout << endl << "First element: " << **it1 << endl;
    cout << "Last element: " << **it2 << endl;
    cout << endl << "---------------------------------------------------------------" << endl; 


    /* Testing std::sort function */
    cout << endl << "Testing std::sort function... " << endl;
    cout << "array = " ;
    for(auto x : array) std::cout << *x << " " ;
    std::sort(array.begin(), array.end(),comparing);  
    cout << endl << "Results: " << endl; 
    for(auto x : array) std::cout << *x << " " ;
    cout << endl << "---------------------------------------------------------------" << endl; 

    /* Testing std::for_each function */
    cout << endl << "Testing std::for_each function..." << endl;
    cout << endl << "Results: " << endl; 
    std::for_each(array.begin(), array.end(),  [&] (shared_ptr<int>& i) {std::cout << (*i) << " ";});
    cout << endl << "array has been printed." << endl;
    cout << endl << "---------------------------------------------------------------" << endl; 

    /* Testing std::find_if function */
    cout << endl << "Testing std::find_if function..." << endl;
    auto it = std::find_if(array.begin(), array.end(), [&](shared_ptr<int>& i) { return *i == 1991; }); 
    cout << "array = " ;
    for(auto x : array) std::cout << *x << " " ;
    cout << endl << "Results: " << endl;

    it = std::find_if(array.begin(), array.end(), [&](shared_ptr<int>& i) { return *i == 1991; });  
    if(it != array.end()) {
        cout << "Element " << **it << " has been found at index " << (it - array.begin()) << endl; 
    }
    else cout << "Element 1991 is not in array." << endl;

    it = std::find_if(array.begin(), array.end(), [&](shared_ptr<int>& i) { return *i == 29; });  
    if(it != array.end()) {
        cout << "Element " << **it << " has been found at index " << (it - array.begin()) << endl; 
    }
    else cout << "Element 29 is not in array." << endl;

    it = std::find_if(array.begin(), array.end(), [&](shared_ptr<int>& i) { return *i == 10; });  
    if(it != array.end()) {
        cout << "Element " << **it << " has been found at index " << (it - array.begin()) << endl; 
    }
    else cout << "Element 10 is not in array." << endl;

    it = std::find_if(array.begin(), array.end(), [&](shared_ptr<int>& i) { return *i == 5; });  
    if(it != array.end()) {
        cout << "Element " << **it << " has been found at index " << (it - array.begin()) << endl; 
    }
    else cout << "Element 5 is not in array." << endl;

     it = std::find_if(array.begin(), array.end(), [&](shared_ptr<int>& i) { return *i == 1000; });  
    if(it != array.end()) {
        cout << "Element " << **it << " has been found at index " << (it - array.begin()) << endl; 
    }
    else cout << "Element 1000 is not in array." << endl;
   
    cout << endl << "---------------------------------------------------------------" << endl;  

    /* Testing cbegin() const and cend() const functions */
    cout << endl << "Testing cbegin() const and cend() const functions 1 times..." << endl;
    auto it3 = array.cbegin();
    auto it4 = array.cend();
 
    cout << endl << "Results: " << endl;
    cout << "array = " ;
    for (auto it_b = array.cbegin(); it_b != array.cend(); ++it_b) std::cout << **it_b << " " ;

    cout << endl << "First element: " << **it3 << endl;
    cout << "Last element: " << **(it4 - 1) << endl;
    cout << endl << "---------------------------------------------------------------" << endl; 


    /* Testing comparing(shared_ptr<T>& i, shared_ptr<T>& j) function */
    cout << "Testing comparing(shared_ptr<T>& i, shared_ptr<T>& j) function 2 times..." << endl;
    shared_ptr<int> sp1 = std::make_shared<int>(7);
    shared_ptr<int> sp2 = std::make_shared<int>(1881);
    shared_ptr<int> sp3 = std::make_shared<int>(2022);
    shared_ptr<int> sp4 = std::make_shared<int>(9);

    cout << endl << "Results: " << endl;
    if(comparing(sp1,sp4)) cout << *sp1 << " < " << *sp4 << endl;
    else  cout << *sp1 << " > " << *sp4 << endl;
    if(comparing(sp2,sp3)) cout << *sp2 << " < " << *sp3 << endl;
    else  cout << *sp2 << " > " << *sp3 << endl;
    cout << endl << "---------------------------------------------------------------" << endl; 


    /* Testing void erase(MyIterator &it_del) function */
    cout << "Testing void erase(MyIterator &it_del) function 2 times..." << endl;
    cout << "array = " ;
    for(auto x : array) std::cout << *x << " " ;
    cout << endl << "Results: " << endl;    
   
    cout << endl;
    it = (array.begin() + 2);
    cout << "Element at " << it - array.begin() << ". index is going to be deleted..." << endl;
    array.erase(it);
    cout << "new array = ";
    for(auto x : array) std::cout << *x << " " ;
    cout << endl;
    it = (array.end() - 2);
    cout << "Element at " << it - array.begin() << ". index is going to be deleted..." << endl;
    array.erase(it);
    cout << "new array = ";
    for(auto x : array) std::cout << *x << " " ;
    cout << endl << "---------------------------------------------------------------" << endl; 


    /* Testing MyIterator(const MyIterator& other) constructor */
    cout << "Testing MyIterator(const MyIterator& other) constructor 1 times.." << endl;
    it1 = array.begin();
    PFArray<int>:: MyIterator it5(it1);
    cout << "Element pointed by first iterator = " << **it1 << endl;
    cout << "First iterator is copied to newly created iterator." << endl;

    cout << endl << "Results: " << endl;    
    cout << "array = ";
    for(auto x : array) std::cout << *x << " " ;
    cout << endl << "Element pointed by newly created iterator = " << **it5 << endl;
    
    cout << endl << "---------------------------------------------------------------" << endl;


    /* Testing operator=(const MyIterator& iterator) function */
    cout << "Testing operator=(const MyIterator& iterator) function 1 times..." << endl;
    it1 = array.begin() + 3;
    it5 = it1;
    cout << "Iterator is assigned to another iterator using copy assignment operator." << endl;
    cout << "Element pointed by first iterator = " << **it1 << endl;
    cout << endl << "Results: " << endl;    
    cout << "array = ";
    for(auto x : array) std::cout << *x << " " ;
    cout << endl << "Element pointed by second iterator = " << **it5 << endl;
    
    cout << endl << "---------------------------------------------------------------" << endl;
    

    /* Testing MyIterator(MyIterator&& other) constructor */
    cout << "Testing MyIterator(MyIterator&& other) constructor 1 times..." << endl;
    it5 = array.begin();
    cout << "Element pointed by first iterator = " << **it5 << endl;
    PFArray<int>:: MyIterator it6(std::move(it5));
    cout << "First iterator is moved to newly created iterator." << endl;
    cout << endl << "Results: " << endl; 
    cout << "array = ";
    for(auto x : array) std::cout << *x << " " ;
    cout << endl << "Element pointed by newly created iterator = " << **it6 << endl;
    cout << endl << "---------------------------------------------------------------" << endl;

    /* Testing MyIterator() constructor */
    cout << "Testing MyIterator() constructor 2 times..." << endl;
    PFArray<int>:: MyIterator it7;
    PFArray<int>:: MyIterator it8;
    it7 = array.begin();
    it8 = array.begin();
    cout << endl << "Results: " << endl; 
    cout << "array = ";
    for(auto x : array) std::cout << *x << " " ;
    cout << endl << "Element pointed by newly created iterator = " << **it7 << endl;
    cout << "Element pointed by newly created iterator = " << **it8 << endl;
    cout << endl << "---------------------------------------------------------------" << endl;

    /* Testing operator=(MyIterator&& other) function */
    cout << "Testing operator=(MyIterator&& other) function 1 times..." << endl;
    it6 = array.begin();
    cout << "Element pointed by first iterator = " << **it6 << endl;
    it7 = (std::move(it6));
    cout << "First iterator is moved to newly created iterator." << endl;
    cout << endl << "Results: " << endl; 
    cout << "array = ";
    for(auto x : array) std::cout << *x << " " ;
    cout << endl << "Element pointed by newly created iterator = " << **it7 << endl;
    cout << endl << "---------------------------------------------------------------" << endl;


    /* Testing PFArray(PFArray<T>& other) constructor */
    cout << "Testing PFArray(PFArray<T>& other) constructor 2 times..." << endl;
    cout << "array = ";
    for(auto x : array) std::cout << *x << " " ;
    PFArray<int> array1(array);
    PFArray<int> array2(array);
    cout << endl << "Results: " << endl; 
    cout << "First newly created array = ";
    for(auto x : array1) std::cout << *x << " " ;
    cout << endl << "Second newly created array = ";
    for(auto x : array2) std::cout << *x << " " ;
    cout << endl << "---------------------------------------------------------------" << endl;

    /* Testing operator=(const PFArray<T>& otherArray) function */
    cout << "Testing operator=(const PFArray<T>& otherArray) function 2 times..." << endl;
    cout << endl << "first array = ";
    for(auto x : array1) std::cout << *x << " " ;

    PFArray<int> array3;
    array3.PushBack(7); 
    array3.PushFront(33);
    array3.PushFront(8);
    array3.PushFront(555);
    array3.PushBack(0);
    array3.PushFront(67);
    array3.PushBack(12);
    array3.PushBack(1694);
    array3.PushFront(199);
    cout << endl << "second array = ";
    for(auto x : array3) std::cout << *x << " " ;
    cout << endl;
    cout << "third array = ";
    for(auto x : array2) std::cout << *x << " " ;

    PFArray<int> array4;
    array4.head_ = nullptr; 
    array4.PushBack(1); 
    array4.PushFront(285);
    array4.PushFront(359);
    array4.PushBack(16);
    array4.PushBack(1200);

    cout << endl << "fourth array = ";
    for(auto x : array4) std::cout << *x << " " ;

    array1 = array3;
    array2 = array4;
    cout << endl << endl << "Results: " << endl;
    cout << "Second array has been copied to first array." << endl;
    cout << "first array = ";
    for(auto x : array1) std::cout << *x << " " ;
    cout << endl << "second array = ";
    for(auto x : array3) std::cout << *x << " " ;
    cout << endl << "Fourth array has been copied to third array." << endl;
    cout << endl <<  "third array = ";
    for(auto x : array2) std::cout << *x << " " ;
    cout << endl << "fourth array = ";
    for(auto x : array4) std::cout << *x << " " ;
    cout << endl << "---------------------------------------------------------------" << endl;


    /* Testing operator=(PFArray<T>&& otherArray) function */
    cout << "Testing operator=(PFArray<T>&& otherArray) function 1 times..." << endl;
    cout << endl << "first array = ";
    for(auto x : array1) std::cout << *x << " " ;
    cout << endl << "second array = ";
    for(auto x : array2) std::cout << *x << " " ;
    array1 = std::move(array2);
    cout << endl << "Second array has been moved to first array." << endl;
    cout << "Results:" << endl;
    cout << "first array = ";
    for(auto x : array1) std::cout << *x << " " ;
    cout << endl << "second array = ";
    for(auto x : array2) std::cout << *x << " " ;
    cout << endl << "---------------------------------------------------------------" << endl;

    /* Testing PFArray(PFArray<T>&& other) constructor */
    cout << "Testing PFArray(PFArray<T>&& other) constructor 1 times..." << endl;
    cout << "array = ";
    for(auto x : array4) std::cout << *x << " " ;
    PFArray<int> array5(std::move(array4));
    cout << endl << "array has been moved to another array to construct it." << endl;
    cout << endl << "Results:" << endl;
    cout << "Newly created array: ";
    for(auto x : array5) std::cout << *x << " " ;
    cout << endl << "having been used empty array: ";
    for(auto x : array4) std::cout << *x << " " ;
    cout << endl << "---------------------------------------------------------------" << endl;


    /* Testing MyIterator(const std::shared_ptr<Node>& pNode) constructor */
    cout << "Testing MyIterator(const std::shared_ptr<Node>& pNode) constructor 1 times..." << endl;
    auto sp9 = array.create_node(5);
    PFArray<int>::MyIterator it_a(sp9);
    cout << endl << "Results:" << endl;
    cout << "Adres of first created node: " << sp9.get() << endl;
    cout << "Adres of head node: " << sp9.get() << endl;
    cout << "They are same." << endl;
    cout << endl << "---------------------------------------------------------------" << endl;

    /* Testing GetHead() function */
    cout << "Testing GetHead() function 1 times..." << endl;
    cout << endl << "Results:" << endl;
    cout << "Adres of head node: " << it_a.GetHead() << endl;
    cout << endl << "---------------------------------------------------------------" << endl;

    /* Testing create_node(const T& data) function */
    cout << endl << "Testing create_node(const T& data) function 4 times..." << endl;
    auto sp5 = array.create_node(7);
    auto sp6 = array.create_node(1881);
    auto sp7 = array.create_node(2022);
    auto sp8 = array.create_node(9);
    cout << endl << "Results: " << endl;
    cout << "Adres of first created node = " << sp5 << endl;
    cout << "Adres of second created node = " << sp6 << endl;
    cout << "Adres of third created node = " << sp7 << endl;
    cout << "Adres of fourth created node = " << sp8 << endl;
    cout << endl << "---------------------------------------------------------------" << endl; 

    PFArray<int> array7;
    array7.PushBack(3); 
    array7.PushFront(99);
    array7.PushFront(8);
    array7.PushFront(555);
    array7.PushBack(5); 
    array7.PushFront(1794);
    array7.PushFront(339);
    array7.PushFront(67);
    array7.PushBack(73);
    array7.PushBack(1694);
    array7.PushBack(0);

    PFArray<int> array8;
    array8.PushBack(81);
    array8.PushBack(21);
    array8.PushBack(693);
    array8.PushBack(1);
    array8.PushBack(34);
    array8.PushBack(35);
    array8.PushBack(9);
    array8.PushBack(85);
    array8.PushBack(13);
    array8.PushBack(1221);
    array8.PushBack(2);

    /* Testing range based for loop */
    cout << "Testing range based for loop 2 times..." << endl;
    cout << endl << "Results:" << endl;
    cout << "First array: ";
    for(auto x : array7) std::cout << *x << " " ;
    cout << endl << "Second array: ";
    for(auto x : array8) std::cout << *x << " " ;
    cout << endl << "---------------------------------------------------------------" << endl; 

    /* Testing std::sort function */
    cout << "Testing std::sort function 2 times..." << endl;
    cout << "First array: ";
    for(auto x : array7) std::cout << *x << " " ;
    cout << endl << "Second array: ";
    for(auto x : array8) std::cout << *x << " " ;

    std::sort(array7.begin(), array7.end(),comparing);  
    std::sort(array8.begin(), array8.end(),comparing);  
    cout << endl << endl << "Results:" << endl;
    cout << "First array: ";
    for(auto x : array7) std::cout << *x << " " ;
    cout << endl << "Second array: ";
    for(auto x : array8) std::cout << *x << " " ;
    cout << endl << "---------------------------------------------------------------" << endl; 

    /* Testing std::swap function */
    cout << "Testing std::swap function 1 times..." << endl;
    cout << "First array: ";
    for(auto x : array7) std::cout << *x << " " ;
    cout << endl << "Second array: ";
    for(auto x : array8) std::cout << *x << " " ;
    std::swap(array7,array8);
    cout << endl << endl << "Results:" << endl;
    cout << "First array: ";
    for(auto x : array7) std::cout << *x << " " ;
    cout << endl << "Second array: ";
    for(auto x : array8) std::cout << *x << " " ;
    cout << endl << "---------------------------------------------------------------" << endl; 


    /* Testing std::for_each function */
    cout << endl << "Testing std::for_each function 2 times..." << endl;
    cout << "First array: ";
    for(auto x : array7) std::cout << *x << " " ;
    cout << endl << "Second array: ";
    for(auto x : array8) std::cout << *x << " " ;
    cout << endl << endl << "Results: " ; 
    cout << endl << "Elements of first and second array will be printed while multiplying with 2." << endl;
    cout << "First array: ";
    std::for_each(array7.begin(), array7.end(),  [&] (shared_ptr<int>& i) {std::cout << (*i)*2 << " ";});
    cout << endl << "Second array: ";
    std::for_each(array8.begin(), array8.end(),  [&] (shared_ptr<int>& i) {std::cout << (*i)*2 << " ";});
    cout << endl << "---------------------------------------------------------------" << endl; 


    /* Testing std::copy function */
    cout << "Testing std::copy function 1 times..." << endl;
    cout << endl << "First array: ";
    for(auto x : array7) std::cout << *x << " " ;
    cout << endl << "Second array: ";
    for(auto x : array8) std::cout << *x << " " ;
    std::copy(array7.begin(), array7.end() , array8.begin());
    cout << endl << "First array is copied to second array." << endl;
    cout << endl << "Results:" << endl;
    cout << "First array: ";
    for(auto x : array7) std::cout << *x << " " ;
    cout << endl << "Second array: ";
    for(auto x : array8) std::cout << *x << " " ;
    cout << endl << "---------------------------------------------------------------" << endl; 

    /* Testing std::find_if function */
    cout << "Testing std::find_if function..." << endl; 
    cout << "array: ";
    for(auto x : array7) std::cout << *x << " " ;
     
   
    auto it_c = std::find_if(array7.begin(), array7.end(), [&](shared_ptr<int>& i) { return *i == 81; });  
   
    cout << endl << endl << "Results: " << endl;
    if(it_c != array7.end()) {
        cout << "Element " << **it_c << " has been found at index " << (it_c - array7.begin()) << endl; 
    }
    else cout << "Element 81 is not in array." << endl;

    it_c = std::find_if(array7.begin(), array7.end(), [&](shared_ptr<int>& i) { return *i == 13; });  
    if(it_c != array7.end()) {
        cout << "Element " << **it_c << " has been found at index " << (it_c - array7.begin()) << endl; 
    }
    else cout << "Element 13 is not in array." << endl;

    it_c = std::find_if(array7.begin(), array7.end(), [&](shared_ptr<int>& i) { return *i == 1221; });  
    if(it_c != array7.end()) {
        cout << "Element " << **it_c << " has been found at index " << (it_c - array7.begin()) << endl; 
    }
    else cout << "Element 1221 is not in array." << endl;

    it_c = std::find_if(array7.begin(), array7.end(), [&](shared_ptr<int>& i) { return *i == 2000; });  
    if(it_c != array7.end()) {
        cout << "Element " << **it_c << " has been found at index " << (it_c - array7.begin()) << endl; 
    }
    else cout << "Element 2000 is not in array." << endl;

    it_c = std::find_if(array7.begin(), array7.end(), [&](shared_ptr<int>& i) { return *i == 6; });  
    if(it_c != array7.end()) {
        cout << "Element " << **it_c << " has been found at index " << (it_c - array7.begin()) << endl; 
    }
    else cout << "Element 6 is not in array." << endl;
    cout << endl << "---------------------------------------------------------------" << endl; 

    /* Testing std::find function */
    cout << endl << "Testing std::find function..." << endl;
    shared_ptr<int> a = std::make_shared<int>(12);
    cout << "array: ";
    for(auto x : array7) std::cout << *x << " " ;
    cout << endl << "Results: " << endl;
    it_c = std::find(array7.begin(), array7.end(), a);
    if(it_c != array7.end()) {
        cout << "Element " << *a << " has been found at index " << (it_c - array7.begin()) << endl; 
    }
    else cout << "Element 12 is not in array." << endl;

   
    cout << endl << "---------------------------------------------------------------" << endl; 

    PFArray<T>:: MyIterator it13, it14;
    it13 = array7.begin();
    it14 = array7.begin();

    /* Testing operator++() function */
    cout << "Testing operator++() function 2 times..." << endl;
    cout << endl << "array: ";
    for(auto x : array7) std::cout << *x << " " ;
    cout << endl << "Element pointed by iterator: " << **it13 << endl;
    cout << endl << "Results:" << endl;
    cout << endl << "Calling function 1 times..." << endl;
    ++it13;
    
    cout << "Element pointed by iterator: " << **it13 << endl; 
    cout << "Next element is pointed." << endl;
    cout << endl << "Calling function 1 times..." << endl;
    ++it13;
    cout << "Element pointed by iterator: " << **it13 << endl; 
    cout << "Next element is pointed." << endl;
    cout << endl << "---------------------------------------------------------------" << endl; 


    /* Testing operator++(int) function */
    cout << "Testing operator++(int) function 2 times..." << endl;
    cout << endl << "array: ";
    for(auto x : array7) std::cout << *x << " " ;
    cout << endl << "Element pointed by first iterator: " << **it13 << endl;
    cout << "Element pointed by second iterator: " << **it14 << endl;
    cout << endl << "Results:" << endl;
    cout << endl << "Calling function 1 times for first iterator while assigning first iterator to second iterator..." << endl;
    it14 = it13++;
    cout << "Element pointed by first iterator: " << **it13 << endl; 
    cout << "Element pointed by second iterator: " << **it14 << endl;
    cout << "Second iterator points to old element pointed by first iterator when first iterator points to next element." << endl;
    cout << endl << "Calling function 1 times for first iterator while assigning first iterator to second iterator..." << endl;
    it14 = it13++;
    cout << "Element pointed by first iterator: " << **it13 << endl; 
    cout << "Element pointed by second iterator: " << **it14 << endl;
    cout << "Second iterator points to old element pointed by first iterator when first iterator points to next element." << endl;
    cout << endl << "---------------------------------------------------------------" << endl; 


    /* Testing operator!=(const MyIterator& iterator) function */
    cout << "Testing operator!=(const MyIterator& iterator) function 2 times..." << endl;
    cout << endl << "array: ";
    for(auto x : array7) std::cout << *x << " " ;
    cout << endl << "Results:" << endl;

    cout << endl <<  "Element pointed by first iterator: " << **it13 << endl; 
    cout << "Element pointed by second iterator: " << **it14 << endl;
    if(it13 != it14) cout << "Iterator locations are not equal." << endl;
    else cout << "Iterator locations are equal." << endl;

    ++it14;
    cout << endl <<  "Element pointed by first iterator: " << **it13 << endl; 
    cout << "Element pointed by second iterator: " << **it14 << endl;
    if(it13 != it14) cout << endl << "Iterator locations are not equal." << endl;
    else cout << "Iterator locations are equal." << endl;
    cout << endl << "---------------------------------------------------------------" << endl; 


    /* Testing operator==(const MyIterator& iterator) function */
    cout << "Testing operator==(const MyIterator& iterator) function 2 times..." << endl;
    cout << endl << "array: ";
    for(auto x : array7) std::cout << *x << " " ;
    cout << endl << "Results:" << endl;

    cout << endl <<  "Element pointed by first iterator: " << **it13 << endl; 
    cout << "Element pointed by second iterator: " << **it14 << endl;
    if(it13 == it14) cout << "Iterator locations are equal." << endl;
    else cout << "Iterator locations are not equal." << endl;

    ++it13;
    cout << endl <<  "Element pointed by first iterator: " << **it13 << endl; 
    cout << "Element pointed by second iterator: " << **it14 << endl;
    if(it13 == it14) cout << endl << "Iterator locations are equal." << endl;
    else cout << "Iterator locations are not equal." << endl;
    cout << endl << "---------------------------------------------------------------" << endl; 


    /* Testing operator--() function */
    cout << "Testing operator--() function 2 times..." << endl;
    cout << endl << "array: ";
    for(auto x : array7) std::cout << *x << " " ;
    cout << endl << "Element pointed by iterator: " << **it13 << endl;
    cout << endl << "Results:" << endl;

    cout << endl << "Calling function 1 times..." << endl;
    --it13;
    cout << "Element pointed by iterator: " << **it13 << endl; 
    cout << "Previous element is pointed." << endl;

    cout << endl << "Calling function 1 times..." << endl;
    --it13;
    cout << "Element pointed by iterator: " << **it13 << endl; 
    cout << "Previous element is pointed." << endl;
    cout << endl << "---------------------------------------------------------------" << endl; 


    /* Testing operator--(int) function */
    cout << "Testing operator--(int) function 2 times..." << endl;
    cout << endl << "array: ";
    for(auto x : array7) std::cout << *x << " " ;
    cout << endl << "Element pointed by first iterator: " << **it13 << endl;
    cout << "Element pointed by second iterator: " << **it14 << endl;
    cout << endl << "Results:" << endl;
    cout << endl << "Calling function 1 times for first iterator while assigning first iterator to second iterator..." << endl;
    it14 = it13--;
    cout << "Element pointed by first iterator: " << **it13 << endl; 
    cout << "Element pointed by second iterator: " << **it14 << endl;
    cout << "Second iterator points to old element pointed by first iterator when first iterator points to previous element." << endl;
    cout << endl << "Calling function 1 times for first iterator while assigning first iterator to second iterator..." << endl;
    it14 = it13--;
    cout << "Element pointed by first iterator: " << **it13 << endl; 
    cout << "Element pointed by second iterator: " << **it14 << endl;
    cout << "Second iterator points to old element pointed by first iterator when first iterator points to previous element." << endl;
    cout << endl << "---------------------------------------------------------------" << endl; 


    /* Testing operator>(const MyIterator& other) function */
    cout << "Testing operator>(const MyIterator& other) function 2 times..." << endl;
    cout << endl << "array: ";
    for(auto x : array7) std::cout << *x << " " ;
    cout << endl << "Results:" << endl;

    cout << endl << "Element pointed by first iterator: " << **it13 << endl;
    cout << "Element pointed by second iterator: " << **it14 << endl;
    if(it13 > it14) cout << "First iterator location > Second iterator location " << endl;
    else cout << "First iterator location < Second iterator location" << endl;

    it13 = it13 + 3;
    cout << endl << "Element pointed by first iterator: " << **it13 << endl;
    cout << "Element pointed by second iterator: " << **it14 << endl;
    if(it13 > it14) cout << "First iterator location > Second iterator location" << endl;
    else cout << "First iterator location < Second iterator location " << endl;
    cout << endl << "---------------------------------------------------------------" << endl; 

    PFArray<int>::MyIterator it_den1, it_den2;

    cout << "Testing operator>=( MyIterator& other) function..." << endl;
    cout << endl << "array: ";
    for(auto x : array7) std::cout << *x << " " ;
    cout << endl << "Results:" << endl;
    it_den1 = array7.begin();
    it_den2 = array7.begin();
    it_den2 = it_den2 + 2;
    cout << endl << "Element pointed by first iterator: " << **it_den1 << endl;
    cout << "Element pointed by second iterator: " << **it_den2 << endl;
    if(it_den1 >= it_den2) cout << "First iterator location >= Second iterator location " << endl;
    else cout << "First iterator location < Second iterator location" << endl;

    it_den1 = it_den1 + 3;
    cout << endl << "Element pointed by first iterator: " << **it_den1 << endl;
    cout << "Element pointed by second iterator: " << **it_den2 << endl;
    if(it_den1 >= it_den2) cout << "First iterator location >= Second iterator location" << endl;
    else cout << "First iterator location < Second iterator location " << endl;

    cout << endl << "---------------------------------------------------------------" << endl; 

    cout << "Testing operator<=( MyIterator& other) function..." << endl;
    cout << endl << "array: ";
    for(auto x : array7) std::cout << *x << " " ;
    cout << endl << "Results:" << endl;
    it_den1 = array7.begin();
    cout << endl << "Element pointed by first iterator: " << **it_den1 << endl;
    cout << "Element pointed by second iterator: " << **it_den2 << endl;
    if(it_den1 <= it_den2) cout << "First iterator location <= Second iterator location " << endl;
    else cout << "First iterator location > Second iterator location" << endl;

    it_den1 = it_den1 + 3;
    cout << endl << "Element pointed by first iterator: " << **it_den1 << endl;
    cout << "Element pointed by second iterator: " << **it_den2 << endl;
    if(it_den1 <= it_den2) cout << "First iterator location <= Second iterator location" << endl;
    else cout << "First iterator location > Second iterator location " << endl;



    cout << endl << "---------------------------------------------------------------" << endl; 
    /* Testing operator<(const MyIterator& other) function */
    cout << "Testing operator<(const MyIterator& other) function 2 times..." << endl;
    cout << endl << "array: ";
    for(auto x : array7) std::cout << *x << " " ;
    cout << endl << "Results:" << endl;
    

    cout << endl << "Element pointed by first iterator: " << **it13 << endl;
    cout << "Element pointed by second iterator: " << **it14 << endl;
    if(it13 < it14) cout << "First iterator location < Second iterator location " << endl;
    else cout << "First iterator location > Second iterator location " << endl;

    it13 = it13 - 4;
    cout << endl << "Element pointed by first iterator: " << **it13 << endl;
    cout << "Element pointed by second iterator: " << **it14 << endl;
    if(it13 < it14) cout << "First iterator location < Second iterator location" << endl;
    else cout << "First iterator location > Second iterator location" << endl;
    cout << endl << "---------------------------------------------------------------" << endl;

    /* Testing operator-(const MyIterator& other) function */
    cout << "Testing operator-(const MyIterator& other) function 1 times..." << endl;
    cout << endl << "array: ";
    for(auto x : array7) std::cout << *x << " " ;
    cout << endl << "Element pointed by first iterator: " << **it13 << endl;
    cout << "Element pointed by second iterator: " << **it14 << endl;
    cout << endl << "Results:" << endl;
    cout << "first iterator location - second iterator location = " << it13 - it14 << endl;
    cout << endl << "---------------------------------------------------------------" << endl;

    /* Testing operator+(const int allsteps) function */
    cout << "Testing operator+(const int allsteps) function 2 times..." << endl;
    cout << endl << "array: ";
    for(auto x : array7) std::cout << *x << " " ;
    cout << endl << "Element pointed by iterator: " << **it13 << endl;
    cout << endl << "Results:" << endl;
    cout << "Calling function 1 times to increment iterator by 2..." << endl;
    it13 = it13 + 2;
    cout << "Element pointed by iterator: " << **it13 << endl;
    cout << endl <<  "Calling function 1 times to increment iterator by 1..." << endl;
    it13 = it13 + 1;
    cout << "Element pointed by iterator: " << **it13 << endl;
    cout << endl << "---------------------------------------------------------------" << endl;

    /* Testing operator-(const int allsteps) function */
    cout << "Testing operator-(const int allsteps) function 2 times..." << endl;
    cout << endl << "array: ";
    for(auto x : array7) std::cout << *x << " " ;
    cout << endl << "Element pointed by iterator: " << **it13 << endl;
    cout << endl << "Results:" << endl;
    cout << "Calling function 1 times to decrement iterator by 2..." << endl;
    it13 = it13 - 2;
    cout << "Element pointed by iterator: " << **it13 << endl;
    cout << endl <<  "Calling function 1 times to decrement iterator by 1..." << endl;
    it13 = it13 - 1;
    cout << "Element pointed by iterator: " << **it13 << endl;
    cout << endl << "---------------------------------------------------------------" << endl;


    /* Testing operator+=(const int allsteps) function */
    cout << "Testing operator+=(const int allsteps) function 2 times..." << endl;
    cout << endl << "array: ";
    for(auto x : array7) std::cout << *x << " " ;
    cout << endl << "Element pointed by iterator: " << **it13 << endl;
    cout << endl << "Results:" << endl;
    cout << "Calling function 1 times to increment iterator by 2..." << endl;
    it13 = it13 += 2;
    cout << "Element pointed by iterator: " << **it13 << endl;
    cout << endl <<  "Calling function 1 times to increment iterator by 1..." << endl;
    it13 = it13 += 1;
    cout << "Element pointed by iterator: " << **it13 << endl;
    cout << endl << "---------------------------------------------------------------" << endl;


    /* Testing operator-=(const int allsteps) function */
    cout << "Testing operator-=(const int allsteps) function 2 times..." << endl;
    cout << endl << "array: ";
    for(auto x : array7) std::cout << *x << " " ;
    cout << endl << "Element pointed by iterator: " << **it13 << endl;
    cout << endl << "Results:" << endl;
    cout << "Calling function 1 times to decrement iterator by 2..." << endl;
    it13 = it13 -= 2;
    cout << "Element pointed by iterator: " << **it13 << endl;
    cout << endl <<  "Calling function 1 times to decrement iterator by 1..." << endl;
    it13 = it13 -= 1;
    cout << "Element pointed by iterator: " << **it13 << endl;
    cout << endl << "---------------------------------------------------------------" << endl;


    /* Testing operator[](const int index) function */
    cout << "Testing operator[](const int index) function 3 times..." << endl;
    cout << endl << "array: ";
    for(auto x : array7) std::cout << *x << " " ;
    cout << endl << endl << "Results:" << endl;
    cout << endl << "Element at 2.index: " << it13[2] << endl;
    cout << "Element at 5.index: " << it13[5] << endl;
    cout << "Element at 0.index: " << it13[0] << endl;
    cout << endl << "---------------------------------------------------------------" << endl;


    /* Testing operator*() const function */
    cout << "Testing operator*() const function 3 times..." << endl;
    cout << endl << "array: ";
    for(auto x : array7) std::cout << *x << " " ;
    cout << endl << endl << "Results:" << endl;
    cout << "Accessing element pointed by iterator..." << endl;
    cout << "Element pointed by iterator: " << **it13 << endl;
    it13 += 5;
    cout << endl << "Iterator has been incremented by 5." << endl;
    cout << "Element pointed by iterator: " << **it13 << endl;
    it13 -= 3;
    cout << endl << "Iterator has been decremented by 3." << endl;
    cout << "Element pointed by iterator: " << **it13 << endl;
    cout << endl << "---------------------------------------------------------------" << endl;


    /* Testing operator->() const function */
    cout << "Testing operator->() const function 3 times..." << endl;
    int* x;
    cout << endl << "array: ";
    for(auto x : array7) std::cout << *x << " " ;
    cout << endl << endl << "Results:" << endl;
    cout << "Accessing element pointed by iterator..." << endl;
    x = it13.operator->();
    cout << "Element pointed by iterator: " << *x << endl;
    it13 += 7;
    cout << endl << "Iterator has been incremented by 7." << endl;
    x = it13.operator->();
    cout << "Element pointed by iterator: " << *x << endl;
    it13 -= 4;
    cout << endl << "Iterator has been decremented by 4." << endl;
    x = it13.operator->();
    cout << "Element pointed by iterator: " << *x << endl;
    cout << endl << "---------------------------------------------------------------" << endl;


    /* some the same tests for char as int */

    PFArray<char> arrayx;
    cout << endl << "Note: To avoid test code duplication, all tests will not be repeated for char type." << endl;
    cout << "All tests have already been done for int type." << endl;

    /* Testing PushBack(T&& data) function */
    cout << endl << "Testing PushBack(T&& data) function 5 times..." << endl;
    arrayx.PushBack('c');
    arrayx.PushBack('a');
    arrayx.PushBack('g');
    arrayx.PushBack('l');
    arrayx.PushBack('a');
    cout << endl << "Results: ";
    for(auto x : arrayx) std::cout << *x << " " ;
    cout << endl << "---------------------------------------------------------------" << endl;
    
    /* Testing PushFront(T&& data) function */
    cout << endl << "Testing PushFront(T&& data) function 5 times..." << endl;
    arrayx.PushFront('y');
    arrayx.PushFront('u');
    arrayx.PushFront('v');
    arrayx.PushFront('a');
    arrayx.PushFront('x');
    cout << endl << "Results: ";
    for(auto x : arrayx) std::cout << *x << " " ;
    cout << endl << "---------------------------------------------------------------" << endl;

    /* Testing range based for loop function */
    cout << endl << "Testing range based for loop 1 times..." << endl;
    cout << endl << "Results: ";
    for(auto x : arrayx) std::cout << *x << " " ;
    cout << endl << "---------------------------------------------------------------" << endl;

    /* Testing std::find function */
    cout << endl << "Testing std::find function..." << endl;
    shared_ptr<char> z = std::make_shared<char>('b');
    PFArray<char>::MyIterator it_g;
    cout << "array: ";
    for(auto x : arrayx) std::cout << *x << " " ;
    cout << endl << "Results: " << endl;
    it_g = std::find(arrayx.begin(), arrayx.end(), z);
    if(it_g != arrayx.end()) {
        cout << "Element " << *z << " has been found at index " << (it_g - arrayx.begin()) << endl; 
    }
    else cout << "Element b is not in array." << endl;
   
    cout << endl << "---------------------------------------------------------------" << endl; 
    /* Testing ContainerSize() const function */
    cout << endl << "Testing ContainerSize() const function 1 times..." << endl;
    cout << endl << "Results: " << endl;
    cout << "array = " ;
    for(auto x : arrayx) std::cout << *x << " " ;
    cout << endl << "Its size = " << arrayx.ContainerSize() << endl;
    cout << endl << "---------------------------------------------------------------" << endl;   

    /* Testing begin() const and end() const functions */
    cout << endl << "Testing begin() const and end() const functions 1 times..." << endl;
    auto itd = arrayx.begin();
    auto itv = arrayx.end();
    itv--;
    cout << endl << "Results: " << endl;
    cout << "array = " ;
    for(auto x : arrayx) std::cout << *x << " " ;
    cout << endl <<  "First element: " << **itd << endl;
    cout << "Last element: " << **itv << endl;
   

   
    cout << endl << "---------------------------------------------------------------" << endl; 


    PFArray<char>:: MyIterator itk, itf;
    itk = arrayx.begin();
    itf = arrayx.begin();

    /* Testing operator++() function */
    cout << "Testing operator++() function 2 times..." << endl;
    cout << endl << "array: ";
    for(auto x : arrayx) std::cout << *x << " " ;
    cout << endl << "Element pointed by iterator: " << **itk << endl;
    cout << endl << "Results:" << endl;
    cout << endl << "Calling function 1 times..." << endl;
    ++itk;
    
    cout << "Element pointed by iterator: " << **itk << endl; 
    cout << "Next element is pointed." << endl;
    cout << endl << "Calling function 1 times..." << endl;
    ++itk;
    cout << "Element pointed by iterator: " << **itk << endl; 
    cout << "Next element is pointed." << endl;
    cout << endl << "---------------------------------------------------------------" << endl; 


    /* Testing operator++(int) function */
    cout << "Testing operator++(int) function 2 times..." << endl;
    cout << endl << "array: ";
    for(auto x : arrayx) std::cout << *x << " " ;
    cout << endl << "Element pointed by first iterator: " << **itk << endl;
    cout << "Element pointed by second iterator: " << **itf << endl;
    cout << endl << "Results:" << endl;
    cout << endl << "Calling function 1 times for first iterator while assigning first iterator to second iterator..." << endl;
    itf = itk++;
    cout << "Element pointed by first iterator: " << **itk << endl; 
    cout << "Element pointed by second iterator: " << **itf << endl;
    cout << "Second iterator points to old element pointed by first iterator when first iterator points to next element." << endl;
    cout << endl << "Calling function 1 times for first iterator while assigning first iterator to second iterator..." << endl;
    itf = itk++;
    cout << "Element pointed by first iterator: " << **itk << endl; 
    cout << "Element pointed by second iterator: " << **itf << endl;
    cout << "Second iterator points to old element pointed by first iterator when first iterator points to next element." << endl;
    cout << endl << "---------------------------------------------------------------" << endl; 
    
    
    
    
    /* Testing operator[](const int index) function */
    cout << "Testing operator[](const int index) function 3 times..." << endl;
    cout << endl << "array: ";
    itk = arrayx.begin();
    itf = arrayx.begin();
    for(auto x : arrayx) std::cout << *x << " " ;
    cout << endl << endl << "Results:" << endl;
    cout << endl << "Element at 2.index: " << itk[2] << endl;
    cout << "Element at 5.index: " << itk[5] << endl;
    cout << "Element at 0.index: " << itk[0] << endl;
    cout << endl << "---------------------------------------------------------------" << endl;


    /* Testing operator*() const function */
    cout << "Testing operator*() const function 3 times..." << endl;
    cout << endl << "array: ";
    for(auto x : arrayx) std::cout << *x << " " ;
    cout << endl << endl << "Results:" << endl;
    cout << "Accessing element pointed by iterator..." << endl;
    cout << "Element pointed by iterator: " << **itk << endl;
    itk += 5;
    cout << endl << "Iterator has been incremented by 5." << endl;
    cout << "Element pointed by iterator: " << **itk << endl;
    itk -= 3;
    cout << endl << "Iterator has been decremented by 3." << endl;
    cout << "Element pointed by iterator: " << **itk << endl;
    cout << endl << "---------------------------------------------------------------" << endl;


    /* Testing operator->() const function */
    cout << "Testing operator->() const function 3 times..." << endl;
    char* y;
    cout << endl << "array: ";
    for(auto x : arrayx) std::cout << *x << " " ;
    cout << endl << endl << "Results:" << endl;
    cout << "Accessing element pointed by iterator..." << endl;
    y = itk.operator->();
    cout << "Element pointed by iterator: " << *y << endl;
    itk += 2;
    cout << endl << "Iterator has been incremented by 2." << endl;
    y = itk.operator->();
    cout << "Element pointed by iterator: " << *y << endl;
    itk -= 1;
    cout << endl << "Iterator has been decremented by 1." << endl;
    y = itk.operator->();
    cout << "Element pointed by iterator: " << *y << endl;
    cout << endl << "---------------------------------------------------------------" << endl; 


   

   
   

}
 









